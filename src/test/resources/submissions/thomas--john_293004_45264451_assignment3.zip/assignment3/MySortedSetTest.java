package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest {

	MySortedSet<Integer> set,setEmpty;
	MySortedSet<Long> setLong;
	ArrayList<Long> arrayLong;
	ArrayList<Integer> collectionToAdd,collectionToAddPartial,collectionToAddOld;
	Integer[] arrayTestList,arrayTestListEmpty;

	@Before
	public void setUp() throws Exception {
		
		setLong = new MySortedSet<Long>();
		arrayLong = new ArrayList<Long>();
		for(int i = 100000; i>0; i--){
			arrayLong.add((long)i);
		}
		arrayTestListEmpty = new Integer[0];
		setEmpty = new MySortedSet<Integer>();
		set = new MySortedSet<Integer>();
		set.add(new Integer(3));
		set.add(new Integer(45));
		set.add(new Integer(32));
		set.add(new Integer(-1));
		set.add(new Integer(13));
		set.add(new Integer(0));
		collectionToAdd = new ArrayList<Integer>();
		collectionToAddPartial = new ArrayList<Integer>();
		collectionToAddOld = new ArrayList<Integer>();
		collectionToAdd.add(new Integer(1));
		collectionToAdd.add(new Integer(2));
		collectionToAdd.add(new Integer(4));
		collectionToAdd.add(new Integer(5));
		collectionToAddPartial.add(new Integer(1));
		collectionToAddPartial.add(new Integer(6));
		collectionToAddPartial.add(new Integer(7));
		collectionToAddPartial.add(new Integer(8));
		collectionToAddOld.add(new Integer(1));
		collectionToAddOld.add(new Integer(2));
		collectionToAddOld.add(new Integer(4));
		collectionToAddOld.add(new Integer(5));
		
		arrayTestList = new Integer[]{-1,0,3,13,32,45};
		
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFirst() {
		assertEquals(-1, set.first().intValue());
	}

	@Test
	public void testLast() {
		assertEquals(45, set.last().intValue());
	}

	@Test
	public void testAddNull() {
		assertEquals(false,set.add(null));
	}
	
	@Test
	public void testAddSame() {
		assertEquals(false,set.add(new Integer(45)));
	}

	@Test
	public void testAdd() {
		assertEquals(true,set.add(new Integer(46)));
	}
	
	@Test
	public void testAddAllNew() {
		assertEquals(true, set.addAll(collectionToAdd));
	}
	
	@Test
	public void testAddAllPartialyNew() {
		assertEquals(true,set.addAll(collectionToAddPartial));
	}
	
	@Test
	public void testAddAllOld() {
		set.addAll(collectionToAdd);
		assertEquals(false,set.addAll(collectionToAddOld));
	}
	
	@Test
	public void testAddAllBig() {
		assertEquals(true, setLong.addAll(arrayLong));
		assertEquals(100000,setLong.size());
	}

	@Test
	public void testClear() {
		set.clear();
		assertEquals(0,set.size());
	}

	@Test
	public void testContainsTrue() {
		assertEquals(true,set.contains(new Integer(3)));
	}
	
	@Test
	public void testContainsFalse() {
		assertEquals(false,set.contains(new Integer(2)));
	}

	@Test
	public void testContainsAllTrue() {
		set.addAll(collectionToAdd);
		assertEquals(true,set.containsAll(collectionToAddOld));
	}
	@Test
	public void testContainsAllPartial() {
		set.addAll(collectionToAdd);
		assertEquals(false,set.containsAll(collectionToAddPartial));
	}
	@Test
	public void testContainsAllNone() {
		assertEquals(false,set.containsAll(collectionToAdd));
	}

	@Test
	public void testIsEmptyTrue() {
		set.clear();
		assertEquals(true,set.isEmpty());
	}
	@Test
	public void testIsEmptyFalse() {
		assertEquals(false,set.isEmpty());
	}

	@Test
	public void testRemoveSuccess() {
		assertEquals(true,set.remove(new Integer(3)));
		assertEquals(false,set.contains(new Integer(3)));
	}
	
	@Test
	public void testRemoveFail() {
		assertEquals(false,set.remove(new Integer(1)));
	}
	@Test
	public void testRemoveNull() {
		assertEquals(false,set.remove(null));
	}

	@Test
	public void testRemoveAllTrue() {
		set.addAll(collectionToAdd);
		assertEquals(true, set.removeAll(collectionToAddOld));
		assertEquals(false,set.contains(new Integer(1)));
		assertEquals(false,set.contains(new Integer(2)));
		assertEquals(false,set.contains(new Integer(4)));
		assertEquals(false,set.contains(new Integer(5)));
	}
	
	@Test
	public void testRemoveAllPartial() {
		set.addAll(collectionToAdd);
		assertEquals(true, set.removeAll(collectionToAddPartial));
		assertEquals(false,set.contains(new Integer(1)));
	}
	
	@Test
	public void testRemoveAllFalse() {
		assertEquals(false, set.removeAll(collectionToAddOld));
	}

	@Test
	public void testSize() {
		assertEquals(6,set.size());
	}
	
	@Test
	public void testSizeGrow() {
		set.addAll(collectionToAdd);
		set.addAll(collectionToAddPartial);
		assertEquals(13,set.size());
	}

	@Test
	public void testToArray() {
		assertArrayEquals(arrayTestList,set.toArray());
	}

	@Test
	public void testToArrayEmpty() {
		assertArrayEquals(arrayTestListEmpty,setEmpty.toArray());
	}
}
