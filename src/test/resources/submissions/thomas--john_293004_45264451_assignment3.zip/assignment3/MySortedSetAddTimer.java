package assignment3;
/**
 * This class is used to test the add() method created as a part of MySortedSet
 * in assignment3 for CS 2420
 * 
 * This class was written using the example from Lab1 in CS 2420
 * 
 * @author JohnPaulThomas
 *
 */
public class MySortedSetAddTimer {

	public static void main(String[] args) {
		long startTime, midpointTime, stopTime, midMidpointTime = 0;
		double timeItTakes[] = new double[100];
		Long ThingToAdd = new Long(-1);
		//create sets to search through
		//use worst case (sets in reverse order)
		//ArrayList<Long> arrayLong = new ArrayList<Long>();
		MySortedSet<Long> setLong = new MySortedSet<Long>();
		
		for(int index = 0; index<20; index++){

			int numberItems = 10000;
			
			//add more items to the array after each test
			for(int i = numberItems; i>0; i--){
				//arrayLong.add((long)i);
				setLong.add(new Long(i*(index+1)));
			}



			// First, spin computing stuff until one second has gone by.
			// This allows this thread to stabilize.

			startTime = System.nanoTime();
			while (System.nanoTime() - startTime < 1000000000) { // empty block
			}

			// Now, run the test.
			long timesToLoop = 100000;

			startTime = System.nanoTime();

			for (long i = 0; i < timesToLoop; i++){
				//Do contains method
				setLong.add(ThingToAdd);
				//midMidpointTime = System.nanoTime();
				
				setLong.remove(ThingToAdd);
			}



			midpointTime = System.nanoTime();

			// Run an empty loop to capture the cost of running the loop.
			for (long i = 0; i < timesToLoop; i++) { // empty block
			}

			stopTime = System.nanoTime();

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop.
			// Average it over the number of runs.
			double averageTime = (((midpointTime - startTime)) - (stopTime - midpointTime))
					/ timesToLoop;

			//-(midpointTime-midMidpointTime)*timesToLoop
			
			System.out.println(averageTime);
			timeItTakes[index] = averageTime;

		}
		System.out.println("I'm done! :)");

	}

}
