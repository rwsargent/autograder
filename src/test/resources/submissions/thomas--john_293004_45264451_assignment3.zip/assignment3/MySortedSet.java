package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * An implementation of the provided SortedSet interface
 * 
 * @author JP Thomas (John in Canvas), Ugo Obi
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E>{
	E data[];
	int size;
	Comparator<? super E> mComparator;
	boolean isComparator;
	
	/**
	 * This constructor starts an empty sorted set that uses the natural ordering
	 * of the type to sort.
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(){
		data = (E[]) new Object[10];
		size = 0;
		mComparator = null;
		isComparator = false;
	}
	/**
	 * This constructor starts an empty sorted set that uses the provided comparator to sort
	 * 
	 * @param comparator - The provided comparator used to sort the set
	 */
	public MySortedSet(Comparator<? super E> comparator){
		mComparator = comparator;
		data = (E[]) new Object[10];
		size = 0;
		isComparator = true;
	}

	/**
	 * This function returns the comparator already passed in or null if the
	 * natural ordering is being used
	 * 
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return mComparator;
	}

	/**
	 * This function returns the first element in the set and throws a 
	 * NoSuchElementException if the set is empty
	 * 
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		// If the set is empty
		if(size == 0){
			throw new NoSuchElementException();
		}
		return data[0];
	}

	/**
	 * This function returns the last element in the set and throws a 
	 * NoSuchElementException if the set is empty
	 * 
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		// If the set is empty
		if(size == 0){
			throw new NoSuchElementException();
		}
		return data[size-1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param objectToAdd - element to be added to this set
	 * 
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E objectToAdd) {
		// If the element exists in the set already 
		// or if the element is a null object
		if (objectToAdd == null || this.contains(objectToAdd))
			return false;
		
		// If there are no spaces left
		if (size == data.length) {
			// Make temporary array that is twice the size of the previous array
			E tempData[] = (E[]) new Object[size*2];
			
			// Copy all elements to temporary array
			for (int i = 0; i < size; i++) {
				tempData[i] = data[i];
			}
			
			// Point the data array to the temporary
			data = tempData;
		}
		
		// Add the element to the array
		// Retrieve the location to add the element to the array
		int[] location = binarySearch(objectToAdd);
		// Starting at the end of the array, move every element right
		// one element in the array until the current location is reached
		for(int i = size-1; i>=location[0]; i--){
			data[i+1] =  data[i];
		}
		// set the element at the location found to the element that is being added
		data[location[0]] = objectToAdd;
		// record the increase in set size
		size++;
		return true;
	}
	
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param collectionToAdd
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> collectionToAdd) {
		// initially set the result to false
		boolean result = false;
		
		// for every element in the collection
		for (E item: collectionToAdd) {
			// attempt to add the item
			// if the item is added successfully record that the set 
			// was changed as a result of the call
			if(this.add(item))
				result = true;			
		}
		
		return result;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		// set the size equal to zero
		size = 0;
		// create a new array to hold the set (only 10 long)
		data =  (E[]) new Object[10];
	}

	/**
	 * This function checks to see if the element is contained within the set
	 * 
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object objectToCheck) {
		// Search for the specified object using binary search
		int[] tempCheck = binarySearch((E)objectToCheck);
		// if the object was found
		if(tempCheck[1] == 1)
			return true;
		// otherwise
		return false;
	}

	/**
	 * This function checks to see if all of the elements in the collection are contained
	 * within the set
	 * 
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> collectionToCheck) {
		// initially set the result to true
		boolean result = true;
		
		// Check every element in the collection
		for (Object item: collectionToCheck) {
			// if any element is not contained in the set
			if(!this.contains(item))
				result = false;			
		}

		return result;
	}

	/**
	 * This function checks to see if this set is empty
	 * 
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (size == 0)
			return true;
		//otherwise
		return false;
	}

	/**
	 * This function defines the iterator for this type of set
	 * The user will be able to use this iterator to navigate this set
	 * 
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		Iterator<E> newIterator = new Iterator<E>(){
			// set the iterator location to the beginning of the set
			int iterLocation = -1;
			/**
			 * This function checks to see if the next value in the set exists
			 */
			@Override
			public boolean hasNext() {
				// if the pointer is not at the end of the set
				if(iterLocation<size-1)
					return true;
				// otherwise
				return false;
			}
			
			/**
			 * This function returns the next value in the set to the user and moves the
			 * location of the iterator to the next element
			 * 
			 * @return the next element in the set
			 */
			@Override
			public E next() {
				//move the location of the iterator to the next element
				iterLocation++;
				//return the next element to the user
				return data[iterLocation];
			}
			
			/**
			 * This function removes the element directly behind the location of the iterator
			 * in the set
			 * 
			 */
			@Override
			public void remove() {
				//remove the element behind the current location
				MySortedSet.this.remove(data[iterLocation]);
			}
		};
		
		return newIterator;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param objectToRemove
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element and has been removed
	 * 			otherwise return false
	 */
	@Override
	public boolean remove(Object objectToRemove) {
		//Check to see if the object trying to be removed is null
		if(objectToRemove == null)
			return false;
		
		// search through the set for the object to be removed
		int[] location = binarySearch((E) objectToRemove);
		// if the object was not found
		if(location[1] == 0)
			return false;
		// Starting at the location of the object to be removed
		// move through the set
		for(int i = location[0]; i<size-1; i++){
			//move each element from the next location one position backwards
			//(this will overwrite the element to be removed
			data[i] = data[i+1];
		}
		//record the decrease in set size
		size--;
		// notify the user of a successful removal
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param collectionToRemove
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> collectionToRemove) {
		//initially set the result to false
		Boolean result = false;
		
		//for every element in the collection
		for(Object item:collectionToRemove){
			//attempt to remove the element
			//if the element is removed successfully
			if (remove(item))
				result =  true;

		}
		return result;
	}

	/**
	 * This function returns the size of the set to the user
	 * 
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * This function returns a sorted array containing all of the elements in the set
	 * 
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object[] result = (E[]) new Object[size];
		for(int i = 0; i<size; i++){
			result[i] = data[i];
		}
		return result;
	}
/**
 * This function searches through the set and attempts to find the specified element
 * 
 * @param searchItem - the item that is being searched for
 * 
 * @return - a new array containing the location of the element and an indicator of
 * 				whether or not the element was found
 */
	public int[] binarySearch (E searchItem){
		// Set the mid index point
		int index = (size-1)/2;
		// Set the upper & lower limits
		int upperLimit = size-1;
		int lowerLimit = 0;
		
		// While the lower & upper limits haven't crossed
		while ( lowerLimit <= upperLimit){
			
			// If item is at current index
			if(searchItem.equals(this.data[index])){
				//return the location of the item in the set and an indication that the
				//item was found
				return new int[] {index,1};
			}
			
			// if the set was given a comparator
			if(isComparator){
				//if the current index is less than the search item
				if (mComparator.compare(this.data[index],searchItem)<0){
					//move the lower limit up to the element after the current index
					lowerLimit = index+1;
				} else {
					//move the upper limit down to the element under the current index
					upperLimit = index-1;
				}
			}else if(!isComparator){
				// cast to comparable
				Comparable<E> comparableItem = (Comparable<E>)searchItem;
				//if the search item is larger than the item at the current index
				//(this is the same as if the item at the current index is less than the search item)
				if ((comparableItem.compareTo(this.data[index])>0)){
					//move the lower limit up to the element after the current index
					lowerLimit = index+1;
				} else {
					//move the upper limit down to the element under the current index
					upperLimit = index-1;
				}
			}else{
				//throw some error
			}
			// Reset the mid index
			index = (upperLimit - lowerLimit)/2 + lowerLimit;
			
		}
		// return an indication that the item was not found
		return new int[] {index,0};
		
		
	}
}
