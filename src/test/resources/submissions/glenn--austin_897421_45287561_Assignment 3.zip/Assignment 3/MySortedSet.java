package assignment3;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * 
 * @author Austin Glenn
 * @author Mike McDonald
 *
 * @param <E>
 */

public class MySortedSet<E extends Comparable<? super E>> implements SortedSet<E> {
	
	private int size;
	private E[] sortedList;
	private Comparator<? super E> comparator;
	
	public MySortedSet() {
		size = 0;
		sortedList = (E[])new Object[8];
		comparator = null;
	}
	
	public MySortedSet(Comparator<? super E> comparator) {
		size = 0;
		sortedList = (E[])new Object[8];
		this.comparator = comparator;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException {
		//if size is zero, throw the exception
		if(size == 0)
			throw new NoSuchElementException();
		return sortedList[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if(size == 0)
			throw new NoSuchElementException();
		return sortedList[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) {
		int index;
		if(o == null)
			return false;
		//if empty list just add as first element
		if(size == 0){
			sortedList[0] = o;
			size++;
			return true;
		}
		//if array is full make new array and copy all elements
		if(size == sortedList.length) {
			E[] tempArray = (E[])new Object[size * 2];
			for(index = 0; index < size; index++)
				tempArray[index] = sortedList[index];
			sortedList = tempArray;
		}
		index = binarySearch(o);
		if(sortedList[index].equals(o))
			return false;
		else {
			for(int i = size; i > index; i--)
				sortedList[i] = sortedList[i - 1];
			sortedList[index] = o;
		}
		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
		boolean flag = false;
		for(E item: c)
			if(add(item))
				flag = true;
		return flag;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		sortedList = (E[])new Object[8];
		size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) {
		if(o == null)
			return false;
		for(E item: sortedList)
			if(o.equals(item))
				return true;
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c) {
		Iterator i = c.iterator();
		for(int j = 0; j < c.size(); j++)
			if(!(contains(i.next())))
				return false;
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		if(size == 0)
			return true;
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		return new MySortedSetIterator<E>();
	}
	
	/**
	 * @param the item we are searching for
	 * 
	 * @return return the index of where the object is/should be
	 */
	private int binarySearch(E o) {
		int index = size / 2, low = 0, high = size - 1;
		if(comparator == null) {
			while(low <= high) {
				if(o.compareTo(sortedList[index]) == 0)
					return index;
				else if(o.compareTo(sortedList[index]) < 0) {
					low = index + 1;
					index = (low + high) / 2;
				}
				else {
					high = index - 1;
					index = (low + high) / 2;
				}
			}
		}
		else {
			while(low <= high) {
				if(comparator.compare(sortedList[index], o) == 0)
					return index;
				else if(comparator.compare(sortedList[index], o) < 0) {
					low = index + 1;
					index = (low + high) / 2;
				}
				else {
					high = index - 1;
					index = (low + high) / 2;
				}
			}
		}
		return index;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		int index;
		if(o == null)
			return false;
		if(sortedList.length == 0)
			return false;
		index = binarySearch((E)o);
		if(!(sortedList[index].equals((E)o)))
				return false;
		else
			for(int i = index; i < size-1; i++)
				sortedList[i] = sortedList[i+1];
		size--;
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		boolean wasRemoved = false;
		Iterator i = c.iterator();
		for(int j = 0; j < c.size(); j++){
			if(remove(i.next()) && !wasRemoved)
				wasRemoved = true;
		}
		return wasRemoved;
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		return sortedList;
	}
	
	private class MySortedSetIterator<E extends Comparable<? super E>> implements Iterator{
		
		private int index;
		private MySortedSet<E> list;
		
		MySortedSetIterator() {
			index = -1;
		}

		@Override
		public boolean hasNext() {
			if(index < size)
				return true;
			
			return false;
		}

		@Override
		public Object next() {
			if(++index == size)
				throw new NoSuchElementException("No more elements in set");
			return sortedList[index];
		}

		@Override
		public void remove() {
			if(index == -1)
				throw new IllegalStateException("next has not been called");
			MySortedSet.this.remove(sortedList[index]);
		}
		
	}
	
}

	