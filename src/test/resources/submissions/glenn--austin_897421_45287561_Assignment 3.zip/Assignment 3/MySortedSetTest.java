package assignment3;

import java.util.ArrayList;
import java.util.NoSuchElementException;


/**
 * 
 * @author Austin Glenn
 * @author Mike McDonald
 *
 */
public class MySortedSetTest {

	public static void main(String[] args) {
		
		MySortedSet<String> set1 = new MySortedSet<String>();
		ArrayList<String> collection = new ArrayList<String>();
		
		try {
			set1.first();
		}
		catch (NoSuchElementException e) {}
		
		try {
			set1.last();
		}
		catch (NoSuchElementException e) {}
		
		if(!(set1.isEmpty()))
			System.err.println("TEST FAILED: is empty on empty set");
		
		if(set1.size() != 0)
			System.err.println("TEST FAILED: size = 0");
		
		if(set1.add(null))
			System.err.println("TEST FAILED: add null item");
		if(!(set1.add("one")))
			System.err.println("TEST FAILED: add first item");
		
		collection.add("two");
		collection.add("three");
		collection.add("four");
		collection.add("five");
		collection.add("six");
		collection.add("seven");
		collection.add("eight");
		
		if(!(set1.addAll(collection)))
			System.err.println("TEST FAILED: add collection to array");
		
		if(set1.size() != 8)
			System.err.println("TEST FAILED: size != 8");
		
		if(set1.addAll(collection))
			System.err.println("TEST FAILED: add repeat collection");
		
		if(set1.size() != 8)
			System.err.println("TEST FAILED: size != 8");
		
		if(set1.add("nine"))
			System.err.println("TEST FAILED: add to a full array");
		
		if(!(set1.contains("nine")))
			System.err.println("TEST FAILED: ninth element not added");
		
		if(set1.add("four"))
			System.err.println("TEST FAILED: adding element already in array");
		
		if(!(set1.first().equals("eight")))
			System.err.println("TEST FAILED: first element");
		
		if(!(set1.last().equals("two")))
			System.err.println("TEST FAILED: last element");
		
		if(set1.contains("ten"))
			System.err.println("TEST FAILED: contains for wrong element");
		
		if(!(set1.contains("five")))
			System.err.println("TEST FAILED: contains for correct element");
		
		if(set1.contains(null))
			System.err.println("TEST FAILED: contains null");
		
		if(!(set1.containsAll(collection)))
			System.err.println("TEST FAILED: contains all of correct set");
			
		collection.add("ten");
		
		if(set1.containsAll(collection))
			System.err.println("TEST FAILED: contains all of incorrect set");
		
		if(set1.isEmpty())
			System.err.println("TEST FAILED: is empty on nonempty set");
		
		if(set1.remove(null))
			System.err.println("TEST FAILED: remove null");
		
		if(set1.size() != 8)
			System.err.println("TEST FAILED: size != 8");
		
		if(!(set1.removeAll(collection)))
			System.err.println("TEST FAILED: remove all");
		
		if(set1.size() != 2)
			System.err.println("TEST FAILED: size != 2");
		
		if(set1.removeAll(collection))
			System.err.println("TEST FAILED: remove all repeat");
		
		if(set1.remove("five"))
			System.err.println("TEST FAILED: remove element not in set");
		
		if(!(set1.remove("one")))
			System.err.println("TEST FAILED: remove element in set");
		
		if(set1.size() != 1)
			System.err.println("TEST FAILED: size != 1");
		
		set1.clear();
		
		if(set1.size() != 0)
			System.err.println("TEST FAILED: size != 0");
		
		System.out.println("Tests Complete.");
		
	}

}
