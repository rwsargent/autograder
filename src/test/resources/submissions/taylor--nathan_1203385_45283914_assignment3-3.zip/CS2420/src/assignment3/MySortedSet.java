package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * @author Nathan Taylor & Nathan Wilkinson
 *
 *
 * @param <E> -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E> 
{
	
	private E set[]; // the array/vector that everything revolves around
	private int size;  // number of things in the array
	private Comparator<? super E> comparator;   // Used for comparing elements

	/**
	 * Creates an empty set
	 */
	public MySortedSet()
	{
		set = (E[]) new Object[8];
		size = 0;
		comparator = null;
	}
	/**
	 * Creates an empty set with a passed in comparator
	 * @param _comparator
	 * 						-- the way the user wants elements compared
	 */
	public MySortedSet(Comparator<? super E> _comparator)
	{
		set = (E[]) new Object[8];
		size = 0;
		comparator = _comparator;
	}
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		return set[0];
	}

	@Override
	public E last() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		return set[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		
		if (o == null) // Checks a null element isn't added
			return false;
		if (comparator == null && !(o instanceof Comparable))
			return false;
		
		int location = 0; // This will be where we add the element
		int compared = 0;
		
		if (size >= set.length - 1) // Doubles the array if necessary
		{
			set = Arrays.copyOf(set, set.length * 2);
		}

		if (size == 0) // If there's nothing in the array add it to the first spot
			location = -1;
		else // Otherwise, find the location that the element should go (minus 1)
			location = find(o, size - 1, 0);
		
		if (location == 0) // Boundary case for when location = 0
		{
			if (comparator != null)
				compared = (comparator.compare((E)o, (E)set[0]));
			else
				compared = (((Comparable)o).compareTo((Comparable)set[0]));
			if (compared < 0)
			{
				for (int i = size; i > 0; i--) // Copies the array adding the element to the start
				{
					set[i] = set[i - 1];
				}
				set[0] = (E) o;
			}
			else
			{
				for (int i = size; i > 1; i--) // Copies the array adding the element to index 1
				{
					set[i] = set[i - 1];
				}
				set[1] = (E) o;
			}
		}
		
		else if (location < -1) // The element was already in the set
			return false;
		
		else // Add the element normally and copy everything to the right
		{
			for (int i = size; i > location + 1; i--)
			{
				set[i] = set[i - 1];
			}
			set[location + 1] = (E) o;
		}
		size++;
		return true;
	}
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		Iterator<? extends E> iterateC = c.iterator(); 
		boolean hasAdded = false;				//bool to return
		
		while(iterateC.hasNext())
		{
			if (this.add((E)iterateC.next()))	//adds the value and checks if it has added
				hasAdded = true;
		}
		
		return hasAdded;
	}
	
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		set = (E[]) new Object[8];
		size = 0;
		
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		if (o == null) // Checks a null element isn't added
			return false;
		if (comparator == null && !(o instanceof Comparable))
			return false;
		if (search(o, size - 1, 0) == -1) // Returns false if the object is not found
			return false;
		else
			return true;
	}
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		Iterator<?> iterateC = c.iterator(); 
		boolean isContained = true;				//bool to return
		for(int i=0; i < c.size(); i++)
		{
			if(iterateC.hasNext())
			{
				if (!(this.contains(iterateC.next())))	//adds the value and checks if it has added
					isContained = false;
			}
		}
		return isContained;
	}
	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (size == 0)
			return true;
		else
			return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator iterator() {
		return new IteratorSortedSet();
	}
	
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {

		int location = 0; // This will be where we remove the element

		if (size == 0)
			return false;
		else
			location = search(o, size - 1, 0); // Returns the index of the element to be removed
		if (location < 0) // if not found
			return false;

		for (int i = location + 1; i < size; i++)
		{
			set[i - 1] = set[i];  // moves everything after the element one to the left 
		}
		size--;
		return true;
	}
	
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		Iterator<?> iterateC = c.iterator(); 
		boolean hasRemoved = false;				//bool to return
		
		while(iterateC.hasNext())
		{
			if (this.remove(iterateC.next()))	//adds the value and checks if it has added
				hasRemoved = true;
		}
		return hasRemoved;
	}
	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object[] array = new Object[size];
		for (int i = 0; i < size; i++)
			array[i] = set[i];
		return array;
	}

	/**
	 * Returns the array index of the element which is being searched for and -1 if it wasn't found
	 * @param toFind -- The thing we're looking for
	 * @param upper -- The upper bound of the array
	 * @param lower -- Lower bound of the array
	 * @return -- The index of the thing found or -1 if not found
	 */
	private int search(Object toFind, int upper, int lower)
	{
		int middle = (lower+upper)/2; // Calculates the midpoint
		int compared;
		
		if (comparator != null) // Compares toFind with the middle
			compared = (comparator.compare((E)toFind, (E)set[middle]));
		else
			compared = (((Comparable)toFind).compareTo((Comparable)set[middle]));
		
		if (lower > upper) // Not found
			return -1;
		else if (compared == 0) // Found it at middle
			return middle;
		else if (compared > 0) // It's to the right
			return search(toFind, upper, middle+1);
		else
			return search(toFind, middle -1, lower);
	}
	
	/**
	 * Returns the array index to the left of where the element should go
	 * @param toFind -- The thing we're looking for
	 * @param upper -- The upper bound of the array
	 * @param lower -- Lower bound of the array
	 * @return -- The index to the left of where it should go or -2 if found
	 */
	private int find(Object toFind, int upper, int lower)
	{
		int middle = (lower+upper)/2; // Calculates the midpoint
		int compared;
		
		if (comparator != null) // Compares toFind with the middle
			compared = (comparator.compare((E)toFind, (E)set[middle]));
		else
			compared = (((Comparable)toFind).compareTo((Comparable)set[middle]));
		
		if (compared == 0) // Found it at middle
			return -2;
		else if (upper < lower)  // Not found
			return middle;
		else if (compared > 0) // It's to the right
			return find(toFind, upper, middle + 1);
		else
			return find(toFind, middle - 1, lower);
	}
	/**
	 * This class represents an iterator for MySortedSet
	 */
	private class IteratorSortedSet implements Iterator
	{
		private int position;
		
		/**
		 * Creates an iterator
		 */
		private IteratorSortedSet ()
		{
			position = 0;
		}
		/**
		 * Checks if there is a next thing
		 */
		@Override
		public boolean hasNext() {
			if (position < size)
				return true;
			else
				return false;
		}

		/**
		 * Returns the next thing
		 */
		@Override
		public E next() {
			return set[position++];
		}
		
	}
}
