package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Test;

//import assignment2.LibraryBookGeneric;

/**
 * 
 * @author Nathan Taylor & Nathan Wilkinson
 *
 */
public class MySortedSetTests {

	
	/**
	 *  Creates an empty MySortedSet with the default constructor
	 */
	@Test
	public void testConstructor() {
		try
		{
			MySortedSet<String> mySet = new MySortedSet<String>();
		}
		catch (Exception e)
		{
			fail("Not yet implemented");
		}
	}
	/**
	 *  Creates an empty MySortedSet with the default constructor
	 */
	@Test
	public void testConstructor2() {
		try
		{
			OrderString comparator = new OrderString();
			MySortedSet<String> mySet = new MySortedSet<String>(comparator);
		}
		catch (Exception e)
		{
			fail("Not yet implemented");
		}
	}
	
	/**
	 * Tests the first() method
	 */
	@Test
	public void testFirst ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("Hi");
		assertEquals("Hi", mySet.first());
	}
	
	/**
	 * Tests the first() method with no elements
	 */
	@Test
	public void testFirstNothing ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		try
		{
			mySet.first();
			fail("Didn't throw a NoSuchElementException");
		}
		catch (NoSuchElementException e)
		{
		}
		
	}
	/**
	 * Tests the first() method with no elements after adding/removing
	 */
	@Test
	public void testFirstAddRemove ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		try
		{
			mySet.add("Hi");
			mySet.remove("Hi");
			mySet.first();
			fail("Didn't throw a NoSuchElementException");
		}
		catch (NoSuchElementException e)
		{
		}
	}
	
	/**
	 * Tests the last() method
	 */
	@Test
	public void testLast ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("Hi");
		assertEquals("Hi", mySet.last());
	}
	
	/**
	 * Tests the last() method with no elements
	 */
	@Test
	public void testLastNothing ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		try
		{
			mySet.last();
			fail("Didn't throw a NoSuchElementException");
		}
		catch (NoSuchElementException e)
		{
		}
		
	}
	/**
	 * Tests the last() method with no elements after adding/removing
	 */
	@Test
	public void testLastAddRemove ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		try
		{
			mySet.add("Hi");
			mySet.remove("Hi");
			mySet.last();
			fail("Didn't throw a NoSuchElementException");
		}
		catch (NoSuchElementException e)
		{
		}
	}
	/**
	 *  Tests the add function with expected success
	 */
	@Test
	public void testAdd() {
		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		mySet.add(0);
		mySet.add(2);
		mySet.add(1);
		mySet.add(6);
		mySet.add(3);
		assertEquals(true,  mySet.contains(1));
	}
	
	/**
	 * attempts to add the same value twice with expected failure
	 */
	@Test
	public void testAddFail() 
	{
		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		mySet.add(7);
		assertEquals(false, mySet.add(7));
	}
	/**
	 * attempts to add an identical string, should fail
	 */
	@Test
	public void testAddFail2() 
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("go away");
		mySet.add("Hello");
		mySet.add("please kindly leave");
		assertEquals(false, mySet.add("go away"));
	}
	
	/**
	 * attempts to add an already contained String
	 */
	@Test
	public void testAddFailString() 
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("pool");
		assertEquals(false, mySet.add("pool"));
	}
	/**
	 * attempts to add null to the set
	 */
	@Test
	public void testAddNull() 
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		assertEquals(false, mySet.add(null));
	}
	/**
	 *  Tests the add() when doubling the array lots
	 */
	@Test
	public void testAddBig() {
		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		for (int i = 0; i < 1000; i++)
			mySet.add(i);
		
		assertEquals(true, mySet.contains(515));
	}
	
	/**
	 * Tests the addAll() method
	 */
	@Test
	public void testAddAll ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		ArrayList<String> strings = new ArrayList<String>();
		strings.add("hi");
		strings.add("Hello");
		strings.add("ajsd\"gil");
		strings.add("No you go away");
		strings.add("please kindly leave");
		
		assertEquals(true, mySet.addAll(strings));
		
	}
	/**
	 * Tests the addAll() method when it should fail
	 */
	@Test
	public void testAddAllFail ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>(new OrderString());
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		ArrayList<String> strings = new ArrayList<String>();
		strings.add("hi");
		strings.add("Hello");
		strings.add("go away");
		strings.add("No you go away");
		strings.add("please kindly leave");
		
		assertEquals(false, mySet.addAll(strings));
	}
	@Test
	public void testClearWithFirst ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		
		mySet.clear();
		try
		{
			mySet.first();
			fail("Didn't throw a NoSuchElementException");
		}
		catch (NoSuchElementException e)
		{
		}
		
	}
	@Test
	public void testClearWithLast ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		
		mySet.clear();
		try
		{
			mySet.last();
			fail("Didn't throw a NoSuchElementException");
		}
		catch (NoSuchElementException e)
		{
		}
		
	}
	
	/**
	 * Tests the contains() method
	 */
	@Test
	public void testContains ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		assertEquals(true, mySet.contains("Hello"));		
	}
	/**
	 * Tests the contains() method when false
	 */
	@Test
	public void testContainsFalseLowerBound ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		assertEquals(false, mySet.contains("Harro"));		
	}
	/**
	 * Tests the contains() method when false
	 */
	@Test
	public void testContainsFalseUpperBound ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		assertEquals(false, mySet.contains("z"));		
	}
	/**
	 * Tests the contains() method
	 */
	@Test
	public void testContainsNull ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		assertEquals(false, mySet.contains(null));		
	}
	/**
	 * Tests the addAll() method
	 */
	@Test
	public void testContainsAll ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>(new OrderString());
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		ArrayList<String> strings = new ArrayList<String>();
		strings.add("hi");
		strings.add("Hello");
		strings.add("go away");
		strings.add("No you go away");
		strings.add("please kindly leave");
		assertEquals(true, mySet.containsAll(strings));
	}
	/**
	 * Tests the addAll() method
	 */
	@Test
	public void testContainsAllFail ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>(new OrderString());
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		ArrayList<String> strings = new ArrayList<String>();
		strings.add("hiasdf");
		strings.add("please kindly leave");
		assertEquals(false, mySet.containsAll(strings));
	}
	/**
	 * Tests the isEmpty()
	 */
	@Test
	public void testIsEmpty ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>(new OrderString());
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		assertEquals(false, mySet.isEmpty());
	}
	/**
	 * Tests the isEmpty()
	 */
	@Test
	public void testIsEmptyPass ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>(new OrderString());
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		mySet.clear();
		assertEquals(true, mySet.isEmpty());
	}
	/**
	 * Tests the iterator's next()
	 */
	@Test
	public void testIteratorNext ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		Iterator iterator = mySet.iterator();
		assertEquals("Hello", iterator.next());		
	}
	/**
	 * Tests the iterator next() when null
	 */
	@Test
	public void testIteratorNextNull ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		mySet.add("hia");
		mySet.add("No you go awaya");
		mySet.add("Helloa");
		Iterator iterator = mySet.iterator();
		for (int i = 0; i < 8; i++)
			iterator.next();
		assertEquals(null, iterator.next());		
	}
	/**
	 * Tests the iterator's hasNext() when true
	 */
	@Test
	public void testIteratorHasNextTrue ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		Iterator iterator = mySet.iterator();
		for (int i = 0; i < 3; i++)
			iterator.next();
		assertEquals(true, iterator.hasNext());		
	}
	/**
	 * Tests the iterator's hasNext() when false
	 */
	@Test
	public void testIteratorHasNextFalse ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		Iterator iterator = mySet.iterator();
		for (int i = 0; i < 5; i++)
			iterator.next();
		assertEquals(false, iterator.hasNext());		
	}
	
	/**
	 * Tests the remove
	 */
	@Test
	public void testRemove ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		
		assertEquals(true, mySet.remove("Hello"));		
	}	
	/**
	 * Tests the remove
	 */
	@Test
	public void testRemove2 ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		
		assertEquals(true, mySet.remove("please kindly leave"));		
	}
	/**
	 * Tests the remove
	 */
	@Test
	public void testRemoveFirst ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		
		assertEquals(true, mySet.remove("hi"));		
	}
	/**
	 * Tests the remove
	 */
	@Test
	public void testRemoveFail ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		
		assertEquals(false, mySet.remove("por que"));		
	}
	/**
	 * Tests the remove
	 */
	@Test
	public void testRemoveWithContains ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		
		assertEquals(true, mySet.contains("Hello"));
		mySet.remove("Hello");
		assertEquals(false, mySet.contains("Hello"));		
	}
	/**
	 * Tests the removeAll() When it should fail
	 */
	@Test
	public void testsRemoveAllFail ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("z");
		mySet.add("ahawef asdg");
		mySet.add("QETYY");
		mySet.add("pioahdg");
		mySet.add("AAAAAA");
		ArrayList<String> strings = new ArrayList<String>();
		strings.add("hi");
		strings.add("Hello");
		strings.add("go away");
		strings.add("No you go away");
		strings.add("please kindly leave");
		
		assertEquals(false, mySet.removeAll(strings));
	}
	/**
	 * Tests the removeAll()
	 */	
	@Test
	public void testRemoveAll ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		ArrayList<String> strings = new ArrayList<String>();
		strings.add("hi");
		strings.add("Hello");
		strings.add("go away");
		strings.add("No you go away");
		strings.add("please kindly leave");
		
		assertEquals(true, mySet.removeAll(strings));
	}
	/**
	 * Tests the size() method
	 */	
	@Test
	public void testSize ()
	{
		MySortedSet<String> mySet = new MySortedSet<String>();
		mySet.add("hi");
		mySet.add("No you go away");
		mySet.add("Hello");
		mySet.add("go away");
		mySet.add("please kindly leave");
		
		assertEquals(5, mySet.size());
	}
	/**
	 * Tests the size() method
	 */	
	@Test
	public void testToArray ()
	{
		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		mySet.add(0);
		mySet.add(2);
		mySet.add(1);
		mySet.add(6);
		mySet.add(3);
		Object[] a = {0,1,2,3,6};
		assertArrayEquals(a,  mySet.toArray());
	}
	
//	/**
//	 *  Tests the search() method
//	 */
//	@Test
//	public void testSearch() {
//		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
//		for (int i = 0; i < 6; i++)
//			mySet.add(i);
//		
//		assertEquals(0, mySet.search(0, 4, 0));
//	}
//	
//	/**
//	 *  Tests the search method for something not found
//	 */
//	@Test
//	public void testSearchDoesNotExist() {
//		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
//		mySet.add(2);
//		mySet.add(7);
//		mySet.add(5);
//		mySet.add(12);
//		mySet.add(3998986);
//		
//		assertEquals(-1, mySet.search(8, 4, 0));
//	}
	
	 /**
	   * Comparator that defines ordering Strings for testing purposes
	   */
	  private class OrderString implements Comparator<String> {
	    /**
	     * Returns a negative value if lhs is smaller than rhs. Returns a positive
	     * value if lhs is larger than rhs. Returns 0 if lhs and rhs are equal.
	     */
	    public int compare(String lhs, String rhs) {
	      return lhs.compareTo(rhs);
	    }
	  }
}
