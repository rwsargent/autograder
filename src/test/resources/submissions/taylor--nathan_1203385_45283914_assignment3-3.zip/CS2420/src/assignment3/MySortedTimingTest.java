package assignment3;

public class MySortedTimingTest {

	  public static void main(String[] args) 
	  {
		MySortedSet<Long> mySortedSet = new MySortedSet<Long>();
	    long startTime, midpointTime, stopTime, removeTime;
	    long numAdd = 5958L;
	    long numElements = 10_000;

	    for (long i = 0; i < numElements; i++)
	    	mySortedSet.add(i);
	    
	    // Removes the element numAdd so that it can be added
	    //mySortedSet.remove(numAdd);
	    // First, spin computing stuff until one second has gone by.
	    // This allows this thread to stabilize.

	    startTime = System.nanoTime();
	    while (System.nanoTime() - startTime < 1_000_000_000) { // empty block
	    }

	    // Now, run the test.

	    long timesToLoop = 1_000_00;

	    startTime = System.nanoTime();

	    
	    for (long i = 0; i < timesToLoop; i++)
	    {
	    	mySortedSet.remove(numAdd);
	    	//startTime = startTime + (startTime - removeTime);
	    	mySortedSet.add(numAdd);
	    	//removeTime = System.nanoTime();
	    	
	    }
	      

	    midpointTime = System.nanoTime();

	    // Run an empty loop to capture the cost of running the loop.

	    for (long i = 0; i < numElements; i++) { // empty block
	    	mySortedSet.add(i+numElements);
	    }

	    stopTime = System.nanoTime();

	    // Compute the time, subtract the cost of running the loop
	    // from the cost of running the loop and computing square roots.
	    // Average it over the number of runs.

	    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
	        / timesToLoop;

	    System.out.println("It takes exactly " + averageTime
	        + " nanoseconds to run once with size"
	        + " 100,000");
	  }
	}