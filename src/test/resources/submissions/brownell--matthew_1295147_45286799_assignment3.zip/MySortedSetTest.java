package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit test cases used to determine the effectiveness of MySortedSet.
 * 
 * @author Rachel Brough & Matthew Brownell
 *
 */
public class MySortedSetTest {
	
	// Declaring objects needed in tests.
	MySortedSet<String> set1;
	MySortedSet<Integer>set2, set3;
	int[] testArray;
	ArrayList<Integer> list1, list2;
	Collection<Integer> list3, list4;
	Iterator<Integer> iter;

	// Sets up the needed lists, arrays, and variables for tests.
	// Resets between tests.
	@Before
	public void setUp() throws Exception {
		set1 = new MySortedSet<String>();
		set2 = new MySortedSet<Integer>();
		set3 = new MySortedSet<Integer>();
		set2.add(5); // 1
		set2.add(6); // 2
		set2.add(2); // 0
		set2.add(7); // 3
		set2.add(10); // 4
		iter = set2.iterator();
		testArray = new int[]{2, 5, 6, 7, 10};
		list1 = new ArrayList<Integer>(Arrays.asList(5, 7, 6, 2, 10));
		list2 = new ArrayList<Integer>(Arrays.asList(5, 7, 4, 2, 10));
		list3 = new ArrayList<Integer>(Arrays.asList(5, 7, 6, 2, 10));
		list4 = new ArrayList<Integer>(Arrays.asList(5, 7, 6, 2, 10,
													12, 14, 13, 15, 16,
													18, 23, 26, 27, 24,
													28, 30, 32, 34, 36,
													4, 9));
	}

	// Resets all initialized variables in setup.
	@After
	public void tearDown() throws Exception {
	}
	
	/**
	 * Tests the toArray method from MySortedSet by grabbing elements
	 * from an already setup set.
	 */
	@Test
	public void toArrayTest() {
		assertEquals(2, set2.toArray()[0]);
		assertEquals(5, set2.toArray()[1]);
		assertEquals(6, set2.toArray()[2]);
		assertEquals(7, set2.toArray()[3]);
		assertEquals(10, set2.toArray()[4]);
	}
	
	/**
	 * Tests the size method from MySortedSet by grabbing the size
	 * from two previously setup tests.
	 */
	@Test
	public void sizeTest() {
		assertEquals(0,set1.size());
		assertEquals(5,set2.size());		
	}
	
	/**
	 * Tests the last method from the MySortedSet by grabbing the
	 * last value from the given set.
	 * 
	 * If set is empty throws exception.
	 */
	@Test
	public void lastTest() {
		assertEquals((int) 10, (int) set2.last());
		try {
			set1.last();
			fail();
		}
		catch (Exception e) {
			
		}
	}
	
	/**
	 * Tests the first method from the MySortedSet by grabbing the
	 * first value from the given set.
	 * 
	 * If set is empty throws exception.
	 */
	@Test
	public void firstTest() {
		assertEquals((int) 2, (int) set2.first());
		try {
			set1.first();
			fail();
		}
		catch (Exception e) {
			
		}
	}

	/**
	 * Tests the add method from MySortedSet by adding elements to empty set
	 * then testing if elements are present and in sorted order.
	 */
	@Test
	public void addTest() {
		set1.add("Hey");
		assertEquals("Hey", set1.toArray()[0]);
		set1.add("Boo");
		assertEquals("Boo", set1.toArray()[0]);
		set1.add("Basketball");
		assertEquals("Basketball", set1.toArray()[0]);
		set1.add("Hockey");
		assertEquals("Hockey", set1.toArray()[3]);

	}
	
	/**
	 * Tests the remove method from MySortedSet by removing elements from a full set
	 * then testing if elements are still present of not as well as new size of set.
	 */
	@Test
	public void removeTest() {
		set2.remove(10);
		set2.remove(5);
		set2.remove(6);
		set2.remove(2);
		assertEquals(1, set2.size());
		assertEquals(7, set2.toArray()[0]);
	}
	
	/**
	 * Tests the contains method from MySortedSet by testing if full set contains
	 * various objects.
	 */
	@Test
	public void containsTest() {
		assertEquals(true, set2.contains(10));
		assertEquals(true, set2.contains(5));
		assertEquals(true, set2.contains(6));
		assertEquals(true, set2.contains(2));
		assertEquals(true, set2.contains(7));
		assertEquals(false, set1.contains("2"));
	}
	
	/**
	 * Tests the clear method from MySortedSet by testing an already empty set
	 * and a full set then testing if they are empty.
	 */
	@Test
	public void clearTest() {
		set1.clear();
		assertEquals(true, set1.isEmpty());
		set2.clear();
		assertEquals(true, set2.isEmpty());
	}
	
	/**
	 * Tests the contains all method from MySortedSet by testing a full set
	 * against a list that contains all values in set2, and one that contains one mistake.
	 */
	@Test
	public void containsAllTest() {
		assertEquals(true, set2.containsAll(list1));
		assertEquals(false, set2.containsAll(list2));
	}
	
	/**
	 * Tests the add all method from SortedSet by testing an empty set
	 * and adding list to it, then checking if elements are in sorted order.
	 */
	@Test
	public void addAllTest() {
		set3.addAll(list3);
		assertEquals(2, set3.toArray()[0]);
		assertEquals(5, set3.toArray()[1]);
		assertEquals(6, set3.toArray()[2]);
		assertEquals(7, set3.toArray()[3]);
		assertEquals(10, set3.toArray()[4]);
	}
	
	/**
	 * Tests the remove all method from SortedSet by testing a full set
	 * and removing a list from it. 
	 * 
	 * Checks to return the set is empty after.
	 */
	@Test
	public void removeAllTest() {
		set1.removeAll(list3);
		assertEquals(true, set1.isEmpty());
	}
	
	/**
	 * Tests the growth of the set by adding a list with more than 20
	 * objects in it.
	 */
	@Test
	public void addAllGrowTest() {
		set3.addAll(list4);
		assertEquals(22, set3.size());
	}
	
	/**
	 * Tests the iterator method from MySortedSet by iterating through the set
	 * then testing whether the hasNext detects the end of the set.
	 */
	@Test
	public void iteratorNextHasNextTest() {
		assertEquals(true, iter.hasNext());
		assertEquals(2, (int) iter.next());
		assertEquals(true, iter.hasNext());
		assertEquals(5, (int) iter.next());
		assertEquals(true, iter.hasNext());
		assertEquals(6, (int) iter.next());
		assertEquals(true, iter.hasNext());
		assertEquals(7, (int) iter.next());
		assertEquals(true, iter.hasNext());
		assertEquals(10, (int) iter.next());
		assertEquals(false, iter.hasNext());
	}
	
	/**
	 * Tests the iterator remove method to see if it removes the previous 
	 * object then keeps the iterator on the right index.
	 */
	@Test
	public void iteratorRemoveTest() {
		assertEquals(true, iter.hasNext());
		iter.next();
		iter.remove();
		assertEquals(5 , set2.toArray()[0]);
		assertEquals(4, set2.size());
	}

}
