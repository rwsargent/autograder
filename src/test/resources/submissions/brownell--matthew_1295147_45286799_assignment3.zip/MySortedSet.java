package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
/**
 * A collection class made from a standard array with methods used to
 * add elements, remove elements, find elements, and iterate through.
 * 
 * The class uses a binary search algorithm to accomplish the above
 * stated methods.
 * 
 * All elements are added and removed in a sorted order.
 * 
 * @author Rachel Brough & Matthew Brownell
 *
 * @param <E>
 *    -- Given object to be used throughout the program.
 */
public class MySortedSet<E> implements SortedSet<E> {
	
	// Needed variables used throughout the class. 
	private E[] setArray;
	private int position;
	private int size = 20;
	private boolean add;
	private Comparator<? super E> comparator;
	
	/**
	 * A constructor for MySortedSet, utilizes a Comparable interface.
	 */
	public MySortedSet() {
		setup();
	}
	
	/**
	 * A constructor for MySortedSet, utilizes a Comparator.
	 * @param objectComparator
	 */
	public MySortedSet(Comparator<? super E> objectComparator) {
		setup();
		comparator = objectComparator;
	}
	
	/**
	 * Used to setup the above two constructors by declaring various variables.
	 */
	@SuppressWarnings("unchecked")
	private void setup() {
		position = 0;
		setArray = (E[]) new Object[size];
		add = false;

	}
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}
	
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (!isEmpty())
			return setArray[0];
		throw new NoSuchElementException();
	}
	
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (!isEmpty())
			return setArray[size()-1];
		throw new NoSuchElementException();
	}
	
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		if (o==null)
			return false;
		else if (isEmpty()) {
			setArray[0]=o;
			position++;
			return true;
		}
		else if (!contains(o)) {
			if (size()==setArray.length)
				doubleArray();
			add=true;
			int index = binarySearch(setArray, 0, size()-1, o);
			for (int i = size()-1; index <= i; i--) 
				setArray[i+1] = setArray[i];
			setArray[index] = o;
			position++;
			add=false;
			return true;
		}
		return false;
	}
	
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean state = false;;
		
		for (E i: c) {
			if(!contains(i)) {
				add(i);
				state = true;
			}
		}
		return state;
	}
	
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		setup();
	}
	
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		if (o == null || (size()-1)==0)
			return false;
		int index = binarySearch(setArray, 0, size()-1, (E) o);
		
		if (index==-1)
			return false;
		else if (setArray[index].equals(o))
			return true;
		return false;
	}
	
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for(Object i: c) {
			if(!contains(i)) {
				return false;
			}
		}
		return true;
	}
	
	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (setArray[0]==null) 
			return true;
		return false;
	}
	
	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new subIterator();
	}
	
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		if (o==null)
			return false;
		if ((!isEmpty())&&(contains(o))) {
			int index = binarySearch(setArray, 0, size()-1, (E) o);
			if (o.equals(setArray[index])){
				E[] temp = (E[]) new Object[setArray.length];
				for (int i = index; i < size()-1; i++){
					setArray[i] = setArray[i+1];
				}
				position--;
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean state = false;
		
		for (Object i: c) {
			if (contains(i)) {
				remove(i);
				state = true;
			}	
		}
		return state;
	}
	
	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return position;
	}
	
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		return setArray;
	}
	
	/**
	 * The helper class for the Iterator method used in MySortedSet
	 * Uses the same methods as other Iterator classes.
	 *
	 */
	private class subIterator implements Iterator<E> {
		private int counter = 0;
		
		public subIterator() {
		}
		
		/**
		 * Finds whether the iterator has a next value to iterate to.
		 * 
		 * @return
		 *    -- Returns true if the SortedSet has a next object.
		 *    -- Returns false if the SortedSet does not have a next object.
		 */
		public boolean hasNext() {
			if (counter<size())
				return true;
			return false;
		}
		
		/**
		 * Finds the next object in the set, and moves there.
		 * 
		 * @return 
		 *    -- Returns the next object in the given set.
		 */
		public E next() {
			if (this.hasNext())
				return setArray[counter++];
			else {
				throw new NoSuchElementException();
			}
		}
		
		/**
		 * Removes the previous object in the given set.
		 */
		public void remove() {
			if (counter!=0)
				MySortedSet.this.remove(setArray[--counter]);
		}
	}
	
	/**
	 * Recursive binary search algorithm used to find where to add or remove objects in
	 * as well as if the set contains the object.
	 * 
	 * @param set
	 *    -- The array used by MySortedSet
	 * @param min
	 *    -- The minimum bound to search through
	 * @param max
	 *    -- The maximum bound to search through
	 * @param desired
	 *    -- The object to find
	 * @return
	 *    -- Returns either the index of the found object or where to insert object
	 */
	private int binarySearch(E[] set, int min, int max, E desired) {
		int middle = (min+max)/2;
		
		if (min>max) {
			if (add==true) {
				if (middle==min)
					return middle;
				return middle+1;
			}
			return -1;
		}
		if(compareTo(desired, set[middle])<0) {
			return binarySearch(set, min, middle-1, desired);
		}
		else if (compareTo(desired, set[middle])>0) {
			return binarySearch(set, middle+1, max, desired);
		}
		else{ 
			if (add==true)
				return -1;
			return middle;
		}
	}
	
	/**
	 * Utilized by the binary search method to compare two objects together
	 * 
	 * @param comparer1
	 *    -- First object being compared
	 * @param comparer2
	 *    -- Second object being compared
	 * @return
	 *    -- Returns -1 if comparer1 is before, 0 if they are equal, or 1 if it is after
	 */
	private int compareTo(E comparer1, E comparer2) {
		if (comparator==null) {
			Comparable<E> comparable = (Comparable<E>) comparer1;
			return comparable.compareTo(comparer2);
		}
		return comparator.compare(comparer1, comparer2);
	}
	
	/**
	 * Doubles the size of the array used by MySortedSet if it runs out of room.
	 */
	private void doubleArray() {
		size = size*2;
		@SuppressWarnings("unchecked")
		E[] temporary = (E[]) new Object[size];
		for(int i = 0; i < size();i++) {
			temporary[i] = setArray[i];
		}
		setArray = temporary;
	}
}
