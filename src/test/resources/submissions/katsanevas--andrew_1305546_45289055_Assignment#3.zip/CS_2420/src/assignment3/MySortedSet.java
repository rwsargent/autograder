package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This class is a generic array list that does not contain duplicates and is
 * guaranteed to always be sorted.
 * 
 * As a note to graders, the method contracts for the overided functions already
 * have contracts automatically in eclipse from the interface/parent it is from.
 * 
 * @author Dyllon Gagnier
 * @author Andrew Katsanevas
 * 
 * @param <E>
 *            The type of the elements this list will contain.
 */
public class MySortedSet<E> implements SortedSet<E>, Iterable {

	// Comparator function
	private Comparator compareFunc;
	// The length of the collection
	private int length;
	// The internal array
	private E[] storage;
	// Keeps track of if a set is comparable or uses a comparator
	private boolean isComparable;

	/**
	 * This method may be used to initialize MySortedSet when E is Comparable
	 * and the default sorting of E is desired.
	 */
	public MySortedSet() {
		compareFunc = null;
		isComparable = true;
		storage = (E[]) (new Object[1]);
		length = 0;
	}

	/**
	 * This method is to be called when a custom Comparator is desired to be
	 * used for sorting.
	 * 
	 * @param compareFunc
	 *            an instance of the desired Comparator.
	 */
	public MySortedSet(Comparator<? super E> compareFunc) {
		this.compareFunc = compareFunc;
		isComparable = false;
		storage = (E[]) (new Object[1]);
		length = 0;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return compareFunc;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		// If the set is empty, throw exception
		if (storage[0] == null)
			throw new NoSuchElementException();
		return storage[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		// If the set is empty, throw exception
		if (storage[0] == null)
			throw new NoSuchElementException();
		return storage[length - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		try {
			// Return false if the element is already contained in the set
			if (this.contains(o)) {
				return false;
			}
			// Add the element and sort the set. Return true
			else {
				// If no element has been added yet, make this the first element
				if (storage[0] == null) {
					storage[0] = o;
					length = 1;
					return true;
				}
				int ind = this.binarySearch(o);
				// Grow the list if necessary
				if (this.length == storage.length) {
					this.growList();
				}
				// Shift values to add a new one
				for (int i = length - 1; i >= ind; i--) {
					storage[i + 1] = storage[i];
				}
				storage[ind] = o;
				length++;
				return true;
			}
		}
		// Return false if the given value is null
		catch (NullPointerException e) {
			return false;
		}
	}

	/**
	 * This method doubles the size of the underlying storage array.
	 */
	private void growList() {
		E[] tempStorage = (E[]) (new Object[length * 2]);
		for (int i = 0; i < length; i++) {
			tempStorage[i] = storage[i];
		}
		storage = tempStorage;
	}

	/**
	 * This method returns the position in storage that the object should be if
	 * it was inserted or where it actually is if it is already in storage.
	 * 
	 * @param o
	 *            the object to search for.
	 * @return the index/potential index of the object.
	 */
	private int binarySearch(E o) {
		int low = 0;
		int high = length - 1;
		int mid;
		int comp;
		// If empty, return index 0
		if (length == 0)
			return 0;
		while (true) {
			// When finished, return either where it is or will be
			if (high <= low) {
				comp = compare(o, storage[low]);
				if (comp > 0)
					return low + 1;
				else
					return low;
			}

			// Set new mid, find which half to look at
			mid = (high + low) / 2;
			comp = compare(o, storage[mid]);

			// If found at mid, return. Otherwise set new high and low
			if (comp == 0)
				return mid;
			else if (comp > 0)
				low = mid + 1;
			else if (comp < 0)
				high = mid - 1;
		}
	}

	/**
	 * This method compares two objects of type E such that it is identical to a
	 * comparator regardless of whether E is supposed to use the natural
	 * ordering of a Comparable type or if it is supposed to use a given
	 * comparator.
	 * 
	 * @param o1
	 *            the left object
	 * @param o2
	 *            the right object
	 * @return an int that will be > 0 if o1 > o2, < 0 if o1 < o2, and 0 if o1
	 *         == o2.
	 */
	private int compare(E o1, E o2) {
		// Check if it is comparable or comparator before returning a value
		if (this.isComparable)
			return ((Comparable) o1).compareTo(o2);
		else
			return compareFunc.compare(o1, o2);
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean isChanged = false;
		// Add each element from the given collection
		for (E ele : c) {
			if (this.add(ele)) {
				// Set to true if the set was changed
				isChanged = true;
			}
		}
		return isChanged;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		storage = (E[]) (new Object[1]);
		length = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		try {
			int low = 0;
			int high = length - 1;
			int mid;
			int comp;
			// If empty, return false
			if (length == 0)
				return false;
			while (true) {
				if (high <= low) {
					// When finished, return if final element is what we are
					// looking for
					if (compare((E) o, storage[low]) == 0)
						return true;
					else
						return false;
				}

				// Set new mid, find which half to look at
				mid = (high + low) / 2;
				comp = compare((E) o, storage[mid]);

				// If found at mid, return true. Else set new high and low
				if (comp == 0)
					return true;
				else if (comp > 0)
					low = mid + 1;
				else if (comp < 0)
					high = mid - 1;
			}
		}
		// If given an incompatible class, throw exception
		catch (ClassCastException e) {
			return false;
		}
		// If given a null object, throw exception
		catch (NullPointerException e) {
			return false;
		}
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for (Object ele : c)
			if (!this.contains(ele))
				return false;
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		return this.length == 0;
	}

	/**
	 * This class is the Iterator for MySortedSet.
	 * 
	 * @author Dyllon Gagnier
	 * @author Andrew Katsanevas
	 * 
	 * @param <T>
	 *            the type of MySortedSet.
	 */
	private class MySortedSetIterator<T> implements Iterator {
		int currentPos;

		public MySortedSetIterator() {
			currentPos = 0;
		}

		@Override
		public boolean hasNext() {
			return currentPos != length - 1;
		}

		@Override
		public Object next() throws NoSuchElementException {
			if (!this.hasNext())
				throw new NoSuchElementException();
			currentPos++;
			return storage[currentPos - 1];
		}

		@Override
		public void remove() throws IllegalStateException {
			// If the current position is before the array, throw exception
			if (currentPos == 0)
				throw new IllegalStateException();

			// Copy over everything except for what to remove
			E[] temp = (E[]) new Object[length];
			for (int pos = 0; pos < length; pos++)
				if (pos < currentPos)
					temp[pos] = storage[pos];
				else if (pos > currentPos)
					temp[pos - 1] = storage[pos];
			storage = temp;
		}
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MySortedSetIterator<E>();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		// If element is not in the set, return false
		if (!this.contains(o))
			return false;

		// Find the index of what to remove
		int indexOfO = this.binarySearch((E) o);

		// Copy over everything except for what to remove
		E[] temp = (E[]) new Object[length];
		for (int pos = 0; pos < length; pos++)
			if (pos < indexOfO)
				temp[pos] = storage[pos];
			else if (pos > indexOfO)
				temp[pos - 1] = storage[pos];
		storage = temp;
		length--;
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean isChanged = false;
		// Remove every element in the given collection from the set
		for (Object ele : c)
			if (this.remove(ele))
				// Set to true if set is changed
				isChanged = true;
		return isChanged;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return length;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		// New array for returning stored values
		E[] result = (E[]) (new Object[length]);
		for (int i = 0; i < length; i++)
			result[i] = storage[i];
		return result;
	}

}
