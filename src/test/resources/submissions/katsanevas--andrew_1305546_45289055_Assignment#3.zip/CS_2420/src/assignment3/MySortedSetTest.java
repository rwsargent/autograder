package assignment3;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;
import java.util.Random;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests methods of the MySortedSet class
 * 
 * @author Dyllon Gagnier
 * @author Andrew Katsanevas
 *
 */
public class MySortedSetTest {

	/**
	 * A comparator for sorting integers in reverse order.
	 * 
	 * @author Andrew Katsanevas
	 * @author Dyllon Gagnier
	 *
	 */
	private class BackwardsInt implements Comparator {

		@Override
		public int compare(Object o1, Object o2) {
			return ((Comparable) o2).compareTo(o1);
		}
	}

	// Collections to be used for testing
	private MySortedSet<Integer> intSet;
	private MySortedSet<Integer> bigSet;
	private MySortedSet<Integer> emptySet;
	private MySortedSet<Integer> setOfOne;
	private MySortedSet<Integer> backwards;

	// Containers for data
	ArrayList<Integer> ints;
	ArrayList<Integer> lessInts;
	private int[] intsResult;
	private int[] bigArray;
	private int[] intArray;

	/**
	 * Sets up all resources to be used before testing. Assures the add and
	 * addAll methods work.
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {

		// These resources won't load if the add and addAll methods don't work.

		// The data for intSet, and the result of its sorting.
		intArray = new int[] { 2, 2, 33, 1, 6, 5, 6, 4, 54, 87, 564 };
		intsResult = new int[] { 1, 2, 4, 5, 6, 33, 54, 87, 564 };
		// Put the data from intArray into an ArrayList ints
		ints = new ArrayList<Integer>();
		for (int i : intArray) {
			ints.add(i);
		}
		// Add values from the ints ArrayList to the intSet
		intSet = new MySortedSet<Integer>();
		intSet.addAll(ints);

		// A set of ints including most of intSet's data
		int[] lessIntsArray = new int[] { 2, 2, 1, 6, 5, 6, 54, 87, 564 };
		lessInts = new ArrayList<Integer>();
		for (int j : lessIntsArray) {
			lessInts.add(j);
		}

		// A set with no data added
		emptySet = new MySortedSet<Integer>();

		// Random number generator for bigSet
		Random gen = new Random(11);
		// A big set of 10000 random numbers
		bigSet = new MySortedSet<Integer>();
		bigArray = new int[10000];
		for (int pos = 0; pos < bigArray.length; pos++) {
			int temp = gen.nextInt();
			bigArray[pos] = temp;
			bigSet.add(temp);
		}

		// A set of the same integers, but sorted backwards with a comparator
		BackwardsInt comparator = new BackwardsInt();
		backwards = new MySortedSet<Integer>(comparator);
		backwards.addAll(ints);

		// A set containing one element
		setOfOne = new MySortedSet<Integer>();
		setOfOne.add(1);
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Tests the first method of MySortedSet
	 */
	@Test
	public void testFirst() {
		assertEquals((Integer) 1, intSet.first());
		assertEquals((Integer) 1, setOfOne.first());
	}

	/**
	 * Tests that the first method of MySortedSet throws the correct exception
	 */
	@Test(expected = NoSuchElementException.class)
	public void testFirstException() {
		emptySet.first();
	}

	/**
	 * Tests the last method of MySortedSet
	 */
	@Test
	public void testLast() {
		assertEquals((Integer) 564, intSet.last());
		assertEquals((Integer) 1, setOfOne.last());
	}

	/**
	 * Tests that the last method of MySortedSet throws the correct exception
	 */
	@Test(expected = NoSuchElementException.class)
	public void testLastException() {
		emptySet.last();
	}

	/**
	 * Tests the toArray method of MySortedSet
	 */
	@Test
	public void testToArray() {
		// Comparable
		Object[] actual = intSet.toArray();
		int pos = 0;
		for (Object i : actual) {
			assertEquals((Integer) intsResult[pos], (Integer) i);
			pos++;
		}

		// Comparator backwards
		actual = backwards.toArray();
		pos = intsResult.length - 1;
		for (Object i : actual) {
			assertEquals((Integer) intsResult[pos], (Integer) i);
			pos--;
		}

		// Empty
		actual = emptySet.toArray();
		assertEquals(0, actual.length);
	}

	/**
	 * Tests the size method of MySortedSet
	 */
	@Test
	public void testSize() {
		assertEquals(intsResult.length, intSet.size());
		assertEquals(0, emptySet.size());
	}

	/**
	 * Tests the contains method of MySortedSet
	 */
	@Test
	public void contains() {
		for (int i : bigArray) {
			assertTrue(bigSet.contains(i));
		}

		assertTrue(intSet.contains(33));
		assertFalse(intSet.contains(-1));
		assertFalse(intSet.contains(5000));
		assertFalse(intSet.contains(55));
		// Contains nothing
		assertFalse(emptySet.contains(1));
	}

	/**
	 * Tests the remove method of MySortedSet. This also assures that the binary
	 * search method works.
	 */
	@Test
	public void testRemove() {
		assertTrue(intSet.remove((Integer) 1));
		assertFalse(intSet.contains(1));
		assertTrue(intSet.remove((Integer) 564));
		assertFalse(intSet.contains(564));
		assertTrue(intSet.remove((Integer) 54));
		assertFalse(intSet.contains(564));
		// Nothing to remove
		assertFalse(emptySet.remove((Integer) 1));

	}

	/**
	 * Tests the removeAll method of MySortedSet
	 */
	@Test
	public void testRemoveAll() {
		ArrayList<Integer> bigArrayList = new ArrayList<Integer>();
		for (int i : bigArray)
			bigArrayList.add(i);
		bigArrayList.remove(0);
		bigSet.removeAll(bigArrayList);
		assertEquals(1, bigSet.size());

		int count = 1;
		for (Object i : bigSet)
			count++;
		assertEquals(1, count);

		// Removes some elements
		assertTrue(intSet.removeAll(lessInts));

		// Nothing to remove
		assertFalse(emptySet.removeAll(ints));
	}
}