package assignment3;

import java.util.Random;

public class MySortedSetTimer {

	public static void main(String[] args) {
		System.out.println("Qiaofeng Wang && Guanlin Chen");
		System.out.println("Assignment 3");

		// timer1();
		timer2();
	}

	/**
	 * timer for question 6
	 */
	public static void timer1() {
		Random r = new Random();
		long startTime, midpointTime, stopTime;
		int timesToLoop = 10000;

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) {
			// empty loop
		}

		for (int N = 100000; N <= 2000000; N += 100000) {
			MySortedSet<Integer> set = new MySortedSet<Integer>();

			while (set.size() < N) {
				set.add(r.nextInt());
			}

			startTime = System.nanoTime();

			for (int i = 0; i < timesToLoop; i++) {
				set.contains(r.nextInt());
			}

			midpointTime = System.nanoTime();

			for (int i = 0; i < timesToLoop; i++) {
				// to compute the time used in loop
			}

			stopTime = System.nanoTime();

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop;

			System.out.println(averageTime);
		}
		System.out.println("done");
	}

	/**
	 * timer for question 7
	 */
	public static void timer2() {
		Random r = new Random();
		long startTime, midpointTime, stopTime;
		int timesToLoop = 10000;

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) {
			// empty loop
		}

		for (int N = 100000; N <= 2000000; N += 100000) {
			MySortedSet<Integer> set = new MySortedSet<Integer>();

			while (set.size() < N) {
				set.add(r.nextInt());
			}

			startTime = System.nanoTime();

			for (int i = 0; i < timesToLoop; i++) {
				int temp = r.nextInt();
				set.add(temp);
				set.remove(temp);
			}

			midpointTime = System.nanoTime();

			for (int i = 0; i < timesToLoop; i++) {
				// to compute the time used in loop
				int temp = r.nextInt();
				set.remove(temp);
			}

			stopTime = System.nanoTime();

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop;

			System.out.println(averageTime);
		}
		System.out.println("done");
	}
}
