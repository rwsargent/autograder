package assignment3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;
import java.util.SortedSet;
import java.util.TreeSet;

import org.junit.Test;

import junit.framework.TestCase;

/**
 * A test class for MysortedSet.
 * 
 * @author Qiaofeng Wang & Guanlin Wu
 * @version 02/05/2015
 */
public class MySortedSetTest extends TestCase {

	MySortedSet<Integer> array1;
	MySortedSet<Double> array2;

	SortedSet<Integer> correctArray;

	private int timesToLoop;
	private Random r;

	protected void setUp() throws Exception {
		array1 = new MySortedSet<Integer>();
		array2 = new MySortedSet<Double>();

		correctArray = new TreeSet<Integer>();

		timesToLoop = 1000;
		r = new Random();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	@Test
	/**
	 * Test comparator method
	 */
	public void testComparator() {
		for (int i = 0; i < timesToLoop; i++) {
			assertEquals(array1.comparator(), null);
			assertEquals(array2.comparator(), null);

			Comparator<Integer> cmp = new Comparator<Integer>() {

				@Override
				public int compare(Integer o1, Integer o2) {
					return 0;
				}
			};

			array1 = new MySortedSet<Integer>(cmp);
			assertEquals(array1.comparator(), cmp);
			array1 = new MySortedSet<Integer>();
		}
	}

	@Test
	/**
	 * Test add method
	 */
	public void testadd() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();
			correctArray = new TreeSet<Integer>();

			int size = 500;
			for (int j = 0; j < size; j++) {
				int random = r.nextInt();
				array1.add(random);
				correctArray.add(random);
			}
			assertEquals(array1.size(), correctArray.size());
			int random = r.nextInt();
			assertEquals(array1.add(random), correctArray.add(random));
		}
	}

	/**
	 * Test first and last method
	 */
	@Test
	public void testfirstAndLast() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();

			correctArray = new TreeSet<Integer>();

			boolean exceptionOrNot1 = false;
			boolean exceptionOrNot2 = false;

			try {
				array1.first();
			} catch (Exception e) {
				exceptionOrNot1 = true;
			}
			assertEquals(exceptionOrNot1, true);

			try {
				array1.last();
			} catch (Exception e) {
				exceptionOrNot2 = true;
			}
			assertEquals(exceptionOrNot2, true);
		}
	}

	/**
	 * Test first, last and size method.
	 */
	@Test
	public void testfirstAndLastAndSize() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();

			correctArray = new TreeSet<Integer>();
			correctArray.add(Integer.MIN_VALUE);

			int size = 500;
			for (int j = 0; j < size; j++) {
				int random = r.nextInt();
				array1.add(random);
				correctArray.add(random);
			}
			array1.add(Integer.MIN_VALUE);
			array1.add(Integer.MAX_VALUE);

			correctArray.add(Integer.MAX_VALUE);

			assertEquals(array1.size(), correctArray.size());
			assertEquals(array1.first(), correctArray.toArray()[0]);
			assertEquals(array1.last(),
					correctArray.toArray()[correctArray.size() - 1]);
		}
	}

	/**
	 * Test addAll method
	 */
	@Test
	public void testAddAll() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();
			ArrayList<Integer> list = new ArrayList<Integer>();
			int size = 1000;
			for (int j = 0; j < size; j++) {
				int random = r.nextInt();
				if (!list.contains(random))
					list.add(random);
			}

			assertEquals(array1.addAll(list), true);
		}
	}

	/**
	 * Test clear and isEmpty method
	 */
	@Test
	public void testClearAndIsEmpty() {
		for (int i = 0; i < timesToLoop; i++) {
			array2 = new MySortedSet<Double>();
			assertEquals(array2.isEmpty(), true);

			array2.add(r.nextDouble());
			assertEquals(array2.isEmpty(), false);

			int size = 1000;
			for (int j = 0; j < size; j++)
				array2.add(r.nextDouble());

			array2.clear();
			assertEquals(array2.isEmpty(), true);
		}
	}

	/**
	 * Test contains and size method
	 */
	@Test
	public void testContainsAndSize() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();

			correctArray = new TreeSet<Integer>();

			int size = 100;
			for (int j = 0; j < size; j++) {
				int random = r.nextInt();
				array1.add(random);
				correctArray.add(random);
			}
			assertEquals(array1.size(), correctArray.size());
			int random = r.nextInt();
			assertEquals(array1.contains(random), correctArray.contains(random));
		}
	}

	/**
	 * Test containsAll method
	 */
	@Test
	public void testContainsAll() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();
			correctArray = new TreeSet<Integer>();

			int size = 1000;
			for (int j = 0; j < size; j++) {
				int random = r.nextInt();
				array1.add(random);
				correctArray.add(random);
			}
			assertEquals(array1.containsAll(correctArray), false);
		}
	}

	/**
	 * Test toArray method
	 */
	@Test
	public void testToArray() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();
			correctArray = new TreeSet<Integer>();

			for (int j = 0; j < 4; j++) {
				int random;
				random = r.nextInt(100);
				array1.add(random);
				correctArray.add(random);
			}

			Object[] temp1 = array1.toArray();
			Object[] temp2 = correctArray.toArray();

			for (int k = 0; k < temp1.length; k++) {
				assertEquals(temp1[k], temp2[k]);
			}
		}
	}

	/**
	 * Test remove method
	 */
	@Test
	public void testRemove() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();
			correctArray = new TreeSet<Integer>();

			int size = 500;
			for (int j = 0; j < size; j++) {
				int random = r.nextInt();
				array1.add(random);
				correctArray.add(random);
			}
			int random = r.nextInt();
			assertEquals(array1.remove(random), correctArray.remove(random));
		}
	}

	/**
	 * Test removeAll method
	 */
	@Test
	public void testRemoveAll() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();
			ArrayList<Integer> list = new ArrayList<Integer>();
			int size = 1000;
			for (int j = 0; j < size; j++) {
				int random = r.nextInt();
				if (!list.contains(random))
					list.add(random);
			}

			array1.addAll(list);
			assertEquals(array1.removeAll(list), true);
		}
	}

	/**
	 * Test iterator method
	 */
	@Test
	public void testIterator() {
		for (int i = 0; i < timesToLoop; i++) {
			array1 = new MySortedSet<Integer>();
			correctArray = new TreeSet<Integer>();

			int size = 100;
			for (int j = 0; j < size; j++) {
				int random = r.nextInt();
				array1.add(random);
				correctArray.add(random);
			}

			assertEquals(array1.iterator().hasNext(), correctArray.iterator()
					.hasNext());
			for (int j = 0; j < size; j++) {
				assertEquals(array1.iterator().next(), correctArray.iterator()
						.next());
			}

		}
	}
}
