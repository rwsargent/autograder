package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * My sorted set class, implements sorted set.
 * 
 * @author Qiaofeng Wang & Guanlin Wu
 * @version 02/05/2015
 */
public class MySortedSet<E> implements SortedSet<E> {
	E[] data;
	int size;
	Comparator<? super E> comparator;

	@SuppressWarnings("unchecked")
	public MySortedSet() {
		size = 0;
		data = (E[]) new Object[20];
		comparator = null;
	}

	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> cmp) {
		size = 0;
		data = (E[]) new Object[20];
		comparator = cmp;
	}

	/**
	 * 
	 * A help method for the situation when comparator is null.
	 * 
	 * @param a
	 *            item to be compared
	 * @param another
	 *            item to be compared
	 * @return negative integer if item 1 is smaller than 2, else positive
	 *         number. 0 for equal.
	 */
	@SuppressWarnings("unchecked")
	private int compare(E item1, E item2) {
		if (comparator == null) {
			return ((Comparable<E>) item1).compareTo(item2);
		} else {
			return comparator.compare(item1, item2);
		}
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		else
			return data[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		else
			return data[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {
		if (contains(o))
			return false;

		if (size == data.length) {
			E newData[] = (E[]) new Object[data.length * 2];

			for (int i = 0; i < size; i++)
				newData[i] = data[i];

			data = newData;
		}

		if (size == 0) {
			data[0] = o;
			size++;
			return true;
		}

		if (size == 1) {
			if (compare(data[0], o) < 0)
				data[1] = o;
			else {
				data[1] = data[0];
				data[0] = o;
			}
			size++;
			return true;
		}

		int lowIndex = 0;
		int highIndex = size - 1;
		int middle = 0;

		if (compare(data[lowIndex], o) > 0) {
			E tempData[] = (E[]) new Object[data.length];

			tempData[0] = o;
			for (int i = 1; i < size + 1; i++) {
				tempData[i] = data[i - 1];
			}

			data = tempData;

			size++;
			return true;
		}

		if (compare(data[highIndex], o) < 0) {
			data[size] = o;
			size++;
			return true;
		}

		while (highIndex - 1 > lowIndex) {
			middle = (lowIndex + highIndex) / 2;
			if (compare(data[middle], o) < 0) {
				if (middle + 1 != highIndex)
					lowIndex = middle + 1;
				else {
					E tempData[] = (E[]) new Object[data.length];

					for (int i = 0; i <= middle; i++)
						tempData[i] = data[i];

					tempData[middle + 1] = o;

					for (int i = middle + 2; i < size + 1; i++)
						tempData[i] = data[i - 1];

					data = tempData;

					size++;
					return true;
				}
			}
			if (compare(data[middle], o) > 0) {
				if (middle - 1 != lowIndex)
					highIndex = middle - 1;
				else {
					E tempData[] = (E[]) new Object[data.length];

					for (int i = 0; i <= lowIndex; i++)
						tempData[i] = data[i];

					tempData[lowIndex + 1] = o;

					for (int i = lowIndex + 2; i < size + 1; i++)
						tempData[i] = data[i - 1];

					data = tempData;

					size++;
					return true;
				}
			}
		}
		E tempData[] = (E[]) new Object[data.length];

		for (int i = 0; i <= lowIndex; i++)
			tempData[i] = data[i];

		tempData[lowIndex + 1] = o;

		for (int i = lowIndex + 2; i < size + 1; i++)
			tempData[i] = data[i - 1];

		data = tempData;
		size++;
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean addOrNot = false;
		for (E item : c) {
			if (!contains(item)) {
				add(item);
				addOrNot = true;
			}
		}

		return addOrNot;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		size = 0;
		for (int i = 0; i < data.length; i++)
			data[i] = null;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		if (o == null)
			return false;

		int lowIndex = 0;
		int highIndex = size - 1;
		int middle = 0;
		while (highIndex >= lowIndex) {
			middle = (lowIndex + highIndex) / 2;
			if (compare(data[middle], (E) o) == 0)
				return true;
			if (compare(data[middle], (E) o) < 0)
				lowIndex = middle + 1;
			if (compare(data[middle], (E) o) > 0)
				highIndex = middle - 1;
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		boolean hasOrNot = true;
		for (Object item : c)
			if (!contains(item))
				hasOrNot = false;

		return hasOrNot;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (data.length == 0)
			return true;

		for (int i = 0; i < size; i++)
			if (data[i] != null)
				return false;
		return true;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MyIterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object o) {
		if (!this.contains(o))
			return false;

		int lowIndex = 0;
		int highIndex = size - 1;
		int middle = 0;
		while (highIndex >= lowIndex) {
			middle = (lowIndex + highIndex) / 2;
			if (compare(data[middle], (E) o) == 0) {
				data[middle] = null;
				for (int i = middle; i < size - 1; i++)
					data[i] = data[i + 1];
				break;
			}
			if (compare(data[middle], (E) o) < 0)
				lowIndex = middle + 1;
			if (compare(data[middle], (E) o) > 0)
				highIndex = middle - 1;
		}
		size--;
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean hasOrNot = false;
		for (Object item : c)
			if (this.contains(item)) {
				hasOrNot = true;
				remove(item);
			}

		return hasOrNot;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object[] toArray() {
		Object result[] = (E[]) new Object[size()];

		for (int i = 0; i < size(); i++)
			result[i] = data[i];

		return result;
	}

	/**
	 * Help class for iterator
	 * 
	 * @author Qiaofeng Wang & Guanlin Wu
	 * 
	 */
	private class MyIterator implements Iterator<E> {

		int index;
		boolean nextCalled;

		/**
		 * Set index and nextCalled
		 */
		public MyIterator() {
			index = -1;
			nextCalled = false;
		}

		/**
		 * @return If there is next item in the array, return true. Otheriwse,
		 *         false.
		 */
		@Override
		public boolean hasNext() {
			return index < size - 1;
		}

		/**
		 * @return The next item in the array.
		 */
		@Override
		public E next() {
			if (!hasNext())
				throw new NoSuchElementException();
			nextCalled = true;
			index++;
			E result = data[index];
			return result;
		}

		/**
		 * Remove the last item which iterator is using.
		 */
		@Override
		public void remove() {
			if (!nextCalled)
				throw new IllegalStateException();

			MySortedSet.this.remove(data[index]);
			index--;
			nextCalled = false;
		}
	}
}
