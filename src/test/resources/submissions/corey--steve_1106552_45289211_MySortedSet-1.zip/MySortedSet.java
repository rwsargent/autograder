package assignment3;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import assignment1.Matrix;

/**
 * Class that handles lists of type E elements
 * 
 * @author Steve Corey & Rebecca Rodriguez
 * @version February 5, 2015
 * 
 * @param <E>
 *            the type of elements maintained by this set
 * 
 */
public class MySortedSet<E> implements SortedSet<E> 
{
	// member variables
	private E[] backingArray;
	private int currentCapacity;
	private int elementCount;
	private Comparator<? super E> comparator;
	private int searchIndex;

	/**
	 * Constructor used to create a sorted set, it is assumed that the elements
	 * are ordered using their natural ordering.
	 */
	public MySortedSet()
	{
		backingArray = (E[]) new Object[10];

		currentCapacity = 10;
		elementCount = 0;
	}

	/**
	 * Constructor used to create a sorted set, given the specified comparator
	 * c. The comparator must be of subtype E.
	 * 
	 * @param c comparator of subtype E
	 */
	public MySortedSet(Comparator<? super E> c)
	{
		comparator = c;
		backingArray = (E[]) new Object[10];
		currentCapacity = 10;
		elementCount = 0;
	}

	/**
	 * Returns the comparator used to order the elements in this set, or null if
	 * this set uses the natural ordering of its elements (i.e., uses
	 * Comparable).
	 * 
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements
	 */
	@Override
	public Comparator<? super E> comparator()
	{
		if (comparator == null)
			return null;

		return comparator;
	}

	/**
	 * Returns the first (lowest, smallest) element currently in this set Throws
	 * a NoSuchElementException if the set is empty.
	 * 
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException
	{
		if (elementCount == 0)
			throw new NoSuchElementException();

		return backingArray[0];
	}

	/**
	 * Returns the last (highest, largest) element currently in this set. Throws
	 * NoSuchElementException if the set is empty.
	 * 
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException
	{
		if (elementCount == 0)
			throw new NoSuchElementException();

		return backingArray[elementCount - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null. Increases element count if element is added.
	 * 
	 * @param o	element to be added to this set
	 * @return true if this set does not already contain the specified element,
	 *         false otherwise
	 */
	@Override
	public boolean add(E o)
	{
		// search for the element, return false if found or null
		if (this.contains(o) || o == null)
			return false;

		// if not found...
		//  check if array is full, if so, call method to double the capacity
		//  otherwise, just insert element
		if (elementCount == currentCapacity)
			insertIfArrayFull(o);
		else
			insertIfArrayHasRoom(o);

		return true;
	}

	/**
	 * Insert element at searchIndex by sliding over all the elements after
	 * searchIndex. Increases element count by one.
	 * 
	 * @param o
	 *            the element of type E to insert
	 */
	private void insertIfArrayHasRoom(E o)
	{
		// slide elements over in the array
		for (int i = elementCount; i > searchIndex - 1; i--)
			backingArray[i] = backingArray[i - 1];

		// add element below searchIndex
		backingArray[searchIndex - 1] = o;

		// Update number of elements
		elementCount++;
	}

	/**
	 * Inserts element at searchIndex by first doubling the size of the array,
	 * then copying elements into the new array. Increases element count by one.
	 * 
	 * @param o
	 *            the element of type E to insert
	 */
	private void insertIfArrayFull(E o)
	{
		int newCapacity = currentCapacity * 2;

		// copy elements from current array to new array up to searchIndex
		E[] bigger = (E[]) new Object[newCapacity];

		for (int i = 0; i < searchIndex - 1; i++)
			bigger[i] = backingArray[i];

		// add element below searchIndex
		bigger[searchIndex - 1] = o;

		// continue copying array
		for (int i = searchIndex; i <= elementCount; i++)
			bigger[i] = backingArray[i - 1];

		// save new array as current array
		backingArray = bigger;

		// update size
		currentCapacity = bigger.length;

		// Update number of elements
		elementCount++;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call, false if it did
	 *         not change.
	 */
	@Override
	public boolean addAll(Collection<? extends E> c)
	{
		boolean addedElement = false;

		for (E element : c)
			if (this.add(element))
				addedElement = true;

		return addedElement;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear()
	{
		elementCount = 0;
	}

	/**
	 * Searches the set for the specified object. Returns true if the set
	 * contains the object, false if it does not. Assigns the value of
	 * searchIndex to the index if found, or (p + 1), where p is the first
	 * position greater than o.
	 * 
	 * @param o
	 *            element whose presence in this set is to be tested
	 * @return true if this set contains the specified object, false if it does
	 *         not
	 */
	@Override
	public boolean contains(Object o)
	{
		// check if null object
		if (o == null)
			return false;
		
		// do a try catch to check if the requested object is the same type as
		//   our elements
		try
		{

			// check if comparable or uses a comparator, then
			//  search for it and assign the index
			if (this.comparator == null)
			{
				// use comparable search
				searchIndex = this.binarySearch(backingArray, (E) o);
			} else
			{
				// use comparator search
				searchIndex = this.binarySearch(backingArray, (E) o,
						this.comparator);
			}

			// if not found, make searchIndex positive and return false
			if (searchIndex < 0)
			{
				searchIndex = -searchIndex;
				return false;
			}

			return true;
		} catch (ClassCastException e)
		{
			return false;
		}
	}

	/**
	 * @param c	collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection, false if it does not
	 */
	@Override
	public boolean containsAll(Collection<?> c)
	{
		for (Object o : c)
			if (!(this.contains(o)))
				return false;

		return true;
	}

	/**
	 * @return true if this set contains no elements, false if it contains at
	 *         least one element
	 */
	@Override
	public boolean isEmpty()
	{
		if (elementCount == 0)
			return true;

		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator()
	{

		return new MyIterator();
	}

	/**
	 * Removes the specified element from this set and reduces elementCount by
	 * one, if it is present.
	 * 
	 * @param o
	 *            object to be removed from this set, if present
	 * @return true if the object was removed, false otherwise
	 */
	@Override
	public boolean remove(Object o)
	{
		// check if element is in set
		if (this.contains(o))
		{
			// slide elements over in the array
			for (int i = searchIndex; i < elementCount - 1; i++)
				backingArray[i] = backingArray[i + 1];

			// Update number of elements
			elementCount--;

			return true;
		}

		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c)
	{
		boolean removedElement = false;

		for (Object o : c)
			if (this.remove(o))
				removedElement = true;

		return removedElement;
	}

	/**
	 * Returns the number of elements in this set.
	 * 
	 * @return the number of elements in this set
	 */
	@Override
	public int size()
	{
		return elementCount;
	}

	/**
	 * Returns an array containing all of the elements in this set, in sorted
	 * (ascending) order.
	 * 
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray()
	{
		Object[] resultArray = new Object[elementCount];
		for (int i = 0; i < elementCount; i++)
			resultArray[i] = backingArray[i];

		return resultArray;
	}

	/**
	 * Performs a search on sorted array using a comparator. If array is not
	 * sorted, results are undefined.
	 * 
	 * @param array
	 *            the array to search
	 * @param element
	 *            the object to search for
	 * @param cmp
	 *            the comparator
	 * @return if element is found, returns the index where it is found
	 *         otherwise, the return value is a negative number equal to -( p +
	 *         1 ), where p is the first position greater than element. This can
	 *         range from -1 down to -(elementCouht + 1).
	 * 
	 * @author Mark Allen Weiss
	 */
	private int binarySearch(E[] array, E element, Comparator<? super E> cmp)
	{
		int low = 0, mid = 0;
		int high = elementCount;

		while (low < high)
		{
			mid = (low + high) / 2;
			if (cmp.compare(element, array[mid]) > 0)
				low = mid + 1;
			else
				high = mid;
		}

		if (low == elementCount || cmp.compare(element, array[low]) != 0)
			return -(low + 1);

		return low;
	}

	/**
	 * Performs a search on sorted array using a comparator. If array is not
	 * sorted, results are undefined.
	 * 
	 * @param array
	 *            the array to search
	 * @param element
	 *            the comparable object to search for
	 * @return if element is found, returns the index where it is found
	 *         otherwise, the return value is a negative number equal to -( p +
	 *         1 ), where p is the first position greater than element. This can
	 *         range from -1 down to -(elementCount + 1).
	 * 
	 * @author Mark Allen Weiss
	 */
	private int binarySearch(E[] array, E element)
	{
		Comparable elementFromArray;
		Comparable parameter = (Comparable) element;

		int low = 0, mid = 0;
		int high = elementCount;

		while (low < high)
		{
			mid = (low + high) / 2;
			// elementFromArray = (Comparable)array[mid];
			if (parameter.compareTo(array[mid]) > 0)
				low = mid + 1;
			else
				high = mid;
		}

		if (low == elementCount || parameter.compareTo(array[low]) != 0)
			return -(low + 1);

		return low;
	}

	/**
	 * Internal iterator class used to create iterators.
	 * @author Steve Corey & Rebecca Rodriguez
	 *
	 */
	private class MyIterator implements Iterator<E>
	{
		int position = -1;
		boolean nextHasRun = false;

		@Override
		public boolean hasNext()
		{
			return position < elementCount - 1;
		}

		@Override
		public E next()
		{
			if (position >= elementCount - 1)
				throw new NoSuchElementException();
			
			position++;
			nextHasRun = true;
			return backingArray[position];
		}

		@Override
		public void remove()
		{
			if (nextHasRun)
			{
				MySortedSet.this.remove(backingArray[position]);
				nextHasRun = false;
				position--;
			}
			else
				throw new IllegalStateException();
		}
		
	}
}


