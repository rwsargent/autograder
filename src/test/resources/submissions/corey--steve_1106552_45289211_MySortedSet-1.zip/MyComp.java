package assignment3;

import java.util.Comparator;

/**
 * Class that creates a comparator that compares strings by length so we can
 * test the MySortedSet class
 * 
 * @author Steve Corey & Rebecca Rodriguez
 * @version February 5, 2015
 * 
 * 
 * 
 */
public class MyComp implements Comparator<String>
{

	@Override
	public int compare(String o1, String o2)
	{
		if (o1.length() < o2.length())
			return -1;

		else if (o1.length() == o2.length())
			return 0;

		else
			return 1;
	}

}
