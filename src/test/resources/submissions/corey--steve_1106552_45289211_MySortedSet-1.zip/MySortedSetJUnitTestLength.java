package assignment3;

import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * MySortedSetJUnitTest performs JUnit tests on the methods within MySortedSet<E>,
 * where E is String.
 * 
 * This uses a comparator that compares strings by length. So a string is equal
 * to another string when their lengths are equal.
 * 
 * @author Steve Corey & Rebecca Rodriguez
 * @version February 5, 2015
 * 
 */
public class MySortedSetJUnitTestLength
{
	
	//private MySortedSet<String> lengthList = new MySortedSet<String>(new MyComp());
	
	// MySortedSet<String>
	private MySortedSet<String> emptyList = new MySortedSet<String>(new MyComp());
	private MySortedSet<String> oneItemList = new MySortedSet<String>(new MyComp());
	private MySortedSet<String> manyItemsList = new MySortedSet<String>(new MyComp());
	private MySortedSet<String> tenItemsList = new MySortedSet<String>(new MyComp());
	private MySortedSet<String> fifteenItemsList = new MySortedSet<String>(new MyComp());
	
	// Result arrays
	private Object[] manyItemsArray = new Object[5];
	private Object[] manyItemsLengthArray = new Object[3];
	private Object[] emptyArray = new Object[0];

	// ArrayLists 
	private ArrayList<String> stringNonexisting = new ArrayList<String>();
	private ArrayList<String> stringExisting = new ArrayList<String>();
	private ArrayList<String> stringHalfNHalf = new ArrayList<String>();
	private ArrayList<Integer> intMismatch = new ArrayList<Integer>();
	private ArrayList<String> tenItems = new ArrayList<String>();
	private ArrayList<String> fifteenItems = new ArrayList<String>();

	@Before
	public void setUp() throws Exception
	{
		// set up ten items arraylist
		tenItems.add("Word 3");
		tenItems.add("Word 8");
		tenItems.add("Word 4");
		tenItems.add("Word 9");
		tenItems.add("Word 0");
		tenItems.add("Word 6");
		tenItems.add("Word 7");
		tenItems.add("Word 1");
		tenItems.add("Word 2");
		tenItems.add("Word 5");
		
		
		
		// setup String sets
		oneItemList.add("Hello");
		
		manyItemsList.add("One");
		manyItemsList.add("Two");
		manyItemsList.add("Three");
		manyItemsList.add("Four");
		manyItemsList.add("Five");		// manyItemsList will have 5 elements
		
		tenItemsList.addAll(tenItems);
		
		fifteenItemsList.addAll(fifteenItems);	
		
		// setup String array results
		manyItemsArray[0] = "Five";
		manyItemsArray[1] = "Four";
		manyItemsArray[2] = "One";
		manyItemsArray[3] = "Three";
		manyItemsArray[4] = "Two";
		
		manyItemsLengthArray[0] = "One";
		manyItemsLengthArray[1] = "Four";
		manyItemsLengthArray[2] = "Three";

		// setup nonexisting String arraylist result
		stringNonexisting.add("EightySeven");
		stringNonexisting.add("FiftyNine");
		stringNonexisting.add("FourHundredSixty");

		// set up existing String arraylist result
		stringExisting.add("Five");
		stringExisting.add("Five");
		stringExisting.add("Four");

		// set up existing/nonexisting String arraylist result
		stringHalfNHalf.add("One");
		stringHalfNHalf.add("Two");
		stringHalfNHalf.add("Nope");
		stringHalfNHalf.add("Nada");
		stringHalfNHalf.add(null);

		// set up mismatch Integer arraylist result
		intMismatch.add(1);
		intMismatch.add(12);
		intMismatch.add(13);
		
		// set up fifteen items arraylist
		fifteenItems.add("Word 3");
		fifteenItems.add("Word 4");
		fifteenItems.add("Word 0");
		fifteenItems.add("Word 30");
		fifteenItems.add("Word 40");
		fifteenItems.add("Word 1");
		fifteenItems.add("Word 6");
		fifteenItems.add("Word 7");
		fifteenItems.add("Word 8");
		fifteenItems.add("Word 10");
		fifteenItems.add("Word 20");
		fifteenItems.add("Word 50");
		fifteenItems.add("Word 60");
		fifteenItems.add("Word 2");
		fifteenItems.add("Word 5");

	}

	@After
	public void tearDown() throws Exception
	{
	}

	@Test
	public void testMySortedSet()
	{
		// create a MySortedSet, test affect on size
		MySortedSet<String> constructorTest = new MySortedSet<String>();
		assertEquals(0, constructorTest.size());

		// test that returned array is empty
		assertArrayEquals(emptyArray, constructorTest.toArray());
	}

	@Test
	public void testMySortedSetComparatorOfQsuperE()
	{
		// will not test this constructor for sets of strings
	}

	@Test
	public void testComparator()
	{
		// will not test this constructor when a comparator is used for the constructor
	}

	@Test(expected = NoSuchElementException.class)
	public void testFirstException()
	{
		emptyList.first();
	}

	@Test
	public void testFirst()
	{
		// first on 1 item
		assertEquals("Hello", oneItemList.first());
		// first on many items
		assertEquals("One", manyItemsList.first());
	}

	@Test(expected = NoSuchElementException.class)
	public void testLastException()
	{
		emptyList.last();
	}

	@Test
	public void testLast()
	{
		// last() on one item
		assertEquals("Hello", oneItemList.last());
		// last() on many items
		assertEquals("Three", manyItemsList.last());
	}

	@Test
	public void testAdd()
	{
		// add new elements to set
		assertEquals(true, emptyList.add("Honda"));
		assertEquals(true, emptyList.add("VW"));
		// test size after add
		assertEquals(2, emptyList.size());

		// add existing element to set
		assertEquals(false, emptyList.add("Honda"));
		assertEquals(false, emptyList.add("VW"));

		// add null to set
		assertEquals(false, emptyList.add(null));

		// test size after add attempts
		assertEquals(2, emptyList.size());
	}

	@Test
	public void testAddAll()
	{
		// add collection of new elements to set
		assertEquals(true, manyItemsList.addAll(stringNonexisting));

		// add collection of existing elements to set
		assertEquals(false, manyItemsList.addAll(stringExisting));
		assertEquals(false, manyItemsList.addAll(stringNonexisting));
	}

	@Test
	public void testClear()
	{
		// clear elements in set of many elements
		manyItemsList.clear();
		// test side effect of clearing elements
		assertEquals(0, manyItemsList.size());
		assertEquals(true, manyItemsList.isEmpty());

		// clear an empty set
		emptyList.clear();
		// test side effect of clearing elements
		assertEquals(0, emptyList.size());
		assertEquals(true, manyItemsList.isEmpty());
	}

	@Test
	public void testContains()
	{
		// contains existing, matching type element
		assertEquals(true, manyItemsList.contains("Five"));

		// contains nonexisting, matching type element
		assertEquals(false, manyItemsList.contains("MaybeMaybeNot"));

		// contains nonmatching type element
		assertEquals(false, manyItemsList.contains(5));

		// contains null
		assertEquals(false, manyItemsList.contains(null));
	}

	@Test
	public void testContainsAll()
	{
		// search for collection of existing, same type elements in set
		assertEquals(true, manyItemsList.containsAll(stringExisting));

		// search for collection of nonexistent, same type elements in set
		assertEquals(false, manyItemsList.containsAll(stringNonexisting));

		// search for collection of half existing/half nonexisting, same type
		// elements in set
		assertEquals(false, manyItemsList.containsAll(stringHalfNHalf));

		// search for mismatching type elements
		assertEquals(false, manyItemsList.containsAll(intMismatch));
	}

	@Test
	public void testIsEmpty()
	{
		// test isEmpty on non-empty list
		assertEquals(false, manyItemsList.isEmpty());

		// test isEmpty on empty list
		assertEquals(true, emptyList.isEmpty());

		// test isEmpty on a list after removing its only item
		oneItemList.remove("Hello");
		assertEquals(true, oneItemList.isEmpty());
	}

	@Test
	public void testIterator() 
	{	
		/* Test hasNext() */
		
		// initialize counters
		int manyCounter = 0;
		int oneCounter = 0;
		int emptyCounter = 0;
		
		// initialize iterators
		Iterator<String> manyIterator = manyItemsList.iterator();
		Iterator<String> oneIterator = oneItemList.iterator();
		Iterator<String> emptyIterator = emptyList.iterator();
		Iterator<String> fifteenItemsIterator = fifteenItemsList.iterator();
		Iterator<String> tenItemsIterator = tenItemsList.iterator();

		// test hasNext() on set of many elements
		while(manyIterator.hasNext())
		{
			manyCounter++;
			manyIterator.next();
		}
					
		assertEquals(3, manyCounter);

		// test hasNext() on set of one element
		while(oneIterator.hasNext())
		{
			oneCounter++;
			oneIterator.next();
		}
			

		assertEquals(1,oneCounter);

		// test hasNext() on empty set
		while(emptyIterator.hasNext())
		{
			emptyCounter++;
			emptyIterator.next();
		}

		assertEquals(0, emptyCounter);
		assertFalse(emptyIterator.hasNext());

	}
	
	@Test
	public void testIteratorNext()
	{
		Iterator<String> tenItemsIterator = tenItemsList.iterator();
		
		// test next() on tenItemsList
		String word1 = "hi";
		while(tenItemsIterator.hasNext())
		{
			word1 = tenItemsIterator.next();
		}
		assertEquals("Word 3", word1);	// the last word in manyItemsList should be "Word 3"
	}
	
	@Test(expected = NoSuchElementException.class)
	public void testIteratorException()
	{
		// test next() on iterator that's at the end
		// should throw the NoSuchElementException
		Iterator<String> manyIterator = manyItemsList.iterator();
		while (manyIterator.hasNext())
			manyIterator.next();
		assertEquals("Five", manyIterator.next());
	}
	@Test
	public void testRemove()
	{
		// remove existing object from set
		assertEquals(true, manyItemsList.remove("Two"));

		// remove nonexistent object from set
		assertEquals(false, manyItemsList.remove("Two"));

		// attempt to remove mismatching type
		assertEquals(false, oneItemList.remove(1));
	}

	@Test
	public void testRemoveAll()
	{
		// remove existing collection from set
		assertEquals(true, manyItemsList.removeAll(stringExisting));

		// remove nonexisting collection from set (same type)
		assertEquals(false, manyItemsList.removeAll(stringNonexisting));

		// remove mismatching type collection from set
		assertEquals(false, manyItemsList.removeAll(intMismatch));
	}

	@Test
	public void testSize()
	{
		// test various size sets
		assertEquals(0, emptyList.size());
		assertEquals(1, oneItemList.size());
		assertEquals(3, manyItemsList.size());
	}

	@Test
	public void testToArray()
	{
		assertArrayEquals(manyItemsLengthArray, manyItemsList.toArray());
	}

}
