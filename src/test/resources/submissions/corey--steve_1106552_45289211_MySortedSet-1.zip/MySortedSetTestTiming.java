package assignment3;

import java.util.ArrayList;
import java.util.Iterator;
/**
 * Class that performs timing tests on MySortedSet
 *  
 * @author Steve Corey & Rebecca Rodriguez
 * @version February 5, 2015
 * 
 */
public class MySortedSetTestTiming
{

	public static void main(String[] args)
	{
		// fill arraylist with numbers 0-100000
		ArrayList<Integer> intal1 = new ArrayList<Integer>();
		for (int i = 0; i < 100000; i++)
			intal1.add(i);

		// add arraylist to set
		MySortedSet<Integer> mssint1 = new MySortedSet<Integer>();
		mssint1.addAll(intal1);

		// start timing experiment

		long startTime, midpointTime, stopTime;

		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000)
		{ // empty block
		}

		// Now, run the test.

		long timesToLoop = 10000;

		startTime = System.nanoTime();

		for (long i = 0; i < timesToLoop; i++)
		{
			//mssint1.contains(49998);
			mssint1.add(1000000);
			mssint1.remove(1000000);
		}

		midpointTime = System.nanoTime();

		// Run an empty loop to capture the cost of running the loop.

		for (long i = 0; i < timesToLoop; i++)
		{ 
			//mssint1.remove(1000000);
		}

		stopTime = System.nanoTime();

		// Compute the time, subtract the cost of running the loop
		// from the cost of running the loop and computing square roots.
		// Average it over the number of runs.

		double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
				/ timesToLoop;

		System.out.println("It takes exactly " + averageTime
				+ " nanoseconds to call the method on the"
				+ " number.");
//		System.out.println("Size of set = " + mssint1.size());
	}

}
