/**
 * A set that provides a total ordering on its elements. The elements are 
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * The type of elements maintained by this set must either have a natural ordering
 * or must send in a comparator into the constructor
 * 
 *  @param <E>
 *            -- the type of elements maintained by this set
 *            
 * @author Kara Douville and Jamey Sciammarella
 */
package assignment3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> {

	// Maybe SortedSet[] because that means any object that
	// implements SortedSet can be added to the array regardless
	// of its actual type.
	public Object[] items;

	private int elementCount;

	private int capacity;

	private Comparator<? super E> comparator;

	/**
	 * Constructor used to create a sorted set
	 * 
	 * Assumed that the elements are ordered using natural ordering
	 */
	public MySortedSet() {
		this.comparator = null;
		capacity = 10;
		elementCount = 0;
		items = new Object[10];
	}

	/**
	 * Constructor used to created the sorted set
	 * 
	 * Assumed that the elements are ordered using a comparator
	 * 
	 * @param comparator
	 *            - comparator used to order the elements
	 */

	public MySortedSet(Comparator<? super E> _comparator) {
		this.comparator = _comparator;
		capacity = 10;
		elementCount = 0;
		items = new Object[10];
	}

	/**
	 * @return comparator - comparator used to order the elements in this set
	 * @return null - if this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		if (this.comparator == null)
			return null;
		else
			return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException {
		if (elementCount == 0)
			throw new NoSuchElementException("No such elememt");
		else
			return (E) items[0];

	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if (elementCount == 0)
			throw new NoSuchElementException("No such elememt");
		else
			return (E) items[elementCount - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) {

		//Check if the array is full
		if (elementCount == capacity)
			growArray(items);

		//Account for adding the first array in the list
		if(elementCount == 0)
		{
			items[0] = o;
			elementCount ++;
			return true;
		}

		//Object added cannot be equal to null
		if (o == null)
			return false;

		int upperBound = elementCount - 1;
		int lowerBound = 0;
		int insertPos = 0;

		int pos = 0;

		//Binary search if no comparator was passed in
		if (comparator == null) {

			while ((upperBound >= lowerBound))
			{
				insertPos = lowerBound + (upperBound - lowerBound)/2;

				if (((Comparable<E>) o).compareTo((E) items[insertPos]) < 0)
					upperBound = insertPos - 1;

				else if (((Comparable<E>) o).compareTo((E) items[insertPos]) > 0)
					lowerBound = insertPos + 1;

				else if (((Comparable<E>) o).compareTo((E) items[insertPos]) == 0)
					return false;
			}
			if (((Comparable<E>) o).compareTo((E) items[insertPos]) > 0) 
				insertPos = insertPos + 1;
		}

		// Comparator was passed in when object was constructed
		// Comparator:
		// returns a negative integer if o1 is less than o2
		// returns a positive integer if o1 is greater than o2
		// returns zero if o1 is less than o2
		else if (comparator != null) {
			while ((upperBound >= lowerBound))
			{
				insertPos = lowerBound + (upperBound - lowerBound)/2;
				
				if (comparator.compare((E) o, (E) items[insertPos]) < 0) 
					upperBound = insertPos - 1;
				else if (comparator.compare((E) o, (E) items[insertPos]) > 0) 
					lowerBound = insertPos + 1;
				 else if (comparator.compare((E) o, (E) items[insertPos]) == 0)
					return false;
			}
			if (comparator.compare((E) o, (E) items[insertPos]) > 0) 
				insertPos = insertPos + 1;	
		}

		//Add item into array and move all other items back
		Object[] sortedArray = new Object[items.length];
		for (int i = 0; i < insertPos; i++)
			sortedArray[i] = items[i];

		sortedArray[insertPos] = o;

		for (int i = insertPos + 1; i < elementCount + 1; i++)
			sortedArray[i] = items[i - 1];

		items = sortedArray;

		elementCount += 1;
		return true;


	}

	/**
	 * Doubles the size of the array when adding an element is no longer
	 * possible due to the original array's size constraints.
	 * 
	 * @param oldArray - array of MySortedSet
	 * @return new array with a length twice as long as the original
	 *
	 */
	private void growArray(Object[] oldArray) {
		int arraySize = oldArray.length * 2;
		capacity = arraySize;

		Object[] temp = new Object[arraySize];
		for (int i = 0; i < oldArray.length; i++)
			temp[i] = oldArray[i];
		items = temp;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
		Object[] collection = (Object[]) c.toArray();
		for (int i = 0; i < collection.length; i++)
			add((E) collection[i]);
		
		return true;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		for (int i = 0; i < items.length; i++)
			items[i] = null;
		elementCount = 0;
	}

	/**
	 * @param o -- element whose presence in this set is to be tested
	 * @return true - if this set contains the specified element
	 * @return false - if object is not in the set
	 */
	public boolean contains(Object o) {
		if (o == null) 
			return false;
		if (comparator == null) {
			for (int i = 0; i < elementCount; i++)
				if (((Comparable<E>) o).compareTo((E) items[i]) == 0)
					return true;
		} else {
			for (int i = 0; i < elementCount; i++)
				if (comparator.compare((E) o, (E) items[i]) == 0)
					return true;
		}
		return false;
	}

	/**
	 * @param c -- collection to be checked for containment in this set
	 * @return true - if this set contains all of the elements of the specified
	 *         collection
	 *  @return false - if the set does not contain every element in the collection
	 */
	public boolean containsAll(Collection<?> c) {
		Object[] collection = c.toArray();
		for (int i = 0; i < collection.length; i++)
			if (!contains(collection[i]))
				return false;
		return true;

	}

	/**
	 * @return true if this set contains no elements
	 * @return false if this set contains one or more elements
	 */
	public boolean isEmpty() {
		if (elementCount == 0)
			return true;
		else
			return false;
	}


	/**
	 * type parameter: <E> - type of elements returned by iterator
	 * 
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		return new Iterator<E>(){

			private int position = 0;

			/**
			 * Returns true if the iteration has more elements
			 * 
			 * @return true - if the iteration has more elements
			 * @return false - if the iteration has no more elements
			 */
			public boolean hasNext() {
				if (items[position] == null || position == (items.length - 1))
					return false;

				return true;
			}

			/**
			 * Returns the next element in the iteration
			 * 
			 * @return - the next element in the iteration
			 * 
			 * @throws NoSuchElementException
			 *             - if the iteration has no more elements
			 */
			public E next() throws NoSuchElementException {
				if (!hasNext())
					throw new NoSuchElementException();
				else {
					position += 1;
					return (E) items[position - 1];
				}
			}

			/**
			 * Removes from the underlying collection the last element returned by
			 * the iterator.
			 * 
			 * Can only be called once per call to next()
			 * 
			 * Behavior is unspecified if the collection is modified while the
			 * iteration is in progress in any way other than by calling this
			 * method.
			 * 
			 * @throws UnsupportedOperationException
			 *             - if the remove operation is not supported by this
			 *             iterator
			 * 
			 * @throws IllegalStateException
			 *             - if the next method has not yet been called, or the
			 *             remove method has already been called after the last call
			 *             to the next method
			 */
			public void remove() {
				Object[] newArray = new Object[items.length];
				for (int i = 0; i < position; i++)
					newArray[i] = items[i];
				for (int i = 0; i < newArray.length; i++)
					newArray[i] = items[i + 1];
				position--;

			}
		};
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		if (o == null)
			return false;

		int position = 0;
		int removePos = -1;
		int upperBound = elementCount - 1;
		int lowerBound = 0;

		if (comparator == null) {

			while(upperBound >= lowerBound)
			{
				position = lowerBound + (upperBound - lowerBound)/2;
				if (((Comparable<E>) o).compareTo((E) items[position]) < 0)
					upperBound = position - 1;
				else if (((Comparable<E>) o).compareTo((E) items[position]) > 0)
					lowerBound = position + 1;	
				else if (((Comparable<E>) o).compareTo((E) items[position]) == 0)
				{
					removePos = position;
					break;	
				}
			}
		}
		// Comparator:
		// returns a negative integer if o1 is less than o2
		// returns a positive integer if o1 is greater than o2
		// returns zero if o1 is less than o2
		else if (comparator != null) {
			while ((upperBound >= lowerBound)) 
			{
				position = lowerBound + (upperBound - lowerBound)/2;
				if (comparator.compare((E) o, (E) items[position]) < 0) {
					upperBound = position - 1;
				} else if (comparator.compare((E) o, (E) items[position]) > 0) {
					lowerBound = position + 1;
				} else if (comparator.compare((E) o, (E) items[position]) == 0)
				{
					removePos = position;
					break;
				}
			}
		}

		// Return to caller if item was not found in set 
		if (removePos == -1)
			return false;

		//Remove item at specified position
		Object[] sortedArray = new Object[items.length];
		for (int i = 0; i < removePos; i++)
			sortedArray[i] = items[i];

		for (int i = removePos; i < elementCount - 1; i++)
			sortedArray[i] = items[i + 1];

		elementCount -= 1;
		items = sortedArray;
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		boolean changed = false;
		Object[] collection = c.toArray();
		for (int i = 0; i < collection.length; i++)
			if (contains(collection[i])) {
				remove(collection[i]);
				changed = true;
			}
		return changed;
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size() {
		return elementCount;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		Object[] array = new Object[items.length];
		for(int i = 0; i < items.length; i++)
			array[i] = items[i];

		return array;
	}

	public Object length() {
		// TODO Auto-generated method stub
		return null;
	}

}