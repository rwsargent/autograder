/**
 * 
 * @author Kara Douville and Jamey Sciammarella 
 */
package assignment3;

import java.util.GregorianCalendar;

public class LibraryBookGeneric<Type> extends Book {

	public Type holder;

	public GregorianCalendar dueDate;

	public LibraryBookGeneric(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);

		// TODO Auto-generated constructor stub
	}

	/**
	 * Returns the holder of the book as a string
	 * 
	 * @return holder - person who checked out the book
	 */
	public Type getHolder() {
		return this.holder;
	}

	/**
	 * Returns the book's due date represented by a Gregorian Calendar
	 * 
	 * @return dueDate - date the book is due
	 */
	public GregorianCalendar getDueDate() {
		return this.dueDate;
	}

	/**
	 * Method for checking a book in. Sets both the due date and holder to null
	 */
	public void checkIn() {
		this.dueDate = null;
		this.holder = null;
	}

	/**
	 * Method for checking a book out.
	 * 
	 * @param _holder
	 *            - person checking out the book
	 * @param _dueDate
	 *            - date the book is due, represented by a Gregorian Calendar
	 */
	public void checkOut(Type _holder, GregorianCalendar _dueDate) {
		this.dueDate = _dueDate;
		this.holder = _holder;
	}

	// Do not override the equals method in Book.

}
