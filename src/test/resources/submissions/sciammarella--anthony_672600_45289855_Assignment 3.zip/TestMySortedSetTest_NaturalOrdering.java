package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import assignment2.PhoneNumber;

public class TestMySortedSetTest_NaturalOrdering {

	MySortedSet<Integer> intSet;
	
	ArrayList<Integer> list;

	Object[] test1;
	Object[] test2;
	Object[] test3;
	Object[] test4;
	Object[] test5;
	Object[] test6;
	Object[] test7;

	Integer zero;
	Integer one;
	Integer two;
	Integer three;
	Integer four;
	Integer five;
	Integer six;

	@Before
	public void setUp() throws Exception {

		intSet = new MySortedSet<Integer>();
		
		list = new ArrayList<Integer>();

		zero = new Integer(0);
		one = new Integer(1);
		two = new Integer(2);
		three = new Integer(3);
		four = new Integer(4);
		five = new Integer(5);
		six = new Integer(6);
		
		list.add(two);
		list.add(three);
		list.add(five);
		list.add(six);

		//Array with one item
		test2 = new Object[10];
		test2[0] = 0;
		

		//Array with  three items
		test3 = new Object[10];
		test3[0] = 0;
		test3[1] = 1;
		test3[2] = 2;
		
		//Array with first item removed
		test4 = new Object [10];
		test4[0] = 1;
		test4[1] = 2;
		
		//Array with entries that have also been added to list
		test5 = new Object [10];
		test5[0] = 2;
		test5[1] = 3;
		test5[2] = 5;
		test5[3] = 6;
		
		//Array with all items added in natual order by author
		test6 = new Object [10];
		test6[0] = 1;
		test6[1] = 2;
		test6[2] = 3;
		test6[3] = 4;
		test6[4] = 5;
		test6[5] = 6;
		
		//Array with all items from the collection removed
		test7 = new Object [10];
		test7[0] = 1;
		test7[1] = 4;
		

	}

	@After
	public void tearDown() throws Exception {
	}

	//test that .isEmpty method returns true if the set is empty
	@Test
	public void testIsEmpty1(){
		assertEquals(true, intSet.isEmpty());
	}

	//test that .isEmpty method returns false if the set is not empty 
	@Test
	public void testIsEmpty2(){
		intSet.add(zero);
		assertEquals(false, intSet.isEmpty());
	}


	//test .add method returns true if item is successfully added
	@Test
	public void testAdd1(){
		assertEquals(true, intSet.add(zero));
	}

	//test if .add method successfully added items to the set
	@Test
	public void testAdd2(){
		intSet.add(zero);
		intSet.add(one);
		intSet.add(two);
		assertEquals(test3, intSet.toArray());

	}

	//test if .first method returns correct first item
	@Test
	public void testFirst1(){
		intSet.add(zero);
		intSet.add(one);
		assertEquals(test3[0], intSet.first());
	}

	//test if .first method throws NoSuchElementException if set is empty
	@Test(expected = NoSuchElementException.class)
	public void testFirst2(){
		intSet.first();
	}

	//test if .last method returns correct last item
	@Test
	public void testLast1(){
		intSet.add(zero);
		intSet.add(one);
		intSet.add(two);
		assertEquals(test3[2], intSet.last());
	}

	//test .last method when there is one element in the set
	@Test
	public void testLast2(){
		intSet.add(zero);
		assertEquals(test3[0], intSet.last());

	}

	//test .last method when there are no elements in the set
	@Test (expected = NoSuchElementException.class)
	public void testLast3()
	{
		intSet.last();
	}

	//test if .addAll method returns true when elements are correctly added to empty set
	@Test
	public void testAddAll1()
	{	
		assertEquals(true,intSet.addAll(list));
	}

	//test if .addAll method correctly adds elements to empty set
	@Test
	public void testAddAll2(){
		intSet.addAll(list);
		assertEquals(test5, intSet.toArray());
	}

	//test if .addAll method does not add items already present in the set
	// book2, book3, book5 and book6 are in the collection
	@Test
	public void testAddAll3(){
		intSet.add(one);
		intSet.add(three);
		intSet.add(four);
		intSet.addAll(list);
		assertEquals(test6, intSet.toArray());
	}


	//test if .clear method removes all items from the set
	@Test
	public void testClear1(){
		intSet.add(six);
		intSet.add(two);
		intSet.add(one);
		intSet.clear();
		assertEquals(0, intSet.size());
	}

	//test if .clear method removes if there are no items in the set
	@Test 
	public void testClear2(){
		intSet.clear();
		assertEquals(0, intSet.size());
	}

	//test .contains method when element is present in the set
	@Test
	public void testContains1(){
		intSet.add(zero);
		intSet.add(one);
		intSet.add(five);

		assertEquals(true, intSet.contains(one));
	}

	//test .contains method when element is not present in the set 
	@Test
	public void testContains2() {
		intSet.add(one);
		intSet.add(two);
		intSet.add(three);

		assertEquals(false, intSet.contains(four));
	}

	//test .containsAll method when all elements in collection are present in the set
	@Test
	public void testContainsAll1()
	{
		intSet.add(two);
		intSet.add(five);
		intSet.add(three);
		intSet.add(six);
		assertEquals(true, intSet.containsAll(list));
	}

	//test .containsAll method when only some elements in a collection are present in the set
	@Test
	public void testContainsAll2(){
		intSet.add(five);
		intSet.add(six);
		assertEquals(false, intSet.containsAll(list));

	}

	//test .containsAll method when no elements in a collection are present in the set
	@Test
	public void testContainsAll3(){
		intSet.add(one);
		intSet.add(four);
		assertEquals(false, intSet.containsAll(list));

	}

	//test if .remove method returns true when element is present in the set
	@Test
	public void testRemove1(){
		intSet.add(one);
		intSet.add(two);
		intSet.add(three);

		assertEquals(true, intSet.remove(one));
	}

	//test if .remove method successfully removes element in the set
	//if the two arrays are equal, check is true 
	@Test
	public void testRemove2(){
		intSet.add(zero);
		intSet.add(one);
		intSet.add(two);

		intSet.remove(zero);

		assertEquals(test4, intSet.toArray());
	}

	//test. remove method when the set is empty
	@Test 
	public void testRemove3(){
		assertEquals(false, intSet.remove(one));
	}

	//test. remove method when element is not present in the set
	@Test 
	public void testRemove4(){
		assertEquals(false, intSet.remove(one));
	}

	//test if .removeAll removes all of the elements that are found in the collection from the set
	@Test
	public void testRemoveAll1(){
		intSet.add(one);
		intSet.add(two);
		intSet.add(three);
		intSet.add(five);
		intSet.add(four);
		intSet.add(six);
		intSet.removeAll(list);
		assertEquals(intSet.toArray(), test7);

	}

	//test .removeAll when no elements from the collection are in the set
	@Test 
	public void testRemoveAll2(){
		intSet.add(one);
		intSet.add(four);
		assertEquals(false, intSet.removeAll(list));
	}

	//test if .size correctly returns the number of elements in the set
	@Test
	public void testSize1(){
		intSet.add(one);
		intSet.add(five);
		assertEquals(2, intSet.size());
	}

	//test .size if there is no elements in the set
	@Test
	public void testSize2(){
		assertEquals(0, intSet.size());
	}

	//test create the iterator and make sure it runs though our list
	@Test
	public void testIterator1()
	{	
		intSet.add(zero);
		intSet.add(one);
		intSet.add(two);

		Iterator<Integer> test = intSet.iterator();
		Object[] array = new Object[10];
		int index = 0;

		//Iterate through the list and store in an array
		while(test.hasNext())
		{
			array[index] = test.next();	
			index++;
		}		
		assertEquals(test3, array);
	}




}
