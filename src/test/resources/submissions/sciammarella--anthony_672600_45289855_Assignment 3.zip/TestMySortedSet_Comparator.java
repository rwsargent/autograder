/**
 * @author Jamey Sciammarella and Kara Douville
 */
package assignment3;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import assignment2.LibraryBook;
import assignment2.LibraryGeneric;
import assignment2.PhoneNumber;

public class TestMySortedSet_Comparator {
	
	OrderByIsbn comparator;
	File books_100000;
	File books_200000;
	File books_300000;
	File books_400000;
	File books_500000;
	File books_600000;
	File books_700000;
	File books_800000;
	File books_900000;
	File books_1000000;
	File books;
	
	ArrayList<LibraryBookGeneric<PhoneNumber>> list;
	
	
	//Create a library to which we add library books to using MySortedSet
	public MySortedSet<LibraryBookGeneric<PhoneNumber>> library;

	LibraryBookGeneric<PhoneNumber>book1 = new LibraryBookGeneric<PhoneNumber>(1255555555L, "Thomas L. Friedman", "The World is Flat");
	LibraryBookGeneric<PhoneNumber>book2 = new LibraryBookGeneric<PhoneNumber>(2333344444L, "Jon Krakauer", "Into the Wild");
	LibraryBookGeneric<PhoneNumber>book3 = new LibraryBookGeneric<PhoneNumber>(3465677777L, "David Baldacci", "Simple Genius");
	LibraryBookGeneric<PhoneNumber>book4 = new LibraryBookGeneric<PhoneNumber>(4292384777L, "Kara C Douville", "Life is a Game");
	LibraryBookGeneric<PhoneNumber>book5 = new LibraryBookGeneric<PhoneNumber>(5934777777L, "John Smith", "Code Testing for Idiots");
	LibraryBookGeneric<PhoneNumber>book6 = new LibraryBookGeneric<PhoneNumber>(6646580378L, "Henry Ford", "Game Face");
	
	
	Object[] test1;
	Object[] test2;
	Object[] test3;
	Object[] test4;
	Object[] test5;
	Object[] test6;
	Object[] test7;
	
	@Before
	public void setUp() throws Exception 
	{
		comparator = new OrderByIsbn();
		
		books_100000 = new File("Mushroom_Publishing_100000.txt");
		books_200000 = new File("Mushroom_Publishing_200000.txt");
		books_300000 = new File("Mushroom_Publishing_300000.txt");
		books_400000 = new File("Mushroom_Publishing_400000.txt");
		books_500000 = new File("Mushroom_Publishing_500000.txt");
		books_600000 = new File("Mushroom_Publishing_600000.txt");
		books_600000 = new File("Mushroom_Publishing_700000.txt");
		books_600000 = new File("Mushroom_Publishing_800000.txt");
		books_600000 = new File("Mushroom_Publishing_900000.txt");
		books_600000 = new File("Mushroom_Publishing_1000000.txt");
		
		list = new ArrayList<LibraryBookGeneric<PhoneNumber>>();
		
		library = new MySortedSet<LibraryBookGeneric<PhoneNumber>>(comparator);
		
		
		list.add(book2);
		list.add(book3);
		list.add(book5);
		list.add(book6);
		
		//Create arrays to test MySortedSet arrays against
		//Array with no entries
		test1 = new Object [10];
		
		//Array with two entry
		test2 = new Object [10];
		test2[0] = book1;
		test2[1] = book2;
	
		//Array with three entries
		test3 = new Object [10];
		test3[0] = book1;
		test3[1] = book2;
		test3[2] = book3;
		
		//Array with book1 removed
		test4 = new Object [10];
		test4[0] = book2;
		test4[1] = book3;
		
		//Array with entries that have been added to collection
		test5 = new Object [10];
		test5[0] = book2;
		test5[1] = book3;
		test5[2] = book5;
		test5[3] = book6;
		
		//Array with all books added in order by isbn
		test6 = new Object [10];
		test6[0] = book1;
		test6[1] = book2;
		test6[2] = book3;
		test6[3] = book4;
		test6[4] = book5;
		test6[5] = book6;
		
		//Array with all items from the collection removed
		test7 = new Object [10];
		test7[0] = book1;
		test7[1] = book4;
	

	}

	@After
	public void tearDown() throws Exception 
	{
		
	}

	//test that .isEmpty method returns true if the set is empty
	@Test
	public void testIsEmpty1(){
		assertEquals(true, library.isEmpty());
	}

	//test that .isEmpty method returns false if the set is not empty 
	@Test
	public void testIsEmpty2(){
		library.add(book1);
		assertEquals(false, library.isEmpty());
	}
	
	
	//test .add method returns true if item is successfully added
	@Test
	public void testAdd1(){
		assertEquals(true, library.add(book1));
	}
	
	//test if .add method successfully added book 1 and book2 to the set
	@Test
	public void testAdd2(){
		library.add(book1);
		library.add(book2);
		assertEquals(test2, library.toArray());	
	}
	
	//test if .first method returns correct first item
	@Test
	public void testFirst1(){
		library.add(book1);
		library.add(book2);
		assertEquals(test2[0], library.first());
	}
	
	//test if .first method throws NoSuchElementException if set is empty
	@Test(expected = NoSuchElementException.class)
	public void testFirst2(){
		library.first();
	}
	
	//test if .last method returns correct last item
	@Test
	public void testLast1(){
		library.add(book1);
		library.add(book2);
		library.add(book3);
		assertEquals(test3[2], library.last());
	}
	
	//test .last method when there is one element in the set
	@Test
	public void testLast2(){
		library.add(book1);
		assertEquals(test2[0], library.last());
	
	}
	
	//test .last method when there are no elements in the set
	@Test (expected = NoSuchElementException.class)
	public void testLast3()
	{
		library.last();
	}
	
	//test if .addAll method returns true when elements are correctly added to empty set
	@Test
	public void testAddAll1()
	{	
		
		assertEquals(true,library.addAll(list));
	}
	
	//test if .addAll method correctly adds elements to empty set
	@Test
	public void testAddAll2(){
		library.addAll(list);
		assertEquals(test5, library.toArray());
	}

	//test if .addAll method does not add items already present in the set
	// book2, book3, book5 and book6 are in the collection
	@Test
	public void testAddAll3(){
		library.add(book1);
		library.add(book2);
		library.add(book3);
		library.add(book4);
		library.addAll(list);
		
		Object[] array = library.toArray();
		for(int i = 0; i < array.length; i++)
			System.out.println(array[i]);
				
		assertEquals(test6, library.toArray());
		
		
	}
	
	
	//test if .clear method removes all items from the set
	@Test
	public void testClear1(){
		library.add(book1);
		library.add(book2);
		library.add(book3);
		library.clear();
		assertEquals(0, library.size());
	}
	
	//test if .clear method removes if there are no items in the set
	@Test 
	public void testClear2(){
		library.clear();
		assertEquals(0, library.size());
	}
	
	//test .contains method when element is present in the set
	@Test
	public void testContains1(){
		library.add(book1);
		library.add(book2);
		library.add(book3);
		
		assertEquals(true, library.contains(book1));
	}
	
	//test .contains method when element is not present in the set 
	@Test
	public void testContains2() {
		library.add(book1);
		library.add(book2);
		library.add(book3);
		
		assertEquals(false, library.contains(book4));
	}
	
	//test .containsAll method when all elements in collection are present in the set
	@Test
	public void testContainsAll1()
	{
		library.add(book2);
		library.add(book3);
		library.add(book5);
		library.add(book6);
		assertEquals(true, library.containsAll(list));
	}
	
	//test .containsAll method when only some elements in a collection are present in the set
	@Test
	public void testContainsAll2(){
		library.add(book5);
		library.add(book6);
		assertEquals(false, library.containsAll(list));
		
	}
	
	//test .containsAll method when no elements in a collection are present in the set
	@Test
	public void testContainsAll3(){
		library.add(book1);
		library.add(book4);
		assertEquals(false, library.containsAll(list));
		
	}
	
	//test if .remove method returns true when element is present in the set
	@Test
	public void testRemove1(){
		library.add(book1);
		library.add(book2);
		library.add(book3);
		
		assertEquals(true, library.remove(book1));
	}
	
	//test if .remove method successfully removes element in the set
	//if the two arrays are equal, check is true 
	@Test
	public void testRemove2(){
		library.add(book1);
		library.add(book2);
		library.add(book3);
		
		library.remove(book1);
			
		assertEquals(test4, library.toArray());
	}
	
	//test. remove method when the set is empty
	@Test 
	public void testRemove3(){
		assertEquals(false, library.remove(book1));
	}
	
	//test. remove method when element is not present in the set
	@Test 
	public void testRemove4(){
		assertEquals(false, library.remove(book1));
	}
	
	//test if .removeAll removes all of the elements that are found in the collection from the set
	@Test
	public void testRemoveAll1(){
		library.add(book1);
		library.add(book2);
		library.add(book3);
		library.add(book4);
		library.add(book5);
		library.add(book6);
		library.removeAll(list);
		assertEquals(library.toArray(), test7);
		
	}
	
	//test .removeAll when no elements from the collection are in the set
	@Test 
	public void testRemoveAll2(){
		library.add(book1);
		library.add(book4);
		assertEquals(false, library.removeAll(list));
		
	}
	
	//test if .size correctly returns the number of elements in the set
	@Test
	public void testSize1(){
		library.add(book1);
		library.add(book2);
		assertEquals(2, library.size());
	}
	
	//test .size if there is no elements in the set
	@Test
	public void testSize2(){
		assertEquals(0, library.size());
	}
	
	//test create the iterator and make sure it runs though our list
	@Test
	public void testIterator1()
	{	
		library.add(book1);
		library.add(book2);
		library.add(book3);
		
		Iterator<LibraryBookGeneric<PhoneNumber>> test = library.iterator();
		Object[] array = new Object[10];
		int index = 0;
		
		//Iterate through the list and store in an array
		while(test.hasNext())
		{
			array[index] = test.next();	
			index++;
		}		
		assertEquals(test3, array);
		
	}
	
	
		//Timing testing
		@Test
		public void testThousands()
		{
			
			//Add a known book
			library.add(book2);
			
			//Add 100,000 books from a file..
			try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			System.out.println("Books Added: " + library.size());
			
			
			// First, spin computing stuff until one second has gone by.
		    // This allows this thread to stabilize.

			long startTime, midpointTime, stopTime;
		    startTime = System.nanoTime();
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    long timesToLoop = 50;

		    startTime = System.nanoTime();

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 100,000 "
		        + " books.");	
				
		    
		    //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 200,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 300,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 400,000 "
		        + " books.");
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 500,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 500,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 600,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 700,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 800,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 900,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 1,000,000 "
		        + " books.");//Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 200,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 300,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 400,000 "
		        + " books.");
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 500,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 500,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 600,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 700,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 800,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 900,000 "
		        + " books.");
		    
		  //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 1,000,000 "
		        + " books.");
		    
		    //Double the list
		    try {
				Scanner fileIn = new Scanner(books_100000);
				int lineNum = 1;

				while (fileIn.hasNextLine()) {
					String line = fileIn.nextLine();

					Scanner lineIn = new Scanner(line);
					lineIn.useDelimiter("\\t");

					if (!lineIn.hasNextLong())
						throw new ParseException("ISBN", lineNum);
					long isbn = lineIn.nextLong();

					if (!lineIn.hasNext())
						throw new ParseException("Author", lineNum);
					String author = lineIn.next();

					if (!lineIn.hasNext())
						throw new ParseException("Title", lineNum);
					String title = lineIn.next();

					library.add(new LibraryBookGeneric<PhoneNumber>(isbn, author, title));

					lineNum++;

				}

			}

			catch (FileNotFoundException e) {
				System.err.println(e.getMessage()
						+ " Nothing added to the library.");
				return;
			} catch (ParseException e) {
				System.err.println(e.getLocalizedMessage()
						+ " formatted incorrectly at line " + e.getErrorOffset()
						+ ". Nothing added to the library.");
				return;
			}
			
			
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    for (long i = 0; i < timesToLoop; i++)
		    	library.contains(book2);
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + (averageTime/1000000000)
		        + " seconds find a book in a list of 2,000,000 "
		        + " books.");
		}

	
	/**
	 * Create comparator to test a set with a type that does not have a natural ordering - 
	 * defines an ordering among library books using the author, and book title as a tie-breaker.
	 * 
	 * Although String has a natural ordering - lexicographic - we want to make sure our
	 * own comparator works, by later comparing it against String's own comparable method.
	 *
	 * Comparator that defines an ordering among library books using the ISBN.
	 */
	protected class OrderByIsbn implements Comparator<LibraryBookGeneric<PhoneNumber>> {

		/**
		 * Returns a negative value if lhs is smaller than rhs. Returns a
		 * positive value if lhs is larger than rhs. Returns 0 if lhs and rhs
		 * are equal.
		 */
		public int compare(LibraryBookGeneric<PhoneNumber> lhs,
				LibraryBookGeneric<PhoneNumber> rhs) {
			return (int) (rhs.getIsbn() -
					lhs.getIsbn());
		}

	}
		
	}



