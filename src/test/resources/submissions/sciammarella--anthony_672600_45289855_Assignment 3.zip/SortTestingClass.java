
package assignment3;

import java.util.ArrayList;
import java.util.Collection;

public class SortTestingClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Object[] integerArray3 = new Integer[] {1,2,3,4,5,6,7,8,9,0};
		Integer[] integerArray4 = new Integer[] {3};
		MySortedSet<Integer> test = new MySortedSet<Integer>();
		
		if(test.isEmpty())
			System.out.println("Array is empty");
		else
			System.err.println("isEmpty fail");
		
		

		
		if(test.add(new Integer(4)))		
			System.out.println("test 1");
		else
			System.out.println("nope");
		
		
		
		if(test.add(new Integer(1)))		
			System.out.println("test 2");
		else
			System.out.println("nope");
		
		
		if(test.add(new Integer(5)))		
			System.out.println("test 3");
		else
			System.out.println("nope");
		
		
		if(test.add(new Integer(100)))		
			System.out.println("test 4");
		else
			System.out.println("nope");
		
	
		
		
		if(test.add(new Integer(897)))		
			System.out.println("test 5");
		else
			System.out.println("please be false");
		
		
		if(test.add(new Integer(4)))		
			System.out.println("test 6");
		else
			System.out.println("nope");
		
		if(test.add(new Integer(5)))		
			System.out.println("test 7");
		else
			System.out.println("nope");
		
		if(test.add(new Integer(5)))		
			System.out.println("test 8");
		else
			System.out.println("nope");
		
		
		if(test.add(new Integer(85)))		
			System.out.println("test 9");
		else
			System.out.println("nope");
		
		
		if(test.add(new Integer(897)))		
			System.out.println("test 10");
		else
			System.out.println("please be false");

		//Array should now be 20 not 10!!!!
		if(test.add(new Integer(5)))		
			System.out.println("test 11");
		else
			System.out.println("nope");
		
		if(test.add(new Integer(5)))		
			System.out.println("test 12");
		else
			System.out.println("nope");
		
		
		if(test.add(new Integer(786)))		
			System.out.println("test 13");
		else
			System.out.println("nope");
		
		
		if(test.add(new Integer(897)))		
			System.out.println("test 14");
		else
			System.out.println("please be false");
		
		System.out.println("\n");
		
		integerArray3 = test.toArray();
		for (int i=0; i<integerArray3.length; i++)
			System.out.println(integerArray3[i]);
		
		//Remove 5
		if(test.remove(new Integer(5)))		
			System.out.println("test 12");
		else
			System.out.println("nope");
	
		
		integerArray3 = test.toArray();
		for (int i=0; i<integerArray3.length; i++)
			System.out.println(integerArray3[i]);
		
		System.out.println(test.first());
		
		
		System.out.println("\n");
		
		
		Integer [] test2 = new Integer[10];
		test2[0]=new Integer(0);
		test2[1]=new Integer(1);
		test2[2]=new Integer(2);
		test2[3]=new Integer(3);
		test2[4]=new Integer(4);
		test2[5]=new Integer(6);
		
		Collection<Integer> test3 = new ArrayList<Integer>();
		test3.add(new Integer(0));
		test3.add(new Integer(1));
		test3.add(new Integer(34));
		test3.add(new Integer(453));
		test3.add(new Integer(348));
		test3.add(new Integer(6890));

		
//		Object[] sortedArray = new Object[test2.length];
//		
//		for (int i = 0; i < 3; i++)
//			sortedArray[i] = test2[i];
//
//		sortedArray[3] = 9;
//
//		for (int i = 3 + 1; i < test2.length; i++)
//			sortedArray[i] = test2[i-1];
//	
//		for(int i = 0; i < test2.length; i++)
//			System.out.println(sortedArray[i]);
//		
//		System.out.println("\n");
		
		test.addAll(test3);
		
		integerArray3 = test.toArray();
		for (int i=0; i<integerArray3.length; i++)
			System.out.println(integerArray3[i]);
		
		
	}

}
