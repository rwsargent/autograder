package assignment3;

import java.util.Random;

public class RunningTimeBinarySearch {

	public static void main(String[] args) {
		long startTime, midpointTime, stopTime;

		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) { // empty block
		}

		// Now, run the test.
		long timesToLoop = 10000;

		Random r = new Random();

		// for(long n = 100000; n< 2000000; n+= 100000){
		long n = 2000000;
		MySortedSet<Integer> timeTest = new MySortedSet<>();
		for (int i = 0; i < n; i++)
			timeTest.add(i);
		timeTest.add(739244);
		startTime = System.nanoTime();

		for (long i = 0; i < timesToLoop; i++) {
			int randomNumber = r.nextInt();
			timeTest.add(randomNumber);
			timeTest.remove(randomNumber);
			timeTest.add(randomNumber);
		}

		midpointTime = System.nanoTime();

		// Run an empty loop to capture the cost of running the loop.

		for (long i = 0; i < timesToLoop; i++) {
			int randomNumber = r.nextInt();
			timeTest.remove(randomNumber);// empty block
		}

		stopTime = System.nanoTime();

		// Compute the time, subtract the cost of running the loop
		// from the cost of running the loop and computing square roots.
		// Average it over the number of runs.
		double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
				/ timesToLoop;
		System.out.println(n + "\t" + averageTime);
	}
}