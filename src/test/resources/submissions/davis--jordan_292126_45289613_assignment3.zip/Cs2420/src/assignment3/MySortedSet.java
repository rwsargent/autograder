package assignment3;

/**
 * assignment3
 * @author Jordan Davis & Jacob Osterloh
 * MySortedSet - Cs 2420
 */

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

	/** 
	 * A set that provides a total ordering on its elements. The elements are
	 * ordered using their natural ordering, or by a Comparator provided at sorted
	 * set creation time. Thus, all elements inserted into a sorted set must
	 * implement the Comparable interface or be accepted by the specified
	 * Comparator. The set's iterator will traverse the set in ascending element
	 * order.
	 *
	 * @author Jordan Davis & Jacob Osterloh 
	 *
	 * @param <E> 
	 *            -- the type of elements maintained by this set
	 */
	
	public class MySortedSet<E> implements SortedSet<E> {
		
		//sorted set used
		private E[] mySet;
		
		//comparator
		private Comparator<? super E> mComparator;
		
		//ammount of items contianed in the set
		private int size;
		
		/**
		 * MySortedSet constructor
		 */
		
		public MySortedSet() {
			//initialize variable
			mySet = (E[]) new Object[10];
			size = 0;
			mComparator = null;
		}
		
		/**
		 * MySortedSet constructor using comparator
		 */
		public MySortedSet(Comparator<? super E> comparator) {
			//initialze variable
			mySet = (E[]) new Object[10];
			size = 0;
			mComparator = comparator;
		}
		
		/** 
		 * @return The comparator used to order the elements in this set, or null if 
		 *         this set uses the natural ordering of its elements (i.e., uses
		 *         Comparable). 
		 */	
		@Override
		public Comparator<? super E> comparator() {
			return mComparator;
		}
		
		
		/**
		 * @return the first (lowest, smallest) element currently in this set
		 * @throws NoSuchElementException
		 *             if the set is empty, returns null
		 */
		@Override
		public E first() throws NoSuchElementException {
			//check if set is empty
			if (this.isEmpty())
				throw new NoSuchElementException();
			else
				//return object at fist index
				return mySet[0];
		}
		
		/**
		 * @return the last (highest, largest) element currently in this set
		 * @throws NoSuchElementException
		 *             if the set is empty, returns null
		 */
		@Override
		public E last() throws NoSuchElementException {
			//check if the set is empty
			if (this.isEmpty())
				throw new NoSuchElementException();
			else
				//return object at last index
				return mySet[size - 1];
		}
		
		/** 
		 * Adds the specified element to this set if it is not already present and 
		 * not set to null.
		 *
		 * @param o 
		 *            -- element to be added to this set
		 * @return true if this set did not already contain the specified element
		 */
		@Override
		public boolean add(E o) {
			//if set is empty, add object to set
			if (this.isEmpty()) {
				mySet[0] = o;
				size++;
				return true;
			} 
			else {
				//if object is null or already contained in set, return false
				if (o == null || this.contains(o)) {
					return false;
				} 
				else {
					//if set is full, doulbe it's size
					if (size == mySet.length - 1) {
						mySet = grow(mySet);
					}
					//find spot to insert object in set
					int index = binarySearch(o, 0, size - 1);
					//compare spot with object to see if it belongs before or after object at current index
					int addIndex = index + compare(o, mySet[index]);
					if (addIndex < 1) {
						//shift array right, starting with last object
						for (int y = size - 1; y >= 0; y--) {
							mySet[y + 1] = mySet[y];
						}
						//add object to set
						mySet[0] = o;
						size++;
						return true;
					} 
					else {
						for (int x = size - 1; x >= addIndex; x--) {
							//shift array right, starting with last object untill addIndex
							mySet[x + 1] = mySet[x];
						}
						//add object to addIndex
						mySet[addIndex] = o;
						size++;
						return true;
					}
				}
			}
		}
		
		/**
		 * Adds all of the elements in the specified collection to this set if they
		 * are not already present and not set to null.
		 * 
		 * @param c
		 *            -- collection containing elements to be added to this set
		 * @return true if this set changed as a result of the call
		 */
		
		@Override
		public boolean addAll(Collection<? extends E> c) {	
			boolean changed = false;
			for (E o : c) {
				//add objects to set, if any object is added to set, return true
				if (this.add(o)) {
					changed = true;
				}
			}
			return changed;
		}
		
		/**
		 * Removes all of the elements from this set. The set will be empty after
		 * this call returns.
		 */
		@Override
		public void clear() {
			//sets mySet to null and resets size
			for(int i = size; i >= 0 ; i--)
				mySet[i]=null;
			size = 0;
		}
		
		/**
		 * @param o
		 *            -- element whose presence in this set is to be tested
		 * @return true if this set contains the specified element
		 */
		
		@Override
		public boolean contains(Object o) {
			//finds location where object should be in set
			int location = binarySearch(o, 0, size - 1);
			//if location is same as object return true
			if (this.compare((E) o, mySet[location]) == 0)
				return true;
			else
				return false;
		}
		
		/**
		 * @param c
		 *            -- collection to be checked for containment in this set
		 * @return true if this set contains all of the elements of the specified
		 *         collection
		 */	
		@Override
		public boolean containsAll(Collection<?> c) {
			boolean changed = true;
			for (Object o : c) {
				//if any object from collection is not contained in set, return false
				if (!this.contains((E) o))
					changed = false;
			}
			return changed;
		}
		
		/**
		 * @return true if this set contains no elements
		 */
		@Override
		public boolean isEmpty() {
			//if empty return true
			if (size == 0)
				return true;
			else
				return false;
		}
		
		/**
		 * @return an iterator over the elements in this set, where the elements are
		 *         returned in sorted (ascending) order
		 */
		@Override
		public Iterator<E> iterator() {
			//new interator
			return new Iterator<E>() {
				int index = -1;
				boolean isValid = false;

				/**
				 * returns true if the iteration has more elements
				 */
				@Override
				public boolean hasNext() {
					//returns true if index is befor last object to array
					return (index < size - 1);
				}
				
				/**
				 * returns the next element in the iteration
				 * @throws NoSuchElementException
				 */
				@Override
				public E next() {
					//sets valid true for remove() method
					isValid = true;
					index++;
					//throw exception if index is larger than array size
					if (index >= size)
						throw new NoSuchElementException();
					return mySet[index];
				}
		
				/**
				 * removes from the underlying collection the last element returned
				 * by this iterator
				 * @throws IllegalStateException
				 */
		
				@Override
				public void remove() {
					// removes object if pointing to valid index
					if (isValid) {
						MySortedSet.this.remove(mySet[index]);
						isValid = false;
						index--;
					} 
					//throws exception if not pointing to valid index
					else
						throw new IllegalStateException();
				}
			};
		}
		
		/**
		 * Removes the specified element from this set if it is present.
		 * 
		 * @param o
		 *            -- object to be removed from this set, if present
		 *             
		 * @return true if this set contained the specified element
		 */
		@Override
		public boolean remove(Object o) {
			//if emtpy return false
			if (this.isEmpty()) {
				return false;
			} 
			//if not in set return false
			else if (!this.contains(o))
				return false;
			else {
				//find location of object to be removed
				int removeSpot = binarySearch(o, 0, size - 1);
				//remove objet. shift all obects right of location to left
				for (int x = removeSpot; x < size; x++)
					mySet[x] = mySet[x + 1];
				size--;
				return true;
			}
		}
		
		
		/**
		 * Removes from this set all of its elements that are contained in the 
		 * specified collection.
		 * 
		 * @param c
		 *            -- collection containing elements to be removed from this set
		 * 
		 * @return true if this set changed as a result of the call
		 */
		@Override
		public boolean removeAll(Collection<?> c) {
			boolean changed = false;
			for (Object o : c) {
				//removes objects in collection from set, if one object has been removed returns true
				if (this.remove((E) o)) {
					changed = true;
				}
			}
			return changed;
		}
		
		
		/** 
		 * @return the number of elements in this set
		 */
		@Override
		public int size() {
			return size;
		}
		
		
		/** 
		 * @return an array containing all of the elements in this set, in sorted
		 *         (ascending) order.
		 */
		@Override
		public Object[] toArray() {
			//create new object array
			Object[] array = new Object[size];
			//add each object from set to new array 
			for (int i = 0; i <= size - 1; i++) {
				array[i] = mySet[i];
			}
			return array;
		}
		
		/**
		 * performes a binary search for the ordered E[] mySet for Object o
		 * 
		 * @param Object
		 *            o
		 * @param first
		 * @param last
		 * @return the position that the object is in the Array -- if o is not
		 *         contained in E[] returns -1
		 */
		public int binarySearch(Object o, int first, int last) {
			
			// set midpoint
			int mid = (first + last) / 2;
			if (first <= last) {
				// if object equals midpoint object return location of mid		
				if (compare(mySet[mid], (E) o) == 0)
					return mid;
				else {
					//change midpoint to re-search next section of array
					if (compare(mySet[mid], (E) o) > 0) {
						last = mid - 1;
					}
					else {
						first = mid + 1;
					}
					//call recurive method
					mid = binarySearch(o, first, last);
				}
			}
			//return location where object should be in array
			return mid;
		}
		
		/**
		 * Helper method to compare items and checks if sorted by Comparator or
		 * Comparable
		 * 
		 * @param item1
		 * @param item2
		 * @return -1 if item1 is less than item2. 0 if equal. +1  if item1 is greater
		 *         than item2.
		 */
		
		private int compare(E item1, E item2) {
			if (mComparator == null)
				//checks if object needs to be placed before, after, or at location
				if (((Comparable) item1).compareTo(item2) > 0)
					return 1;
				else if (((Comparable) item1).compareTo(item2) == 0)
					return 0;
				else
					return -1;
			else
				//checks if object needs to be placed before, after, or at location
			if (mComparator.compare(item1, item2) > 0)
				return 1;
			else if ((mComparator.compare(item1, item2) == 0))
				return 0;
			else
				return -1;
		}
		
		/**
		 * doubles the size of the set. if set equals 0 or null, creates a size 1
		 * array
		 * 
		 * @param mySet
		 * @return
		 */
		private E[] grow(E[] mySet) {
			//create new array with double the size of set
			E[] tmp = (E[]) new Object[2 * mySet.length];
			//copy each item from set to array
			for (int i = 0; i < mySet.length; i++)
				tmp[i] = mySet[i];
			//set mySet to doulbed set
			mySet = tmp;
			return mySet;
		}
}