package assignment3;

/**
 * assignment3
 * @author Jordan Davis & Jacob Osterloh
 * MySortedSetTest - Cs 2420
 */


import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Test;


public class MySortedSetTest {

	
	//sets used for testing
	MySortedSet <Integer> emptyTest = new MySortedSet <Integer>();
	MySortedSet <Integer> test = new MySortedSet <Integer>();
	ArrayList <Integer> collectionTest = new ArrayList <Integer>();
	MySortedSet <Integer> comparatorTestAdd;
	MySortedSet <Integer> comparatorTestFirst;
	MySortedSet <Integer> comparatorTestLast;
	MySortedSet <Integer> comparatorTestAddAll;
	MySortedSet <Integer> comparatorTestClear;
	MySortedSet <Integer> comparatorTestRemove;
	MySortedSet <Integer> comparatorTestRemoveAll;
	MySortedSet <Integer> comparatorTestToArray;
	MySortedSet <Integer> comparatorIterator;
	MySortedSet <Integer> comparatorTestContains;
	MySortedSet <Integer> comparatorTestEmpty;


	//tests exception in first() method
	@Test(expected=NoSuchElementException.class)
	public void findFirstTestException() {
		emptyTest.first();
	}
	
	
	/**
	 * tests first() method
	 */
	@Test
	public void findFirstTest() {
		test.add(3);
		//first object in set is 3
		assertSame(3,(Integer)test.first());
		test.add(9);
		//first object in set is still 3
		assertSame(3,(Integer)test.first());
		test.add(2);
		//first object in set is now 2
		assertSame(2,(Integer)test.first());
	}
	
	/**
	 * tests first() method using comparator
	 */
	@Test
	public void findFirstComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestFirst = new MySortedSet(descendingOrder);
		
		comparatorTestFirst.clear();
		comparatorTestFirst.add(3);
		//first object in set is 3
		assertSame(3,(Integer)comparatorTestFirst.first());
		comparatorTestFirst.add(35);
		//first object in set is now 3
		assertSame(35,(Integer)comparatorTestFirst.first());
		comparatorTestFirst.add(2);
		//first object in set is still 35
		assertSame(35,(Integer)comparatorTestFirst.first());
	}
	
	/**
	 * test last() method
	 */
	@Test
	public void findLastTest() {
		test.clear();
		test.add(4);
		//last object in set is 4
		assertSame(4,(Integer)test.last());
		test.add(2);
		//last object is set is still 4
		assertSame(4,(Integer)test.last());
		test.add(8);
		//last object in set is now 8
		assertSame(8,(Integer)test.last());

	}
	
	
	/**
	 * test last() method using comparator
	 */
	@Test
	public void findLastComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestLast = new MySortedSet(descendingOrder);
		
		comparatorTestLast.clear();
		comparatorTestLast.add(4);
		//last object in set is 4
		assertSame(4,(Integer)comparatorTestLast.last());
		comparatorTestLast.add(2);
		//last object in set is 2
		assertSame(2,(Integer)comparatorTestLast.last());
		comparatorTestLast.add(8);
		//last object in set is still 2
		assertSame(2,(Integer)comparatorTestLast.last());
	}
	
	//test exception for last() method
	@Test(expected=NoSuchElementException.class)
	public void findLastTestException() {
		emptyTest.last();
	}
	
	/**
	 * test the add() method
	 */
	@Test
	public void addTest() {
		test.clear();
		
		//adding should result in true
		assertEquals(true,test.add(7));
		assertEquals(true,test.add(6));
		assertEquals(true,test.add(5));
		assertEquals(true,test.add(10));
		assertEquals(true,test.add(8));
		assertEquals(true,test.add(11));
		assertEquals(true,test.add(12));
		assertEquals(true,test.add(13));
		assertEquals(true,test.add(14));
		assertEquals(true,test.add(15));
		
		//already added to set: should be false
		assertEquals(false,test.add(7));
		assertEquals(false,test.add(7));
		assertEquals(false,test.add(6));
		assertEquals(false,test.add(5));
		assertEquals(false,test.add(10));
		assertEquals(false,test.add(8));
		assertEquals(false,test.add(11));

	}
	
	/**
	 * test the add() method using a comparator
	 */
	@Test
	public void addTestComparator() {
		//create a new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestAdd = new MySortedSet(descendingOrder);
		
		comparatorTestAdd.clear();
		
		//adding should result in true
		assertEquals(true,comparatorTestAdd.add(7));
		assertEquals(true,comparatorTestAdd.add(6));
		assertEquals(true,comparatorTestAdd.add(5));
		assertEquals(true,comparatorTestAdd.add(10));
		assertEquals(true,comparatorTestAdd.add(8));
		assertEquals(true,comparatorTestAdd.add(11));
		
		//these already exist in set: should return false
		assertEquals(false,comparatorTestAdd.add(7));
		assertEquals(false,comparatorTestAdd.add(7));
		assertEquals(false,comparatorTestAdd.add(6));
		assertEquals(false,comparatorTestAdd.add(5));
		assertEquals(false,comparatorTestAdd.add(10));
		assertEquals(false,comparatorTestAdd.add(11));
		assertEquals(false,comparatorTestAdd.add(8));
		
	}
	
	/**
	 * test the addAll() method
	 */
	@Test
	public void addAllTest() {
		//collection that is to be added to set
		collectionTest.add(1);
		collectionTest.add(2);
		collectionTest.add(3);
		collectionTest.add(4);
		collectionTest.add(5);
		
		//my set
		test.clear();
		test.add(5);
		test.add(4);
		
		//return true, because it added 1, 2, 3, to set
		assertEquals(true,test.addAll(collectionTest));
		
		//return false when no elements from collection were added to set
		assertEquals(false,test.addAll(collectionTest));
	}
	
	/**
	 * 	test the addAll() method using comparator
	 */
	@Test
	public void addAllComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestAddAll = new MySortedSet(descendingOrder);
		
		//create new collection to be added to set
		collectionTest.clear();
		collectionTest.add(1);
		collectionTest.add(2);
		collectionTest.add(3);
		collectionTest.add(4);
		collectionTest.add(5);
		
		//create new set
		comparatorTestAddAll.clear();
		comparatorTestAddAll.add(5);
		comparatorTestAddAll.add(4);
		
		//return true, because it added 1, 2, 3, to set
		assertEquals(true,comparatorTestAddAll.addAll(collectionTest));
		
		//return false when no elements from collection were added to set
		assertEquals(false,comparatorTestAddAll.addAll(collectionTest));
	}
	
	/**
	 * 	test the clear() method
	 */
	@Test
	public void clearTest() {
		//add elements into set then clear()
		emptyTest.add(5);
		emptyTest.add(6);
		emptyTest.add(30);
		
		//should return false; set is not empty
		assertEquals(false,emptyTest.isEmpty());
		
		emptyTest.clear();
		
		//should return true if set is empty
		assertEquals(true,emptyTest.isEmpty());
	}
	
	/**
	 * 	test the clear() method using comparator
	 */
	@Test
	public void clearComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestClear = new MySortedSet(descendingOrder);
		
		comparatorTestClear.clear();
		comparatorTestClear.add(5);
		comparatorTestClear.add(6);
		comparatorTestClear.add(30);
		
		//should return false: set is not empty
		assertEquals(false,comparatorTestClear.isEmpty());

		comparatorTestClear.clear();
		
		//should return true if set is empty
		assertEquals(true,comparatorTestClear.isEmpty());
		
	}
	
	/**
	 * test containts() method
	 */
	@Test
	public void containsTest() {
		test.add(7);
		//should return true, set contains 7
		assertEquals(true,test.contains(7));
		test.add(8);
		test.add(9);
		//should return true, set contains 8
		assertEquals(true,test.contains(8));
		//should return false, set doesn't contain 5
		assertEquals(false,test.contains(5));
	}
	
	
	/**
	 * test contains() method using comparator
	 */
	@Test
	public void containsComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestContains = new MySortedSet(descendingOrder);
		
		comparatorTestContains.clear();
		comparatorTestContains.add(45);
		//should return true: set contains 45
		assertEquals(true,comparatorTestContains.contains(45));
		comparatorTestContains.add(81);
		comparatorTestContains.add(4);
		//should return true: set contains 81
		assertEquals(true,comparatorTestContains.contains(81));
		//should return false: set doesn't contain 5
		assertEquals(false,comparatorTestContains.contains(5));
	}
	
	/**
	 * test containsAll() method
	 */
	@Test
	public void containsAllTest() {
		//create a new collection to test if set contains
		collectionTest.add(1);
		collectionTest.add(2);
		collectionTest.add(3);
		collectionTest.add(4);
		collectionTest.add(5);
		collectionTest.add(6);
		
		//create a set
		test.clear();
		test.add(5);
		test.add(4);
		
		//should be false: colelctionTest is larger than set
		assertEquals(false,test.containsAll(collectionTest));
		
		test.add(1);
		test.add(2);
		test.add(3);
		test.add(6);
		
		//should be true: collctionTest is contained in set
		assertEquals(true,test.containsAll(collectionTest));
		collectionTest.remove(3);
		assertEquals(true,test.containsAll(collectionTest));
		
		//test for emtpy collection
		collectionTest.clear();
		assertEquals(true,test.containsAll(collectionTest));
		
		collectionTest.add(23);
		//false: 23 is not is set
		assertEquals(false,test.containsAll(collectionTest));

	}
	
	/**
	 * test containsAll() method using comparator
	 */
	@Test
	public void containsAllComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestContains = new MySortedSet(descendingOrder);
		
		//create a collection
		collectionTest.clear();
		collectionTest.add(1);
		collectionTest.add(2);
		collectionTest.add(3);
		collectionTest.add(4);
		collectionTest.add(5);
		collectionTest.add(6);
		
		//create a set
		comparatorTestContains.clear();
		comparatorTestContains.add(5);
		comparatorTestContains.add(4);
		
		//should be false: colelctionTest is larger than set
		assertEquals(false,comparatorTestContains.containsAll(collectionTest));
		
		comparatorTestContains.add(1);
		comparatorTestContains.add(2);
		comparatorTestContains.add(3);
		comparatorTestContains.add(6);
		
		//should be true: collctionTest is contained in set
		assertEquals(true,comparatorTestContains.containsAll(collectionTest));
		collectionTest.remove(3);
		assertEquals(true,comparatorTestContains.containsAll(collectionTest));
		
		//test for emtpy collection
		collectionTest.clear();
		assertEquals(true,comparatorTestContains.containsAll(collectionTest));
		
		collectionTest.add(23);
		//false: 23 is not is set
		assertEquals(false,comparatorTestContains.containsAll(collectionTest));
	}
	
	/**
	 * test isEmpty() method
	 */
	@Test
	public void isEmptyTest() {
		//test when set is empty
		assertEquals(true,emptyTest.isEmpty());
		
		//test when set is not empty
		emptyTest.add(5);
		emptyTest.add(12);
		assertEquals(false,emptyTest.isEmpty());
	}
	
	/**
	 * test isEmpty() method for comparator
	 */
	@Test
	public void isEmptyComparatorTest() {
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestEmpty = new MySortedSet(descendingOrder);
		
		comparatorTestEmpty.clear();
		
		//test when set is empty
		assertEquals(true,comparatorTestEmpty.isEmpty());
		
		//test when set is not empty
		comparatorTestEmpty.add(5);
		comparatorTestEmpty.add(12);
		assertEquals(false,comparatorTestEmpty.isEmpty());
	}
	
	/**
	 * test iterator() method
	 */
	@Test
	public void iteratorTest() {
		//create set
		test.clear();
		test.add(5);
		test.add(4);
		test.add(9);
		
		//create new iterator
		Iterator<Integer> myIteratorTest = test.iterator();

		//test next() method
		assertSame(4, myIteratorTest.next());
		
		//test when hasNext() method
		assertEquals(true, myIteratorTest.hasNext());
		assertSame(5, myIteratorTest.next());
		assertSame(9, myIteratorTest.next());
		myIteratorTest.remove();
		
		//test when doesn't have next
		assertEquals(false, myIteratorTest.hasNext());
		
		//test remove() method
		//check last item (9) was removed: last should be 5
		assertSame(5, test.last());


	}
	
	/**
	 * test iterator() method using comparator
	 */
	@Test
	public void iteratorComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorIterator = new MySortedSet(descendingOrder);
		
		//create set
		comparatorIterator.clear();
		comparatorIterator.add(5);
		comparatorIterator.add(4);
		comparatorIterator.add(9);
		
		//create new iterator
		Iterator<Integer> comparatorIteratorTest = comparatorIterator.iterator();
		
		//test next()
		assertSame(9, comparatorIteratorTest.next());
		
		//test hasNext()
		assertEquals(true, comparatorIteratorTest.hasNext());
		
		assertSame(5, comparatorIteratorTest.next());
		assertSame(4, comparatorIteratorTest.next());
		
		//test remove() method
		comparatorIteratorTest.remove();
		//last should be five if 4 was removed
		assertSame(5, comparatorIterator.last());
		
		//test when hasNext() is not true
		assertEquals(false, comparatorIteratorTest.hasNext());

	}
	
	
	/**
	 * test for exception in iterator in remove() method
	 */
	@Test(expected=IllegalStateException.class)
	public void iteratorExceptionTest() {
		test.clear();
		Iterator<Integer> testIterator = test.iterator();
		//not pointing to index, should throw exception
		testIterator.remove();

	}
	
	
	/**
	 * test remove() method
	 */
	@Test
	public void removeTest() {
		//add something to set
		test.add(5);
		
		//remove if from set: should return true
		assertEquals(true,test.remove(5));
		
		
		test.add(12);
		test.add(7);
		//remove something not contained in set
		assertEquals(false, test.remove(6));
		
		//extra test: try removing same object twice
		assertEquals(true, test.remove(7));
		assertEquals(false, test.remove(7));
	}
	
	
	/**
	 * test remove() method using comparator
	 */
	@Test
	public void removeComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestRemove = new MySortedSet(descendingOrder);
		
		comparatorTestRemove.clear();
		
		//add something to set
		comparatorTestRemove.add(5);
		//remove if from set: should return true
		assertEquals(true,comparatorTestRemove.remove(5));
		
		comparatorTestRemove.add(12);
		comparatorTestRemove.add(7);
		//remove something not contained in set
		assertEquals(false, comparatorTestRemove.remove(6));
		
		//extra test: try removing same object twice
		assertEquals(true, comparatorTestRemove.remove(7));
		assertEquals(false, comparatorTestRemove.remove(7));
	}
	
	/**
	 * test removeAll() method
	 */
	@Test
	public void removeAllTest() {
		
		//create a collection to remove from set
		collectionTest.add(1);
		collectionTest.add(2);
		collectionTest.add(3);
		collectionTest.add(4);
		collectionTest.add(5);
		
		//create a set
		test.clear();
		test.add(5);
		test.add(4);
		test.add(10);
		
		//remove objects from set: should be true
		assertEquals(true,test.removeAll(collectionTest));
		
		//remove objects that are not contained in set: should be false
		assertEquals(false,test.removeAll(collectionTest));
	}
	
	
	/**
	 * test removeAll() method using comparator
	 */
	@Test
	public void removeAllComparatorTest() {
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestRemoveAll = new MySortedSet(descendingOrder);
		
		//create a collection
		comparatorTestRemoveAll.clear();
		collectionTest.add(1);
		collectionTest.add(2);
		collectionTest.add(3);
		collectionTest.add(4);
		collectionTest.add(5);
		
		//create a set
		comparatorTestRemoveAll.clear();
		comparatorTestRemoveAll.add(5);
		comparatorTestRemoveAll.add(4);
		comparatorTestRemoveAll.add(10);
		
		//remove objects from set: should be true
		assertEquals(true,comparatorTestRemoveAll.removeAll(collectionTest));
		
		//remove objects that are not contained in set: should be false
		assertEquals(false,comparatorTestRemoveAll.removeAll(collectionTest));
	}
	
	
	/**
	 * test size() method
	 */
	@Test
	public void sizeTest() {
		
		//test when set is emtpy
		assertEquals(0, emptyTest.size());
		
		//test when set is not empty
		emptyTest.add(5);
		emptyTest.add(6);
		assertEquals(2, emptyTest.size());
	}
	
	
	/**
	 * test size() method when using comparator
	 */
	@Test
	public void sizeComparatorTest() {
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestRemoveAll = new MySortedSet(descendingOrder);
		
		//test when set is empty
		comparatorTestRemoveAll.clear();
		assertEquals(0, comparatorTestRemoveAll.size());
		
		//test when set is not empty
		comparatorTestRemoveAll.add(51);
		comparatorTestRemoveAll.add(63);
		assertEquals(2, comparatorTestRemoveAll.size());
	}
	
	/**
	 * test toArray() method
	 */
	@Test
	public void toArrayTest() {
		//create a set
		test.clear();
		test.add(0);
		test.add(4);
		test.add(2);
		test.add(3);
		test.add(5);
		test.add(1);
		test.add(8);
		test.add(7);
		test.add(6);
		
		//call toArray() method
		Object[] testArray = test.toArray();
		
		//test new array
		assertEquals(0, testArray[0]);
		assertEquals(1, testArray[1]);
		assertEquals(2, testArray[2]);
		assertEquals(3, testArray[3]);
		assertEquals(4, testArray[4]);
		assertEquals(5, testArray[5]);
		assertEquals(6, testArray[6]);
		assertEquals(7, testArray[7]);
		assertEquals(8, testArray[8]);
		assertEquals(9, testArray.length);
	}
	
	/**
	 * test toArray() method for comparator
	 */
	@Test
	public void toArrayComparatorTest() {
		//create a new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestToArray = new MySortedSet(descendingOrder);
		
		//crate a set
		comparatorTestToArray.clear();
		comparatorTestToArray.add(0);
		comparatorTestToArray.add(4);
		comparatorTestToArray.add(2);
		comparatorTestToArray.add(3);
		comparatorTestToArray.add(5);
		comparatorTestToArray.add(1);
		comparatorTestToArray.add(8);
		comparatorTestToArray.add(7);
		comparatorTestToArray.add(6);
		
		//call toArray()
		Object[] testArray = comparatorTestToArray.toArray();
		
		//test new array
		assertEquals(8, testArray[0]);
		assertEquals(7, testArray[1]);
		assertEquals(6, testArray[2]);
		assertEquals(5, testArray[3]);
		assertEquals(4, testArray[4]);
		assertEquals(3, testArray[5]);
		assertEquals(2, testArray[6]);
		assertEquals(1, testArray[7]);
		assertEquals(0, testArray[8]);
		assertEquals(9, testArray.length);
	}
	
	/**
	 * test binarySearch() method
	 */
	@Test
	public void binarySearchTest(){
		//create a set
		test.clear();
		test.add(1);
		test.add(4);
		test.add(6);
		test.add(2);
		test.add(3);
		test.add(5);
		
		//check order of set: binary search returns index location of object
		assertEquals(5, test.binarySearch(6, 0, test.size() -1));
		assertEquals(4, test.binarySearch(5, 0, test.size() -1));
		assertEquals(3, test.binarySearch(4, 0, test.size() -1));
		assertEquals(2, test.binarySearch(3, 0, test.size() -1));
		assertEquals(1, test.binarySearch(2, 0, test.size() -1));
		assertEquals(0, test.binarySearch(1, 0, test.size() -1));
	}
	
	
	/**
	 * test binarySearch() method using comparator
	 */
	@Test
	public void binarySearchComparatorTest(){
		//create new comparator
		DescendingOrder descendingOrder = new DescendingOrder();
		comparatorTestToArray = new MySortedSet(descendingOrder);
		
		//add to set
		comparatorTestToArray.clear();
		comparatorTestToArray.clear();
		comparatorTestToArray.add(1);
		comparatorTestToArray.add(2);
		comparatorTestToArray.add(3);
		comparatorTestToArray.add(4);
		comparatorTestToArray.add(5);
		comparatorTestToArray.add(6);
		
		//test order of set: biary search returns index location of object
		assertEquals(3, comparatorTestToArray.binarySearch(3, 0, comparatorTestToArray.size() -1));
		assertEquals(2, comparatorTestToArray.binarySearch(4, 0, comparatorTestToArray.size() -1));
		assertEquals(4, comparatorTestToArray.binarySearch(2, 0, comparatorTestToArray.size() -1));
		assertEquals(5, comparatorTestToArray.binarySearch(1, 0, comparatorTestToArray.size() -1));
		assertEquals(1, comparatorTestToArray.binarySearch(5, 0, comparatorTestToArray.size() -1));
		assertEquals(0, comparatorTestToArray.binarySearch(6, 0, comparatorTestToArray.size() -1));
	}
	

//comparator used for Descending Order in Testing
	  /**
	   * Comparator that defines an ordering among Integers.
	   */
	  protected class DescendingOrder implements Comparator<Integer> {

	    /**
	     * Returns a negative value if o1 is smaller than o2. Returns a positive
	     * value if o1 is larger than o2. Returns 0 if o1 and o2 are equal.
	     */
	   
		@Override
		public int compare(Integer o1, Integer o2) {
			// TODO Auto-generated method stub
			return (int) (o2 - o1);
		}
	  }
	}




//Oh how I love that Green bar from JUnit Testing :D