package assignment3;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author Katherine Liu and Riley Jacobson
 *
 * @param <E>
 *            -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] arr;
	private int arraySize;
	private Comparator<? super E> com;

	/**
	 * Creates a MySortedSet that will use the natural comparator of an element.
	 */
	public MySortedSet() {
		arr = (E[]) new Object[10];
		arraySize = 0;
	}

	/**
	 * Creates a MySortedSet that will use a given comparator.
	 * 
	 * @param Comparator
	 *            c      -- This is what will be used to compare the objects
	 */
	public MySortedSet(Comparator<E> c) {
		arr = (E[]) new Object[10];
		com = c;
		arraySize = 0;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return com;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (arraySize == 0) {
			throw new NoSuchElementException();
		}
		return arr[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (arraySize == 0) {
			throw new NoSuchElementException();
		}
		return arr[arraySize - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 *
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {

		E[] temp;
		// Check if it's already in the set.
		if (contains(o)) {
			return false;
		}
		// Check if the set is empty. If it is empty, adds the element to the
		// beginning.
		else if (isEmpty()) {
			arr[0] = o;
			arraySize++;
			return true;
		} 
		else {
			arraySize++;

			// Double if the current array size is smaller than how many
			// elements we have with the added element.
			if (arraySize > arr.length){
				temp = (E[]) new Object[arr.length*2];
			}
			else{// temporary array to hold the new items
			temp = (E[]) new Object[arr.length];
			}
			// Flag to let us know when the new item has been added.
			boolean flag = true;

			// if it uses the natural comparator
			if (com == null) {
				// Go through the array and populate with the new item.
				for (int i = 0; i < arraySize; i++) {
					if(i == arr.length && flag == true){
						temp[i] = arr[i-1];
						break;
					}
					// if it reaches the end of the array and has already added
					// the new item.
					if (arr[i] == null && flag == false) {
						temp[i] = arr[i - 1];
						break;
					}
					// if the element needs to be added at the end of the item.
					else if (arr[i] == null) {
						temp[i] = o;
						break;
					}
					// find where to add the new item.
					else if (flag && ((Comparable<E>) o).compareTo(arr[i]) < 0) {
						temp[i] = o;
						i++;
						flag = false;
					}
					// if the item has been added, loop through array and add
					// more items after the new one.
					if (flag == false)
						temp[i] = arr[i - 1];
					else
						temp[i] = arr[i]; // Otherwise keep populating the new
											// array.
				}
			} else {
				// Go through the array and populate with the new item.
				for (int i = 0; i < arraySize; i++) {
					if(i == arr.length && flag == true){
						temp[i] = arr[i-1];
						break;
					}// if it reaches the end of the array and has already added the new item.
					else if (arr[i] == null && flag == false) {
						temp[i] = arr[i - 1];
						break;
					}
					// if the element needs to be added at the end of the item.
					else if (arr[i] == null) {
						temp[i] = o;
						break;
					}
					// find where to add the new item.
					else if (flag && (com.compare(o, arr[i])) < 0) {
						temp[i] = o;
						i++;
						flag = false;
					}
					// if the item has been added, loop through array and add
					// more items after the new one.
					if (flag == false)
						temp[i] = arr[i - 1];
					else
						temp[i] = arr[i]; // Otherwise keep populating the new
											// array.
				}
			}
			arr = temp;
		}
		return true;

	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 *
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		int setSize = arraySize;
		// iterate through the collection and add every element in the
		// collection to our array
		for (int i = 0; i < c.size(); i++) {
			E[] e = (E[]) c.toArray();
			this.add(e[i]);
		}
		// return false if the array did not change size.
		if (setSize == arraySize) {
			return false;
		}
		return true;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		// Sets our array back to it's original form
		arr = (E[]) new Object[10];
		arraySize = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		// Check if the array is empty
		if (arraySize == 0) {
			return false;
		}
		// Use our binary search to check if the object is in the array.
		return binarySearchBool(arr, (E) o);

	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		// iterate through the array to check if every element in the collection is in the array.
		for (int i = 0; i < c.size(); i++) {
			E[] e = (E[]) c.toArray();
			// If it doesn't find any of the elements in the set it will return false.
			if (!this.contains(e[i])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (arraySize == 0)
			return true;

		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		
		return new MyIterator();

	}

	/**
	 * Removes the specified element from this set if it is present.
	 *
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		// Check if the element is in the set.
		if (!contains(o)) {
			return false;
		}
		// Find where we need to remove the object.
		E[] temp = (E[]) new Object[arr.length];
		// flag tells us whether something has been removed.
		boolean flag = false;
		// Calls our helper method to find where the element is
		int pos = binarySearchInt(arr, (E) o);
		// Re-populate the set until it gets to the position the element was at and 
		// replaces that element with the next. 
		for (int i = 0; i < arraySize; i++) {
			if (pos == i) {
				temp[i] = arr[i + 1];
				flag = true;
			} else {
				temp[i] = arr[i];
			}
		}
		arr = temp;
		arraySize--;
		return flag;

	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 *
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		int setSize = arraySize;
		// Iterate through the set and removes all of the elements in the collection from the set.
		for (int i = 0; i < c.size(); i++) {
			E[] e = (E[]) c.toArray();
			this.remove(e[i]);
		}
		// If the set doesn't change size then return false.
		if (setSize == arraySize) {
			return false;
		}
		return true;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return arraySize;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object[] temp = new Object[arraySize];
		// Populate our array with all the elements from the set. 
		for (int i = 0; i < arraySize; i++) {
			temp[i] = arr[i];
		}
		return temp;
	}

	/**
	 * Binary search that will return where the element is in the array. Helper
	 * method for remove.
	 * 
	 * @return int -- Where the element should go. Returns -1 if the element is
	 *         current in the array.
	 * 
	 */
	private int binarySearchInt(E[] e, E o) {
		// Check if the object is even in the array.
		if (!contains(o)) {
			return -1;
		}
		int pos = -1;
		int lo = 0;
		int hi = arraySize - 1;
		while (hi >= lo) {
			// This is our key that will show us where we need to check
			int middle = (lo + hi) / 2;
			// Do this test if it uses it's natural comparable.
			if (com == null) {
				if (((Comparable<E>) o).compareTo(e[middle]) == 0) {
					pos = middle;
					return pos;
				}
				// else we will split in half and use the side the object
				// "should" be on
				else {
					// Checks the right side
					if (((Comparable<E>) o).compareTo(e[middle]) > 0) {
						lo = middle + 1;
					}
					// Checks the left side
					else {
						hi = middle - 1;
					}
				}

			} // Do this test if it has it's own comparator.
			else {
				// if the middle of the array is the object we are looking for
				// return true
				if (com.compare(e[middle], o) == 0) {
					pos = middle;
					return pos;
				}
				// else we will split in half and use the side the object
				// "should" be on
				else {
					// Checks the right side
					if (com.compare(o, e[middle]) > 0) {
						lo = middle + 1;
					}
					// Checks the left side
					else {
						hi = middle - 1;
					}
				}
			}
		}
		return pos;

	}

	/**
	 * Binary search that will return whether the element is in the array.
	 * 
	 * @param E
	 *            [] e -- The array of objects to be searched.
	 * @param E
	 *            o -- The object the search is looking for.
	 * @return bool -- Whether the element is in the array.
	 * 
	 */
	private boolean binarySearchBool(E[] e, E o) {
		int lo = 0;
		int hi = arraySize - 1;
		while (hi >= lo) {
			// This is our key that will show us where we need to check
			int middle = (lo + hi) / 2;
			// Do this test if it uses it's natural comparable.
			if (com == null) {
				if (((Comparable<E>) o).compareTo(e[middle]) == 0) {
					return true;
				}
				// else we will split in half and use the side the object
				// "should" be on
				else {
					// Checks the right side
					if (((Comparable<E>) o).compareTo(e[middle]) > 0) {
						lo = middle + 1;
					}
					// Checks the left side
					else {
						hi = middle - 1;
					}
				}

			} // Do this test if it has it's own comparator.
			else {
				// if the middle of the array is the object we are looking for
				// return true
				if (com.compare(e[middle], o) == 0) {
					return true;
				}
				// else we will split in half and use the side the object
				// "should" be on
				else {
					// Checks the right side
					if (com.compare(o, e[middle]) > 0) {
						lo = middle + 1;
					}
					// Checks the left side
					else {
						hi = middle - 1;
					}
				}
			}
		}
		return false;
	}

	/**
     * Creates an iterator for our MySortedSet class. 
     *
     */
	private class MyIterator implements Iterator<E> {

		private int pointer = 0;

		@Override
		public boolean hasNext() {
			if (pointer < arraySize) {
				return true;
			} else {
				return false;
			}
		}

		@Override
		public E next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			pointer++;
			return arr[pointer - 1];
		}

		@Override
		public void remove() {
			
			if (pointer == 0) {
				throw new IllegalStateException();
			}
			// Call our remove method and decrement our pointer accordingly
			MySortedSet.this.remove(arr[pointer - 1]);
			pointer--;

		}
	}
}
