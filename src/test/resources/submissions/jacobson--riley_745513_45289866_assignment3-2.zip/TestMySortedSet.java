package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class TestMySortedSet extends MySortedSet {

	
	private MySortedSet<String> s1, s2, s3;
	private Collection<String> col;
	Object[] oArray1;
	
	@Before
	public void setUp() throws Exception {
		s2 = new MySortedSet<String>(String.CASE_INSENSITIVE_ORDER);
		s3 = new MySortedSet<String>(String.CASE_INSENSITIVE_ORDER);
        s1 = new MySortedSet<String>();
        
		col = new ArrayList<String>();
        col.add("e");
        col.add("d");
        col.add("c");
        col.add("b");
        col.add("a");
        //Objects that the collection already contains.
        col.add("e");
        col.add("c");
        
		oArray1= new Object[]{"a", "b", "c"};


	}

	@After
	public void tearDown() throws Exception {
	}
	//Tests if a MySortedSet is using a given comparator or it's natural one.
	//s1 uses natural should return null.
	@Test
	public void testComparator1() {
		assertEquals(null, s1.comparator());
	}
	//Tests if a MySortedSet is using a given comparator or it's natural one.
	//s2 is using the CASE_INSENSITIVE_ORDER comparator.
	@Test
	public void testComparator2() {
		assertEquals(String.CASE_INSENSITIVE_ORDER, s2.comparator());
	}
	//Nothing has been added to s2 yet so this should return true because it is empty.
	@Test
	public void testIsEmpty1() {
		assertTrue(s2.isEmpty());
	}
	//The String "hi" is added to the list before checking if empty should return false.
	@Test
	public void testIsEmpty2() {
		s2.add("hi");
		assertFalse(s2.isEmpty());
	}
	//The String "test" was added so the contains method should return true.
	@Test
	public void testContains1() {
		s2.add("test");
		assertTrue(s2.contains("test"));
	}
	//There is no String "abc" in the set, contains should return false.
	@Test
	public void testContains2() {
		assertFalse(s2.contains("abc"));
	}
	//When something is added to the set the add method should return true.
	// Test if it adds more elements.
	@Test
	public void testAdd1() {
		s3.clear();
		s3.add("a");
		s3.add("b");
		s3.add("c");
		s3.add("d");
		s3.add("e");
		s3.add("f");
		s3.add("g");
		s3.add("h");
		s3.add("i");
		s3.add("j");
		s3.add("k");

		assertTrue(s3.add("test"));
	}
	//When and equivalent object all ready exists in the set add should return false.
	@Test
	public void testAdd2() {
		s3.add("test");
		assertFalse(s3.add("test"));
	}
	//Checks that the element was added to the set.
	@Test
	public void testAdd3() {
		s3.clear();
		s3.add("a");
		assertEquals("a", s3.first());
	}
	//Returns the first element (also the smallest) in the set.
	@Test
	public void testFirst1() {

	    s1.add("c");
        s1.add("b");
        s1.add("a");
        s1.add("c");
        s1.add("d");
        s1.add("e");
        assertEquals("a", s1.first());
	}
	//Throws a NoSuchElementException if MySortedSet is empty.
	@Test
	public void testFirst2() {
		try
		{
			s1.clear();
			s1.first();
			fail();
		}
		catch(NoSuchElementException e)
		{
			assertTrue(true);
		}
	}
	//Returns the last element (also the largest) in the set.
	@Test
	public void testLast1() {

	    s1.add("c");
        s1.add("b");
        s1.add("a");
        s1.add("c");
        s1.add("d");
        s1.add("e");
        assertEquals("e", s1.last());
	}
	//Throws a NoSuchElementException if MySortedSet is empty.
	@Test
	public void testLast2() {
		try
		{
			s1.clear();
			s1.last();
			fail();
		}
		catch(NoSuchElementException e)
		{
			assertTrue(true);
		}
	}
	//Checks that the set contains all the elements in the collection.
	@Test
	public void testAddAll1() {

        
        s1.clear();
        s1.addAll(col);
        
        assertTrue(s1.containsAll(col));
	}
	//Checks that the items were added and returned true.
	@Test
	public void testAddAll2() {
		s1.clear();
        assertTrue(s1.addAll(col));
	}
	//Checks that the set has not changed adding the set and returns false.
	@Test
	public void testAddAll3() {
		s1.clear();
        s1.addAll(col);
        assertFalse(s1.addAll(col));
	}
	//Returns true if an element was removed.
	@Test
	public void testRemove1() {
		s1.clear();
		s1.add("a");
		assertTrue(s1.remove("a"));

	}
	//Returns false if an element was not removed.
	@Test
	public void testRemove2() {
		s1.clear();
		s1.add("a");
		assertFalse(s1.remove("b"));
	}
	//Tests if the element truly was removed.
	@Test
	public void testRemove3() {
		s1.clear();
		s1.add("a");
		s1.remove("a");
		assertFalse(s1.contains("a"));
	}
	//Checks that all elements were removed returns true.
	@Test
	public void testRemoveAll1() {
		s1.clear();
		s1.addAll(col);
		assertTrue(s1.removeAll(col));
	}
	//Checks that there was no change returns false.
	@Test
	public void testRemoveAll2() {
		s1.clear();
		assertFalse(s1.removeAll(col));
	}
	//Checks each element of the collection is not contained in the set.
	@Test
	public void testRemoveAll3() {
		s1.clear();
		s1.addAll(col);
		s1.removeAll(col);
		for(int i = 0; i < col.size(); i++)
		{
			Object[]  array = col.toArray();
			if(s1.contains(array[i]))
			{
				fail();
			}
		}
		assertTrue(true);
	}
	//Tests that the set is size 0 when cleared.
	@Test
	public void testClear1() {
		s1.add("x");
		s1.add("y");
		s1.add("z");
		s1.clear();
		assertTrue(s1.isEmpty());
	}
	//Tests that the set does not contain an element.
	@Test
	public void testClear2() {
		s1.add("x");
		s1.clear();
		assertFalse(s1.contains("x"));
	}
	//Checks if the set contains all the elements in a collection.
	@Test
	public void testContainsAll1() {
		s1.clear();
		s1.addAll(col);
		assertTrue(s1.containsAll(col));
	}
	//Checks that the set does NOT contain all the elements a collection.
	@Test
	public void testContainsAll2() {
		s1.clear();
		s1.add("x");
		assertFalse(s1.containsAll(col));
	}
	//Checks that correct size is returned.
	@Test
	public void testSize1() {
		s1.clear();
		assertEquals(0, s1.size());

	}
	//Checks that correct size is returned. (Adding the an element twice should not increase the size.)
	@Test
	public void testSize2() {
		s1.clear();
		s1.add("x");
		s1.add("x");
		s1.add("y");
		assertEquals(2, s1.size());
	}
	//Tests that the array was the correct length.
	@Test
	public void testToArray1() {
		s1.clear();
		s1.add("x");
		s1.add("x");
		s1.add("y");
		Object[] objectArray =  s1.toArray();
		assertEquals(2, objectArray.length);
	}
	//Tests if the first element was the same as the one in the set.
	@Test
	public void testToArray2() {
		s1.clear();
		s1.add("x");
		s1.add("x");
		s1.add("y");
		Object[] objectArray =  s1.toArray();
		assertEquals("x", objectArray[0]);
	}
	// Test if our Iterator's hasNext() method works.
	@Test
	public void testIterator1() {
		s1.clear();
		s1.add("a");
		s1.add("b");
		s1.add("c");
		Iterator<String> i = s1.iterator();
		assertTrue(i.hasNext());
	}
	// Test if our Iterator's next() method works.
	@Test
	public void testIteratorNext1() {
		s1.clear();
		s1.add("a");
		s1.add("b");
		s1.add("c");
		Iterator<String> i = s1.iterator();
		assertEquals("a", i.next());
	}
	// Test if our Iterator's next() method will throw its exception.
	@Test
	public void testIteratorNext2() {
		try {
			s1.clear();
			s1.add("a");
			s1.add("b");
			s1.add("c");
			Iterator<String> i = s1.iterator();
			i.next();
			i.next();
			i.next();
			i.next();
			fail();
		} catch (NoSuchElementException e) {
			assertTrue(true);
		}
	}
	// Test if our Iterator's remove() method works. 
	@Test
	public void testIteratorRemove1() {
		s1.clear();
		s1.add("a");
		s1.add("b");
		s1.add("c");
		Iterator<String> i = s1.iterator();
		i.next();
		i.remove();
		assertEquals("b", i.next());
	}
	// Test if our Iterator's remove() method will throw an exception.
	@Test
	public void testIteratorRemove2() {
		try {
			s1.clear();
			s1.add("a");
			s1.add("b");
			s1.add("c");
			Iterator<String> i = s1.iterator();
			i.next();
			i.remove();
			i.remove();
			fail();
		} catch (IllegalStateException e) {
			assertTrue(true);
		}
	}
}
