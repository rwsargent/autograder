package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 * @author Jet Vellinga, Gradey Cullins
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] data;
	int size; // number of elements in the generic array
	int currentIndex;
	Comparator<? super E> cmp;

	/**
	 * default constructor, using natural ordering for sorting
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet() {
		data = (E[]) new Object[10];
		size = 0;
	}

	/**
	 * 
	 * use the _cmp passed in by user as the basis for comparison and sorting of items
	 * as they are added to array
	 * 
	 * @param _cmp
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> _cmp) {
		cmp = _cmp;
		data = (E[]) new Object[10];
		size = 0;
	}

	/**
	 * 
	 * return comparator passed in by user, will return null if none initiated
	 * 
	 */
	@Override
	public Comparator<? super E> comparator() {
		return cmp;
	}

	/**
	 * 
	 * return the first element 'E' in the array. If there are no items,
	 * throw NoSuchElementException
	 * 
	 */
	@Override
	public E first() throws NoSuchElementException {
		if(size == 0) {
			throw new NoSuchElementException();
		}
		return data[0];
	}

	/**
	 * 
	 * return the last element 'E' in the array. If there are no items,
	 * throw NoSuchElementException 
	 * 
	 */
	@Override
	public E last() throws NoSuchElementException {
		if(size == 0) {
			throw new NoSuchElementException();
		}
		return data[size-1];
	}

	/**
	 * 
	 * first check that the array does not already contain 'o', next check if the underlying
	 * array needs to grow to accommodate for 'o'. Finally, employ binary search for find
	 * the correct position for 'o' and return true. Returns false if 'o' is a duplicate
	 * 
	 * @param o
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {

		if (contains(o))
			return false;

		if (size == 0){
			data[0] = o;
			size++;
			return true;
		}

		// the underlying array needs to grow
		if (size == data.length){
			E[] temp = (E[])new Object[size*2];
			for (int i = 0; i < size; i++)
				temp[i] = data[i];
			data = temp;
		}

		int first = 0;
		int last = size-1;
		int mid = first + (last - first)/2;

		// binary search
		while (first <= last){
			mid = first + (last - first)/2;
			// if we are using natural ordering
			if(cmp == null) {
				if (((Comparable<E>)o).compareTo(data[mid]) < 0){
					last = mid-1;
				}
				else if (((Comparable<E>)o).compareTo(data[mid]) > 0){
					first = mid+1;
				}
				else
					break;
			// if the sorted set was created with a custom comparator as an argument
			} else {
				if(cmp.compare(o, data[mid]) < 0) {
					last = mid-1;
				}
				else if (cmp.compare(o, data[mid]) > 0){
					first = mid+1;
				}
				else
					break;
			}
		}

		mid = first + (first - last)/2;

		// index items over to create space for the next item
		for (int i = size-1; i >= mid; i--)
			data[i+1] = data[i];
		data[mid] = o;
		size ++;

		return true;

	}

	/**
	 * return true if the set changes as a result of attempting to add all items
	 * within Collection c. Returns false if the set does not change
	 * 
	 * @param Collection<? extends E> c
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		Boolean didChange = false;
		for (E e: c) {
			if(this.add(e)) didChange = true;
		}
		return didChange;
	}

	/**
	 * 
	 * remove all items from the set, return underlying array to original capacity of 10,
	 * change size to 0
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		data = (E[])new Object[10];
		size = 0;
	}

	/**
	 * 
	 * returns true if the set contains 'o' by means of binary search. Return false if the item is 
	 * not a duplicate
	 * 
	 * @param Object o
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {

		if(o == null) {
			return false;
		}

		if(size==0) {
			return false;
		}

		int first = 0;
		int last = size-1;
		int mid = first + (last - first)/2;

		// binary search
		while (first <= last){
			mid = first + (last - first)/2;
			// if user did not pass in comparator
			if(cmp == null) {
				if (((Comparable<E>)o).compareTo(data[mid]) < 0){
					last = mid-1;
				}
				else if (((Comparable<E>)o).compareTo(data[mid]) > 0){
					first = mid+1;
				}
				else{
					return ((Comparable<E>)o).compareTo(data[mid]) == 0;
				}	
			} else {
				if (cmp.compare((E)o, data[mid]) < 0){
					last = mid-1;
				}
				else if (cmp.compare((E)o, data[mid]) > 0){
					first = mid+1;
				}
				else{
					mid = first + (first - last)/2;
					return (cmp.compare((E)o, data[mid]) == 0);
				}	
			}
		}
		return false;

	}
	
	/**
	 * 
	 * returns true if the set contains all items within the collection 'c' passed
	 * as an argument, return false otherwise.
	 * 
	 * @param Collection<?> c
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for(Object item: c) {
			if(!this.contains(item)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 
	 * if the set is empty, return true, otherwise return false
	 * 
	 */
	@Override
	public boolean isEmpty() {
		return this.size == 0;
	}

	/**
	 * 
	 * return a new instance of the custom iterator nested in this class
	 * 
	 */
	@Override
	public Iterator<E> iterator() {
		return new MyIterator<E>(this);
	}

	/**
	 * 
	 * create a new instance of MyIterator, index until pointing to 'o', call the
	 * remove method in MySortedSet which then delegates the remove to MyIterator's remove
	 * which removes the item by process of overwriting and indexing all additional items to
	 * the left one position
	 * 
	 * @param Object o
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object o) {

		MyIterator<E> itr = (MyIterator<E>) iterator();

		// special case for removing the only item at index 0
		if(size == 1 && itr.index == -1) {
			itr.index++;
			itr.remove();
			size--;
			return true;
		}
		while (itr.hasNext()){
			// if the user did not pass in a custom comparator
			if(cmp == null) {
				if (((Comparable<E>) o).compareTo(itr.next()) == 0){
					itr.remove();
					size--;
					return true;
				} 
			} else {
				if (cmp.compare((E) o, itr.next()) == 0){
					itr.remove();
					size--;
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * 
	 * remove every item in the set that is contained in the collection
	 * passed in as an argument. Returns true if the set changes as a 
	 * result, false otherwise
	 * 
	 * @param Collection<?> c
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		Boolean didChange = false;
		for (Object o: c) {
			if(this.remove(o)) didChange = true;
		}
		return didChange;
	}

	/**
	 * return the number of elements in the set
	 */
	@Override
	public int size() {
		return this.size;
	}

	/**
	 * return an object array containing all of the sorted elements
	 * in the set
	 */
	@Override
	public Object[] toArray() {
		Object[] resultArray = new Object[this.data.length];
		int index = 0;
		for(E e: this.data) {
			if(index == size) break;
			resultArray[index++] = e;
		}
		return resultArray;
	}

	/**
	 * returns the number of elements in the set
	 */
	public int getSize() {
		return this.size;
	}


	/**
	 * 
	 * @author Gradey Cullins, Jet Vellinga
	 *
	 */
	@SuppressWarnings("hiding")
	public class MyIterator<E> implements Iterator<E> {

		private final MySortedSet<E> set;
		private E current;
		private int index = -1; // start at index -1 to emulate the iterator starting at the space before the first item


		public MyIterator(MySortedSet<E> _set) {
			set = _set;
			current = set.first();
		}

		/**
		 * returns true if the next index does not contain true, false otherwise
		 */
		@SuppressWarnings("unchecked")
		@Override
		public boolean hasNext() {

			return (((Comparable<E>) current).compareTo(set.last()) < 0);
		}

		/**
		 * return the next element in the set, throws exception if next returns false
		 */
		@Override
		public E next() {
			if (!hasNext())
				throw new NoSuchElementException();

			current = set.data[++index];
			return current;
		}

		/**
		 * remove the item at the current index, index all items to the right down by one space
		 */
		@Override
		public void remove() {
			int temp = index; // used to keep track of the original index before calling remove

			while(hasNext()) {
				set.data[index] = set.data[index+1];
				current = set.data[index++];
			}
			set.data[index] = null;
			index = temp;
			return;
		}

	}
}















