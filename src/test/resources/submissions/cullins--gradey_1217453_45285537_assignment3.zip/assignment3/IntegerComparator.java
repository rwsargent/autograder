package assignment3;

import java.util.Comparator;

/**
 * 
 * This sample comparator is used solely for the purpose of testing the constructor
 * in MySortedSet that takes a Comparator as an argument
 * 
 * @author Gradey Cullins, Jet Vellinga
 *
 */
public class IntegerComparator implements Comparator<Integer> {

	@Override
	public int compare(Integer o1, Integer o2) {
		return o2 - o1;
	}

}
