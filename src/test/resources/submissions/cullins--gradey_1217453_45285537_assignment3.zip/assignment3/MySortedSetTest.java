package assignment3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * 
 * @author Jet Vellinga, Gradey Cullins
 *
 */
public class MySortedSetTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAdd() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();

		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}

		// ensures the items were added in the correct order
		int index = 1;
		for(Object o: s1.toArray()) {
			assertTrue(o == (Object)index++);
		}

		assertTrue(s1.size == 10);
		assertTrue(s1.toArray().length == 10);

		// add items in random order
		MySortedSet<Integer> s2 = new MySortedSet<Integer>();
		s2.add(5);
		s2.add(2);
		s2.add(1);
		s2.add(10);
		s2.add(9);
		s2.add(3);
		s2.add(7);
		s2.add(8);
		s2.add(6);
		s2.add(4);

		Object[] o1 = s1.toArray();
		Object[] o2 = s2.toArray();

		// ensures MySortedSets are sorted as they are created
		assertArrayEquals(o1, o2);

		//test Strings
		MySortedSet<String> s3 = new MySortedSet<String>();
		s3.add("b");
		s3.add("a");
		s3.add("j");
		s3.add("d");
		s3.add("c");
		s3.add("f");
		s3.add("e");
		s3.add("h");
		s3.add("g");
		s3.add("i");

		Object[] stringO = new Object[] {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j"};
		Object[] stringArr = s3.toArray();
		assertArrayEquals(stringO, stringArr);

		// trigger underlying array growth
		s1.add(11);
		assertTrue(s1.size == 11);
		assertTrue(s1.toArray().length == 20);
		assertTrue(s1.toArray()[10].equals(11));

		s1.add(0);
		assertTrue(s1.size == 12);
		assertTrue(s1.toArray().length == 20);
		assertTrue(s1.toArray()[0].equals(0));

		s1.add(0);
		s1.add(1);
		s1.add(2);
		s1.add(3);
		s1.add(4);

		//don't allow duplicates
		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}

		assertTrue(s1.size == 12);
		assertTrue(s1.toArray().length == 20);
		assertTrue(s1.toArray()[0].equals(0));
		
		// test with comparator constructor
		IntegerComparator cmp = new IntegerComparator();
		
		MySortedSet<Integer> s4 = new MySortedSet<Integer>(cmp);
		for(int i = 1; i < 11; i++) {
			s4.add(i);
		}
		
		assertTrue(s4.size == 10);
		assertTrue(s4.toArray().length == 10);
		
		Object[] o5 = new Object[] {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
		assertArrayEquals(o5, s4.toArray());
		
	}

	@Test
	public void testFirst() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		MySortedSet<Integer> s2 = new MySortedSet<Integer>();
		MySortedSet<Integer> s3 = new MySortedSet<Integer>();

		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}

		s3.add(0);

		assertTrue(s1.first() == 1);
		
		try {
			assertTrue(s2.first() == null);
		} catch(NoSuchElementException e) {
			// exception was correctly thrown
		}
		
		assertTrue(s3.first() == 0);

	}

	@Test
	public void testLast() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		MySortedSet<Integer> s2 = new MySortedSet<Integer>();
		MySortedSet<Integer> s3 = new MySortedSet<Integer>();

		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}

		s3.add(0);

		assertTrue(s1.last() == 10);
		
		try {
			assertTrue(s2.last() == null);
		} catch(NoSuchElementException e) {
			// exception was correctly thrown
		}
		assertTrue(s3.last() == 0);


	}


	@Test
	public void testAddAll() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		List<Integer> c1 = new ArrayList<Integer>();
		for(int i = 1; i < 11; i++) {
			c1.add(i);
		}
		s1.addAll(c1);
		assertTrue(s1.size == 10);
		int index = 1;
		for(Object o: s1.toArray()) {
			assertTrue(o == (Object)index++);
		}
	}

	@Test
	public void testClear() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}
		
		s1.clear();
		assertTrue(s1.size == 0);
		for(Object o: s1.toArray()) {
			assertTrue(o == null);
		}
		assertTrue(s1.toArray().length == 10);
		
		s1.clear();
		assertTrue(s1.toArray().length == 10);
		assertTrue(s1.size == 0);
	}

	@Test
	public void testContains() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}
		for(int i = 1; i < 11; i++) {
			assertTrue(s1.contains(i));
		}
		for(int i = 12; i < 1000; i++) {
			assertTrue(!s1.contains(i));
		}
		for(int i = 0; i > -1000; i--) {
			assertTrue(!s1.contains(i));
		}
		
		MySortedSet<String> s3 = new MySortedSet<String>();
		s3.add("b"); s3.add("a"); s3.add("j"); s3.add("d"); s3.add("c"); s3.add("f"); s3.add("e");s3.add("h");
		s3.add("g");
		s3.add("i");
		assertTrue(s3.contains("a"));
		assertTrue(s3.contains("b"));
		assertTrue(s3.contains("c"));
		assertTrue(s3.contains("d"));
		assertTrue(s3.contains("e"));
		assertTrue(s3.contains("f"));
		assertTrue(s3.contains("g"));
		assertTrue(s3.contains("h"));
		assertTrue(s3.contains("i"));
		assertTrue(s3.contains("j"));
		
		assertFalse(s3.contains("k"));
		assertFalse(s3.contains("l"));
		assertFalse(s3.contains("m"));
		assertFalse(s3.contains("n"));
		assertFalse(s3.contains("o"));
		assertFalse(s3.contains("p"));
	}

	@Test
	public void testContainsAll() {
		List<Integer> l1 = new ArrayList<Integer>();
		for(int i = 0; i < 11; i++) {
			l1.add(i);
		}
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		for(int i = 0; i < 11; i++) {
			s1.add(i);
		}
		assertTrue(s1.containsAll(l1));
		
		l1.add(100);
		assertTrue(!s1.containsAll(l1));
		
		l1.clear(); s1.clear();
		assertTrue(s1.containsAll(l1));
	}

	@Test
	public void testIsEmpty() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		assertTrue(s1.isEmpty());
		s1.add(0);
		assertTrue(!s1.isEmpty());
		
	}

	@Test
	public void testRemove() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}
		s1.remove(1);
		assertTrue(s1.size == 9);
		assertTrue(!s1.contains(1));
		s1.remove(10);
		assertTrue(!s1.contains(10));
		assertTrue(s1.size == 8);
		s1.clear();
		for(int i = 1; i < 20; i++) {
			s1.add(i);
		}
		for(int i = 1; i < 20; i++) {
			assertTrue(s1.remove(i));
		}
		assertTrue(s1.size == 0);
		
	}

	@Test
	public void testRemoveAll() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}
		List<Integer> c1 = new ArrayList<Integer>();
		c1.add(1); c1.add(3); c1.add(5); c1.add(7);
		c1.add(9);
		
		assertTrue(s1.removeAll(c1));
		assertTrue(s1.size == 5);
		
		List<Integer> c2 = new ArrayList<Integer>();
		c2.add(2); c2.add(4); c2.add(6); c2.add(8); c2.add(10);
		
		assertTrue(s1.removeAll(c2));
		assertTrue(s1.size == 0);
		
		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}
		
		c1.clear();
		c1.add(-1000); c1.add(0); c1.add(1000);
		assertTrue(!s1.removeAll(c1));
		assertTrue(s1.size == 10);
		
		s1.clear();
		s1.add(0); s1.add(0); s1.add(0); s1.add(0); s1.add(0);
		c1.clear();
		c1.add(0);
		assertTrue(s1.removeAll(c1));
		System.out.println(s1.size);
		
		s1.clear();
		c1.clear();
		assertTrue(!s1.removeAll(c1));
	}

	@Test
	public void testSize() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		assertTrue(s1.size() == 0);
		for(int i = 0; i < 1001; i++) {
			s1.add(i);
			assertTrue(s1.size() == i+1);
		}
		s1.clear(); assertTrue(s1.size() == 0);
	}

	@Test
	public void testToArray() {
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		for(int i = 1; i < 11; i++) {
			s1.add(i);
		}
		Object[] o1 = new Object[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		Object[] o2 = s1.toArray();
		assertArrayEquals(o1, o2);
		
		s1.clear();
		o2 = s1.toArray();
		o1 = new Object[] {null, null, null, null, null, null, null, null, null, null};
		assertArrayEquals(o1, o2);
		
		MySortedSet<String> s2 = new MySortedSet<String>();
		s2.add("hello"); s2.add("my"); s2.add("friend");
		
		o1 = s2.toArray();
		o2 = new Object[] {"friend", "hello", "my", null, null, null, null, null, null, null};
		assertArrayEquals(o1, o2);
		
		s2.clear();
		o1 = s2.toArray();
		o2 = new Object[] {null, null, null, null, null, null, null, null, null, null};
		assertArrayEquals(o1, o2);
	}

}
