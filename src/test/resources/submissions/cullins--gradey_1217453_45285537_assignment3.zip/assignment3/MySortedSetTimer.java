package assignment3;

public class MySortedSetTimer {
	public static void main(String[] args) {
		//timeContains();
		timeAdd();
	}
	
	public static void timeContains() {
		long start = 0, mid = 0, end = 0;
		long timesToLoop = 100; // subject to change
		
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		
		// warmup
		for (int z = 0; z < 1000000; z++) { 
	    }
		
		for (int N = 100000; N <= 2000000; N += 100000) {
			for(int i = 0; i < timesToLoop; i++) {
				s1 = generateSet(N);
				
				start = System.currentTimeMillis();
				
				for(int z = 0; z < s1.size; z++) 
					s1.contains(z); // code to be timed
				
				mid = System.currentTimeMillis();
				
				// capture loop overhead
				for(int z = 0; z < s1.size; z++) {
				}
					
				end = System.currentTimeMillis();
			}
			
			double average = (double)((mid - start) - (end - mid)) / (double)timesToLoop;
			System.out.println("N size: " + N + " " + "Runtime: " + average);
		}
	}
	
	
	
	
	public static void timeAdd() {
		long start = 0, mid = 0, end = 0;
		long timesToLoop = 20; // subject to change
		
		MySortedSet<Integer> s1 = new MySortedSet<Integer>();
		
		// warmup
		for (int z = 0; z < 1000000; z++) { 
	    }
		
		for (int N = 10000; N <= 200000; N += 10000) {
			for(int i = 0; i < timesToLoop; i++) {
				s1 = generateSet(N);
				
				start = System.currentTimeMillis();
				
				for(int z = 0; z < s1.size; z++) {
					s1.remove(z);
					s1.add(z); // code to be timed
				}
				mid = System.currentTimeMillis();
				
				// capture loop overhead
				for(int z = 0; z < s1.size; z++) {
					s1.remove(z);
				}
					
				end = System.currentTimeMillis();
				
			}
			
			double average = (double)((mid - start) - (end - mid)) / (double)timesToLoop;
			//System.out.println("N size: " + N + " " + "Runtime: " + average);
			System.out.println(average);
			
		}
	}
	
	
	public static MySortedSet<Integer> generateSet(int size) {
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		for(int i = 1; i <= size; i++) {
			set.add(i);
		}
		return set;
	}
	
	
	
}
























