package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Enrico Cecala And Jeramie Mcdonough
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */

public class MySortedSet<E> implements SortedSet<E> {
	private int setSize = 0;
	private int arraySize = 10;
	private Object[] mySortedSet;
	private Comparator<? super E> comparer;
	private boolean comparerChecker;

	public MySortedSet() {
		mySortedSet = new Object[10];
		comparerChecker = true;
	}

	public MySortedSet(Comparator<? super E> comparer) {
		this();
		this.comparer = comparer;
		comparerChecker = false;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */

	@Override
	public Comparator<? super E> comparator() {
		return comparer;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */

	@Override
	public E first() throws NoSuchElementException {
		if (isEmpty())
			return null;
		return (E)mySortedSet[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */

	@Override
	public E last() throws NoSuchElementException {
		if (isEmpty())
			return null;
		return (E) mySortedSet[setSize - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */

	@Override
	public boolean add(E o) {
		if (this.isEmpty()) {
			mySortedSet[0] = o;
			setSize++;
			return true;
		}
		if (mySortedSet.length >= arraySize)
			growArray();

		int insertPos = binarySearch(o, this.comparer, true);
		if (insertPos == -1)
			return false;
		Object[] temp = new Object[setSize + 1];
		for (int i = 0; i < insertPos; i++) {
			temp[i] = mySortedSet[i];
		}
		temp[insertPos] = o;
		for (int i = insertPos + 1; i < setSize + 1; i++) {
			temp[i] = mySortedSet[i - 1];
		}
		setSize++;
		mySortedSet = temp;
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */

	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean allAdded = false;
		for (E o : c) {
			if(add(o))
				allAdded=true;
		}

		return allAdded;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */

	@Override
	public void clear() {
		Object[] allClean = new Object[10];
		mySortedSet = allClean;
		setSize = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */

	@Override
	public boolean contains(Object o) {
		@SuppressWarnings("unchecked")
		int objectPos = binarySearch((E) o, this.comparer, false);
		if (objectPos == -1)
			return false;
		return true;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */

	@Override
	public boolean containsAll(Collection<?> c) {
		boolean allInCollection = false;
		for (Object o : c) {
			allInCollection = allInCollection || this.contains(o);
		}

		return allInCollection;
	}

	/**
	 * @return true if this set contains no elements
	 */

	@Override
	public boolean isEmpty() {
		if (setSize == 0) {
			return true;
		}
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */

	@Override
	public Iterator<E> iterator() {

		Iterator<E> itr = new Iterator<E>() {
			private boolean iterateNext;
			private int index = -1;

			@Override
			public boolean hasNext() {
				return (index < setSize - 1);
			}

			@Override
			public E next() {
				if (index >= setSize - 1) {
					throw new NoSuchElementException();
				}
				index++;
				iterateNext = true;
				return (E) mySortedSet[index];
			}

			@Override
			public void remove() {
				if (iterateNext) {
					MySortedSet.this.remove((E) mySortedSet[index]);
					iterateNext = false;
					index--;
				} else
					throw new IllegalStateException();
			}
		};
		return itr;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */

	@Override
	public boolean remove(Object o) {

		@SuppressWarnings("unchecked")
		int removePos = binarySearch((E) o, this.comparer, false);

		if (removePos == -1)
			return false;

		Object[] temp = new Object[setSize - 1];
		for (int i = 0; i < removePos; i++) {
			temp[i] = mySortedSet[i];
		}
		for (int i = removePos; i < setSize - 1; i++) {
			temp[i] = mySortedSet[i + 1];
		}

		setSize--;
		mySortedSet = temp;

		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */

	@Override
	public boolean removeAll(Collection<?> c) {
		boolean allRemoved = false;
		for (Object o : c) {
			if(remove(o))
				allRemoved=true;
		}

		return allRemoved;
	}

	/**
	 * @return the number of elements in this set
	 */

	@Override
	public int size() {
		if(isEmpty())
			return 0;
		return setSize;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */

	@Override
	public Object[] toArray() {
		if (isEmpty())
			return null;
		return mySortedSet;
	}

	/**
	 * This method searches through objects when called efficiently with a binary search. 
	 * 
	 * @param E, comparer
	 * 
	 * @return--middle value the value you are looking for basically or a negative value if the element exists. 
	 */

	@SuppressWarnings("unchecked")
	private int binarySearch(E key, Comparator<? super E> comparer,
			boolean addCall) {
		int start = 0;
		int end = setSize - 1;
		int middle = start + (end - start) / 2;
		while (start <= end) {
			middle = start + (end - start) / 2;
			if (comparerChecker) {
				if (((Comparable<E>) key).compareTo((E) mySortedSet[middle]) > 0)
					start = middle + 1;
				else if (((Comparable<E>) key)
						.compareTo((E) mySortedSet[middle]) < 0)
					end = middle - 1;

				else if (((Comparable<E>) key)
						.compareTo((E) mySortedSet[middle]) == 0) {
					if (addCall)
						return -1;
					else
						return middle;
				}

			} else {
				if (comparer.compare(key, (E) mySortedSet[middle]) > 0)
					start = middle + 1;
				else if (comparer.compare(key, (E) mySortedSet[middle]) < 0)
					end = middle - 1;
				else if (comparer.compare(key, (E) mySortedSet[middle]) == 0) {
					if (addCall)
						return -1;
					else
						return middle;
				}
			}
		}
		if (addCall) {
			if (middle == end)
				middle++;
			return middle;
		} else
			return -1;
	}

	/**
	 * This method Grows the Array when the Array has no more room expanding it by 2 times. 
	 */
	
	private void growArray() {
		arraySize = arraySize * 2;
		Object[] tmpBiggerArray = new Object[arraySize];
		for (int i = 0; i < setSize; i++) {
			tmpBiggerArray[i] = mySortedSet[i];
		}

		mySortedSet = tmpBiggerArray;
	}

}
