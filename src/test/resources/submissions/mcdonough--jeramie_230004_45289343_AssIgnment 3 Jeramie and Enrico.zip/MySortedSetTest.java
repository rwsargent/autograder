package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *  This is the comparator we are using to test our comparator class. It compares integers left side 
 *  and right side placing the lesseer value first. 
 *  
 * @author Enrico Cecala and Jeramie Mcdonough
 *
 */

public class MySortedSetTest {

	
	
	class MyComparatorTest implements Comparator<Integer>
		{
			public int compare(Integer lhs,Integer rhs)
			{
				return (int)(lhs-rhs);
			}
		}
	/**
	 * These Object's are created to test certain functions within our JUnit test class. 
	 */
	
	public MyComparatorTest comparator = new MyComparatorTest();

	public MySortedSet<Integer> integerTestSort = new MySortedSet<Integer> (comparator);
	public ArrayList<Integer> integerList1 = new ArrayList<Integer>();
	public ArrayList<Integer> integerList2 = new ArrayList<Integer>();
	
	public MySortedSet<String> stringTestSort = new MySortedSet<String> ();
	public ArrayList<String> stringList1 = new ArrayList<String>();
	public ArrayList<String> stringList2 = new ArrayList<String>();
	
	@BeforeClass
	public static <E> void setUpBeforeClass() throws Exception 
	{
		 
	}

	/**
	 * These tests test the first and the last methods built into our MySortedSet. 
	 * Our add function is tested as well adding thing to the Object so they can be tested. 
	 * 
	 * @return -- These tests return the first and last elements within the object selected. 
	 */
	@Test
	public void firstLastInteger() 
	{
		integerTestSort.clear();
		integerList1.clear();
		integerList1.add(50);
		integerList1.add(6);
		integerList1.add(10);
		integerList1.add(9);
		integerList1.add(100);
		
		assertTrue(integerTestSort.addAll(integerList1));
		Object firstTest1 = integerTestSort.first();
		Object lastTest1 = integerTestSort.last(); 
		
		System.out.println(firstTest1);
		System.out.println(lastTest1);
		
		//Testing the first Function
		assertEquals(firstTest1,6);
		//This one should fail
		assertNotSame(lastTest1,firstTest1);

		//Testing the Last Function
		assertEquals(lastTest1,100);
		//This one should fail
		assertNotSame(firstTest1,lastTest1); 
	}
	
	/**
	 * This test test's the ability of our add and addAll methods specifically.
	 * 
	 */
	
	@Test
	public void addInteger()
	{
		System.out.println("Add individual integer objects test.");
		integerTestSort.clear();
		integerList1.clear();
		boolean addtest1 = integerTestSort.add(2);
		boolean addtest2 = integerTestSort.add(3);
		boolean addtest3 = integerTestSort.add(1);
		boolean addtest4 = integerTestSort.add(4);
		
		assertTrue(addtest1);
		assertFalse(integerTestSort.add(1));
		assertTrue(addtest2);
		assertFalse(integerTestSort.add(2));
		assertTrue(addtest3);
		assertFalse(integerTestSort.add(3));
		assertTrue(addtest4);
		assertFalse(integerTestSort.add(4));
		
		integerList1.add(50);
		integerList1.add(6);
		integerList1.add(10);
		integerList1.add(9);
		integerList1.add(100);
		integerList1.add(68);
		integerList1.add(42);
		integerList1.add(78);
		integerList1.add(21);
		
		System.out.println("Add medium integer list test.");
		assertTrue(integerTestSort.addAll(integerList1));
		
		integerTestSort.clear();
		
		System.out.println("Add large(10000) integer list test. ");
		
		integerList2=createLargeTestList(10000);
		
		assertTrue(integerTestSort.addAll(integerList2));
		
		
	}
	
	/**
	 * This test test's the remove, clear, and RemoveAll function removing a selected element. 
	 */
	
	@Test
	public void removeInteger()
	{
		System.out.println("Remove individual integer objects test");
		integerTestSort.clear();
		
		boolean addtest1 = integerTestSort.add(2);
		boolean addtest2 = integerTestSort.add(3);
		boolean addtest3 = integerTestSort.add(1);
		boolean addtest4 = integerTestSort.add(4);
		
		assertTrue(addtest1);
		assertTrue(addtest2);
		assertTrue(addtest3);
		assertTrue(addtest4);
		
		boolean remTest1 = integerTestSort.remove(3);
		boolean remTest2 = integerTestSort.remove(2);
		
		assertTrue(remTest1);
		assertFalse(integerTestSort.remove(2));
		assertTrue(remTest2);
		assertFalse(integerTestSort.remove(3));
		
		System.out.println("Remove large integer list test");
		
		integerList1.clear();
		
	    
	    for(int i = 500; i>0;i--)
	    	integerList1.add(i);
	    assertTrue(integerTestSort.addAll(integerList1));
		
		integerList2.clear();
		for(int i =0; i<200;i++)
			integerList2.add(i);

		
		assertTrue(integerTestSort.removeAll(integerList2));
		
		integerTestSort.clear();
		Object[] testArray = integerTestSort.toArray();
		for(int i=0; i<integerTestSort.size();i++)
			System.out.println(testArray[i]);
		
	}
	/**
	 * This test test's the iterator to test and make sure it goes through the list 
	 * and returns a ascending list of values. 
	 */
	
	@Test
	public void iteratorInteger()
	{
		System.out.println("Iterator through integer objects test!");
		integerTestSort.clear();
		integerTestSort.add(50);
		integerTestSort.add(3);
		integerTestSort.add(6);
		integerTestSort.add(10);
		integerTestSort.add(9);
		integerTestSort.add(100);
		integerTestSort.add(68);
		integerTestSort.add(42);
		integerTestSort.add(78);
		integerTestSort.add(2);
		integerTestSort.add(21);
		
		Iterator<Integer> go = integerTestSort.iterator();
		
		while(go.hasNext())
		{
			System.out.println(go.next());
		}
	}
	
	/**
	 * This test test's the contains and containsAll method looking for a specific element and returning that element. 
	 */
	
	@Test
	public void containsInteger()
	{
		System.out.println("Contains integer object test");
		integerTestSort.clear();
		integerTestSort.add(50);
		integerTestSort.add(3);
		integerTestSort.add(6);
		integerTestSort.add(10);
		integerTestSort.add(9);
		integerTestSort.add(100);
		integerTestSort.add(68);
		integerTestSort.add(42);
		integerTestSort.add(78);
		integerTestSort.add(2);
		integerTestSort.add(21);
		
		assertTrue(integerTestSort.contains(3));
		assertFalse(integerTestSort.contains(1));
		assertTrue(integerTestSort.contains(10));
		assertFalse(integerTestSort.contains(99));
		
		integerList1.clear();
		
		System.out.println("Contains integer object list test");
	    
	    for(int i = 500; i>0;i--)
	    	integerList1.add(i);
	    
	    assertTrue(integerTestSort.addAll(integerList1));
		
		integerList2.clear();
		for(int i =0; i<200;i++)
			integerList2.add(i);
		assertTrue(integerTestSort.containsAll(integerList2));
		
	}
	
	/**
	 * This generates an Object of random values to test the methods abilities to 
	 * sort, add, and discard where necessary. 
	 * @param-- size
	 * @return--testList
	 */
	
	private ArrayList<Integer> createLargeTestList(int size)
	{
		ArrayList<Integer> testList = new ArrayList<Integer>();
		for(int i = 0; i<size+1;i++)
			testList.add(generateRandomIntegers());
		return testList;
	}
	
	/**
	 * This generates a random number generator Object. 
	 * 
	 * @return -- ranNum
	 */
	
	private int generateRandomIntegers() {
		Random randomNumGen = new Random();
		int ranNum = randomNumGen.nextInt(10000);
		return ranNum;
	}
	
	/**
	 * This test test the first and last methods with strings grabbing the last an first elements of the Object. 
	 * 
	 * @return-- last element and first element
	 */
	
	 public void firstLastString() 
	{
		stringTestSort.clear();
		stringList1.clear();
		stringList1.add("go");
		stringList1.add("neat");
		stringList1.add("Done");
		stringList1.add("help");
		stringList1.add("apple");
		stringList1.add("abacus");
		stringList1.add("check");
		stringList1.add("lost night working");
		stringList1.add("running");
		stringList1.add("time is lost");
		stringList1.add("hello");
		
		assertTrue(stringTestSort.addAll(stringList1));
		Object firstTest1 = stringTestSort.first();
		Object lastTest1 = stringTestSort.last(); 
		
		System.out.println(firstTest1);
		System.out.println(lastTest1);
		
		//Testing the first Function
		//assertEquals(firstTest1,6);
		//This one should fail
		assertNotSame(lastTest1,firstTest1);

		//Testing the Last Function
		//assertEquals(lastTest1,100);
		//This one should fail
		assertNotSame(firstTest1,lastTest1); 
	}
	
	 /**
	  * This test test's the add and addAll methods of for string putting the string or strings in alphabetical order. 
	  * 
	  */
	 
	@Test
	public void addString()
	{
		System.out.println("Add individual string objects test.");
		stringTestSort.clear();
		stringList1.clear();
		boolean addtest1 = stringTestSort.add("Jim");
		boolean addtest2 = stringTestSort.add("Bill");
		boolean addtest3 = stringTestSort.add("Tommy");
		boolean addtest4 = stringTestSort.add("Dill");

		
		assertTrue(addtest1);
		assertFalse(stringTestSort.add("Jim"));
		assertTrue(addtest2);
		assertFalse(stringTestSort.add("Bill"));
		assertTrue(addtest3);
		assertFalse(stringTestSort.add("Tommy"));
		assertTrue(addtest4);
		assertFalse(stringTestSort.add("Dill"));
		
		stringList1.add("go");
		stringList1.add("neat");
		stringList1.add("Done");
		stringList1.add("help");
		stringList1.add("apple");
		stringList1.add("abacus");
		stringList1.add("check");
		stringList1.add("lost night working");
		stringList1.add("running");
		stringList1.add("time is lost");
		stringList1.add("hello");
		
		System.out.println("Add medium string list test.");
		assertTrue(stringTestSort.addAll(stringList1));
		
		stringTestSort.clear();		
		
	}
	
	/**
	 * This test test's the remove and removeAll methods removing the appropriate object or object's as specified by the user. 
	 * 
	 */
	
	@Test
	public void removeString()
	{
		System.out.println("Remove individual string objects test");
		stringTestSort.clear();
		
		boolean addtest1 = stringTestSort.add("Jim");
		boolean addtest2 = stringTestSort.add("Bill");
		boolean addtest3 = stringTestSort.add("Tommy");
		boolean addtest4 = stringTestSort.add("Dill");
		
		assertTrue(addtest1);
		assertTrue(addtest2);
		assertTrue(addtest3);
		assertTrue(addtest4);
		
		boolean remTest1 = stringTestSort.remove("Bill");
		boolean remTest2 = stringTestSort.remove("Tommy");
		
		assertTrue(remTest1);
		assertFalse(stringTestSort.remove("Bill"));
		assertTrue(remTest2);
		assertFalse(stringTestSort.remove("Tommy"));
		
		stringList1.clear();
	    
		stringList1.add("go");
		stringList1.add("neat");
		stringList1.add("Done");
		stringList1.add("help");
		stringList1.add("apple");
		stringList1.add("abacus");
		stringList1.add("check");
		stringList1.add("lost night working");
		stringList1.add("running");
		stringList1.add("time is lost");
		stringList1.add("hello");
		
		assertTrue(stringTestSort.addAll(stringList1));
		
		stringList2.add("Dill");
		stringList2.add("neat");
		stringList2.add("Done");
		stringList2.add("help");
		stringList2.add("lost night working");
		stringList2.add("running");
		stringList2.add("hello");
		
		System.out.println("Add medium remove string list test.");
		assertTrue(stringTestSort.removeAll(stringList2));
		
	}
	
	/**
	 * This test's the ability to iterate through the object
	 */
	
	@Test
	public void iteratorString()
	{
		System.out.println("Iterator through string objects test!");
		stringTestSort.clear();
		stringTestSort.add("go");
		stringTestSort.add("neat");
		stringTestSort.add("Done");
		stringTestSort.add("help");
		stringTestSort.add("Apple");
		stringTestSort.add("abacus");
		stringTestSort.add("check");
		stringTestSort.add("lost night working");
		stringTestSort.add("running");
		stringTestSort.add("Time is lost");
		stringTestSort.add("hello");
		
		Iterator<String> go = stringTestSort.iterator();
		
		while(go.hasNext())
		{
			System.out.println(go.next());
		}
	}
	
	/**
	 * This test test's contains or containsAll for a specific element or element's  within the Object 
	 * and returns the element if it is within the Object. 
	 */
			
	
	@Test
	public void containsString()
	{
		System.out.println("Contains string object test");
		stringTestSort.clear();
		stringTestSort.add("go");
		stringTestSort.add("neat");
		stringTestSort.add("Done");
		stringTestSort.add("help");
		stringTestSort.add("apple");
		stringTestSort.add("abacus");
		stringTestSort.add("check");
		stringTestSort.add("lost night working");
		stringTestSort.add("running");
		stringTestSort.add("time is lost");
		stringTestSort.add("hello");
		
		assertTrue(stringTestSort.contains("Done"));
		assertFalse(stringTestSort.contains("Hello"));
		assertTrue(stringTestSort.contains("hello"));
		assertFalse(stringTestSort.contains("orange"));
		
		stringList1.clear();
		
		System.out.println("Contains string object list test");
	    
		stringList1.add("go");
		stringList1.add("neat");
		stringList1.add("Done");
		stringList1.add("help");
		stringList1.add("apple");
		stringList1.add("abacus");
		stringList1.add("hello");
		
		assertTrue(stringTestSort.containsAll(stringList1));
		
	}
	
}
