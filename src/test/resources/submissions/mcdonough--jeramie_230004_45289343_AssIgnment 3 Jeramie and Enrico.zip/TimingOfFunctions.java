package assignment3;

public class TimingOfFunctions
{

  public static void main(String[] args) 
  {
    long startTime, midpointTime, stopTime;

    // First, spin computing stuff until one second has gone by.
    // This allows this thread to stabilize.

    startTime = System.nanoTime();
    while (System.nanoTime() - startTime < 1000000000) ;

    // Now, run the test.

    long timesToLoop = 1000;

    for(int n = 1000; n <= 20000; n+=1000){

    	MySortedSet<Integer> TimerTest = new MySortedSet<Integer>(); 
    	
    	for(int i =0; i < n; i++)
    	{
    	TimerTest.add(i);
    	}
    	
    	startTime = System.nanoTime();
    	
    	int toAdd = -1;
    	for (long i = 0; i < timesToLoop; i++)
    		//TimerTest.contains(-1);
    		TimerTest.add(toAdd--);

    	midpointTime = System.nanoTime();

    	// Run an empty loop to capture the cost of running the loop.

    	for (long i = 0; i < timesToLoop; i++) { // empty block
    	}

    	stopTime = System.nanoTime();

    	// Compute the time, subtract the cost of running the loop
    	// from the cost of running the loop and computing square roots.
    	// Average it over the number of runs.

    	double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
    			/ timesToLoop;

    	System.out.println(n + "\t" + averageTime);
    }}
}