/*
 * @Author Anna Buchman
 * @Author Alex Motro
 */

package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> {
	protected int size = 0;
	protected E[] elements;
	private Comparator<? super E> comp;
	

	/**
	 * @param args
	 */

	@SuppressWarnings("unchecked")
	public MySortedSet() {
		elements = (E[]) new Object[10];
		this.comp = null;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> c) {
		elements = (E[]) new Object[10];
		this.comp = c;
	}

	@Override
	public Comparator<? super E> comparator() {
		return comp;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		return elements[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		return elements[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {
		int place = binarySearch(o);
		if (place <0 || (place==0 && elements[0]!= o)) {
			if (size == elements.length-1) {
				//Grow the array
				E[] temp = (E[]) new Object[elements.length*2];
				for (int i = 0; i < elements.length; i++)
					temp[i] = elements[i];
			
				elements = temp;
			
			}
			
			int placeToPut = Math.abs(place);
			for (int i = size + 1; i > placeToPut; i--){
				elements[i] = elements[i - 1];
			}
			elements[placeToPut] = o;
			size = size +1;
			return true;
		}
		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *       		-- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean addAll(Collection<? extends E> c) {
		E[] collectionArray = (E[]) new Object[c.size()];
		collectionArray = (E[]) c.toArray();
		for (int pos=0; pos<c.size(); pos++){
			add(collectionArray[pos]);
		}
		return true;
	}
	
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		elements = (E[]) new Object[10];
		size = 0;

	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		return binarySearch(o) >= 0;
	}


	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean containsAll(Collection<?> c) {
		E[] collectionArray = (E[]) new Object[c.size()];
		collectionArray = (E[]) c.toArray();
		for (int pos=0; pos<c.size(); pos++){
			if (!contains(collectionArray[pos])){
				return false;
			}
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (size == 0)
			return true;

		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		@SuppressWarnings({ "rawtypes", "hiding" })
		class NewIterator<E> extends MySortedSet implements Iterator<E>{
			private int index = 0;
			private MySortedSet<E> ourSortedSet;
			
			NewIterator(MySortedSet ourSortedSet){
				
			}

			@Override
			public boolean hasNext() {
				if (index < ourSortedSet.size){
					return true;
				}
				return false;
			}

			@Override
			public E next() throws NoSuchElementException {
				return ourSortedSet.elements[index++];
			}

			@Override
			public void remove() {
				ourSortedSet.elements[index] = ourSortedSet.elements[index+1];
				for (int i = index+1; i<ourSortedSet.size - 1; i++){
					ourSortedSet.elements[i] = ourSortedSet.elements[i+1];
				}
				ourSortedSet.elements[ourSortedSet.size - 1] = null;
			}

		}
		NewIterator<E> it = new NewIterator<E>(this);	
		return it;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int toRemove = binarySearch(o);
		if (toRemove > 0 || (toRemove == 0 && elements[toRemove]== o)) {
			elements[toRemove] = null;
			for (int i = toRemove; i < elements.length - 1; i++)
				elements[i] = elements[i + 1];
			size--;
			return true;
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean removeAll(Collection<?> c) {
		for (E thing : (Collection<E>) c)
			remove(thing);
		/*E[] collectionArray = (E[]) new Object[c.size()];
		collectionArray = (E[]) c.toArray();
		for (int pos=0; pos<c.size(); pos++){
			remove(collectionArray[pos]);
		}*/
		
		return true;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		return elements;
	}

	/** @param o 
	 * 		-- the object to search for
	 * 
	 * @return the position in the array of a given object. If the object is not in the array, the negative of the position where that 
	 * object would be placed is returned.
	 */
	@SuppressWarnings("unchecked")
	protected int binarySearch(Object o) {
		int start = 0;
		int end = size;
		int position = 0;
		
		while (start != end) {
			position = ((start + end) / 2);
			E middle = (E) elements[position];
			if (middle.equals(o)){

				return position;
			}

			if (comp == null) {
				if (((Comparable<Object>) middle).compareTo((Comparable<Object>) o) > 0) {
					end = position;

					continue;
				}
				else {
					start = position+1;
					position++;
					continue;
				} // Go up
			}

			if (comp.compare(middle, (E) o) > 0) {
				end = position;
				continue;
			}

			else {
				start = position;
				
				continue;
			}

		}
		return -1*position;
	}
	
	//@SuppressWarnings("unchecked")
	/*protected int toAdd(Object o) {
		int start = 0;
		int end = size;
		int position = 0;
		while (start != end) {
			position = ((start + end) / 2);
			E middle = (E) elements[position];
			if (middle.equals(o)){

				return position;
			}

			if (comp == null) {
				if (((Comparable<Object>) middle)
						.compareTo((Comparable<Object>) o) > 0) {
					end = position;

					continue;
				}
				else {
					start = position;
					continue;
				} // Go up
			}

			if (comp.compare(middle, (E) o) > 0) {
				end = position;
				continue;
			}

			else {
				start = position;
				continue;
			}

		}
		return -1;
	}*/
	



public static void main(String[] args){
	MySortedSet<Integer> testSet = new MySortedSet<Integer>();
	
	testSet.add(23);
	testSet.add(5);
	testSet.add(3);
	testSet.add(4);
}
}


