/*
 * @Author Anna Buchman
 * @Author Alex Motro
 */

package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


@SuppressWarnings("rawtypes")
public class MySortedSetTests extends MySortedSet{
	MySortedSet<Integer> ints = new MySortedSet<Integer>();
	List<Integer> stuffs = new ArrayList<Integer>();
	List<Integer> moarStuffs = new ArrayList<Integer>();
	MySortedSet<String> strings = new MySortedSet<String>();
	List<String> words = new ArrayList<String> ();
	List<String> moarWords = new ArrayList<String>();


	@Before
	public void setUp() throws Exception {
		ints.add(23);
		ints.add(7);
		ints.add(10);
		ints.add(36);
		ints.add(83);
		ints.add(84);
		strings.add("Thank");
		strings.add("Goodness");
		strings.add("it");
		strings.add("appears");
		strings.add("to");
		strings.add("be");
		strings.add("working");
		for(int i = 1; i < 10; i++) {
			moarStuffs.add(i);
		}
		stuffs.add(7);
		stuffs.add(23);
		words.add("Ello");
		words.add("chap");
		moarWords.add("Thank");
		moarWords.add("Goodness");
		
	}

	@After
	public void tearDown() throws Exception {
	}

	
	
	@Test
	public void addTests(){
		assertTrue(ints.add(47));
		assertFalse(ints.add(7));
		assertTrue(ints.add(51));
		assertFalse(ints.add(51));
		assertTrue(strings.add("Huzzah"));
		assertTrue(strings.add("Queen Victoria"));
		assertFalse(strings.add("Huzzah"));
		assertFalse(strings.add("it"));
		}

	@Test 
	public void removeTests(){
		assertFalse(ints.remove(100));
		assertTrue(ints.remove(7));
		assertFalse(ints.remove(7));
		assertTrue(ints.remove(83));
		assertFalse(ints.remove(83));
		assertTrue(strings.remove("it"));
		assertFalse(strings.remove("it"));
		assertTrue(strings.remove("working"));
		assertFalse(strings.remove("fish"));
	}
	
	@Test
	public void firstTests(){
		assertEquals(7, (int)ints.first());
		assertEquals("Goodness", strings.first());
		
	}
	
	@Test
	public void lastTests(){
		assertEquals(84, (int)ints.last());
		assertEquals("working", strings.last());
	}
	
	@Test
	public void addAllTests(){		
		assertTrue(ints.addAll(moarStuffs));
		assertEquals(14, ints.size());
		assertTrue(strings.addAll(words));
		assertEquals(9, strings.size());
	}
	
	@Test
	public void clearTests(){
		ints.clear();
		assertEquals(0, ints.size());
		strings.clear();
		assertEquals(0, strings.size());
	}
	
	@Test
	public void containsTests(){
		assertFalse(ints.contains(20));
		assertTrue(ints.contains(7));
	}
	
	@Test
	public void containsAllTests(){
		
	assertTrue(ints.containsAll(stuffs));
	assertFalse(ints.containsAll(moarStuffs));
	assertFalse(strings.containsAll(words));
	assertTrue(strings.containsAll(moarWords));
	}
	
	@Test
	public void isEmptyTests(){
		ints.clear();
		assertTrue(ints.isEmpty());
		strings.clear();
		assertTrue(strings.isEmpty());
	}
	
	@Test
	public void removeAllTests(){
		ints.removeAll(stuffs);
		assertEquals(10, (int)ints.first());
		assertEquals(4, ints.size());
		strings.removeAll(moarWords);
		assertEquals("appears", strings.first());
		assertEquals(5, strings.size());
	}


}