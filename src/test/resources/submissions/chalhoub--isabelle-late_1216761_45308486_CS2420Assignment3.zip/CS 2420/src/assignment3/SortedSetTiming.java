package assignment3;

import java.util.Random;

/**
 * Timing Tests for the MySortedSet class.
 * 
 * @author Isabelle Chalhoub & Andrew Yavornitzky
 *
 */
public class SortedSetTiming 
{
	public static void main(String[] args) 
	{
		long startTime, midpointTime, stopTime;
		MySortedSet timingSet = new MySortedSet();
		
		//Used for the contains test.
		Random rand = new Random();
		 
		for (int i = 0; i < 100000; i++)
		{
			timingSet.add(rand.nextInt((100 - 0) + 1) + 0);
		}

		
		
		
		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) 
		{ // empty block
		}

		// Now, run the test.

		long timesToLoop = 1000000;

		startTime = System.nanoTime();
		
		//Contains test
		//for (long i = 0; i < timesToLoop; i++)
			//timingSet.contains(rand.nextInt((100 - 0) + 1) + 0);
		
		//Add test
		for (long i = 0; i < timesToLoop; i++)
			timingSet.add(-1);

		midpointTime = System.nanoTime();

		// Run an empty loop to capture the cost of running the loop.

		for (long i = 0; i < timesToLoop; i++) 
		{ // empty block
		}

		stopTime = System.nanoTime();
		timingSet.remove(-1);

		// Compute the time, subtract the cost of running the loop
		// from the cost of running the loop and computing square roots.
		// Average it over the number of runs.

		double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
				/ timesToLoop;

		System.out.println("It takes exactly " + averageTime
				+ " nanoseconds to check if the int given is in the set.");
	}
}
