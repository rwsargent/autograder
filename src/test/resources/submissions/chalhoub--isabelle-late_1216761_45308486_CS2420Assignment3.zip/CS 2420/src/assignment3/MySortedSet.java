package assignment3;

import static org.junit.Assert.assertEquals;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Isabelle Chalhoub and Andrew Yavornitzky
 *
 * @param <E>
 * 			-- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E>
{
    private int elementCount = 0;
    private int arraySize = 10;
    private E[] mySet;
    private Comparator<? super E> sorter;
    private boolean useComp;
    private boolean shouldAddOrRemove = true;

    /**
     * Constructor for a naturally ordered set.
     */
    public MySortedSet()
    {
        mySet = (E[]) new Object[arraySize];
        useComp = false;
    }
    
    /**
     * Constructor for a set ordered by a given comparator.
     * 
     * @param sorter  -- the comparator used to sort the set.
     */
    public MySortedSet(Comparator<? super E> sorter)
    {
        // initialize list with comparator ordering
        this();
        useComp = true;
    }

    /**
     * @return The comparator used to order the elements in this set, or null if
     *         this set uses the natural ordering of its elements (i.e., uses
     *         Comparable).
     */
    @Override
    public Comparator<? super E> comparator() 
    {
        return this.comparator();
    }

    /**
     * @return the first (lowest, smallest) element currently in this set
     * @throws NoSuchElementException
     *             if the set is empty
     */
    @Override
    public E first() throws NoSuchElementException 
    {
        if (this.elementCount == 0)
            throw new NoSuchElementException("The list is empty.");
        return mySet[0];
    }

    /**
     * @return the last (highest, largest) element currently in this set
     * @throws NoSuchElementException
     *             if the set is empty
     */
    @Override
    public E last() throws NoSuchElementException 
    {
        if (this.elementCount == 0)
            throw new NoSuchElementException("The list is empty.");
        return mySet[elementCount - 1];
    }

    /**
     * Adds the specified element to this set if it is not already present and
     * not set to null.
     * 
     * @param o -- element to be added to this set
     * @return true if this set did not already contain the specified element
     */
    @Override
    public boolean add(E o) 
    {   
    	if (o == null)
    		return false;
    	
    	// If the set is empty
        if (elementCount == 0)
        {
        	mySet[0] = o;
        	elementCount++;
        }
        else
        {
        	// Check if the object already exists
        	shouldAddOrRemove = true;
        	int needToAddPos = binarySearch(o);
        	if (shouldAddOrRemove == false)
        		return false;
        	
        	// Check if there is enough space
        	if (elementCount == arraySize)
        	{
        		// Grow the array
        		E[] tempArray = (E[]) new Object[arraySize*2];
        		for (int i = 0; i < elementCount; i++)
        			tempArray[i] = mySet[i];
        		mySet = tempArray;
        		arraySize = 2*arraySize;
        	}
        
        	// Add the element into the correct location
        
        	// If the needToAddPos is the last slot
        	if (needToAddPos == elementCount)
        	{
        		mySet[elementCount] = o;
        		elementCount++;
        		return true;
        	}
        
        	// Anywhere else in the set - shift all the elements above it
        	for (int i = elementCount; i > needToAddPos; i--)
        		mySet[i] = mySet[i-1];
        	mySet[needToAddPos] = o;
        	elementCount++;
        	return true;
        }
        return false;
    }

    /**
     * Adds all of the elements in the specified collection to this set if they
     * are not already present and not set to null.
     * 
     * @param c
     *            -- collection containing elements to be added to this set
     * @return true if this set changed as a result of the call
     */
    @Override
    public boolean addAll(Collection<? extends E> c) 
    {
    	int currentSize = elementCount;
    	
    	// Try to add every element of c
    	for(E element : c)
    	{
			this.add(element);
		}
    	
    	if (currentSize != elementCount)  // the size will change if elements were successfully added
    		return true;
    	return false;
    }

    /**
     * Removes all of the elements from this set. The set will be empty after
     * this call returns.
     */
    @Override
    public void clear() 
    {
    	E[] clearSet = (E[]) new Object[10];  // Create new empty set
    	mySet = clearSet;
    	elementCount = 0;
    }

    /**
     * @param o
     *            -- element whose presence in this set is to be tested
     * @return true if this set contains the specified element
     */
    @Override
    public boolean contains(Object o) 
    {
    	shouldAddOrRemove = true;
    	if (o == null)
    		return false;
    	if (elementCount == 0)
    		return false;
    	
    	// Search for object
    	E searchObj = (E) o;
    	binarySearch(searchObj);
        if (shouldAddOrRemove == false)
        	return true;
        return false;
    }

    /**
     * @param c
     *            -- collection to be checked for containment in this set
     * @return true if this set contains all of the elements of the specified
     *         collection
     */
    @Override
    public boolean containsAll(Collection<?> c) 
    {
    	//Check if mySet contains any elements from c
    	for(Object element : c)
    	{
			if(!this.contains(element))
				return false;
		}
    	return true;
    }

    /**
     * @return true if this set contains no elements
     */
    @Override
    public boolean isEmpty() 
    {
        if (elementCount == 0)
            return true;
        return false;
    }

    /**
     * @return an iterator over the elements in this set, where the elements are
     *         returned in sorted (ascending) order
     */
    @Override
    public Iterator<E> iterator() 
    {
        class setIterator implements Iterator<E>
        {
        	int iteratorPos = 0;
        	boolean gotNext = false;
        	
        	public setIterator()
        	{
        	}
        	
        	public boolean hasNext()
        	{
        		if (iteratorPos < elementCount)
        			return true;
        		return false;
        	}
        	
        	public E next()
        	{
        		if (iteratorPos >= elementCount)
        			throw new NoSuchElementException();
        		iteratorPos++;
        		gotNext = true;
        		return mySet[iteratorPos];
        	}
        	
        	public void remove()
        	{
        		if (gotNext)			// remove can only be called once per next call
        			MySortedSet.this.remove(mySet[iteratorPos]);
        		gotNext = false;
        	}
        }
        return new setIterator();
    }
    
    /**
     * Removes the specified element from this set if it is present.
     * 
     * @param o
     *            -- object to be removed from this set, if present
     * @return true if this set contained the specified element
     */
    @Override
    public boolean remove(Object o) 
    {
    	if (o == null)
    		return false;
    	if (elementCount == 0)
    		return false;
    	
    	E removeObj = (E) o;
    	//shouldAddOrRemove = true;
    	int needToRemovePos = binarySearch(removeObj);
    	
    	//if(shouldAddOrRemove == false)
    		//return false;
    	
    	// If it is the only element on the list
    	if (elementCount == 1)
    	{
    		mySet[0] = null;
    		return true;
    	}
    	// If it is the last element
    	else if (needToRemovePos == elementCount-1)
    	{
    		mySet[elementCount-1] = null;
    		elementCount--;
    		return true;
    	}
    
    	// Anywhere else in the set - shift all the elements above it.
    	else
    	{
    		
    		for (int j = needToRemovePos; j < elementCount; j++)
    			mySet[j] = mySet[j+1];
    		elementCount--;
    		return true;
    	}
    }

    /**
     * Removes from this set all of its elements that are contained in the
     * specified collection.
     * 
     * @param c
     *            -- collection containing elements to be removed from this set
     * @return true if this set changed as a result of the call
     */
    @Override
    public boolean removeAll(Collection<?> c) 
    {
    	int currentSize = elementCount;
    	
    	// Try and remove every element of c
    	for(Object element : c)
    	{
			this.remove(element);
		}
    	
    	if (currentSize != elementCount)  // the size will change if elements were successfully added
    		return true;
    	return false;
    }

    /**
     * @return the number of elements in this set
     */
    @Override
    public int size() 
    {
        return elementCount;
    }

    /**
     * @return an array containing all of the elements in this set, in sorted
     *         (ascending) order.
     */
    @Override
    public Object[] toArray() 
    {
    	Object[] returnArray = new Object[elementCount];
    	// Copy elements into the object array
    	for (int i = 0; i < elementCount; i ++)
    		returnArray[i] = mySet[i];
    	return returnArray;
    }
    
    /**
     * Helper function to do a binary search for the parameter o and to find where it fits in the ordered set.
     * 
     * @param o
     * 			-- The object that is being searched for.
     * @return
     * 			-- The position where the item needs to go. Or -1 if the item already exists.
     */
	public int binarySearch(E o)
    {
		shouldAddOrRemove = true;
		// Binary Search for Comparator Items
		if (useComp)
		{
			int low = 0;
			int high = elementCount - 1;
			int mid = 0;
        
			// If there is only one item in the set
			if (elementCount == 1)
			{
				int compVal = compare(o, mySet[0]);
				if(compVal == 0)
				{
					shouldAddOrRemove = false;
					return 0;
				}
				if (compVal < 0)
					return 0;
				if (compVal > 0)
					return 1;
			}
			
			// If there are only two items in the set
			else if (elementCount == 2)
			{
				int compVal = compare(o, mySet[0]);
				if (compVal == 0)
				{
					shouldAddOrRemove = false;
					return 0;
				}
				if (compVal < 0)
					return 0;
				if (compVal > 0)
				{
					compVal = compare(o, mySet[1]);
					if (compVal == 0)
					{
						shouldAddOrRemove = false;
						return 1;
					}
					if (compVal < 0)
						return 1;
					if (compVal > 0)
						return 2;
				}
			}
			
			else
			{
				// For any other number of items.
				while (low <= high)
				{
					mid = (low + high)/2;
					int compVal = compare(o, mySet[mid]);
					if (compVal == 0) 				// the item already exists
					{
						shouldAddOrRemove = false;
						return mid;
					}
					if (compVal < 0)			// move to lower half
					{
						if (mid == high)
						{
							if (compare(o, mySet[low]) == 0)
							{
								return low;
							} else if (compare(o, mySet[low]) < 0)
							{
								return low;
							} else if (compare(o, mySet[low]) > 0)
							{
								return low + 1;
							}
						}
						if (low == high +1)
						{
							return low;
						}
						high = mid;
						if (compVal > 0)			// move to upper half
						{
							if (mid == low)
							{
								if (compare(o, mySet[high]) == 0)
								{
									return high;
								} else if (compare(o, mySet[high]) < 0)
								{
									return high;
								} else if (compare(o, mySet[high]) > 0)
								{
									return high + 1;
								}
							}
							if (high == low +1)
							{
								return high;
							}
							low = mid;
							low = mid;
						}
					}
				return high;
			}
			return -1;
			}
		}
		
		// Binary Search for Comparable Items
		else
		{
			int low = 0;
			int high = elementCount - 1;
			int mid = 0;
			Comparable<? super E> element = (Comparable<? super E>) o;
			
			// If there is only one item in the set
			if (elementCount == 1)
			{
				int compVal = element.compareTo(mySet[0]);
				if(compVal == 0)
				{
					shouldAddOrRemove = false;
					return -1;
				}
				if (compVal < 0)
					return 0;
				if (compVal > 0)
					return 1;
			}
						
			// If there are only two items in the set
			else if (elementCount == 2)
			{
				int compVal = element.compareTo(mySet[0]);
				if (compVal == 0)
				{
					shouldAddOrRemove = false;
					return 0;
				}
				if (compVal < 0)
					return 0;
				if (compVal > 0)
				{
					compVal = element.compareTo(mySet[1]);
					if (compVal == 0)
					{
						shouldAddOrRemove = false;
						return 1;
					}
					if (compVal < 0)
						return 1;
					if (compVal > 0)
						return 2;
				}
			}
			
			// For any other number of items
			else
			{
				while (low <= high)
				{
					mid = (low + high)/2;
					int compVal = element.compareTo(mySet[mid]);
					if (compVal == 0) 			// the item already exists
					{
						shouldAddOrRemove = false;
						return mid;
					}
					if (compVal < 0)			// move to lower half
					{
						
						if (mid == high)
						{
							if (element.compareTo(mySet[low]) == 0)
							{
								return low;
							} else if (element.compareTo(mySet[low]) < 0)
							{
								return low;
							} else if (element.compareTo(mySet[low]) > 0)
							{
								return low + 1;
							}
						}
						if (low == high +1)
						{
							return low;
						}
						high = mid;
					}
					if (compVal > 0)			// move to upper half
					{
						if (mid == low)
						{
							if (element.compareTo(mySet[high]) == 0)
							{
								return high;
							} else if (element.compareTo(mySet[high]) < 0)
							{
								return high;
							} else if (element.compareTo(mySet[high]) > 0)
							{
								return high + 1;
							}
						}
						if (high == low +1)
						{
							return high;
						}
						low = mid;
					}
				}
				return high;
			}
			return -1;
		}
		return -1;
   }

	/**
	 * Helper function for comparing objects based on natural ordering or the given comparator.
	 * 
	 * @param obj1 -- first object to be compared
	 * @param obj2 -- second object to be compared
	 * @return -- 0 if they are the same, -1 if obj1 < obj2, 1 if obj1 > obj2
	 */
	private int compare(E obj1, E obj2)
	{
		// If there isn't a comparator
		
		if (this.sorter == null)
		{
			Comparable<E> comparable;
			if (obj1 instanceof Comparable)
			{
				comparable = (Comparable<E>) obj1;
				return comparable.compareTo(obj2);
			}
				
		}
		
		// If there is a comparator
		
		return sorter.compare(obj1, obj2);
	}
}