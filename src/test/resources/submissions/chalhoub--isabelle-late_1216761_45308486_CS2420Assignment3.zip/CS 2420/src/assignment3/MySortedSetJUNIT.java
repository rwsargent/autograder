package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit testing for the MySortedSet class.
 * 
 * @author Isabelle Chalhoub & Andrew Yavornitzky
 *
 */
public class MySortedSetJUNIT 
{
	MySortedSet testSet = new MySortedSet();
	ArrayList<Integer> x = new ArrayList<>(Arrays.asList(-1, 2, 44, -4, 100));
	ArrayList<Integer> y = new ArrayList<>();
	ArrayList<Integer> z = new ArrayList<>(Arrays.asList(1, 2, 3));
	
	@Before
	public void setUp() throws Exception 
	{
		testSet.add(2);
		testSet.add(5);
		testSet.add(4);
		testSet.add(3);
		testSet.add(1);
	}

	@After
	public void tearDown() throws Exception 
	{
	}

	@Test
	public void firstTest() 
	{
		assertEquals(1, testSet.first());
		testSet.addAll(x);
		assertEquals(-4, testSet.first());
		testSet.remove(-4);
		assertEquals(-1, testSet.first());
		testSet.clear();
		testSet.add(4);
		assertEquals(4, testSet.first());
	}

	@Test
	public void lastTest()
	{
		assertEquals(5, testSet.last());
		testSet.addAll(x);
		assertEquals(100, testSet.last());
		testSet.remove(100);
		assertEquals(44, testSet.last());
		testSet.clear();
		testSet.add(4);
		assertEquals(4, testSet.last());
	}
	
	@Test
	public void addTest() 
	{
		testSet.add(6);
		assertEquals(6, testSet.size());  // Add to the last slot
		testSet.add(5);
		assertEquals(6, testSet.size());  // Make sure it doesn't add duplicates.
		assertEquals(6, testSet.last());  
		testSet.add(-10);				  // Add to the first slot
		assertEquals(-10, testSet.first());
		testSet.clear();
		testSet.add(4);
		assertEquals(1, testSet.size());
	}

	@Test
	public void addAllTest()
	{
		testSet.addAll(x);
		assertEquals(-4, testSet.first());
		assertEquals(100, testSet.last());
		assertEquals(9, testSet.size());
		testSet.addAll(y);
		assertEquals(9, testSet.size());   // Try and add an empty collection
	}
	
	@Test
	public void clearTest() 
	{
		testSet.addAll(x);
		assertEquals(9, testSet.size());
		testSet.clear();
		assertEquals(0, testSet.size());
	}

	@Test
	public void containsTest()
	{
		assertEquals(true, testSet.contains(4));     // Should exist
		assertEquals(false, testSet.contains(20));	 // Shouldn't exist
		testSet.add(-1);
		assertEquals(true, testSet.contains(-1));
	}
	
	@Test
	public void containsAllTest() 
	{
		assertEquals(false, testSet.containsAll(x));
		assertEquals(true, testSet.containsAll(z));
		assertEquals(true, testSet.containsAll(y));
	}

	@Test
	public void isEmptyTest()
	{
		testSet.addAll(x);
		assertEquals(9, testSet.size());
		assertEquals(false, testSet.isEmpty());
		testSet.clear();
		assertEquals(true, testSet.isEmpty());
		testSet.add(5);
		assertEquals(false, testSet.isEmpty());
	}
	
	@Test
	public void removeTest() 
	{
		testSet.remove(5);
		assertEquals(4, testSet.last());
		testSet.remove(1);
		assertEquals(2, testSet.first());
		assertEquals(3, testSet.size());
	}

	@Test
	public void removeAllTest()
	{
		testSet.removeAll(z);
		assertEquals(2, testSet.size());
		testSet.removeAll(y);
		assertEquals(2, testSet.size());
	}
	
	@Test
	public void sizeTest() 
	{
		assertEquals(5, testSet.size());
		testSet.add(7);
		testSet.add(9);
		assertEquals(7, testSet.size());
		testSet.clear();
		assertEquals(0, testSet.size());
	}

	@Test
	public void toArrayTest()
	{
		Object[] myArray = new Object[testSet.size()];
		myArray = testSet.toArray();
		for (int i = 0; i < testSet.size(); i++)
			System.out.println(myArray[i]);
	}
}
