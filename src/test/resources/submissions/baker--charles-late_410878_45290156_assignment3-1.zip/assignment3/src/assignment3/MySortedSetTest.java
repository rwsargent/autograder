package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.Test;

public class MySortedSetTest<E> {

	static final Comparator<Integer> comp = new Comparator<Integer>(){
	    public int compare(Integer e1, Integer e2) {
	        return (int) (e1 - e2);
	    }
	};

	private Object[] arr1 = new Object[4];
	private Object[] arr4 = new Object[4];
	private Object[] arr6 = new Object[1];
    private MySortedSet arr2 = new MySortedSet(comp);
    private MySortedSet arr3 = new MySortedSet();
    private MySortedSet arr5 = new MySortedSet();
    private ArrayList<Integer> collect1 = new ArrayList<Integer>();
    private ArrayList<Integer> collect2 = new ArrayList<Integer>();
    
    @Test
    public void firstTest1()
    {
    	arr2.add((Integer) 5);
    	arr2.add((Integer) 2);
    	arr2.add((Integer) 0);
    	assertEquals(0, arr2.first());
    	//test an empty array
    	assertEquals(null, arr5.first());
    }
    
    @Test
    public void lastTest1()
    {
    	arr2.add((Integer) 5);
    	arr2.add((Integer) 2);
    	arr2.add((Integer) 0);
    	assertEquals(5, arr2.last());
    	//test an empty array
    	assertEquals(null, arr5.first());
    }
    
    @Test
    public void addCompareTest1() {
        
    	//sorted array
    	arr1[0] = 0;
    	arr1[1] = 2;
    	arr1[2] = 20;
    	arr1[3] = 200000;    	
    	// added out of order
        assertEquals(true, arr2.add((Integer) 2));        
        assertEquals(true, arr2.add((Integer) 200000));
        assertEquals(true, arr2.add((Integer) 20));
        assertEquals(true, arr2.add((Integer) 0));
        // add a number already in the array, if array didn't change false
        assertEquals(false, arr2.add((Integer) 2));
        assertEquals(false, arr2.add((Integer) 0));
        // see if when added it was sorted correctly
        // also tests the toArray method
        assertArrayEquals(arr1, arr2.toArray());
    }
    @Test
    public void addCompareToTest1() {
    	//sorted array
    	arr4[0] = 0;
    	arr4[1] = 7;
    	arr4[2] = 44;
    	arr4[3] = 30000;    	
    	// added out of order
        assertEquals(true, arr3.add((Integer) 7));        
        assertEquals(true, arr3.add((Integer) 30000));
        assertEquals(true, arr3.add((Integer) 44));
        assertEquals(true, arr3.add((Integer) 0));
        // add a number already in the array, if array didn't change false
        assertEquals(false, arr3.add((Integer) 7));
        assertEquals(false, arr3.add((Integer) 0));
        // see if when added it was sorted correctly
        // also tests the toArray method
        assertArrayEquals(arr4, arr3.toArray());

    }
    
    @Test
    public void addAll()
    {
    	collect1.add(7);
    	collect1.add(0);
    	collect1.add(44);
    	collect1.add(30000);
    	arr4[0] = 0;
    	arr4[1] = 7;
    	arr4[2] = 44;
    	arr4[3] = 30000;  
    	assertEquals(true, arr5.addAll(collect1));
    	assertArrayEquals(arr4, arr5.toArray());
    	// nothing added because empty array
    	assertEquals(false, arr5.addAll(collect2));
    	//same values added again
    	assertEquals(false, arr5.addAll(collect1));
    }
    
    @Test
    public void addAllTest2() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);
    	collect1.add(14);
    	collect1.add(12);
    	collect1.add(120);
    	collect1.add(5);
        assertEquals(true, arr3.addAll(collect1));       
    }
    
    @Test
    public void clearTest1() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);
        arr3.clear();        
        //arr5 is an empty array
        assertArrayEquals(arr5.toArray(), arr3.toArray());
    }        
    
    @Test
    public void containsTest1() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);    	
        assertEquals(true, arr3.contains(2));
        assertEquals(false, arr3.contains(200));
        assertEquals(true, arr3.contains(6));
    }
    
    @Test
    public void containsAllTest1() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);
    	collect1.add(2);
    	collect1.add(4);
    	collect1.add(100);
        assertEquals(true, arr3.containsAll(collect1));
        collect2.add(22);
        collect2.add(10000);
        assertEquals(false, arr3.containsAll(collect2));
    }
    
    @Test
    public void isEmptyTest()
    {
    	assertEquals(true, arr5.isEmpty());
    	arr2.add((Integer) 100);
    	assertEquals(false, arr2.isEmpty());
    }
    //tests next() and hasNext()
    @Test
    public void iteratorTest1() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);    	
        assertEquals(true, arr3.iterator().hasNext());
        assertEquals(2, arr3.iterator().next());        
        assertEquals(4, arr3.iterator().next());
        assertEquals(true, arr3.iterator().hasNext());
        assertEquals(6, arr3.iterator().next());
        assertEquals(true, arr3.iterator().hasNext());
        assertEquals(100, arr3.iterator().next());
        assertEquals(false, arr3.iterator().hasNext());
        //assertEquals(null, arr3.iterator().next());
    }
    //tests next() and remove()
    public void iteratorTest2() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6); 
        arr1[0] = 6;
        arr1[1] = 100;
        assertEquals(2, arr3.iterator().next());
        arr3.iterator().remove();
        assertEquals(4, arr3.iterator().next());
        arr3.iterator().remove();
        assertArrayEquals(arr1, arr3.toArray());
    }
    
    @Test
    public void removeTest1() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);
    	collect1.add(2);
    	collect1.add(4);
    	collect1.add(100);
    	collect1.add(6);
        assertEquals(false, arr3.remove(5));
        assertEquals(false, arr3.remove(3000));
    }
    
    @Test
    public void removeTest2() {
        arr6[0] = 1;
    	arr2.add((Integer) 2);
        arr2.add((Integer) 4);
        arr2.add((Integer) 1);
        assertEquals(true, arr2.remove((Integer) 2));
        // 5 isn't there so returns false
        assertEquals(false, arr2.remove(5));
    }
    
    @Test
    public void removeAllTest1() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);
    	collect1.add(2);
    	collect1.add(4);
    	collect1.add(100);
    	collect1.add(6);
        assertEquals(true, arr3.removeAll(collect1));
        assertArrayEquals(arr5.toArray(), arr3.toArray());
        
        // remove nothing returns false
        collect2.add(7);
    	collect2.add(12);
    	collect2.add(13);
    	collect2.add(5);
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);
        assertEquals(false, arr3.removeAll(collect2));
    }
    @Test
    public void removeAllTest2() {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);
    	collect1.add(2);
    	collect1.add(4);
    	collect1.add(100);    	
    	arr6[0] = 6;
        assertEquals(true, arr3.removeAll(collect1));
        assertArrayEquals(arr6, arr3.toArray());
    }
    @Test
    public void sizeTest1()
    {
    	arr3.add((Integer) 2);
        arr3.add((Integer) 4);
        arr3.add((Integer) 100);
        arr3.add((Integer) 6);
    	assertEquals(4, arr3.size());
    	//empty array
    	assertEquals(0, arr5.size());
    }
    
    @Test
    public void toArrayTest1()
    {
    	arr4[0] = 0;
    	arr4[1] = 7;
    	arr4[2] = 44;
    	arr4[3] = 30000; 
    	arr3.add((Integer) 0);
        arr3.add((Integer) 7);
        arr3.add((Integer) 44);
        arr3.add((Integer) 30000);
        assertArrayEquals(arr4, arr3.toArray());
    }
}
