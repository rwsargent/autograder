package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import javax.lang.model.type.ArrayType;
/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Charles Preston Baker
 * 		   Jonathan Chen
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E> {
    
    private Object[] typeArray;
    private Comparator<? super E> comp;
    private int counter;
    private Iterator<E> iterator = new Iterator<E>();
  
    /**
     * Constructor that doesnt take a comparator meaning that it uses comparable
     */
    public MySortedSet()
    {
        typeArray = new Object[1]; //Create a new object array with 30 set as the default
        //Object[] typeArray = {1, 2, 3, 4, 5};
    }
    
    /**
     * constructor that takes a comparator which means it uses the compare method
     * @param comp
     */
    public MySortedSet(Comparator<? super E> comp)
    {
        this(); 
        this.comp = comp; //Set the Comparator the given one.
    }
    
    /**
     * @return The comparator used to order the elements in this set, or null if
     *         this set uses the natural ordering of its elements (i.e., uses
     *         Comparable).
     */
    @Override
    public Comparator<? super E> comparator() {
        
        return comp; //Return the Comparator
    }

    /**
     * @return the first (lowest, smallest) element currently in this set
     * @throws NoSuchElementException
     *             if the set is empty
     */
    @Override
    public E first() throws NoSuchElementException {       
        return (E) typeArray[0]; //Returns first (lowest, smallest) element currently in this set
    }

    /**
     * @return the last (highest, largest) element currently in this set
     * @throws NoSuchElementException
     *             if the set is empty
     */
    @Override
    public E last() throws NoSuchElementException {
        // TODO Auto-generated method stub
        return (E) typeArray[this.size()-1]; //Returns the last (highest/largest) element in the set.
    }

    /**
     * Adds the specified element to this set if it is not already present and
     * not set to null.
     * 
     * @param o
     *            -- element to be added to this set
     * @return true if this set did not already contain the specified element
     */
    @Override
    public boolean add(E o) {
    	Object[] newArray = new Object[this.size()+1]; // Create a new array

    	for (int i = 0; i < newArray.length-1; i++)  // Goes through the original array and copies it to the new array that is +1 length.
    	{    	
    		newArray[i] = typeArray[i];
    	}    	
    	
    	if(this.isEmpty()) // Condition that if the array is empty, set it's 0 pointer to the first value.
    	{
    		typeArray[0] = o;
    		counter++;
    		return true; // Returns true if the set did not already contain the specified element.
    	}
    	else
    	{	         
    		//The Binary Search Method
        	int low = 0;
        	int mid = 0;
        	int high = this.size();
        	int comparedLow = 0;
        	int comparedMid;
        	
        	while(low < high)
        	{
        		mid = (low + high)/2;
        		
        		if(comp == null)
        		{
        			comparedMid = ((Comparable)o).compareTo((E) typeArray[mid]);
        			comparedLow =  ((Comparable)o).compareTo( (E) typeArray[low]);
        		}
        		else
        		{
        			comparedMid = comp.compare(o, (E) typeArray[mid]);
        			comparedLow =  comp.compare(o, (E) typeArray[low]);
        		}
        		
        		if(comparedMid == 0)
        		{
        			return false;
        		}
        		
        		if ( comparedMid > 0)
        		{
        			low = mid + 1;
        		}
        		else
            	{
            		high = mid;
            	}        			
        	}        		
        		
        	if ( low == this.size() || comparedLow != 0) //Condition if the lowest index for the given element is not found.
        	{
        		for(int i = 0; i < low; i++) //Goes through the array to copy it to a new Array for shifting elements.
    			{
    				newArray[i] = typeArray[i]; //Copied all elements smaller than the given low.
    			}
        		
    			newArray[low] = o;
    			
    			for( int j = low+1;j < newArray.length; j++) // Goes through the rest of the loop and shifts all elements higher than low by 1.
    			{
    				newArray[j] = typeArray[j-1];
    			}
    			typeArray = newArray;
        		counter++; // Adds one to the counter since the array size was added.
        		return true; //Returns true if the set did not already contain the specified element.
        	}
        	return false; //Returns false if the set did already contain the specified element.	        			        			      
        }	    	
    }

    /**
     * Adds all of the elements in the specified collection to this set if they
     * are not already present and not set to null.
     * 
     * @param c
     *            -- collection containing elements to be added to this set
     * @return true if this set changed as a result of the call
     */
    @Override
    public boolean addAll(Collection<? extends E> c) {
    	
    	boolean contained = false;
    	if (c != null)
    	{
	    	for(Object E : c)
	    	{
	    		if(!this.contains(E))
	    		{
	    			this.add((E) E);
	    			contained = true; // Where contained is changed from false to true due to the call
	    		}
	    	}
    	}
        return contained; //If this set changed as a result of the call we return true
    }

    /**
     * Removes all of the elements from this set. The set will be empty after
     * this call returns.
     */
    @Override
    public void clear() {
    	counter = 0;
        Object[] newArray = new Object[1]; //Removes all elements from the set 
        typeArray = newArray;
    }

    /**
     * @param o
     *            -- element whose presence in this set is to be tested
     * @return true if this set contains the specified element
     */

    @Override
    public boolean contains(Object o) {
    	
    	int low = 0;
    	int mid = 0;
    	int high = this.size();
    	int comparedLow = 0;
    	int comparedMid;
    	
    	//Binary Search Method
    	while(low < high)
    	{
    		mid = (low + high)/2;
    		
    		if(comp == null)
    		{
    			comparedMid = ((Comparable)o).compareTo((E) typeArray[mid]);
    			comparedLow =  ((Comparable)o).compareTo( (E) typeArray[low]);
    		}
    		else
    		{
    			comparedMid = comp.compare((E) o, (E) typeArray[mid]);
    			comparedLow =  comp.compare((E) o, (E) typeArray[low]);
    		}
    		if ( comparedMid > 0)
    		{
    			low = mid + 1;
    		}
    		else if (comparedMid == 0)
        	{
    			return true; //Meaning that the given element was found in the set
        	}
    		else
    		{
        		high = mid;
        	}        			
    	}        		
    		
    	if ( low == this.size() || comparedLow != 0)
    	{
    		return false; //Meaning that the given element was not found in the set
    	}
        return true; //Meaning that the given element was found in the set
    }

    /**
     * @param c
     *            -- collection to be checked for containment in this set
     * @return true if this set contains all of the elements of the specified
     *         collection
     */
    @Override
    public boolean containsAll(Collection<?> c) {
    	
    	for(Object E : c)
    	{
    		if(!this.contains(E))
    		{
    			return false; // Returns false if this set does not contain all of the elements of the specified collection
    		}
    	}
        return true; // Returns true if this set does contain all of the elements of the specified collection
    }

    /**
     * @return true if this set contains no elements
     */
    @Override
    public boolean isEmpty() {
        if (counter == 0)
        {
            return true; // Returns true if this set contains no elements
        }
        return false; // Returns false if this set contains elements
    }

    /**
     * @return an iterator over the elements in this set, where the elements are
     *         returned in sorted (ascending) order
     */
    
    public Iterator<E> iterator() {
        return iterator; 
    }
    
    interface MySortedSetIterator<E> extends java.util.Iterator<Object> {}
    
    protected class Iterator<E> implements MySortedSetIterator {
    	
    	private int index = -1;
    	private boolean gotNext = false;
    	
		@Override
		public boolean hasNext() {
			if (index + 1 < counter)
			{
				return true; // Return true if the iteration has more elements. 
			}
			else //  If the index is = null, then there isn't anything in the array to move on to.
			{
				return false; // Return false if there is no more elements.
			}			
		}

		@Override
		public E next() {
			gotNext = true;
			if (index <= counter-1)
			{				
				return (E) (typeArray[++index]);	//Returns the next element in the iteration	
			}
			else
			{
				throw new NoSuchElementException ();	// If the iteration has no more elements 	
			}
		}
   	
		public void remove() {
			if (gotNext == true)
			{
				MySortedSet.this.remove(typeArray[index]); // Removes the last element returned by this iterator
				gotNext = false; // to make the remove method not able to run without a next() between them.
				index--;		
			}
			else
			{
				throw new UnsupportedOperationException ();	// If the remove operation is not supported by this iterator
			}
		}
    }

	/**
     * Removes the specified element from this set if it is present.
     * 
     * @param o
     *            -- object to be removed from this set, if present
     * @return true if this set contained the specified element
     */
    @Override
    public boolean remove(Object o) {
    	
        for ( int i = 0; i < this.size(); i++)
        {
            if (o.equals(typeArray[i]))
            {
            	if (counter-1 == 0)
            	{
            		this.clear();
            		return true; // Return true if this set contained the specified element
            	}
                Object[] newArray = new Object[this.size()-1];
                for ( int j = 0; j < i; j++)
                {
                    newArray[j] = typeArray[j];
                }    
                
                for (int k = (i + 1); k < this.size()-i; k++)
                {
                    newArray[k-1] = typeArray[k];
                }
                typeArray = newArray;
                counter--;
                return true; // Return true if this set contained the specified element
            }
        }
        return false; 	// Return false if this set did not contained the specified element
    }

    /**
     * Removes from this set all of its elements that are contained in the
     * specified collection.
     * 
     * @param c
     *            -- collection containing elements to be removed from this set
     * @return true if this set changed as a result of the call
     */
    @Override
    public boolean removeAll(Collection<?> c) {
        
    	boolean changed = false;
        for (Object E : c)
        {
        	if(this.contains(E))
        	{
        		this.remove(E);            
        		changed = true;
        	}
        }        
        return changed; // Only return true if the call changed the set.
    }

    /**
     * @return the number of elements in this set
     */
    @Override
    public int size() { 
        return counter; //Return the number of elements in this set
    }

    /**
     * @return an array containing all of the elements in this set, in sorted
     *         (ascending) order.
    **/
    @Override
    public Object[] toArray() {
    	Object[] newArray = new Object[counter];

    	for (int i = 0; i < newArray.length; i++)
    	{    	
    		newArray[i] = typeArray[i];
    	}     
    	return newArray; // Return an array containing all of the elements in sorted ascending order.
    }

}
