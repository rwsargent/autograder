package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This class tests our MySortedSet class 
 * @author Kory Hansen & Daniel Avery
 * @since 2/5/15
 */

public class TestMySortedSet {
	
	MySortedSet<Integer> bunchofInts;
	ArrayList<Integer> integerArray;
	MySortedSet<Integer> bunchofBackwardsInts;
	
	/**
	 * Comparator that defines an ordering among library books using the ISBN.
	 */
	public class GreatestToLeast implements Comparator<Integer> {

		/**
		 * Returns a negative value if lhs is smaller than rhs. Returns a
		 * positive value if lhs is larger than rhs. Returns 0 if lhs and rhs
		 * are equal.
		 */
		public int compare(Integer lhs, Integer rhs) {
			return (int) (rhs - lhs);
		}
	}
	
	@Before
	public void setUp() throws Exception {
		bunchofInts = new MySortedSet<Integer>();
		integerArray = new ArrayList<Integer>();
		bunchofBackwardsInts = new MySortedSet<Integer>(new GreatestToLeast());
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test (expected = NoSuchElementException.class)
	public void TestFirst1(){
		bunchofInts.first();
	}
	
	@Test
	public void TestFirst2() {
	for (int i = 1; i < 13; i++)
		bunchofInts.add(i);
	assertEquals(1, (int)bunchofInts.first());
	}
	
	@Test (expected = NoSuchElementException.class)
	public void TestLast1(){
		bunchofInts.last();
	}
	
	@Test
	public void TestLast2() {
	for (int i = 1; i < 13; i++)
		bunchofInts.add(i);
	assertEquals(12, (int)bunchofInts.last());
	}
	
	@Test
	public void TestAdd1() {
		assertFalse(bunchofInts.add(null));
	}
	
	@Test
	public void TestAdd2() {
		assertTrue(bunchofInts.add(4));
		assertEquals(4, bunchofInts.toArray()[0]);
		assertFalse(bunchofInts.add(4));
		assertNull(bunchofInts.toArray()[1]);
		assertEquals(1, bunchofInts.size());
	}
	
	@Test
	public void TestAdd3() {
		assertTrue(bunchofInts.add(4));
		assertTrue(bunchofInts.add(3));
		assertEquals(3, bunchofInts.toArray()[0]);
		assertEquals(4, bunchofInts.toArray()[1]);
		assertNull(bunchofInts.toArray()[2]);
		assertEquals(2, bunchofInts.size());
	}
	
	@Test
	public void TestAdd4() {
		assertTrue(bunchofInts.add(4));
		assertTrue(bunchofInts.add(5));
		assertEquals(4, bunchofInts.toArray()[0]);
		assertEquals(5, bunchofInts.toArray()[1]);
		assertNull(bunchofInts.toArray()[2]);
		assertEquals(2, bunchofInts.size());
	}
	
	@Test
	public void TestAdd5() {
		assertTrue(bunchofInts.add(4));
		assertTrue(bunchofInts.add(7));
		assertTrue(bunchofInts.add(6));
		assertEquals(4, bunchofInts.toArray()[0]);
		assertEquals(6, bunchofInts.toArray()[1]);
		assertEquals(7, bunchofInts.toArray()[2]);
		assertNull(bunchofInts.toArray()[3]);
		assertEquals(3, bunchofInts.size());
	}
	
	@Test
	public void TestAdd6() {
		for (int i = 1; i < 11; i++)
			bunchofInts.add(i);
		assertEquals(20, bunchofInts.toArray().length);
	}
	
	@Test
	public void TestAddAll1() {
		for (int i = 1; i < 13; i++)
			integerArray.add(i);
		assertTrue(bunchofInts.addAll(integerArray));
		integerArray.add(null);
		assertFalse(bunchofInts.addAll(integerArray));
	}
	
	@Test (expected = NoSuchElementException.class)
	public void TestClear(){
		bunchofInts.clear();
		bunchofInts.first();
	}
	
	@Test
	public void TestContains() {
		assertFalse(bunchofInts.contains(5));
		for (int i = 1; i < 11; i++)
			bunchofInts.add(i);
		assertFalse(bunchofInts.contains(9001));
		assertTrue(bunchofInts.contains(7));
	}
	
	@Test
	public void TestContainsAll() {
		for (int i = 1; i < 11; i++)
			bunchofInts.add(i);
		for (int i = 1; i < 9; i += 2)
			integerArray.add(i);
		assertTrue(bunchofInts.containsAll(integerArray));
		integerArray.add(8675309);
		assertFalse(bunchofInts.containsAll(integerArray));
	}
	
	@Test
	public void TestisEmpty() {
		assertTrue(bunchofInts.isEmpty());
		bunchofInts.add(1);
		assertFalse(bunchofInts.isEmpty());
		bunchofInts.clear();
		assertTrue(bunchofInts.isEmpty());
	}
	
	@Test
	public void TestRemove() {
		assertFalse(bunchofInts.remove(12));
		for (int i = 1; i < 11; i++)
			bunchofInts.add(i);
		assertFalse(bunchofInts.remove(12));
		assertTrue(bunchofInts.remove(5));
		assertEquals(9, bunchofInts.size());
		assertFalse(bunchofInts.contains(5));
	}
	
	@Test
	public void TestRemoveAll1() {
		for (int i = 1; i < 11; i++)
			bunchofInts.add(i);
		for (int i = 1; i < 9; i += 2)
			integerArray.add(i);
		assertTrue(bunchofInts.removeAll(integerArray));
		assertEquals(6, bunchofInts.size());
	}
	
	@Test
	public void TestRemoveAll2() {
		for (int i = 18; i < 24; i += 2)
			integerArray.add(i);
		assertFalse(bunchofInts.removeAll(integerArray));
	}
	
	@Test
	public void TestToArray() {
		Object[] sample = new Object[10];
		int counter = 0;
		for (int i = 2; i < 18; i += 3)
			sample[counter++] = i;
		for (int i = 2; i < 18; i += 3)
			bunchofInts.add(i);
		assertArrayEquals(bunchofInts.toArray(), sample);
	}

	@Test
	public void TestIteratorNext1() {
		for (int i = 2; i < 18; i += 3)
			bunchofInts.add(i);
		Iterator<Integer> slider = bunchofInts.iterator();
		assertTrue(slider.hasNext());
		assertEquals(2, slider.next(), 0);
		assertEquals(5, slider.next(), 0);
		assertEquals(8, slider.next(), 0);
		assertEquals(11, slider.next(), 0);
		assertEquals(14, slider.next(), 0);
		assertEquals(17, slider.next(), 0);
		assertFalse(slider.hasNext());
	}
	
	@Test (expected = NoSuchElementException.class)
	public void TestIteratorNext2() {
		for (int i = 2; i < 18; i += 3)
			bunchofInts.add(i);
		Iterator<Integer> slider = bunchofInts.iterator();
		while (slider.hasNext())
			slider.next();
		slider.next();
	}
	
	@Test (expected = IllegalStateException.class)
	public void TestIteratorRemove2() {
		for (int i = 2; i < 12; i += 3)
			bunchofInts.add(i);
		Iterator<Integer> slider = bunchofInts.iterator();
		slider.remove();
	}
	
	@Test
	public void TestIteratorRemove1() {
		for (int i = 2; i < 18; i += 3)
			bunchofInts.add(i);
		Iterator<Integer> slider = bunchofInts.iterator();
		for (int i = 1; i < 5; i++)
			slider.next();
		slider.remove();
		assertEquals(14, slider.next(), 0);
	}
	
	/**
	 * Begin testing with comparator rather than Comparable
	 */
	
	@Test
	public void Test2Add() {
		assertTrue(bunchofBackwardsInts.add(4));
		assertTrue(bunchofBackwardsInts.add(7));
		assertTrue(bunchofBackwardsInts.add(6));
		assertEquals(7, bunchofBackwardsInts.toArray()[0]);
		assertEquals(6, bunchofBackwardsInts.toArray()[1]);
		assertEquals(4, bunchofBackwardsInts.toArray()[2]);
		assertNull(bunchofBackwardsInts.toArray()[3]);
		assertEquals(3, bunchofBackwardsInts.size());
		
	}
	
	@Test
	public void Test2IteratorNext() {
		for (int i = 2; i < 18; i += 3)
			bunchofBackwardsInts.add(i);
		Iterator<Integer> slider = bunchofBackwardsInts.iterator();
		assertTrue(slider.hasNext());
		assertEquals(17, slider.next(), 0);
		assertEquals(14, slider.next(), 0);
		assertEquals(11, slider.next(), 0);
		assertEquals(8, slider.next(), 0);
		assertEquals(5, slider.next(), 0);
		assertEquals(2, slider.next(), 0);
		assertFalse(slider.hasNext());
	}
	
	@Test
	public void Test2IteratorRemove() {
		for (int i = 2; i < 18; i += 3)
			bunchofBackwardsInts.add(i);
		Iterator<Integer> slider = bunchofBackwardsInts.iterator();
		for (int i = 1; i < 5; i++)
			slider.next();
		slider.remove();
		assertEquals(5, slider.next(), 0);
	}
}
