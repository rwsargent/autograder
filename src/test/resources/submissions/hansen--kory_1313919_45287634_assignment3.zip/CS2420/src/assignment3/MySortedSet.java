package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This class implements SortedSet, backed by an array of a generic type
 * @author Kory Hansen & Daniel Avery
 * @since 2/3/15
 */

public class MySortedSet<E> implements SortedSet<E> {

	private E[] ourArray;
	private Comparator<? super E> comparator;
	private int arraySize;
	
	/**
	 * Constructor for a set whose elements have a natural ordering and thus
	 * utilize Comparable
	 */
	public MySortedSet() {
		ourArray = (E[]) new Object[10];
		arraySize = 0;
	}
	
	/**
	 * Constructor for a set utilizing a comparator
	 * @param ourComparator
	 * 		-- comparator to be used with items in this set
	 */
	public MySortedSet(Comparator<? super E> ourComparator) {
		ourArray = (E[]) new Object[10];
		arraySize = 0;
		comparator = ourComparator;
	}
	
	@Override
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		return comparator;
	}

	@Override
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException {
		if (arraySize == 0)
			throw new NoSuchElementException();
		return ourArray[0];
	}

	@Override
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if (arraySize == 0)
			throw new NoSuchElementException();
		return ourArray[arraySize-1];
	}

	@Override
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) {
		// if the element is null, do nothing
		if (o == null)
			return false;
		
		// if the set is empty, put an element in the first position, increment the size, return true
		if (arraySize == 0){
			ourArray[0] = o;
			arraySize++;
			return true;
		}
		
		// if the element is already in the set, do nothing
		if (this.contains(o))
			return false;
		
		if (compareThisType(o, ourArray[0]) < 0)
		{
			// if the element comes before the first element, move everything over and put it in the first position
			for(int i = arraySize -1; i >= 0; i--)
				ourArray[i+1] = ourArray[i];
			ourArray[0] = o;
		}
		else if (compareThisType(o, ourArray[arraySize - 1]) > 0)
			// if the element comes after the last element, put it in the last position
			ourArray[arraySize] = o;
		else
		{
			// if the element belongs somewhere else in the list, find the position to insert, move things over, put it there
			int pos = searchThis(o);
			if (compareThisType(ourArray[pos], o) < 0) // if the value at the position we found comes before the element, pos up
				pos++;
			for (int i = arraySize - 1; i >= pos; i--)
				ourArray[i+1] = ourArray[i];
			ourArray[pos] = o;
		}

		// Finally, increase the size, and see if the array needs to be grown. The set was changed, so return true
		arraySize++;
		if (ourArray.length == arraySize)
			ourArray = growArray(ourArray);
		return true;
	}

	@Override
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
		E[] cArray = (E[]) c.toArray();
		boolean didWork = false; // track if any elements were actually added
		
		for (int i = 0; i < c.size(); i++)
			if(this.add(cArray[i]))
				didWork = true; //If the add was successful, the array was changed and work was done
		
		return didWork;
	}

	@Override
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		arraySize = 0;
	}

	@Override
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) {
		// if there is nothing in the array, it cannot contain the object
		if (arraySize == 0)
			return false;
		
		// search for the value in the set, return true if it is found
		if (compareThisType(ourArray[searchThis((E)o)], (E)o) == 0)
			return true;
		
		return false;
	}

	@Override
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c) {
		Object[] cArray = c.toArray();
		
		// search for each element, return false if any are not found
		for (int i = 0; i < c.size(); i++)
			if (!this.contains(cArray[i]))
				return false;
		
		return true;
	}

	@Override
	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		if (arraySize == 0)
			return true;
		
		return false;
	}

	@Override
	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		return new MySortedSetIterator();
	}

	@Override
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		// if the element isn't there, do nothing
		if (!this.contains(o))
			return false;
		
		// otherwise find the position, and shift everything else to fill it in
		int pos = searchThis((E)o);
		for (int i = pos; i < arraySize - 2; i++)
			ourArray[i] = ourArray[i+1];
		
		// decrement the size and return true
		arraySize--;
		
		return true;
	}

	@Override
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		Object[] cArray = c.toArray();
		boolean didWork = false; // track whether things were removed
		
		for (int i = 0; i < c.size(); i++)
			if(this.remove(cArray[i]))
				didWork = true; // we just removed something; say so
		
		return didWork;
	}

	@Override
	/**
	 * @return the number of elements in this set
	 */
	public int size() {
		return arraySize;
	}

	@Override
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		return ourArray;
	}
	
	/**
	 * Utilizes a binary search to locate the given element's position.
	 * If the element is not present, returns the last location visited.
	 * @param element
	 * 		-- the element to search for in the set
	 * @return the position of the element or the last location visited
	 */
	private int searchThis(E element){
		// do a binary search on the elements in the list
		int min = 0;
		int max = arraySize-1;
		int mid = 0; 
		
		while (min <= max)
		{
			mid = (min + max)/2;
			if (compareThisType(ourArray[mid],element) < 0)
				min = mid+1;
			else if (compareThisType(ourArray[mid],element) > 0)
				max = mid-1;
			else
				return mid;
		}
		// if the element wasn't found, return one of the closest values
		return mid;
	}
	 
	/**
	 * Doubles the capacity of an array
	 * @param list
	 * 		-- an array
	 * @return the enlarged array
	 */
	private E[] growArray(E[] list){
		// copy the values of the current array into a new one with double the capacity
		E[] bigger = (E[]) new Object[2*list.length];
		for(int i = 0; i < list.length; i++)
			bigger[i] = list[i];
		return bigger;
	}
	
	/**
	 * Compares two items based on how the set specifies the comparison for the set type
	 * @param lhs
	 * 		-- the left hand side of the comparison
	 * @param rhs
	 * 		-- the right hand side of the comparison
	 * @return a negative integer if lhs is less than rhs, a positive integer if lhs is greater
	 * than rhs, or zero if lhs and rhs are equal
	 */
	private int compareThisType(E lhs, E rhs){
		// check if a comparator is available, otherwise cast to a comparable
		if (comparator == null)
			return (((Comparable<E>) lhs).compareTo(rhs));
		return (comparator.compare(lhs, rhs));
					
	}
	
	/**
	 * An implementation of the Iterator interface. 
	 * This class specifies how to traverse the set.
	 */
	private class MySortedSetIterator implements Iterator<E>{
		
		private int current; 
		private boolean nextHasBeenCalled; // state
		
		/**
		 * Constructor for this iterator
		 */
		private MySortedSetIterator(){
			current = -1;
			nextHasBeenCalled = false;
		}
		
		/**
		 * Checks if the set contains another element after the current element
		 * @return true if there is another element; false if there is not
		 */
		public boolean hasNext(){
			return current < MySortedSet.this.size() - 1;
		}
		
		/**
		 * Returns the next element in the set if applicable and advances
		 * the current position
		 * @throws NoSuchElementException if there is no element
		 */
		public E next() throws NoSuchElementException{
			if (current >= MySortedSet.this.size() - 1)
				throw new NoSuchElementException();
			
			nextHasBeenCalled = true;
			// increment the counter and return the next element
			return ourArray[++current];
		}
		
		/**
		 * Removes the last element visited and decrements the current position
		 * @throws IllegalStateException if next has not previously been called
		 */
		public void remove() throws IllegalStateException{
			if (!nextHasBeenCalled)
				throw new IllegalStateException();
			
			// remove the current element and decrement the counter
			MySortedSet.this.remove(ourArray[current--]);
			nextHasBeenCalled = false;
		}
	}

}
