package assignment3;

import java.util.ArrayList;

/**
 * This class was used for testing only. It does not implement either 
 * Comparator or Comparable. We use this class to pass it 
 * into MySortedSet with a new Comparator of CircleAreaComparator()
 * 
 * @author Amit Athani and Natalie Cottrill-Yavornitzky
 *
 */
public class Circle {

	private double radius = 0;
	private String color;

	public Circle(double r) {
		
		this.radius = r;
		this.color = "red";
	}

	public double area() {
			double area = Math.PI * (radius * radius);
		return area;
	}

	public String changeColor() {
		if (this.area() > 3.0 && this.area() < 6.0) {
			color = "blue";
		} else if (this.area() >= 6.0) {
			color = "pink";
		}
		return color;
	}

	public double getArea() {
		return this.area();
	}
}
