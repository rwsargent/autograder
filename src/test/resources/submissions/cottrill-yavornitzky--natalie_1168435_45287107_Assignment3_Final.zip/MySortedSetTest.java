package assignment3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/**
 * This JUnit class has methods that test MySortedSet methods
 * 
 * @author Amit Athani and Natalie Cottrill-Yavornitzky
 *
 */
public class MySortedSetTest {
	@Rule
	public ExpectedException exception = ExpectedException.none();

	@Test
	public void testMySortedSet() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		Integer[] l2 = {1,3,4,null}; 
		assertTrue(Arrays.equals(l2, l1.getList()));
	}

	/**
	 * Test first constructor with an Object that does not implement Comparable
	 * and doesn't pass a Comparator. Object Circle will flow through 1st
	 * constructor and then throw exception in the add method. Circle objects
	 * will not be added to list[].
	 * 
	 * @throws ClassCastException
	 */
	@Test
	public void testMySortedSet2() {
		exception.expect(ClassCastException.class);
		// Add object Circle
		MySortedSet<Circle> l2 = new MySortedSet<Circle>();
		Circle c1 = new Circle(2.0);
		Circle c2 = new Circle(3.0);
		l2.add(c1);
	}

	@Test
	public void testMySortedSetComparatorOfQsuperE() {
		new MySortedSet<Circle>(new CircleAreaComparator());

	}

	@Test
	public void testComparator() {
		MySortedSet<Circle> c1 = new MySortedSet<Circle>(new CircleAreaComparator());
		Circle l1 = new Circle(1.0);
		Circle l2 = new Circle(3.0);
		Circle l3 = new Circle(4.0);
		c1.add(l1);
		c1.add(l2);
		c1.add(l3);
		assertEquals((int)l3.area(), (int)c1.getElementFromList(0).getArea());
	}

	@Test
	public void testFirst() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		assertEquals((Integer) 1, l1.first());

		MySortedSet<String> l2 = new MySortedSet<String>();
		l2.add("a");
		l2.add("b");
		l2.add("c");
		assertEquals("a", l2.first());
	}

	@Test
	public void testLast() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		assertEquals((Integer) 4, l1.last());

		MySortedSet<Object> l2 = new MySortedSet<Object>();
		l2.add("a");
		l2.add("b");
		l2.add("c");
		assertEquals("c", l2.last());

	}

	@Test
	public void testAdd() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		Integer[] i = { 1, 3, 4, null };
		assertTrue(Arrays.equals(i, l1.getList()));

		// add two integers that already exist (should not add)
		l1.add(3);
		l1.add(4);
		assertTrue(Arrays.equals(l1.getList(), i));

		// add an integer in the middle
		l1.add(2);
		Integer[] j = { 1, 2, 3, 4 };
		assertTrue(Arrays.equals(j, l1.getList()));
	}

	/**
	 * Tests adding a Collection with no Comparable or Comparator. The attempt
	 * to add this to E[] list should throw exception.
	 * 
	 * @throws ClassCastException
	 */
	@Test
	public void testAdd2() {
		exception.expect(ClassCastException.class);
		MySortedSet<HashSet<Integer>> l2 = new MySortedSet<HashSet<Integer>>();
		l2.add(new HashSet<Integer>(Arrays.asList(4, 5, 7)));

	}

	@Test
	public void testAddAll() {
		// create 2 new Collections
		Collection<String> c1 = new ArrayList<String>(Arrays.asList("a", "b",
				"c"));
		Collection<String> c2 = new ArrayList<String>(Arrays.asList("d", "e",
				"f", "g"));
		// create a new SortedSet object
		MySortedSet<String> l1 = new MySortedSet<String>();
		l1.add("a");
		l1.add("b");
		l1.addAll(c1);
		l1.addAll(c2);
		// test that all elements from Collection c1, c2 are in MySortedSet l1
		assertTrue(l1.containsAll(c2));
		assertTrue(l1.containsAll(c1));
	}

	@Test
	public void testClear() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		l1.clear();
		assertEquals(0, l1.size());
	}

	@Test
	public void testContains() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		assertTrue(l1.contains(4));
		assertTrue(l1.contains(1));
		assertFalse(l1.contains(20));
		assertFalse(l1.contains(-4));

		MySortedSet<String> l2 = new MySortedSet<String>();
		l2.add("a");
		l2.add("b");
		l2.add("c");
		assertTrue(l2.contains("a"));
		assertFalse(l2.contains("A"));
		assertFalse(l2.contains(1));
	}

	@Test
	public void testContainsAll() {
		Collection<String> c1 = new ArrayList<String>(Arrays.asList("a", "b",
				"c"));
		Collection<String> c2 = new ArrayList<String>(Arrays.asList("a", "b",
				"c", "d"));
		Collection<Integer> i1 = new ArrayList<Integer>(Arrays.asList(1, 2, 3,
				4, 5, 6, 7, 8, 101, 1, 2, 20, 1, 17, 18, 11));
		// create a new SortedSet object
		MySortedSet<String> l1 = new MySortedSet<String>();
		l1.add("a");
		l1.add("b");
		l1.add("c");
		// test that all elements from Collection c1, c2 are in MySortedSet l1
		assertTrue(l1.containsAll(c1));
		assertFalse(l1.containsAll(c2));
		assertFalse(l1.containsAll(i1));

	}

	@Test
	public void testIsEmpty() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		assertFalse(l1.isEmpty());
		l1.clear();
		assertTrue(l1.isEmpty());
	}

	@Test
	public void testIterator() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		Iterator<Integer> i = l1.iterator();
		assertTrue(i.hasNext());
		i.next();
		i.next();
		i.next();
		assertFalse(i.hasNext());

		MySortedSet<String> l2 = new MySortedSet<String>();
		Iterator<String> s = l2.iterator();
		l2.add("a");
		l2.add("b");
		l2.add("D");
		l2.add("B");
		l2.add("D");

		assertTrue(s.hasNext());
		s.next();
		s.next();
		s.next();
		s.next();
		assertFalse(s.hasNext());
	}

	@Test
	public void testRemove() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		l1.remove(0);
		Integer[] i = { 1, 3, 4, null };
		assertTrue(Arrays.equals(i, l1.getList()));

		l1.remove(4);
		Integer[] temp = { 1, 3, 4, null };
		assertTrue(Arrays.equals(temp, l1.getList()));

	}

	@Test
	public void testMoveElementsLeft() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		l1.remove(1);
		Integer[] i = { 3, 4, 4, null };
		assertTrue(Arrays.equals(i, l1.getList()));

		MySortedSet<String> l2 = new MySortedSet<String>();
		l2.add("a");
		l2.add("b");
		l2.add("B");
		l2.add("D");
		l2.remove("b");
		String[] s = { "B", "D", "a", "b" };
		assertTrue(Arrays.equals(s, l2.getList()));
		l2.remove("B");
		String[] s1 = { "D", "a", "a", "b" };
		assertTrue(Arrays.equals(s1, l2.getList()));
	}

	@Test
	public void testRemoveAll() {
		// create 2 new Collections
		Collection<String> c1 = new ArrayList<String>(Arrays.asList("a", "b",
				"c"));
		Collection<String> c2 = new ArrayList<String>(Arrays.asList("d", "e",
				"f", "g"));
		// create a new SortedSet object
		MySortedSet<String> l1 = new MySortedSet<String>();
		l1.add("a");
		l1.add("b");
		l1.addAll(c1);
		l1.addAll(c2);
		c2 = new ArrayList<String>(Arrays.asList("a", "e", "b", "g"));
		l1.removeAll(c2);
		c2 = new ArrayList<String>(Arrays.asList("c", "d", "f"));
		// test that all elements from Collection c1, c2 are in MySortedSet l1
		assertTrue(l1.containsAll(c2));

		MySortedSet<Integer> l2 = new MySortedSet<Integer>();
		Collection<Integer> i1 = new ArrayList<Integer>(Arrays.asList(1, 2, 3,
				4, 5, 6, 7, 8, 101, 1, 2, 20, 1, 17, 18, 11));
		Collection<Integer> i2 = new ArrayList<Integer>(Arrays.asList(8, 13,
				101, 20, 17, 18, 98, 74));
		l2.addAll(i2);
		l2.removeAll(i1);
		i2 = new ArrayList<Integer>(Arrays.asList(13, 98, 74));
		assertTrue(l2.containsAll(i2));
		assertFalse(l1.removeAll(i1));
	}

	@Test
	public void testSize() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		assertEquals(3, l1.size());

		MySortedSet<String> l2 = new MySortedSet<String>();
		l2.add("Cat");
		l2.add("Dog");
		l2.add("4");
		l2.add("66");
		l2.add("Sixty Six");
		assertEquals(5, l2.size());

		MySortedSet<Character> l3 = new MySortedSet<Character>();
		l3.add('A');
		l3.add('B');
		l3.add('6');
		l3.add('a');
		assertEquals(4, l3.size());
	}

	@Test
	public void testToArray() {
		MySortedSet<Integer> l1 = new MySortedSet<Integer>();
		l1.add(1);
		l1.add(3);
		l1.add(4);
		assertEquals(new ArrayList<Integer>(Arrays.asList(1, 3, 4)),
				Arrays.asList(l1.toArray()));

		MySortedSet<String> l2 = new MySortedSet<String>();
		l2.add("A");
		l2.add("B");
		l2.add("C");
		assertEquals(new ArrayList<String>(Arrays.asList("A", "B", "C")),
				Arrays.asList(l2.toArray()));

		MySortedSet<Character> l3 = new MySortedSet<Character>();
		l3.add('A');
		l3.add('B');
		l3.add('6');
		l3.add('a');
		assertEquals(
				new ArrayList<Character>(Arrays.asList('6', 'A', 'B', 'a')),
				Arrays.asList(l3.toArray()));


	}

}
