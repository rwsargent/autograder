package assignment3;

import java.util.Comparator;

/**
 * This class was created to test a Comparator to sort our Circle() class. It
 * sorts the list in reverse order based on the area() of each Circle.
 * 
 * @author Amit Athani and Natalie Cottrill-Yavornitzky
 *
 */
public class CircleAreaComparator implements Comparator<Circle> {
	
	@Override
	public int compare(Circle o1, Circle o2) {
		Circle circ1 = (Circle) o1;
		Circle circ2 = (Circle) o2;
		Double d1 = circ1.area();
		Double d2 = circ2.area();
			
		if (d1.compareTo(d2) > 0) 
			return -1;
		else if (d1.compareTo(d2) < 0)
			return 1;
		return 0;
	}
}
