/**
 * 
 */
package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * The MySortedSet class constructs and maintains a sorted list of generic objects.
 * 
 * @author Amit Athani and Natalie Cottrill-Yavornitzky
 * 
 */
public class MySortedSet<E> implements SortedSet<E> {

	/*
	 * List is a set of Objects of type E which does not contain duplicates and
	 * is sorted. Size represents the number of elements in the list
	 */
	private E[] list;
	private int size;
	private Comparator<? super E> cmp;

	/**
	 * Constructs a SortedSet out of any object that is not a Comparator.
	 */
	public MySortedSet() {
		// TODO Auto-generated constructor stub
		list = (E[]) new Object[2];
		size = 0;
		cmp = null;
	}

	/**
	 * Constructs a SortedSet out of any object which implements comparator and
	 * the parameter passed must be a subclass of <E>.
	 * 
	 * @param c
	 */
	public MySortedSet(Comparator<? super E> c) {
		list = (E[]) new Object[2];
		size = 0;
		cmp = c;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return cmp;

	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();

		return list[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();

		return list[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		int index = 0;
		if (size == list.length)
			list = Arrays.copyOf(list, size * 2);

		// if object is in list, return false
		if (this.contains(o) || o == null) {
			return false;
		}

		// following code will add object with comparator
		if (cmp != null) {
			if (size == 0) {
				list[size] = o;
			} else if (cmp.compare(list[size - 1], o) < 0) {
				list[size] = o;
			} else {
				index = binaryComparator(o);
				addElement(index, o);
			}
		} else {
			// if object is not comparable and has no comparator, throws
			// exception
			Comparable<E> temp = (Comparable<E>) o;
			if (size == 0) {
				list[size] = o;
			} else if (temp.compareTo(list[size - 1]) > 0) {
				list[size] = o;
			} else {
				index = binaryComparable(temp);
				addElement(index, o);
			}
		}
		size++;
		return true;

	}

	/**
	 * Takes object with Comparator and searches for the element in MySortedSet
	 * 
	 * @param o
	 * @return the index of the element or where it needs to be inserted
	 */
	private int binaryComparator(E o) {
		// does binary search for object with Comparator
		int mid, high, low;
		mid = 0;
		high = list.length - 1;
		low = 0;
		while (low <= high) {
			mid = (low + high) / 2;
			if ((cmp.compare(list[mid], o) < 0))
				low = mid + 1;
			else if (cmp.compare(list[mid], o) > 0)
				high = mid - 1;
			else
				return mid;
		}
		return low; // index is the point where we need to insert the
					// object.
	}

	/**
	 * Takes Comparable object and searches for the element in MySortedSet
	 * 
	 * @param o
	 * @return the index of the element or where it needs to be inserted
	 */
	private int binaryComparable(Comparable<E> temp) {
		// Initiate a binary search on Comparable object
		int mid, high, low;
		mid = 0;
		high = list.length - 1;
		low = 0;
		while (low <= high) {
			mid = (low + high) / 2;
			if (temp.compareTo(list[mid]) > 0)
				low = mid + 1;
			else if (temp.compareTo(list[mid]) < 0)
				high = mid - 1;
			else
				return mid;
		}
		return low; // index is the point where we need to insert the
					// object.
	}

	/**
	 * Pushes element to the right and adds the new element at index
	 * 
	 * @param index
	 * @param object
	 *            o
	 */
	private void addElement(int index, E o) {
		for (int i = size; i > index; i--) {
			list[i] = list[i - 1];
		}
		list[index] = o;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		int orgSize = size;
		for (Object o : c) {
			this.add((E) o);
		}
		// if size was changed from the original size, then return true
		if (orgSize != size)
			return true;
		return false;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {

		if (size == 0 || o == null)
			return false;
		if (cmp != null) {
			E temp = null;
			try {
				// throws ClassCastException on compare() if not same type
				temp = (E) o;
				int mid, high, low;
				mid = 0;
				high = list.length - 1;
				low = 0;
				while (low <= high) {
					mid = (low + high) / 2;
					if (cmp.compare(list[mid], temp) < 0)
						low = mid + 1;
					else if (cmp.compare(list[mid], temp) > 0)
						high = mid - 1;
					else
						return true;
				}
			} catch (ClassCastException e) {
				return false;
			}
		}
		if (o instanceof Comparable) {
			Comparable<E> temp = null;
			try {
				// throws ClassCastException on compareTo() if not same type
				temp = (Comparable<E>) o;
				// Initiate a binary search
				int mid, high, low;
				mid = 0;
				high = size - 1;
				low = 0;
				while (low <= high) {
					mid = (low + high) / 2;
					if (temp.compareTo(list[mid]) > 0)
						low = mid + 1;
					else if (temp.compareTo(list[mid]) < 0)
						high = mid - 1;
					else
						return true;
				}
			} catch (ClassCastException e) {
				return false;
			}
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		// if list contains each element of Collection c, then return true
		for (Object o : c) {
			if (!this.contains(o))
				return false;
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (size == 0) {
			return true;
		}
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MySortedSetIterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int index = 0;
		if (this.contains(o)) {
			if (cmp != null) {
				E temp = null;
				try {
					// throws ClassCastException on binaryComparator if not same
					// type
					temp = (E) o;
					index = binaryComparator(temp);
					moveElementsLeft(index);
				} catch (ClassCastException e) {
					return false;
				}
			} else if (o instanceof Comparable) {
				Comparable<E> temp = null;
				try {
					// throws ClassCastException on binaryComparator if not same
					// type
					temp = (Comparable<E>) o;
					index = binaryComparable(temp);
					moveElementsLeft(index);
				} catch (ClassCastException e) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	/**
	 * Push elements to the left after removing an element an index
	 * 
	 * @param index
	 */
	private void moveElementsLeft(int index) {
		for (int i = index; i < size - 1; i++) {
			list[i] = list[i + 1];
		}
		size--;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		int orgSize = size;
		for (Object o : c) {
			this.remove(o);
		}
		if (size != orgSize)
			return true;
		return false;
	}

	/**
	 * @return the number of elements (values) in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		return Arrays.copyOfRange(list, 0, size);
	}

	/**
	 * For JUnit testing purposes only.
	 * 
	 * @param index
	 * @return
	 */
	public E[] getList() {
		return list;
	}

	/**
	 * For JUnit testing purposes only.
	 * 
	 * @param index
	 * @return
	 */
	public E getElementFromList(int index) {
		return list[index];
	}

	/**
	 * Creates an Iterator to move through elements in MySortedSet
	 */
	protected class MySortedSetIterator implements Iterator {
		private int pos = 0;
		private boolean nextCalled = false;

		@Override
		// Returns true if the iteration has more elements.
		public boolean hasNext() {
			if (pos < size)
				return true;
			return false;
		}

		@Override
		// Returns the next element in the iteration.
		public Object next() {
			if (this.hasNext() == true) {
				E temp = list[pos];
				pos++;
				nextCalled = true;
				return temp;
			}
			throw new NoSuchElementException();

		}

		@Override
		// Removes from the underlying collection the last element returned by
		// this iterator (optional operation). This method can be called only
		// once per call to next()
		public void remove() {
			if (nextCalled) {
				// then we can remove list[pos]
				pos--;
				MySortedSet.this.remove(list[pos]);
				nextCalled = false;
			} else {
				throw new IllegalStateException();
			}
		}
	}
}
