package assignment3;

import java.util.Random;

/**
 * This class was built to time the MySortedSet.adds() and .contains()
 * methods.
 * 
 * @author Amit Athani and Natalie Cottrill-Yavornitzky
 *
 */
public class TimingTester {

	public static void main(String[] args) {
		long avg = 0;
		int max = 1000000;
		int randomNum = 50000;
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		for (int i = 0; i < max; i++) {
			set.add(i);
		}
		set.remove(randomNum);
		// This block times the adds method
		for (int i = 0; i < 100000; i++) {
			long startTimeContains = System.nanoTime();
			set.add(randomNum);
			long stopTimeContains = System.nanoTime();
			set.remove(randomNum);
			avg += (stopTimeContains - startTimeContains);
		}
		System.out.println(avg / 100000);
		
		// Below code was for timing contains
//		for (int i = 0; i < 100000; i++) {
//			randomNum = rand.nextInt((max - 0) + 1);
//
//			long startTimeContains = System.nanoTime();
//			set.contains(randomNum);
//			long stopTimeContains = System.nanoTime();
//			avg += (stopTimeContains - startTimeContains);
//		}
//		System.out.println(avg / 100000);

	}

}
