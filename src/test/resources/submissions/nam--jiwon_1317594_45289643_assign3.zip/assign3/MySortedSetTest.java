package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author Charles Shoup, Jiwon Nam
 *
 */
public class MySortedSetTest 
{
	private MySortedSet set;
	private ArrayList<Integer> reference; 
	
	@Before
	public void setUp() throws Exception 
	{
		set = new MySortedSet();
		
		reference = new ArrayList<Integer>();
		
		reference.add(4);
		reference.add(5);
		reference.add(6);
		reference.add(7);
		reference.add(9);
		reference.add(12);
		reference.add(13);
		reference.add(15);
		reference.add(16);
		reference.add(17);
		reference.add(19);
		reference.add(21);
		reference.add(22);
		reference.add(23);
		reference.add(25);
		reference.add(91);
		reference.add(95);
		reference.add(97);
		reference.add(99);
		reference.add(110);
		reference.add(115);
		reference.add(139);		
	}

	@After
	public void tearDown() throws Exception 
	{
		set.clear();
	}
	
	/**
	 *Adds some elements to set and checks for correct output from first() 
	 */
	@Test
	public void testFirst() 
	{
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		
		assertEquals(set.first(), 5);
	}
	
	/**
	 * Adds some elements to set and checks for correct output from last()
	 */
	@Test
	public void testLast() 
	{
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		
		assertEquals(set.last(), 9);
	}
	
	/**
	 * Adds a whole bunch of integers to set, if they are properly added and sorted
	 * then the array representation of set should match up with the array representation of reference
	 */
	@Test
	public void testAdd() 
	{
		//Add enough integers to force resize twice
		//Not added in sorted order
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		set.add(13);
		set.add(15);
		set.add(17);
		set.add(19);
		set.add(21);
		set.add(23);
		set.add(25);
		set.add(16);
		set.add(4);
		set.add(12);
		set.add(22);
		set.add(99);
		set.add(95);
		set.add(97);
		set.add(91);
		set.add(110);
		set.add(115);
		set.add(139);				
		
		//Add some duplicates
		set.add(7);
		set.add(5);
		set.add(16);
		set.add(139);
		
		assertArrayEquals(set.toArray(), reference.toArray());																			
	}
	
	/**
	 * tests the addAll() method by adding reference to set and checking the results against one another
	 * currently having issues
	 */
	@Test
	public void testAddAll() 
	{
		set.addAll(reference);
		assertArrayEquals(set.toArray(), reference.toArray());
	}
	
	/**
	 * adds integers to set and then invokes clear()
	 * check against expected size value
	 */
	@Test
	public void testClear() 
	{
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		set.add(13);
		set.add(15);
		set.add(17);
		set.add(19);
		set.add(21);
		set.add(23);
		set.add(25);
		set.add(16);
		set.add(4);
		set.add(12);
		set.add(22);
		set.add(99);
		set.add(95);
		set.add(97);
		set.add(91);
		
		set.clear();		
		
		assertEquals(set.size(), 0);		
	}
	
	/**
	 * adds integers to setand then checks against expected output from contains()
	 */
	@Test
	public void testContains() 
	{
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		set.add(13);
		set.add(15);
		set.add(17);
		set.add(19);
		set.add(21);
		set.add(23);
		set.add(25);
		set.add(16);
		set.add(4);
		set.add(12);
		set.add(22);
		set.add(99);
		set.add(95);
		set.add(97);
		set.add(91);
		set.add(110);
		set.add(115);
		set.add(139);
		
		assertEquals(set.contains(13), true);
		assertEquals(set.contains(5), true);
		assertEquals(set.contains(139), true);
		assertEquals(set.contains(991), false);
	}
	
	/**
	 * Tests contains all by checking the contents of set against reference
	 * not working correctly at the moment
	 */
	@Test
	public void testContainsAll() 
	{		
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		set.add(13);
		set.add(15);
		set.add(17);
		set.add(19);
		set.add(21);
		set.add(23);
		set.add(25);
		set.add(16);
		set.add(4);
		set.add(12);
		set.add(22);
		set.add(99);
		set.add(95);
		set.add(97);
		set.add(91);
		set.add(110);
		set.add(115);
		set.add(139);
		
		assertEquals(set.containsAll(reference), true);
	}
	
	/**
	 * tests isEmpty() against expected output
	 */
	@Test
	public void testIsEmpty() 
	{
		assertEquals(set.isEmpty(), true);
	}	
	
	/**
	 * tests remove() by adding members to set, removing some and then checking against reference
	 */
	@Test
	public void testRemove() 
	{
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		set.add(13);
		set.add(15);
		set.add(17);
		set.add(19);
		set.add(21);
		set.add(23);
		set.add(25);
		set.add(16);
		set.add(4);
		set.add(12);
		set.add(22);
		set.add(99);
		set.add(95);
		set.add(97);
		set.add(91);
		set.add(110);
		set.add(115);
		set.add(139);
		
		set.remove(4);
		set.remove(5);
		set.remove(6);
		
		set.remove(999);
		
		reference.remove(0);
		reference.remove(0);
		reference.remove(0);
		
		assertArrayEquals(set.toArray(), reference.toArray());
								
	}
	
	/**
	 * currently not working, we were having iterator issues with collections, may be fixed by turn in time
	 */
	@Test
	public void testRemoveAll() 
	{
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		set.add(13);
		set.add(15);
		set.add(17);
		set.add(19);
		set.add(21);
		set.add(23);
		set.add(25);
		set.add(16);
		set.add(4);
		set.add(12);
		set.add(22);
		set.add(99);
		set.add(95);
		set.add(97);
		set.add(91);
		set.add(110);
		set.add(115);
		set.add(139);
		
		set.removeAll(reference);
		
		assertEquals(set.isEmpty(), true);
	}
	
	/**
	 * Add members to set and then check the size of set against the expected size
	 */
	@Test
	public void testSize() 
	{
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		set.add(13);
		set.add(15);
		set.add(17);
		set.add(19);
		set.add(21);
		set.add(23);
		set.add(25);
		set.add(16);
		set.add(4);
		set.add(12);
		set.add(22);
		set.add(99);
		set.add(95);
		set.add(97);
		set.add(91);
		set.add(110);
		set.add(115);
		set.add(139);
		
		assertEquals(set.size(), 22);
	}
	
	/**
	 * basically a repeat of earlier tests, toArray() has been validated extensively in the preceeding tests
	 */
	@Test
	public void testToArray() 
	{
		set.add(5);
		set.add(6);
		set.add(7);
		set.add(9);
		set.add(13);
		set.add(15);
		set.add(17);
		set.add(19);
		set.add(21);
		set.add(23);
		set.add(25);
		set.add(16);
		set.add(4);
		set.add(12);
		set.add(22);
		set.add(99);
		set.add(95);
		set.add(97);
		set.add(91);
		set.add(110);
		set.add(115);
		set.add(139);
		
		assertArrayEquals(set.toArray(), reference.toArray());
	}

}
