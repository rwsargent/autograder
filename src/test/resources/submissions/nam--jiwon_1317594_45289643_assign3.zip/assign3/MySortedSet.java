package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
/**
 * 
 * @author Jiwon Nam, Charles Shoup
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E>
{
	public E[] arr;
	private Comparator<? super E> comparator;
	private int size = 0; 
	
	private E[] copy;
			
	
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> comparator)
	{
		arr = (E[])new Object[10];
		this.comparator = comparator;
	}

	
	@SuppressWarnings("unchecked")
	public MySortedSet() 
	{
		arr = (E[])new Object[10];
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() 
	{		
		 return this.comparator; 		
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException 
	{			
		return arr[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException 
	{	
		return arr[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E item) 
	{									
 		if (item == null || binarySearch(item) == -2)	
		return false; 	 		 	
 		
		if (arr.length == size)
 		{
 			copy = arr;
 			arr = (E[])new Object[size * 2];
 			
 			for (int i = 0; i < size; i++)
 			{
 				arr[i] = copy[i];
 			} 			 			
 		}
		
		
 		int position = binarySearch(item); 		
 		 
 		if (position == -1)
 		{
 			arr[size] = item;
 			size++;
 			return true; 
 		}
 		
 		copy = (E[])new Object[size - position];
	 		
	 		for (int i = 0; i < size - position; i++)
	 		{
	 			copy[i] = arr[i + position];
	 		} 		 		 		 		 		  		  		 		 		 		
 		
 		arr[position] = item; 		
 		
 		for (int i = 0; i < size - position; i++)
 		{
 			arr[position + 1 + i] = copy[i];
 		}
 		
 		size++; //Don't forget to increment size
 		
 		return true;
	}	

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection <? extends E> collection) 
	{			
		boolean result = false;								
		Iterator<? extends E> it = collection.iterator();
		while (it.hasNext())
		{
			E temp = it.next();
			if(!contains(temp))
			{
				if(this.add(temp))
					result = true;
			}
			
		}
		
		return result;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public void clear() 
	{		
		arr = (E[])new Object[10];
		size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object item) 
	{
		if (item == null || size == 0)
			return false;				
		
		if (binarySearch((E) item) == -2)
			return true;
		
		return false;	
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection <? extends E> collection) 
	{
		int count = 0;
		Iterator<? extends E> it = collection.iterator();
		while (it.hasNext())
		{
			if (contains(it.next()))
			{
				count ++;
			}
					
		}
		if(count == collection.size())
			return true;
		
		return false;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() 
	{		
		if (size == 0) return true;		
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() 
	{			
		return new Iterator<E>() 
		    {						    								
				int index = 0;
				@Override
				public boolean hasNext() 
				{
					if (index <= size)										
						return true;
											
					return false;
				}
	
				@Override
				public E next() 
				{
					if (hasNext() == true)
					{
						E temp = arr[index];
						index++;
						return temp;						
					}
					return null;
				}
	
				@Override
				public void remove() 
				{
					if (index <= 0)
						return;
					
					int position = index;
					
					while (position < size)
					{
						arr[position - 1] = arr[position];
						position++;
					}
					
					arr[size] = null;
					
					size--; //Size decrement 
				}
			
		    };
	}
	
	/**
	 * 
	 * @param item
	 * @param function ~true if you want to search for a place to put something, false if you want to find if something is in the array
	 * @return
	 */
	public int binarySearch(E item)
	{				
		 	int lower = 0;
	        int higher = size;
	        
	        if(size == 0)
	        {
	        	return 0;
	        }
	        
	        if (comparator() != null)
	        {
	            while (lower < higher)
	            {                                
	                int mid = lower + (higher - lower)/2;
	                if(comparator.compare(item, arr[mid]) < 0) 
	                higher = mid;
	                if(comparator.compare(item, arr[mid]) > 0) 
	                lower = mid + 1;
	                if(comparator.compare(item, arr[mid]) == 0) 
	                	return -2;	  
	                if(lower == higher) 
		                return higher;
	            }            
	            return -1; 
	        }
	        else 
	        {	        
	            while (lower < higher)
	            {                                
	                int mid = lower + (higher - lower)/2;
	                if(((Comparable<? super E>)item).compareTo(arr[mid]) < 0)
	                higher = mid;            
	                if(((Comparable<? super E>)item).compareTo(arr[mid]) > 0) 
	                lower = mid + 1;
	                if(((Comparable<? super E>)item).compareTo(arr[mid]) == 0) 
	                	return -2;
	                if(lower == higher) 
	                	return higher;
	            }         	          	            
	            return -1;
	        }
	}
	

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object item) 
	{			
		Iterator itr = this.iterator();
		
		
		while (itr.hasNext())
		{
			if (comparator() != null)
			{
				if (comparator.compare((E) item, (E) itr.next()) == 0)
				{
					itr.remove();
						return true;
				}
			}
			else
			{
				if (((Comparable<E>)item).compareTo((E) itr.next()) == 0)
				{
					itr.remove();
						return true;
				}
			}
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection <? extends E> collection) 
	{		
		boolean result = false;
		Iterator<?> it = collection.iterator();
		if (collection.isEmpty())
			return false;
		
		while (it.hasNext())
		{
			if (remove(it.next()))
			{
				result = true;
			}
		}
		return result;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() 
	{			
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() 
	{
		if (size == 0)
			return null;
		
		Object[] array = new Object[size];
		
		for (int i = 0; i < size; i++)
			array[i] = arr[i];
		
		return array;
	}	

}
