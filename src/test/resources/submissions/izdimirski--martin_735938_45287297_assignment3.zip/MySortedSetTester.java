package assignment3;

/**
 * @author Justin Tse, Martin Izdimirski
 */

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTester {
	
	/**ourComparator
	 * This is an example comparator for string, We are using this to test if our second constructor works or not.
	 * It is the same as the natural string Comparable except in the form of a comparator. 
	 * @author Justin Tse, Martin Izdimirski
	 *
	 */
	public class ourComparator  implements Comparator<String> {
		  public int compare(String a1, String a2) 
		  {
		    if (a1 == a2) {
		        return 0;
		    }
		    if (a1 == null) {
		        return -1;
		    }
		    if (a2 == null) {
		        return 1;
		    }
		    return a1.compareTo(a2); 
		  }
		}
	
	ourComparator Compa = new ourComparator(); 
	MySortedSet<String> tester = new MySortedSet<String>();
	MySortedSet<String> tester2 = new MySortedSet<String>();
	ArrayList<String> arrayTester = new ArrayList<String>();
	MySortedSet<String> tester3 = new MySortedSet<String>(Compa); //This set uses a Comparator
	
	@Before
	public void setUp() throws Exception {
		
		tester.add("1");
		tester.add("2");
		tester.add("3");
		arrayTester.add("4");
		arrayTester.add("5");
		tester.addAll(arrayTester); //tester should be 1 2 3 4 5
		
		//Second test array of strings to test if array grows correctly
		int i = 0;
		String tempString = " ";
		while (i< 22)
		{
			tempString = "1" + tempString;
			tester2.add(tempString);
			i++;
		}
		tester2.add("b"); //Last element of tester 2 should be b and it should have grown
		
		
		//Initialize tester 3
		//Tester 3 is used to test functions that are different when using a comparator instead of comparable
		tester3.add("1");
		tester3.add("2");
		tester3.add("3");
		tester3.add("4");
		tester3.add("5"); //Tester3 should be 1 2 3 4 5 
		

		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testcontain1() //Test if contains returns true when it should
	{
		assertEquals(true,tester.contains("1")); 
	}
	
	@Test
	public void testcontain2()  //Test if contains returns false when it should
	{
		assertEquals(false,tester.contains("6")); //tester does not contain 6
	}
	
	@Test
	public void testfirst1() 
	{
		assertEquals("1",tester.first());
	}

	@Test
	public void testlast1() 
	{
		assertEquals("5",tester.last());
	}
	
	@Test
	public void testclear1() 
	{
		tester.clear(); //Testing if clear function returns empty list. 
		assertEquals(0,tester.size()); //Once cleared size should be 0 
	}
	
	@Test
	public void testsize1() 
	{   
		assertEquals(5,tester.size());
	}
	
	@Test
	public void testcontainsAll1() //Test if containsAll returns true when it should
	{	
		ArrayList<String> arr = new ArrayList<String>();
		arr.add("1");
		arr.add("2");
		arr.add("3");
		assertEquals(true,tester.containsAll(arr)); //Should contain all values of arr
	}
	
	@Test
	public void testcontainsAll2() //Test if containsAll returns false when it should 
	{	
		ArrayList<String> arr = new ArrayList<String>();
		arr.add("6");
		arr.add("2");
		arr.add("3");
		assertEquals(false,tester.containsAll(arr)); //Should not contain six so returns false 
		
	}
	
	@Test
	public void testisEmpty1() //tests if isEmpty returns false when it should 
	{
		assertEquals(false,tester.isEmpty());
	}
	
	@Test
	public void testisEmpty2() //tests if isEmpty returns true when it should 
	{
		tester.clear();
		assertEquals(true,tester.isEmpty());
	}

	@Test
	public void testremove1() //tests if removing an element works. 
	{
		tester.remove("2");
		assertEquals(false,tester.contains("2"));
	}
	
	@Test
	public void testremoveAll1() //Testing remove all 
	{
		ArrayList<String> arr = new ArrayList<String>();
		arr.add("1");
		arr.add("2");
		arr.add("7"); //This is not in the array but it should not affect the function
		tester.removeAll(arr);
		assertEquals(false,tester.containsAll(arr));
		assertEquals(false,tester.contains("2")); // Even though above test returned false, 2 should no longer be in it
	}
	
	@Test
	public void testtoArray1()
	{
		String[] arr = new String[10];
		arr[0] = "1";
		arr[1] = "2";
		arr[2] = "3";
		arr[3] = "4";
		arr[4] = "5";	//Tests if the array has the same values where it should. 
		assertEquals(true,arr[0] == tester.toArray()[0]);
		assertEquals(true,arr[1] == tester.toArray()[1]);
		assertEquals(true,arr[2] == tester.toArray()[2]);
		assertEquals(true,arr[3] == tester.toArray()[3]);
		assertEquals(true,arr[4] == tester.toArray()[4]);
		
	}
	
	@Test
	public void growArray()
	{
		//This tests if our add function growas the array correctly. 
		assertEquals("b", tester2.last());
		assertEquals(23,tester2.size()); //tests if array grows correctly, tests last value and amount of items 
	}
	
	@Test
	public void IteratorTestNext()
	{
		//This test tests all functions in our iterator.
		Iterator<String> ourIterator = (Iterator<String>) tester.iterator();
		assertEquals(true, ourIterator.hasNext());
		assertEquals("1", ourIterator.next());
		while(ourIterator.hasNext()) //Goes through entire array
		{
			ourIterator.remove();
			ourIterator.next();
		}
		ourIterator.remove(); //All values should be removed so size should be zero
		assertEquals(0, tester.size());
		
	}
	
	@Test //Tests if the Comparator sortedSet created the array correctly
	public void tester3Basics()
	{
	
		assertEquals("1", tester3.first());
		assertEquals("5", tester3.last());
		assertEquals(5, tester3.size());
		assertEquals(true, tester3.contains("2"));
		assertEquals(false, tester3.contains("6"));
		tester3.remove("2");
		assertEquals(false, tester3.contains("2"));
		//Tested add , contain , remove all which differentiate between comparator and comparable 
	
	}
	
	
}




