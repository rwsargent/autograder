package assignment3;

/**
 * 
 * @author Justin Tse, Martin Izdimirski
 *
 */

public class MySortedSetTimesTest {

	public static void main(String[] args) 
	{
		int i = 0;
		String tempString = "";  //our base string
		System.out.println(tempString);
		//First make a big MySortedSet
		MySortedSet<String> tester = new MySortedSet<String>();
		
		while(i< 2000000) //how many values in array
		{
			tempString = "" + i; //This will add an integer i as a string, the n element will be "n-1"
			tester.add(tempString);
			i++;
			System.out.println(i);
		}
		//System.out.println(tester.last());
		//Now time our contains method
		int j = 0;
		long start = System.nanoTime();
		long endtime = System.nanoTime();
		while(endtime - start <1000000000)
			endtime = System.nanoTime();// delay one second
		
		//Loop to time values for contains
		/*while(j<5)
		{
		 long startTime = System.nanoTime();
		 tester.contains("1200");
		 tester.contains("300");
		 tester.contains("9");
		 tester.contains("42");
		 tester.contains("3");
		 long endTime = System.nanoTime();
		 long elapsedTime = endTime - startTime;
		 System.out.println(elapsedTime/5 + " nano  seconds ");
		 i++;
		}*/
		//Loop to time values for add
		while(j<5)
		{
		 long startTime = System.nanoTime();
		 
		 tester.add("2000001");
		 
		 long endTime = System.nanoTime();
		 long elapsedTime = endTime - startTime;
		 System.out.println(elapsedTime + " nano  seconds ");
		 j++;
		 tester.remove("2000001"); //personally average these times
		}
		

	}

}
