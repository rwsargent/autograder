package assignment3;

/**
 * @author Justin Tse, Martin Izdimirski
 */

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;



public class MySortedSet<E> implements SortedSet<E>
{
	//Variables
	private E[] sortedList; 
	private boolean whichConstructor; //True if constructor 1 false if constructor 2
	private Comparator<? super E> ourComparator;
	private Comparable<? super E> ourComparable;
	private int arraySize;
	private int nextAvailablePos = 0;



	/**
	 * MySortedSet()
	 * This is our first constructor. This creates an array of size 10 to hold the Objects of type E.
	 * This constructor tells us to use E's natural ordering. 
	 * @param -- none
	 * @return -- none
	 */
	public MySortedSet() 
	{
		arraySize = 10;
		sortedList = (E[]) new Object[arraySize]; //Declare empty array of size 10
		whichConstructor = true; //Tells us which constructor we used

	}
	/**
	 * MySortedSet(Comparator<? super E> c)
	 * This is our second constructor. This creates an array of size 10 to hold the Objects of type E. 
	 * This constructor tells us to use a given Comparator. 
	 * @ param -- Comparator<?super E> 
	 * 				This is the comparator that we should use to order our list. 
	 * @ return -- none 
	 */
	public MySortedSet(Comparator<? super E> c)
	{
		arraySize = 10;
		sortedList = (E[]) new Object[arraySize]; //Declare empty array of size 10
		whichConstructor = false;
		ourComparator = c; //Sets the comparator we will use. 
	}


	@Override
	public Comparator<? super E> comparator() // We can just return ourComparator, since it uses the second constructor; this would return null, if Comparable was used (Constructor 1)
	{
		return ourComparator;
	}
	@Override
	public E first() throws NoSuchElementException 
	{
		if(nextAvailablePos == 0) //if empty
			throw new NoSuchElementException();
		return  sortedList[0]; //Return the first element of our array
	}
	@Override
	public E last() throws NoSuchElementException {
		if(nextAvailablePos == 0) //if empty
			throw new NoSuchElementException();
		return sortedList[nextAvailablePos-1]; //Return the last element of our array
	}
	@Override
	public boolean add(E o) 
	{	
		Comparable ourComparable;
		ourComparable = (Comparable) o;
		//If array empty is empty , automatically add this object
		if(nextAvailablePos == 0)
		{
			sortedList[0]=o; 
			nextAvailablePos++;
			return true;

		}
		//boolean ourReturn; //true if this set did not already contain the specified element
		//Need grow array in here as well as add 
		//Check if array is big enough
		//If its not big grow array
		if(nextAvailablePos >= sortedList.length)
		{
			arraySize = arraySize*2;
			Object[] tempList = (E[]) new Object[arraySize]; 
			for (int i = 0; i < sortedList.length; i++)
				tempList[i] = sortedList[i];
			sortedList = (E[]) tempList;
		}
		//Now to add the object
		//Make temp array 
		Object[] tempArray = (E[]) new Object[arraySize]; //Temporary Array
		//int j = 0;

		//Do our binary search to add

		int leftBound = -1; //-1 to account for first object
		int rightBound = nextAvailablePos - 1;
		int mid = (leftBound+rightBound)/2;
		int newMid;

		//Binary search if using comparator 
		if(!whichConstructor) //We are using comparator
		{
			//Binary Search
			while( leftBound < rightBound)
			{
				if( ourComparator.compare(o, sortedList[mid])==0)
					return false; // If its already in array  we dont want it
				else if(ourComparator.compare(o, sortedList[mid])<0)
					rightBound = mid -1;
				else
					leftBound = mid + 1;
				mid = (leftBound+rightBound)/2;
			}

			//System.out.println(mid);
			//Mid is the position before we want to add o. 
			//Now make a new array and add in all values.
			int i = 0;
			while(i< mid +1)
			{
				tempArray[i] = sortedList[i];
				i++;	
			} //Loop to add objects before o
			tempArray[i] = o; //Adds o in the right place
			i++;
			while(i< nextAvailablePos + 1)
			{
				tempArray[i] = sortedList[i-1];
				i++;
			} //Adds in the rest of the objects
			sortedList = (E[]) tempArray;
			nextAvailablePos ++;
			return true;
		}

		//Code if using comparable


		if(whichConstructor) //We are using comparable
		{
			//Binary Search
			while( leftBound < rightBound)
			{
				if( ourComparable.compareTo(sortedList[mid])==0)
					return false; // If its already in array  we dont want it
				else if(ourComparable.compareTo(sortedList[mid])<0)
					rightBound = mid -1;
				else
					leftBound = mid + 1;
				mid = (leftBound+rightBound)/2;
			}

			//System.out.println(mid);
			//Mid is the position before we want to add o. 
			//Now make a new array and add in all values.
			int i = 0;
			while(i< mid +1)
			{
				tempArray[i] = sortedList[i];
				i++;	
			} //Loop to add objects before o
			tempArray[i] = o; //Adds o in the right place
			i++;
			while(i< nextAvailablePos + 1)
			{
				tempArray[i] = sortedList[i-1];
				i++;
			} //Adds in the rest of the objects
			sortedList = (E[]) tempArray;
			nextAvailablePos ++;
			return true;
		}
		return true;
	}
	@Override
	public boolean addAll(Collection<? extends E> c) {
		Iterator<E> ourIterator = (Iterator<E>) c.iterator();
		boolean iter = false;
		if(ourIterator.hasNext())
			iter = true;
		while (ourIterator.hasNext())
		{
			add(ourIterator.next());
		}
		return iter;
	}
	@Override
	public void clear() {
		//Make a new empty array of the same size and return that array
		Object[] tempArray = (E[]) new Object[arraySize];
		sortedList = (E[]) tempArray;
		//reset counter variable
		nextAvailablePos = 0;

	}
	@Override
	public boolean contains(Object o) {
		if(nextAvailablePos == 0) //if empty
			return false;
		Comparable ourComparable;
		ourComparable = (Comparable) o;
		//This will be a binary search for the object
		int leftBound = 0; 
		int rightBound = nextAvailablePos - 1;
		int mid = (leftBound+rightBound)/2;
		int newMid;
		int j = 0;
		if(whichConstructor) //If we use comparable
		{
			while( leftBound < rightBound)
			{
				if( ourComparable.compareTo(sortedList[mid])==0)
					return true; // If its already in array  we dont want it
				else if(ourComparable.compareTo(sortedList[mid])<0)
					rightBound = mid -1;
				else
					leftBound = mid + 1;
				mid = (leftBound+rightBound)/2;
			}
			if(ourComparable.compareTo(sortedList[mid])==0)
				return true;
			return false;
		}

		if(!whichConstructor) //If we use comparator 
		{
			while( leftBound < rightBound)
			{
				if( ourComparator.compare((E) o, sortedList[mid])==0)
					return true; // If its already in array  we dont want it
				else if(ourComparator.compare((E) o, sortedList[mid])<0)
					rightBound = mid -1;
				else
					leftBound = mid + 1;
				mid = (leftBound+rightBound)/2;
			}
			if(ourComparable.compareTo(sortedList[mid])==0)
				return true;
		}
		return false;
	}
	@Override
	public boolean containsAll(Collection<?> c) {
		if(nextAvailablePos == 0) //if empty
			return false;
		Iterator<E> ourIterator = (Iterator<E>) c.iterator();
		boolean iter = false;
		if(ourIterator.hasNext())
			iter = true;
		while (ourIterator.hasNext())
		{
			if(contains(ourIterator.next())) //if has the element, sets true
				iter = true;
			else 
				return false;
		}
		return iter;		//returns iter, if it has everything inside c
	}
	@Override
	public boolean isEmpty() {
		//Check if first element is empty if it is return true, if not return false
		if(nextAvailablePos == 0)
			return true;
		return false;
	}

	 @Override
	public Iterator<E> iterator()
	{
		return new Iterator<E>()

				{
			private boolean wasNextCalled = false; 
			private int i = 0; //Our index variable 

			@Override
			public boolean hasNext() 
			{
				if(i >= nextAvailablePos) //If i is greater or equal to the position of the last position then there is no next
					return false;
				else 
					return true; 
			}

			@Override
			public E next() 
			{
				//If there's no next throw
				if(!hasNext())
					throw new NoSuchElementException();
				i++;
				wasNextCalled = true; 
				return sortedList[i-1]; //i - 1 because we incremented i above
			}
			/**void remove()
			 * Removes the last element returned
			 */
			public void remove()
			{
				if(!wasNextCalled)
					throw new IllegalStateException();
				if(wasNextCalled) // If next was called before this function call
				{
					MySortedSet.this.remove(sortedList[i-1]); //Removes the pos
					i--; // if we removed be go back in the list 
					wasNextCalled = false; // Resets if next was called before or not 
				}

			}

				};


	}

	@Override
	public boolean remove(Object o) {
		if(nextAvailablePos == 0) //if empty
			return false;
		boolean isObjectHere = false;
		Comparable ourComparable;
		ourComparable = (Comparable) o;
		//This will be a binary search for the object
		int leftBound = -1; //-1 to account for first object
		int rightBound = nextAvailablePos - 1;
		int mid = (leftBound+rightBound)/2;
		int newMid;
		int j = 0;

		if(whichConstructor) //If we use comparable
		{
			while( leftBound < rightBound)
			{
				if( ourComparable.compareTo(sortedList[mid])==0)
				{isObjectHere = true;
				break;
				}
				// If its here we mark it for removal 
				else if(ourComparable.compareTo(sortedList[mid])<0)
					rightBound = mid -1;
				else
					leftBound = mid + 1;
				mid = (leftBound+rightBound)/2;
			}
			if(!(ourComparable.compareTo(sortedList[mid])==0)) //If not the object we want to remove, then the object is not in our list so return false
				return false;
			else 
				isObjectHere = true;
			//Then make sortedList again but without the object with delete function
			Object[] tempArray = (E[]) new Object[arraySize];
			while(j < mid)
			{
				tempArray[j] = sortedList[j];
				j++;
			}
			//now skip the object o
			j++;
			while(j<nextAvailablePos)
			{

				tempArray[j-1] = sortedList[j];
				j++;
			}
			nextAvailablePos--;
			sortedList = (E[]) tempArray;

		}


		if(!whichConstructor) //If we use comparator 
		{
			while( leftBound < rightBound)
			{
				if( ourComparator.compare((E) o, sortedList[mid])==0)
				{
					isObjectHere = true; // If its here we mark it for removal
					break;
				}
				else if(ourComparator.compare((E) o, sortedList[mid])<0)
					rightBound = mid -1;
				else
					leftBound = mid + 1;
				mid = (leftBound+rightBound)/2;
			}
			if(!(ourComparator.compare((E) o, sortedList[mid])==0)) //If not the object we want to remove, then the object is not in our list so return false
				return false;
			else	
				isObjectHere = true;

			//Then make sortedList again but without the object with delete function
			Object[] tempArray = (E[]) new Object[arraySize];
			while(j < mid)
			{
				tempArray[j] = sortedList[j];
				j++;
			}
			//now skip the object o
			j++;
			while(j<nextAvailablePos)
			{

				tempArray[j-1] = sortedList[j];
				j++;
			}
			nextAvailablePos--;
			sortedList = (E[]) tempArray;
		}
		return isObjectHere;
	}
	@Override
	public boolean removeAll(Collection<?> c) {
		if(nextAvailablePos == 0) //if empty
			return false;
		Iterator<E> ourIterator = (Iterator<E>) c.iterator();
		boolean iter = false;
		boolean ourBool = false;
		if(!ourIterator.hasNext()) //if it doesn't have anything, return false
			return iter;
		if(ourIterator.hasNext())
			iter = true;
		while (ourIterator.hasNext())
		{	
			iter = this.remove(ourIterator.next());
			if(iter) //if we removed something set ourBool, this will not change once it becomes true
				ourBool = true;



		}
		return ourBool;		
	}
	@Override
	public int size() {
		// Return the amount of elements
		return nextAvailablePos;
	}
	@Override
	public Object[] toArray() {
		//Just return our array because its already sorted
		return sortedList;
	}
	/**
	 * void test()
	 * This function goes through the array and prints each entry with the objects default toString() method. 
	 * @param -- none
	 * @return -- none
	 */
	public void test()
	{
		for(int i=0 ;i<nextAvailablePos; i++ )
			System.out.println(sortedList[i]);
	}

	
}
