package assignment3;

/**
 * @author Justin Tse, Martin Izdimirski
 */

import java.util.ArrayList;
import java.util.Iterator;

import assignment3.MySortedSet;
public class PersonalTester {

	public static void main(String[] args) 
	{
		MySortedSet<String> testSet = new MySortedSet<String>();
		testSet.add("4");
		testSet.add("3");
		testSet.add("2");
		testSet.add("1");
		testSet.add("5");
		testSet.add("6");
		testSet.add("7");
		testSet.add("8");
		testSet.add("0");
		testSet.remove("4");
		testSet.remove("5");
	//	testSet.test();
		ArrayList<String> tester = new ArrayList<String>();
		tester.add("a");
		tester.add("b");
		tester.add("c");
		tester.add("d");
		tester.add("e");
		testSet.addAll(tester);
		Object[] copiedArray;
		copiedArray = testSet.toArray();
		//System.out.println(copiedArray[11]);
		
		//testSet.clear();
		//System.out.println(testSet.size());
		Iterator<String> ourIterator = (Iterator<String>) testSet.iterator();
		
			ourIterator.next();
			ourIterator.remove();
			testSet.test();
		
		
		
		
	//	testSet.test();
		
//		System.out.println(testSet.containsAll(tester));
//		System.out.println("Doesn't contain 4, false: " + testSet.contains("4"));
//		System.out.println("contains e: " + testSet.contains("e"));
//		tester.add("f");
//		System.out.println(testSet.remove("e"));
		//System.out.println("doesn't contain e: " + testSet.contains("e"));
		
//		System.out.println("contains f: " + testSet.contains("f"));
		//System.out.println(testSet.containsAll(tester));
		//testSet.test();
		//System.out.println();
		//System.out.println("remove tester from testSet: " + testSet.removeAll(tester));
//		System.out.println("testSet doesn't contain tester anymore: " + testSet.containsAll(tester));
		//testSet.test();
//		for (int i = 0; i < 6; i++)
//			System.out.println(tester.get(i));
//		testSet.test();
		
	



	//	System.out.println(testSet.contains("4"));
	//	System.out.println(testSet.contains("11"));
		//System.out.println(testSet.last());
		 //Grow works 
		//testSet.clear();
		
		
		/*int[] testerArray = new int[9];
		testerArray[0] = 0;
		testerArray[1] = 1;
		testerArray[2] = 2;
		testerArray[3]= 3;
		testerArray[4]= 5;
		testerArray[5] = 6;
		testerArray[6]= 7;
		testerArray[7] = 8;
		testerArray[8] = 9;*/

		//System.out.println(binarySearch2(4, testerArray));
	}
	
	/*public static int binarySearch(int o, int[] sortedList)
	{
		int leftBound = 0;
		int rightBound = 9;
		int mid = (leftBound+rightBound)/2;
		int newMid;
		while (leftBound <= rightBound || Math.abs(leftBound - rightBound)==1)
		{
			//System.out.println(sortedList[mid]);
			if(o < sortedList[mid])
				{mid = (leftBound+rightBound)/2;
				rightBound = mid;}
			else
				{mid = (leftBound+rightBound)/2;
				leftBound = mid;}
			newMid = (leftBound+rightBound)/2;
			
			if(newMid == mid)
				return mid;
			
			mid = (leftBound+rightBound)/2;
			
		}
		return mid;
	}*/
	
	public static int binarySearch2(int o, int[] sortedList)
	{
		int leftBound = 0;
		int rightBound = 9;
		int mid = (leftBound+rightBound)/2;
		while( leftBound < rightBound)
		{
			if( o == sortedList[mid])
				return mid;
			else if(o<sortedList[mid])
				rightBound = mid -1;
			else
				leftBound = mid + 1;
			mid = (leftBound+rightBound)/2;
		}
		return mid;
		
	}

}
