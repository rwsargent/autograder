package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This class contains defines all of the methods required to implement a sorted
 * set of a generic type.
 * 
 * @authors Christina Foreman & Safia Hassan
 *
 *
 * @Param <E> - a generic type
 */
public class MySortedSet<E> implements SortedSet<E> {

	// Instance variables
	private E[] mySet;
	private int capacity;
	private int size; // number of elements in the array
	private boolean usesNaturalSorting;
	private Comparator<? super E> theComparator;
	public int pos = 0;
	public int indexPos = 0;
	public boolean usedNext = false;

	// Constructors
	/**
	 * If this constructor is used to create the sorted set, it is assumed that
	 * the elements are ordered using their natural ordering (i.e., E implements
	 * Comparable<? super E>).
	 */
	public MySortedSet() {
		capacity = 20;
		mySet = (E[]) new Object[capacity];
		size = 0;
		usesNaturalSorting = true;
	}

	/**
	 * If this constructor is used to create the sorted set, it is assumed that
	 * the elements are ordered using the provided comparator.
	 */
	public MySortedSet(Comparator<? super E> c) {
		capacity = 20;
		mySet = (E[]) new Object[capacity];
		size = 0;
		usesNaturalSorting = false;
		theComparator = c;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {

		// comparator is used to order the elements in this set
		// return Comparator

		if (!usesNaturalSorting)
			return theComparator;
		return null;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (mySet[0] != null) // will not return the first element if it is null
			return mySet[0];

		else
			throw new NoSuchElementException();
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (size > 0)
			return mySet[size - 1];
		else
			throw new NoSuchElementException();
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		// looking for duplicates
		for (int i = 0; i < size; i++) {
			if (mySet[i] == o || o == null)
				return false; // not a duplicate, add it to the array
		}

		// make sure the array isn't at capacity before adding
		// if array is at capacity, double it
		if (size == capacity)
			mySet = doubleArray(mySet);
		// add the element and keep sorted order
		// check what type of sorting we are working with ie: natural vs
		// specific

		if (usesNaturalSorting) {
			if (size == 0) {
				mySet[0] = o;
				size++;
				return true;
			}
			for (int i = size; i > 0; i--) { // compare here, if o is smaller
												// than item at [i-1]
				if (((Comparable) mySet[i - 1]).compareTo(o) > 0) { // if o
																	// comes
																	// before
																	// item at
																	// index i

					mySet[i] = mySet[i - 1]; // copy item[i - 1] to item[i]

				} else { // if o is larger than item at i-1
					mySet[i] = o; // set item[i] to
					size++;
					return true;
				}
			} // if o belongs at the beginning of the array
			if (((Comparable) mySet[0]).compareTo(o) > 0) {
				mySet[0] = o;
				size++;
				return true;
			}

		}

		else if (!usesNaturalSorting) {
			if (size == 0) {
				mySet[size] = o;
				size++;
				return true;
			}
			for (int i = size; i > 0; i--) { // compare here, if o is smaller
												// than item at [i-1]
				if (theComparator.compare(mySet[i - 1], o) > 0) { // if o comes
																	// before
																	// item at
																	// index i

					mySet[i] = mySet[i - 1]; // copy item[i - 1] to item[i]
				} else { // if o is larger than item at i-1
					mySet[i] = o; // set item[i] to
					size++;
					return true;
				}
			}
			if (theComparator.compare(mySet[0], o) > 0) {
				mySet[0] = o;
				size++;
				return true;
			}
		}
		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {

		boolean changed = false;

		E[] cArray = (E[]) new Object[c.size()];
		cArray = (E[]) c.toArray();

		for (int i = 0; i < c.size(); i++) {
			if (this.add(cArray[i]))
				changed = true;
		}
		return changed;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		for (int i = 0; i < size; i++)
			mySet[i] = null;
		size = 0; // clear all elements from the set, so size is now 0.

	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		for (int i = 0; i < size; i++) {
			if (mySet[i] == o)
				return true;
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {

		boolean contains = false;

		E[] cArray = (E[]) new Object[c.size()];
		cArray = (E[]) c.toArray();

		for (int i = 0; i < c.size(); i++) {
			if (this.contains(cArray[i]))
				contains = true;
			else {
				contains = false;
				return contains;
			}
		}
		return contains;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (size == 0)
			return true;
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		Iterator<E> myItr = new Iterator<E>() {

			@Override
			/**
			 * Returns true if the iteration has more elements. 
			 * (In other words, returns true if next() would return an element rather than throwing an exception.)
			 * @return true if the iteration has more elements
			 */
			public boolean hasNext() {
				E[] arr = (E[]) new Object[MySortedSet.this.capacity];
				arr = (E[]) MySortedSet.this.toArray();

				while (pos < MySortedSet.this.size())
					if (arr[pos + 1] != null) {
						pos++;
						return true;
					}

				return false;
			}

			@Override
			/**
			 * Returns the next element in the iteration.
			 * @return the next element in the iteration.
			 * @throws NoSuchElementException - if the iteration has no more elements
			 */
			public E next() {
				E[] arr = (E[]) new Object[MySortedSet.this.capacity];
				arr = (E[]) MySortedSet.this.toArray();
				while (indexPos < MySortedSet.this.size()) {
					if (arr[indexPos + 1] != null) {
						indexPos++;
						usedNext = true;
						return arr[indexPos];
					}
				}

				throw new NoSuchElementException("No next element");

			}

			@Override
			/**
			 * Removes from the underlying collection the last element returned by this iterator (optional operation). 
			 * This method can be called only once per call to next(). The behavior of an iterator is unspecified if 
			 * the underlying collection is modified while the iteration is in progress in any 
			 * way other than by calling this method.
			 * 
			 * @throws UnsupportedOperationException - if the remove operation is not supported by this iterator 
			 * @throws IllegalStateException - if the next method has not yet been called, or the remove method 
			 * has already been called after the last call to the next method
			 */
			public void remove() {

				if (usedNext) { // if we used next(), usedNext is true and we
								// can remove

					if (MySortedSet.this.remove(mySet[size - 1])) {// successfully
						// remove
						usedNext = false; // we remove, then set usedNext to
						// false, making it so remove can't
						// be used again until next is
						// called again

					} else if (!MySortedSet.this.remove(mySet[size - 1])) { // remove
																			// returned
																			// false
																			// not
																			// supported
						throw new UnsupportedOperationException(
								"Remove operation is not supported by this iterator");
					}
				}

				else if (!usedNext) // if we did not use next, usedNext is false
									// and
					// we will throw this exception
					throw new IllegalStateException(
							"Next method has not yet been called or remove method has already been called after the last call to the next method");

			}

		};
		return myItr;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int pos = 0;

		for (int i = 0; i < size; i++) {
			if (mySet[i] == o) {
				for (pos = i; pos < size; pos++) {
					mySet[pos] = mySet[pos + 1];
				}
				mySet[size] = null;
				size = size - 1;
				return true;
			}
			pos++;

		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {

		boolean changed = false;

		E[] cArray = (E[]) new Object[c.size()];
		cArray = (E[]) c.toArray();

		for (int i = 0; i < c.size(); i++) {
			if (this.remove(cArray[i]))
				changed = true;
		}
		return changed;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		return mySet;
	}

	/**
	 * This method is called when an array has reached its capacity and we need
	 * to make it bigger to make more room for more elements
	 * 
	 * @param arr
	 *            , the array that we are doubling
	 * @return an array twice the capacity of the original array
	 */
	public E[] doubleArray(E[] arr) {
		E[] arrayTwiceSize = (E[]) new Object[arr.length * 2];

		for (int i = 0; i < arr.length; i++) {
			arrayTwiceSize[i] = (E) arr[i];
		}

		capacity = arrayTwiceSize.length; // set capacity to the array's new
											// length
		return arrayTwiceSize;
	}

}
