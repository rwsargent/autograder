package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/*
 * This class is the JUnit testing for MySortedSet. Note, we also have a testing class (MySortedSetTest) for more specific tests. 
 * 
 * @authors Christina Foreman & Safia Hassan
 * 
 */

public class MySortedSetTesting {

	private MySortedSet<String> set1, set2, set3, set4, set5, set6;
	private ArrayList<String> arr, arr2;

	@Before
	public void setUp() throws Exception {
		// MySortedSet of Strings
		set1 = new MySortedSet<String>();
		set1.add("hi"); // [does][hi][thing][this][work]
		set1.add("does");
		set1.add("this");
		set1.add("thing");
		set1.add("work?");

		// ArrayList of Strings
		set2 = new MySortedSet<String>();
		arr = new ArrayList<String>();
		arr.add("apple"); // [apple][bye][color][zoo]
		arr.add("color");
		arr.add("bye");
		arr.add("zoo");

		set2.addAll(arr);

		arr.add("lol"); // add another element to compare containsAll

		set3 = new MySortedSet<String>();
		set3.addAll(arr);
		set3.clear();

		set4 = new MySortedSet<String>(); // empty array to test isEmpty

		set5 = new MySortedSet<String>();
		set5.add("hi"); // [does][hi][thing][this][work]
		set5.add("does");
		set5.add("this");
		set5.add("thing");
		set5.add("work?");

		set5.remove("does");

		set6 = new MySortedSet<String>();
		arr2 = new ArrayList<String>();
		arr2.add("apple"); // [apple][bye][color][zoo]
		arr2.add("color");
		arr2.add("bye");
		arr2.add("zoo");

		set6.addAll(arr2);
		set6.add("check");
		set6.removeAll(arr2);

	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFirst() {
		assertEquals("does", set1.first());
	}

	@Test
	public void testLast() {
		assertEquals("work?", set1.last());
	}

	@Test
	public void testAddAllCollectionFirst() {

		assertEquals("apple", set2.first());
	}

	@Test
	public void testAddAllCollectionLast() {

		assertEquals("zoo", set2.last());
	}

	@Test
	public void testClear() {
		assertEquals(0, set3.size());
	}

	@Test
	public void testContains() {
		assertEquals(true, set1.contains("work?"));
	}

	@Test
	public void testContainsAllCollections() {
		assertEquals(false, set2.containsAll(arr));
	}

	@Test
	public void testIsEmpty() {
		assertEquals(true, set4.isEmpty());
	}

	@Test
	public void testHasNext() {
		assertEquals(true, set1.iterator().hasNext());
	}

	@Test
	public void testNext() {
		assertEquals("hi", set1.iterator().next());
	}

	@Test
	public void testSize() {
		assertEquals(5, set1.size());
	}

	@Test
	public void testRemove() {
		assertEquals("hi", set5.first());
	}

	@Test
	public void testRemoveAllCollection() {
		assertEquals("check", set6.first());
	}

}
