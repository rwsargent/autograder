package assignment3;

import java.util.Comparator;


/*
 * This class contains testing for MySortedSet
 * 
 * @authors Christina Foreman & Safia Hassan
 * 
 */
public class MySortedSetTest {

	public static void main(String[] args) {

		MySortedSet<String> mySet = new MySortedSet<String>();

		mySet.add("Hi");
		mySet.add("hi");
		mySet.add("ahoy");
		mySet.add("there");

		if (mySet.add("Hi"))
			System.out.println("Test Failed: for adding a duplicate");

		mySet.clear();
		if (mySet.size() != 0)
			System.out.println("Test Failed: for clearing a set");

		// ITERATOR

		MySortedSet<String> mySet2 = new MySortedSet<String>();

		mySet2.add("Hi");
		mySet2.add("hi");
		mySet2.add("ahoy");
		mySet2.add("there");

		mySet2.iterator().next();

		mySet2.iterator().remove();

		if (mySet2.size() != 3) {
			System.out.println("Test Failed: iterator did not remove properly");
		}

		if (!mySet2.last().equals("hi"))
			System.out
					.println("Test Failed: iterator did not remove the last item");

		MySortedSet<String> mySet3 = new MySortedSet<String>();

		mySet3.add("Hi");
		mySet3.add("hi");
		mySet3.add("aho");
		mySet3.add("thre");
		mySet3.add("H");
		mySet3.add("i");
		mySet3.add("hoy");
		mySet3.add("here");
		mySet3.add("Hii");
		mySet3.add("hii");
		mySet3.add("ahory");
		mySet3.add("theere");
		mySet3.add("Hwi");
		mySet3.add("hei");
		mySet3.add("ahffoy");
		mySet3.add("thefre");
		mySet3.add("His");
		mySet3.add("hiaa");
		mySet3.add("ahossy");
		mySet3.add("thereee");
		mySet3.add("Hi4");
		mySet3.add("hji");
		mySet3.add("ahfoy");
		mySet3.add("thebre");

		if (mySet3.size() != 24)
			System.out.println("Test Failed: array capacity did not double");

		
		// Testing a set with a comparator (ReverseString)
		Comparator<String> comp = new ReverseString();

		MySortedSet<String> mySet4 = new MySortedSet<String>(comp);
		mySet4.add("Hi");
		mySet4.add("hi");
		mySet4.add("ahoy");
		mySet4.add("there");

		if (!mySet4.first().equals("there"))
			System.out.println("Test Failed: set with comparator did not work");

	}

}
