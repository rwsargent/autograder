package assignment3;

import java.util.Comparator;
/**
 * This class contains a comparator to order strings in a descending order.
 * @author Christina Foreman & Safia Hassan 
 *
 */
public class ReverseString implements Comparator<String>{
	public int compare(String lhs, String rhs){
		return -1*lhs.compareTo(rhs);
	}
}