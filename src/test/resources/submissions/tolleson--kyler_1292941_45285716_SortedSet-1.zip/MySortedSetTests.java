package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTests
{
	private MySortedSet set1, set2, set3, set4;
	private TestPuppy logan = new TestPuppy("Logan");
	private TestPuppy kyler = new TestPuppy("Kyler");
	private TestPuppy bob = new TestPuppy("Bob");
	private ArrayList<TestPuppy> puppies1 = new ArrayList<TestPuppy>();
	private ArrayList<TestPuppy> puppies2 = new ArrayList<TestPuppy>();
	
	@Before
	public void setup() throws Exception
	{
		set1 = new MySortedSet();
		set1.add(1);
		set1.add(2);
		set1.add(3);
		
		set2 = new MySortedSet();
		set2.add("Hi");
		set2.add("Hello");
		set2.add("Hola");
		
		set3 = new MySortedSet();
		set3.add(logan);
		set3.add(kyler);
		
		set4 = new MySortedSet();
		set4.add(1);
		set4.add("Hi");
		set4.add(logan);
		
		puppies1.add(logan);
		puppies1.add(kyler);
		
		puppies2.add(logan);
		puppies2.add(kyler);
		puppies2.add(bob);
	}
	
	@Test
	public void testFirstAndLast()
	{
		assertEquals(1, set1.first());
		assertEquals(3, set1.last());
		
		assertEquals("Hi", set2.first());
		assertEquals("Hola", set2.last());
		
		assertEquals(logan, set3.first());
		assertEquals(kyler, set3.last());
		
		assertEquals(1, set4.first());
		assertEquals(logan, set4.last());
	}
	
	@Test
	public void testAddOddities()
	{
		assertEquals(false, set1.add(1));
		assertEquals(false, set1.add(null));
		
		assertEquals(false, set2.add("Hi"));
		
		assertEquals(false, set3.add(logan));
		
		assertEquals(false, set4.add(1));
		assertEquals(false, set4.add("Hi"));
	}
	
	
	@Test
	public void testAddAll()
	{
		assertEquals(false, set3.addAll(puppies1));
		assertEquals(true, set3.addAll(puppies2));
	}
	
	@Test
	public void testRemove()
	{
		set1.remove(1);
		assertEquals(false, Arrays.asList(set1).contains(1));
	}
	
	@Test
	public void testClearAndIsEmpty()
	{
		set1.clear();
		assertEquals(true, set1.isEmpty());
		set2.clear();
		assertEquals(true, set2.isEmpty());
		set3.clear();
		assertEquals(true, set3.isEmpty());
		set4.clear();
		assertEquals(true, set4.isEmpty());
	}
	
	@Test
	public void testSize()
	{
		assertEquals(3, set1.size());
	}
	

	
}