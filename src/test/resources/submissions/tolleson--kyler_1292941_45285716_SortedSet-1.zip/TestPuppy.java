package assignment3;

public class TestPuppy implements Comparable
{
	private String name;
	public TestPuppy(String name1)
	{
		name = name1;
	}
	@Override
	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
