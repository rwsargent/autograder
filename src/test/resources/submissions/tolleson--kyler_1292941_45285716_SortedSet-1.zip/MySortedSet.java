package assignment3;

/**
 * 
 * MySortedSet class for CS 2420
 * 
 * @author Kyler Tolleson and Logan Cox February 5, 2015
 * 
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E extends Comparable<E>> implements SortedSet<E>
{
	private E[] data;
	private Comparator<? super E> comparator;
	private int size = 0;
	
	public MySortedSet()
	{
		data = (E[]) new Object[10];
	}

	public MySortedSet(Comparator<? super E> comp)
	{
		data = (E[])new Object[10];
		comparator = comp;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator()
	{
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException
	{
		return data[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException
	{
		return data[size-1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o)
	{
		
		//Checks to see if o is already contained in the set
		if(contains(o))
		{
			return false;
		}

		//Checks to see if adding another object to the set would bring the set over its current capacity
		//if so, double the current capacity of the set
		if (size + 1 >= data.length)
		{
			E[] temp = (E[])new Object[data.length*2];
			for (int i = 0; i < data.length-1; i++)
			{
				temp[i] = data[i];
			}
			data = temp;
		}
		
		
		for (int i = 0; i<size;i++)
		{
			//Finds where to insert the object in the set when using a comparator
			if(comparator!=null)
			{
				if((comparator.compare(data[i], o)>0))
				{
					for(int j = size-1; j > i; j--)
					{
		                data[j+1] = data[j];
		            }
		            data[i] = o;
		            return true;
				}
			}
			//Finds where to insert the object in the set when not using a comparator
			else
			{
				if((data[i]).compareTo(o)<0)
				{
					for(int j = size-1; j > i; j--)
					{
		                data[j+1] = data[j];
		            }
		            data[i] = o;
		            return true;
				}
			}
		}
		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c)
	{
		//Calls the add method for each object in the collection
		boolean test = false;
		for (E item : c)
		{
			if (this.add(item))
			{
				test = true;
				size++;
			}
		}
		return test;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear()
	{
		//Sets data equal to a new empty array
		data = (E[])new Object[10];
		size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o)
	{
		//Uses binary search to locate object o in the set when using a comparator
		if (comparator != null)
		{
			int low = 0;
			int high = size-1;
			while (high >= low)
			{
				int middle = (low + high)/2;
				if(data[middle] == o)
				{
					return true;
				}
				if(comparator.compare(data[middle],(E) o)<0)
				{
					low = middle + 1;
				}
				if(comparator.compare(data[middle],(E) o)>0)
				{
					high = middle-1;
				}
			}
		}
		//Uses binary search to locate object o in the set when not using a comparator
		else
		{
			int low = 0;
			int high = size-1;
			while (high >= low)
			{
				int middle = (low + high)/2;
				if(data[middle] == o)
				{
					return true;
				}
				if(data[middle].compareTo((E) o)<0)
				{
					low = middle + 1;
				}
				if(data[middle].compareTo((E) o)>0)
				{
					high = middle-1;
				}
			}
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c)
	{
		//Calls the contains method on each item in the collection
		boolean test = true;
		for (Object item : c)
		{
			test = contains(item);
		}
		return test;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty()
	{
		for (E item : data)
		{
			if (item != null)
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator()
	{
		Iterator<E> iterator = new Iterator<E>()
		{
			private int currentIndex = 0;
			
			@Override
			public boolean hasNext()
			{
				return (currentIndex < size && data[currentIndex]!=null);
			}

			@Override
			public E next()
			{
				return data[currentIndex++];
			}
			
			@Override
			public void remove()
			{
				throw new UnsupportedOperationException();
			}
		};
		return iterator;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o)
	{
		boolean contained = false;
		int i, j;
		for (i = 0, j = 0; j < data.length; ++j)
		{
			if (o.equals(data[j]))
			{
				contained = true;
				data[i++] = data[j];
				size--;
			}
			data = Arrays.copyOf(data, i);
		}
		return contained;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c)
	{
		boolean contained = false;
		for (Object item : c)
		{
			if (contains(item))
			{
				contained = true;
				remove(item);
				size--;
			}
		}
		return contained;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size()
	{
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray()
	{
		return data;
	}

}