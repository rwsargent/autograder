package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * MySortedSet is a custom Collection we're
 * implementing to be able to handle input
 * of any type - Strings, integers, floats,
 * cars, ducks, and any other object our 
 * "client" can think of.
 * @author Richard Frost and Ryan Fletcher
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E>{
	private E[] baseArray;
	private boolean usesComparator;
	public final int INITIAL_ARRAY_LENGTH = 10; 
	Comparator<? super E> myComparator; //Compare items of this type, as well as its super classes
	private int itemCounter;
	
	/**
	 * If this constructor is used to create the sorted 
	 * set, it is assumed that the elements are ordered 
	 * using their natural ordering (i.e., E implements 
	 * Comparable<? super E>).
	 * @throws Exception 
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(){
		//Make our initial size 10
		this.baseArray = (E[])new Object[INITIAL_ARRAY_LENGTH];
		myComparator = null;
		usesComparator = false;
		itemCounter = 0;
	}
	
	/**
	 * If this constructor is used to create the sorted 
	 * set, it is assumed that the elements are ordered 
	 * using the provided comparator.
	 * @param comparator
	 * 			-Use to order the elements in our set
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator <?super E> comparator){
		this.baseArray = (E[])new Object[INITIAL_ARRAY_LENGTH];
		myComparator = comparator;
		usesComparator = true;
		itemCounter = 0;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		// TODO Auto-generated method stub
		return myComparator;
	}
	
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		//Check to make sure the type is ok
		if(baseArray[0] == null || baseArray.length == 0){
			throw new NoSuchElementException();
		}
		// TODO Auto-generated method stub
		return baseArray[0];
	}
	
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if(itemCounter == 0) throw new NoSuchElementException();
		if(baseArray[itemCounter - 1] == null){
			throw new NoSuchElementException();
		}
		
		// TODO Auto-generated method stub
		return baseArray[itemCounter - 1];
	}
	
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param item
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E item) {
		//If we aren't using the comparator and the class doesn't implement Comparable, return false
		//if(!usesComparator && !(item instanceof Comparable<?>)) return false;
		
		int initialSize = itemCounter;
		if(item == null) return false;
		if(itemCounter == 0){
			baseArray[0] = item;
			itemCounter++;
			return initialSize < itemCounter;
		}
		if(itemCounter == this.baseArray.length) resizeArray();
		
		//Make sure there are no duplicates
		if(search(item) != -1) return false;
		
		//Look for where we need to add this
		int position = searchToAdd(item);
		
		//If we get -1 from an exception or other problem, return false
		if(position == -1) return false;
		
		//Shift everything else over and then add it
		for(int i = itemCounter; i>position; i--){
			baseArray[i] = baseArray[i-1];
		}
		baseArray[position] = item;
		
		//Increment the item counter by 1
		itemCounter++;
		
		return initialSize < itemCounter;
	}
	
	/**
	 * Implement a binary search for finding stuff.
	 * @return - The position of the item we're searching for.
	 * 				-1 means it's not in the collection.
	 */
	@SuppressWarnings("unchecked")
	public int searchToAdd(E item){
		if(!this.iterator().hasNext()) return -1;
		if(item == null) return -1;
		
		
		int low = 0;
		int high = itemCounter - 1;
		int mid;
		
		try{
		while(low <= high){
			mid = (low + high)/2;
			
			//If there was no comparator passed in, use the natural ordering with Comparable
			if(!usesComparator){
				if(((Comparable<E>) item).compareTo(baseArray[mid]) > 0)
					low = mid + 1;
				else if(((Comparable<E>) item).compareTo(baseArray[mid]) < 0)
					high = mid - 1;
				else
					return mid;
			}
			
			//If there IS a comparator passed in, use that to order instead
			else{
				//If the item is greater than the mid point item, use the upper half of our set
				if(myComparator.compare(item, baseArray[mid]) > 0)
					low = mid + 1;
				else if(myComparator.compare(item, baseArray[mid]) < 0)
					high = mid - 1;
				else
					return mid;
			}
		}
		//if(low == itemCounter - 1) return itemCounter;
		}
		catch(ClassCastException e){
			return -1;
		}
		
		//Return the next position
		return low;
	}
	
	/**
	 * Resize our array
	 */
	@SuppressWarnings("unchecked")
	private void resizeArray(){
		//Make a temporary array to store our old items
		E[] tmpArray = (E[])new Object[baseArray.length * 2];
		
		//Copy everything over to our temporary array
		for(int i = 0; i<baseArray.length; i++){
			tmpArray[i] = baseArray[i];
		}
		
		//Set the base array to the temporary array
		baseArray = tmpArray;
	}
	
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		if(c == null || c.size() == 0) return false;
		int initialSize = itemCounter;
		Iterator<?> i = c.iterator();
		while(i.hasNext()){
			this.add((E)i.next());
		}
		int mid = (0 + 8) >>> 1;
		return initialSize < itemCounter;
	}
	
	
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		this.baseArray = (E[])new Object[INITIAL_ARRAY_LENGTH];
		this.itemCounter = 0;
	}
	
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object item) {
		if(baseArray.length == 0) return false;
		
		//Search only returns -1 if the item isn't in there. Otherwise, it is.
		return this.search((E) item) != -1;
	}
	
	/**
	 * Implement a binary search for finding stuff.
	 * @return - The position of the item we're searching for.
	 * 				-1 means it's not in the collection
	 */
	@SuppressWarnings("unchecked")
	public int search(Object item){
		if(!this.iterator().hasNext()) return -1;
		if(item == null) return -1;
		
		try{
		boolean greaterThan = false;
		int low = 0;
		int high = itemCounter - 1;
		int mid;
		
		while(low < high){
			mid = (low + high)/2;
			//If the item is greater than the mid point item, use the upper half of our set
			if(!usesComparator)
				greaterThan = ((Comparable<E>) item).compareTo(baseArray[mid]) > 0;
			else 
				greaterThan = myComparator.compare((E)item, baseArray[mid]) > 0; 
			if(greaterThan)
				low = mid + 1;
			else
				high = mid;
		}
		
		//If it's greater than any of the others in the set, return -1
		if(low == itemCounter) return -1;
		
		if(baseArray[low].equals(item)) return low;
		}
		catch(ClassCastException e){
			//Just return -1, don't worry about error reporting here. This is our way of handling mismatched types.
			return -1;
		}
		//If it's not found, return -1
		return -1;
	}
	
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		if(c == null || c.size() == 0) return false;
		boolean contains = false;
		Iterator<?> i = c.iterator();
		while(i.hasNext()){
			//If an item isn't in the collection, the whole thing is false
			contains = this.contains(i.next());
			if(contains == false) return false;
		}
		return contains;
	}
	
	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		
		return itemCounter == 0;
	}
	
	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return new MyIterator(this);
	}
	
	protected class MyIterator implements Iterator<E>{
		private int currentPos = 0;
		private MySortedSet<E> mySortedSet;
		
		public MyIterator(MySortedSet<E> _mySortedSet) {
			// TODO Auto-generated constructor stub
			this.mySortedSet = _mySortedSet;
		}

		@Override
		public boolean hasNext() {
			// TODO Auto-generated method stub
			return currentPos < mySortedSet.size();
		}

		@Override
		public E next() {
			return mySortedSet.baseArray[currentPos++];
		}

		@Override
		public void remove() {
			// TODO Auto-generated method stub
			
		}
		
	}
	
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object object) {
		if(baseArray == null || baseArray.length == 0) return false;
		
		//Store the initial size, to be compared later to see if anything changed
		int initialSize = itemCounter;
		
		//Find where the object is
		int position = search((E)object);
		
		//If it doesn't exist, return false
		if(position == -1) return false;
		
		if(itemCounter == 1){
			baseArray[itemCounter - 1] = null;
			itemCounter--;
			return itemCounter < initialSize;
		}
		if(position == initialSize-1){
			baseArray[position] = baseArray[initialSize];
			baseArray[initialSize] = null;
			itemCounter--;
			return itemCounter < initialSize;
		}
		
		//Move everything down by one from the item we need to remove (just copy over it)
		for(int i = position; i<initialSize-1; i++){
			baseArray[i] = baseArray[i+1];
		}
		
		//"Remove" the last element, since it was just copied anyway
		baseArray[itemCounter - 1] = null;
		itemCounter--;
		
		//Return true only if the base array changed
		return itemCounter < initialSize;
	}
	
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		if(c == null) return false;
		int initialSize = itemCounter;
		//Iterate over each item in the collection to be removed
		Iterator<?> i = c.iterator();
		while(i.hasNext()){
			this.remove(i.next());
		}
		
		
		return initialSize < itemCounter;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return itemCounter;
	}
	
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order. Make sure to only return items that aren't null.
	 */
	@Override
	public Object[] toArray() {
		//If there's no array set, return an empty one
		if(baseArray == null || baseArray.length == 0) return new Object[]{};
		
		Object[] result = new Object[itemCounter];
		for(int i = 0; i<itemCounter; i++){
			result[i] = baseArray[i];
		}
		
		return result;
	}
	
	public Object[] getBaseArray() {
		return baseArray;
	}

	public void setBaseArray(E[] _baseArray) {
		this.baseArray = _baseArray;
	}
	
	public void setItem(E item, int position){
		this.baseArray[position] = item;
	}
	
	public void setItemCounter(int counter){
		this.itemCounter = counter;
	}

}
