package assignment3;

/**
 * TimingTestMySortedSet uses 3 timers for 3 methods of the 
 * MySortedSet class. It times the .add(), .contains(), and 
 * .remove() methods. Each test is ran a number of times and 
 * averaged out.
 * @author Ryan Fletcher, Richard Frost
 * 
 *
 */

public class TimingTestMySortedSet {

  public static void main(String[] args) {
    long startTime, midpointTime, stopTime;
    MySortedSet<Double> addDoubleTest = new MySortedSet<Double>();
    MySortedSet<Double> containsDoubleTest = new MySortedSet<Double>();
    MySortedSet<Double> removeDoubleTest = new MySortedSet<Double>();
    int elements = 200000;
    long timesToLoop = 10000;
    double random = 0;
    double averageTime = 0;

    /************************************************
	 * TEST THE .add() METHOD
	 *************************************************/

    /*
     * Runs the while loop for one second to allow the 
     * thread to stabilize.
     */
    for(double i = 0; i < elements; i++){
    	addDoubleTest.add(i);
    }
    startTime = System.nanoTime();
    while (System.nanoTime() - startTime < 1000000000) { // empty block
    }
    
    startTime = System.nanoTime();
    
    //Adds element number of random numbers to addDoubleTest, timesToLoop amount of times
    for (long i = 0; i < timesToLoop; i++){
    	random = (Math.random() * 100000);
        addDoubleTest.add(random);
   

    midpointTime = System.nanoTime();

    // Run an empty loop to capture the cost of running the loop.

    for (long j = 0; j < timesToLoop; j++) { // empty block
    }
    addDoubleTest.remove(random);

    stopTime = System.nanoTime();

    // Compute the time, subtract the cost of running the loop
    // from the cost of running the loop and computing square roots.
    // Average it over the number of runs.

    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime));
    }
    averageTime = averageTime / timesToLoop;

    System.out.println("It takes on average " + averageTime
        + " nanoseconds to add 1 random double element to a double array of 10000 elements.\n");
    
    /************************************************
	 * END OF TESTING FOR THE .add() METHOD
	 *************************************************/
    
    
    
    /************************************************
	 * TEST THE .contains() METHOD
	 *************************************************/
    
//    /*
//     * Runs the while loop for one second to allow the 
//     * thread to stabilize.
//     */
//    startTime = System.nanoTime();
//    while (System.nanoTime() - startTime < 1000000000) { // empty block
//    }
//
//    //adds element number of i's to containsDoubleTest
//    for(double i = 0; i < elements; i++)
//    	containsDoubleTest.add(i);
//
//    startTime = System.nanoTime();
//    
//    //Tests if containsDoubleTest contains each d
//    for (long i = 0; i < timesToLoop; i++)
//      for (int d = 1; d <= elements; d++)
//        containsDoubleTest.contains(d);
//    midpointTime = System.nanoTime();
//
//    // Run an empty loop to capture the cost of running the loop.
//
//    for (long i = 0; i < timesToLoop; i++) { // empty block
//    }
//
//    stopTime = System.nanoTime();
//
//    // Compute the time, subtract the cost of running the loop
//    // from the cost of running the loop and running .contains().
//    // Average it over the number of runs.
//
//   double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
//        / timesToLoop;
//
//    System.out.println("It takes on average " + averageTime
//        + " nanoseconds to run contains() on a sorted array of 10000 elements\n");
    
    /************************************************
	 * END OF TESTING FOR THE .contains() METHOD
	 *************************************************/
    
    
    
    /************************************************
	 * TEST THE .remove() METHOD
	 *************************************************/
    
//    /*
//     * Runs the while loop for one second to allow the 
//     * thread to stabilize.
//     */
//    
//    startTime = System.nanoTime();
//    while (System.nanoTime() - startTime < 1000000000) { // empty block
//    }
//
//    //adds element number of i's to containsDoubleTest
//    for(double i = 0; i < elements; i++)
//    	removeDoubleTest.add(i);
//
//    startTime = System.nanoTime();
//    
//    //Tests if containsDoubleTest contains each d
//    for (long i = 0; i < timesToLoop; i++)
//      for (int d = 1; d <= elements; d++)
//        removeDoubleTest.remove(d);
//    midpointTime = System.nanoTime();
//
//    // Run an empty loop to capture the cost of running the loop.
//
//    for (long i = 0; i < timesToLoop; i++) { // empty block
//    }
//
//    stopTime = System.nanoTime();
//
//    // Compute the time, subtract the cost of running the loop
//    // from the cost of running the loop and running .contains().
//    // Average it over the number of runs.
//
//    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
//        / timesToLoop;
//
//    System.out.println("It takes on average " + averageTime
//        + " nanoseconds to run remove() on a sorted array of 10000 elements\n");
//    
    /************************************************
	 * END OF TESTING FOR THE .remove() METHOD
	 *************************************************/
  }
  
  
  
  
  
  
}