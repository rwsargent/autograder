package assignment3;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import assignment2.LibraryBook;

public class TestMySortedSet {
	MySortedSet<String> myStringSortedSet;
	MySortedSet<Object> myEmptySet;
	MySortedSet<Integer> myIntSortedSet;
	MySortedSet<LibraryBook> myLibraryBookSortedSet;
	ArrayList<String> myStringTestCollection;
	ArrayList<Object> myEmptyTestCollection;
	ArrayList<Integer> myIntTestCollection;
	ArrayList<LibraryBook> myLibraryBookTestCollection;

	/**
	 * Unless otherwise stated, all of our arrays will be pre-sorted upon
	 * initialization.
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		myIntSortedSet = new MySortedSet<Integer>();
		myIntSortedSet.setBaseArray(new Integer[] { 2, 4, 6, 8, 10 });
		myIntSortedSet.setItemCounter(5);
		
		myStringSortedSet = new MySortedSet<String>();
		myStringSortedSet.setItem("Abraham Lincoln", 0);
		myStringSortedSet.setItem("Bob Dole", 1);
		myStringSortedSet.setItem("Carlton Cole", 2);
		myStringSortedSet.setItem("Dave Thomas", 3);
		myStringSortedSet.setItem("Ernest Hemingway", 4);
		myStringSortedSet.setItem("Fozzie Bear", 5);
		myStringSortedSet.setItem("George Washington", 6);
		myStringSortedSet.setItem("Hillary Clinton", 7);
		myStringSortedSet.setItem("Ignacio Santana", 8);
		myStringSortedSet.setItemCounter(9);
		
		// Library book sorted set sorted by ISBN
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbn());
		myLibraryBookSortedSet.add(new LibraryBook(9780330351690L, "Jon Krakauer",
				"Into the Wild"));
		myLibraryBookSortedSet.add(new LibraryBook(9780374292799L, "Thomas L. Friedman",
								"The World is Flat"));
		myLibraryBookSortedSet.add(new LibraryBook(9780446580342L, "David Baldacci",
								"Simple Genius"));
		
		myLibraryBookSortedSet.setItemCounter(3);
		
		myEmptySet = new MySortedSet<Object>();
		
		myStringTestCollection = new ArrayList<String>();
		myStringTestCollection.add("Javier");
		myStringTestCollection.add("Mike");
		myStringTestCollection.add("Susan");
		myStringTestCollection.add("Bob");
		myStringTestCollection.add("Sally");
		
		myEmptyTestCollection = new ArrayList<Object>();
		
		myIntTestCollection = new ArrayList<Integer>();
		myIntTestCollection.add(2);
		myIntTestCollection.add(12);
		myIntTestCollection.add(21);
		myIntTestCollection.add(32);
		myIntTestCollection.add(23);
		myIntTestCollection.add(4);
		
		myLibraryBookTestCollection = new ArrayList<LibraryBook>();
		myLibraryBookTestCollection.add(new LibraryBook(9990446333123L, "Martha Stewart", "My Life"));
		myLibraryBookTestCollection.add(new LibraryBook(9990446333456L, "Mary Swanson", "The Best Book"));
		myLibraryBookTestCollection.add(new LibraryBook(8880446333789L, "Ronald Schneider", "How to Use Your Computer"));
		myLibraryBookTestCollection.add(new LibraryBook(7770446333987L, "James Madison", "Why Animals Taste Great"));
		myLibraryBookTestCollection.add(new LibraryBook(6660446333654L, "Deepok Chopra", "But Vegans can be Cool too"));
	}

	@After
	public void tearDown() throws Exception {
		myIntSortedSet = null;
		myStringSortedSet = null;
		myLibraryBookSortedSet = null;
		myEmptySet = null;
	}

	/************************************************
	 * TEST THE .first() METHOD
	 *************************************************/

	/**
	 * Tests to make sure we return the first string in the set
	 */
	@Test
	public void testFirstString() {
		assertEquals("Abraham Lincoln", myStringSortedSet.first());
	}

	/**
	 * Make sure it throws a NoSuchElementException when there is no first item
	 */
	@Test(expected = NoSuchElementException.class)
	public void testFirstNullException() {
		myEmptySet.first();
	}

	/**
	 * Test that the first item is the right int
	 */
	@Test
	public void testFirstInt() {
		int i = myIntSortedSet.first();
		assertEquals(2, i);
	}

	/**
	 * Tests to make sure the right book is first
	 */
	@Test
	public void testFirstLibraryBook() {
		LibraryBook first = new LibraryBook(9780330351690L, "Jon Krakauer",
				"Into the Wild");
		assertEquals(first, myLibraryBookSortedSet.first());
	}
	/************************************************
	 * END TESTING FOR THE .first() METHOD
	 *************************************************/

	/************************************************
	 * TEST THE .last() METHOD
	 *************************************************/

	/**
	 * Tests to make sure we return the last string in the set
	 */
	@Test
	public void testLastString() {
		assertEquals("Ignacio Santana", myStringSortedSet.last());
	}

	/**
	 * Make sure it throws a NoSuchElementException when there is no last item
	 */
	@Test(expected = NoSuchElementException.class)
	public void testLastNullException() {
		myEmptySet.last();
	}

	/**
	 * Test that the last item is the right int
	 */
	@Test
	public void testLastInt() {
		int i = myIntSortedSet.last();
		assertEquals(10, i);
	}

	/**
	 * Tests to make sure the right book is last
	 */
	@Test
	public void testLastLibraryBook() {
		LibraryBook myLibraryBook = new LibraryBook(9780446580342L, "David Baldacci",
				"Simple Genius");
		assertEquals(myLibraryBook, myLibraryBookSortedSet.last());
	}

	/************************************************
	 * END TESTING FOR THE .last() METHOD
	 *************************************************/

	
	
	/************************************************
	 * TEST THE .add() METHOD
	 *************************************************/
	/**
	 * See if we can add two different types to a collection if
	 * they extend the same class but are not the same type
	 */
	@Test
	public void testAddMismatchedTypes(){
		//First let's add a string
		myEmptySet.add("Hey there");
		//Make sure it can't add a library book
		assertFalse(myEmptySet.add(new LibraryBook(123456789L, "Jemimah", "My Story")));
	}
	/**
	 * Make sure we can add a string ot our string set
	 */
	@Test
	public void testAddString() {
		assertEquals(true, myStringSortedSet.add("Madonna"));
	}

	/**
	 * Make sure we can add an int to our int set
	 */
	@Test
	public void testAddInt() {
		assertEquals(true, myIntSortedSet.add(15));
	}

	/**
	 * Test that we can add a LibraryBook
	 */
	@Test
	public void testAddLibraryBook() {
		assertEquals(true, myLibraryBookSortedSet.add(new LibraryBook(9780330351633L, "James Taylor",
				"Autobiography")));
	}

	/**
	 * Make sure it returns false when we add nothing to an empty set 
	 */
	@Test
	public void testAddNullToEmptySet() {
		assertEquals(false, myEmptySet.add(null));
	}
	
	/**
	 * Make sure it returns false when we add nothing to a regular set
	 */
	@Test
	public void testAddNullToNormalSet(){
		assertEquals(false, myStringSortedSet.add(null));
	}

	/**
	 * Make sure what we're adding doesn't already exist
	 */
	@Test
	public void testAddIntWhenAlreadyExists() {
		assertEquals(false, myIntSortedSet.add(4));
	}

	/**
	 * Make sure what we're adding doesn't already exist
	 */
	@Test
	public void testAddStringWhenAlreadyExists() {
		assertEquals(false, myStringSortedSet.add("Abraham Lincoln"));
	}

	/**
	 * Make sure what we're adding doesn't already exist
	 */
	@Test
	public void testAddLibraryBookWhenAlreadyExists() {
		assertEquals(false, myLibraryBookSortedSet.add(new LibraryBook(9780374292799L, "Thomas L. Friedman",
								"The World is Flat")));
	}

	/**
	 * Make sure what we add ends up in the right place
	 */
	@Test
	public void testAddIntInTheRightPlace() {
		// First, add an int to our sorted set
		myIntSortedSet.add(5);
		
		//Make sure the item we want is at index 2
		assertEquals(2, myIntSortedSet.search(5));
	}

	/**
	 * Make sure what we add ends up in the right place
	 */
	@Test
	public void testAddStringInTheRightPlace() {
		// First, add a string to our sorted set
		myStringSortedSet.add("Cary Grant");

		// Get the array back so we can see the whole thing and search manually
		Object[] array = myStringSortedSet.getBaseArray();

		// Loop through the array until we get the index of the item we just
		// inserted
		int i = 0;
		for (i = 0; i < array.length; i++) {
			if (array[i].equals("Cary Grant"))
				break;
		}
		
		//Make sure the item we want is at index 3
		assertEquals(3, i);
	}

	/**
	 * Make sure what we add ends up in the right place
	 */
	@Test
	public void testAddLibraryBookInTheRightPlace() {
		//First, add an int to our sorted set
		LibraryBook myLibraryBook = new LibraryBook(9780330351691L, "Rework", "Jason Hannemer");
		myLibraryBookSortedSet.add(myLibraryBook);

		
		//Make sure our library book is at index 1
		assertEquals(true, myLibraryBookSortedSet.contains(myLibraryBook) && myLibraryBookSortedSet.search(myLibraryBook) == 1);
	}
	/************************************************
	 * END TESTING FOR THE .add() METHOD
	 *************************************************/

	
	
	
	/************************************************
	 * TEST THE .addAll() METHOD
	 *************************************************/
	/**
	 * Add a collection of ints
	 */
	@Test
	public void testAddAllInt(){
		assertTrue(myIntSortedSet.addAll(myIntTestCollection));
	}
	
	/**
	 * Add a collection of strings
	 */
	@Test
	public void testAddAllString(){
		assertTrue(myStringSortedSet.addAll(myStringTestCollection));
	}
	
	/**
	 * Add a collection of library books
	 */
	@Test
	public void testAddAllLibraryBook(){
		assertTrue(myLibraryBookSortedSet.addAll(myLibraryBookTestCollection));
	}
	
	/**
	 * Make sure it returns false when we add a null collection
	 */
	@Test
	public void testAddAllNull(){
		myEmptyTestCollection = null;
		assertFalse(myEmptySet.addAll(myEmptyTestCollection));
	}
	
	/**
	 * Make sure it returns false when we add an empty collection
	 */
	@Test
	public void testAddAllEmptyCollection(){
		assertFalse(myEmptySet.addAll(myEmptyTestCollection));
	}
	
	/**
	 * Try to add a collection with some duplicates in the target sorted set
	 * Should return true, as long as the set has changed
	 */
	@Test
	public void testAddAllSomeDuplicates(){
		assertTrue(myIntSortedSet.addAll(myIntTestCollection));
	}
	
	/**
	 * Try to add a collection when all items we are trying to add are already in the sorted set
	 * Should return false, since the collection will not have changed
	 */
	@Test
	public void testAddAllDuplicates(){
		ArrayList<Integer> allDuplicates = new ArrayList<Integer>();
		allDuplicates.add(2);
		allDuplicates.add(4);
		allDuplicates.add(6);
		allDuplicates.add(8);
		allDuplicates.add(10);
		assertFalse(myIntSortedSet.addAll(allDuplicates));
	}
	
	/**
	 * Make sure adding to an empty set returns true
	 */
	@Test
	public void testAddToEmptySet(){
		assertTrue(myEmptySet.add("Hey there"));
	}
	
	/**
	 * Test to make sure that it returns false when adding two 
	 * mismatched types
	 */
	@Test
	public void testAddAllMismatchedTypes(){
		//Add some strings first
		myEmptySet.addAll(myStringTestCollection);
		
		//Make sure it returns false if we try to add a colllection of a different type
		assertFalse(myEmptySet.addAll(myLibraryBookTestCollection));
	}
	/************************************************
	 * END TESTING FOR THE .addAll() METHOD
	 *************************************************/

	
	
	/************************************************
	 * TEST THE .clear() METHOD
	 *************************************************/
	/**
	 * Test clearing the sorted set with primitive types
	 */
	@Test
	public void testClearInt(){
		myIntSortedSet.clear();
		assertEquals(0, myIntSortedSet.size());
	}
	
	/**
	 * Test clearing the sorted set of strings
	 */
	@Test
	public void testClearString(){
		myStringSortedSet.clear();
		assertEquals(0, myStringSortedSet.size());
	}
	
	/**
	 * Test clearing the sorted set of reference types
	 */
	@Test
	public void testClearLibraryBook(){
		myLibraryBookSortedSet.clear();
		assertEquals(0, myLibraryBookSortedSet.size());
	}
	
	/**
	 * Test clearing an empty sorted set
	 */
	@Test
	public void testEmptySortedSet(){
		myIntSortedSet.setBaseArray(new Integer[]{});
		myIntSortedSet.clear();
		assertEquals(0, myIntSortedSet.size());
	}
	/************************************************
	 * END TESTING FOR THE .clear() METHOD
	 *************************************************/

	
	
	
	/************************************************
	 * TEST THE .contains() METHOD
	 *************************************************/
	/**
	 * Test .contains() for primitive type sorted set
	 */
	@Test
	public void testContainsInt(){
		assertEquals(true, myIntSortedSet.contains(2));
	}
	
	/**
	 * Test .contains() for string type sorted set
	 */
	@Test
	public void testContainsString(){
		assertEquals(true , myStringSortedSet.contains("Abraham Lincoln"));
	}
	
	/**
	 * Test .contains() for reference types
	 */
	@Test
	public void testContainsLibraryBook(){
		LibraryBook myLibraryBook = new LibraryBook(9780374292799L, "Thomas L. Friedman",
				"The World is Flat");
		assertEquals(true, myLibraryBookSortedSet.contains(myLibraryBook));
	}
	
	/**
	 * Test .contains() for empty sorted set
	 */
	@Test
	public void testContainsEmptySet(){
		myIntSortedSet.setBaseArray(new Integer[]{});
		myIntSortedSet.setItemCounter(0);
		assertEquals(false, myIntSortedSet.contains(2));
	}
	
	/**
	 * Test .contains() for mismatched types:
	 * Look for primitive in a reference type sorted set 
	 */
	@Test
	public void testContainsIntInRef(){
		assertEquals(false, myLibraryBookSortedSet.contains(1));
	}
	
	/**
	 * Test .contains() for mismatched types:
	 * Look for reference type in a primitive type sorted set 
	 */
	@Test
	public void testContainsRefInInt(){
		LibraryBook myLibraryBook = new LibraryBook(9780374292799L, "Thomas L. Friedman",
				"The World is Flat");
		assertEquals(false, myIntSortedSet.contains(myLibraryBook));
	}
	
	/**
	 * Test .contains() for mismatched types:
	 * Look for String in primitive type sorted set
	 */
	@Test
	public void testContainsStringInInt(){
		assertEquals(false, myIntSortedSet.contains("Hey humdinger"));
	}
	
	/**
	 * Test .contains for mismatched types:
	 * Look for primitive type in String sorted set
	 */
	@Test
	public void testContainsIntInString(){
		assertEquals(false, myStringSortedSet.contains(2));
	}
	/************************************************
	 * END TESTING FOR THE .contains() METHOD
	 *************************************************/

	
	
	
	/************************************************
	 * TEST THE .containsAll() METHOD
	 *************************************************/
	/**
	 * Test to make sure the type we're searching on is the same as
	 * the type in our sorted set
	 */
	@Test
	public void testContainsAllSameType(){
		ArrayList<Integer> c = new ArrayList<Integer>();
		c.add(2);
		c.add(4);
		c.add(6);
		assertTrue(myIntSortedSet.containsAll(c));
	}
	
	/**
	 * Test to make sure it returns false if we pass in a collection
	 * that's bigger than our sorted set 
	 */
	@Test
	public void testContainsAllTooBig(){
		ArrayList<Integer> c = new ArrayList<Integer>();
		c.add(2);
		c.add(4);
		c.add(6);
		c.add(8);
		c.add(10);
		c.add(12);
		assertFalse(myIntSortedSet.containsAll(c));
	}
	
	/**
	 * Test to make sure it returns false if we pass in a null collection
	 */
	@Test
	public void testContainsAllNullCollection(){
		ArrayList<Integer> list = null;
		assertFalse(myIntSortedSet.containsAll(list));
	}
	
	/**
	 * Test to make sure it returns false if we pass in an empty collection
	 */
	@Test
	public void testContainsAllEmptyCollection(){
		ArrayList<Integer> list = new ArrayList<Integer>();
		assertFalse(myIntSortedSet.containsAll(list));
	}
	
	/**
	 * Test to make sure it can handle the .containsAll() when we pass in
	 * a collection that isn't sorted
	 */
	@Test
	public void testContainsAllNotSorted(){
		ArrayList<Integer> myList = new ArrayList<Integer>();
		myList.add(10);
		myList.add(6);
		myList.add(8);
		assertTrue(myIntSortedSet.containsAll(myList));
	}
	
	/**
	 * Test .containsAll() when there are mismatched types
	 * (should return false)
	 */
	@Test
	public void testContainsAllMismatchedTypes(){
		assertFalse(myLibraryBookSortedSet.containsAll(myIntTestCollection));
	}
	/************************************************
	 * END TESTING FOR THE .containsAll() METHOD
	 *************************************************/

	
	
	
	/************************************************
	 * TEST THE .isEmpty() METHOD
	 *************************************************/
	/**
	 * Test .isEmpty() for no elements
	 */
	@Test
	public void testIsEmptyRegular(){
		myIntSortedSet.setBaseArray(new Integer[]{});
		myIntSortedSet.setItemCounter(0);
		assertEquals(true, myIntSortedSet.isEmpty());
	}
	
	/**
	 * Test .isEmpty() for some elements
	 */
	@Test
	public void testIsEmpty(){
		assertEquals(false, myIntSortedSet.isEmpty());
	}
	/************************************************
	 * END TESTING FOR THE .isEmpty() METHOD
	 *************************************************/

	
	
	
	/************************************************
	 * TEST THE .iterator() METHOD
	 *************************************************/
	/**
	 * Test to make sure .iterator() returns an actual iterator
	 */
	@Test
	public void testIterator(){
		assertEquals(true, (myIntSortedSet.iterator() instanceof Iterator));
	}
	/************************************************
	 * END TESTING FOR THE .iterator() METHOD
	 *************************************************/

	
	
	
	
	/************************************************
	 * TEST THE .remove() METHOD
	 *************************************************/
	/**
	 * Test .remove() for normal case (same type, item exists)
	 */
	@Test
	public void testRemoveRegular(){
		assertEquals(true, myIntSortedSet.remove(2));
	}
	
	/**
	 * Test .remove() for ref types that don't implement Comparable
	 */
	@Test
	public void testRemoveLibraryBook(){
		assertEquals(true, myLibraryBookSortedSet.remove(new LibraryBook(9780446580342L, "David Baldacci",
				"Simple Genius")));
	}
	
	/**
	 * Test .remove() when same type, item doesn't exist
	 */
	@Test
	public void testRemoveItemDoesntExist(){
		assertEquals(false, myIntSortedSet.remove(253));
	}
	
	/**
	 * Test .remove() when types are mismatched
	 */
	@Test
	public void testRemoveMismatchedTypes(){
		assertEquals(false, myIntSortedSet.remove("Harriet Tubman"));
	}
	
	/**
	 * Test .remove() when we pass in null
	 */
	@Test
	public void testRemoveWhenItemIsNull(){
		assertEquals(false, myIntSortedSet.remove(null));
	}
	
	/**
	 * Test .remove() on an null set
	 */
	@Test
	public void testRemoveOnNullSet(){
		myIntSortedSet.setBaseArray(null);
		assertEquals(false, myIntSortedSet.remove(4));
	}
	
	/**
	 * Test .remove() on an empty set
	 */
	@Test
	public void testRemoveOnEmptySet(){
		myIntSortedSet.setBaseArray(new Integer[]{});
		assertEquals(false,  myIntSortedSet.remove(2));
	}
	/************************************************
	 * END TESTING FOR THE .remove() METHOD
	 *************************************************/

	
	
	
	
	/************************************************
	 * TEST THE .removeAll() METHOD
	 *************************************************/
	/**
	 * Remove a collection of ints
	 */
	@Test
	public void testRemoveAllInt(){
		ArrayList<Integer> compareSet = new ArrayList<Integer>();
		compareSet.add(2);
		compareSet.add(4);
		compareSet.add(6);
		compareSet.add(8);
		myIntSortedSet.removeAll(compareSet);
		
		//Make sure there's only one item left, and that it's 10
		assertEquals(true, myIntSortedSet.first().equals(10) && myIntSortedSet.size() == 1);
	}
	
	/**
	 * Remove a collection of strings
	 */
	@Test
	public void testRemoveAllString(){
		ArrayList<String> toRemove = new ArrayList<String>();
		toRemove.add("Abraham Lincoln");
		toRemove.add("Bob Dole");
		toRemove.add("Carlton Cole");
		toRemove.add("George Washington");
		toRemove.add("Dave Thomas");
		toRemove.add("Hillary Clinton");
		toRemove.add("Fozzie Bear");
		toRemove.add("Ignacio Santana");
		
		myStringSortedSet.removeAll(toRemove);
		
		assertEquals(true, myStringSortedSet.size() == 1 && myStringSortedSet.contains("Ernest Hemingway"));
	}
	
	/**
	 * Make sure it returns false when we remove a null collection
	 */
	@Test
	public void testRemoveAllNull(){
		assertFalse(myIntSortedSet.removeAll(null));
	}
	
	/**
	 * Make sure it returns false when we remove an empty collection
	 */
	@Test
	public void testRemoveAllEmptyCollection(){
		assertFalse(myEmptySet.removeAll(myEmptyTestCollection));
	}
	
	/**
	 * Make sure removing from an empty set returns false
	 */
	@Test
	public void testRemoveFromEmptySet(){
		assertFalse(myEmptySet.removeAll(myStringTestCollection));
	}
	/************************************************
	 * END TESTING FOR THE .removeAll() METHOD
	 *************************************************/

	
	
	
	/************************************************
	 * TEST THE .size() METHOD
	 *************************************************/
	/**
	 * Get the size of a normal set
	 */
	@Test
	public void testSizeRegular(){
		assertEquals(5, myIntSortedSet.size());
	}
	
	/**
	 * Get the size of a null set
	 */
	@Test
	public void testSizeNullSet(){
		myIntSortedSet.setBaseArray(null);
		myIntSortedSet.setItemCounter(0);
		assertEquals(0, myIntSortedSet.size());
	}
	
	/**
	 * Get the size of an empty set
	 */
	@Test
	public void testSizeEmptySet(){
		myIntSortedSet.setBaseArray(new Integer[]{});
		myIntSortedSet.setItemCounter(0);
		assertEquals(0,  myIntSortedSet.size());
	}
	/************************************************
	 * END TESTING FOR THE .size() METHOD
	 *************************************************/

	
	
	
	/************************************************
	 * TEST THE .toArray() METHOD
	 *************************************************/
	/**
	 * Test .toArray() for a normal, working case (sorted)
	 */
	@Test
	public void testToArray(){
		Integer[] myInt = new Integer[]{2, 4, 6, 8, 10};
		assertArrayEquals(myInt, myIntSortedSet.toArray());
	}
	
	/**
	 * Test .toArray() on a null set
	 */
	@Test
	public void testToArrayNullSet(){
		Integer[] myInt = new Integer[]{};
		myIntSortedSet.setBaseArray(null);
		assertArrayEquals(myInt, myIntSortedSet.toArray());
	}
	
	/**
	 * Test .toArray() on an empty set
	 */
	@Test
	public void testToArrayEmptySet(){
		Integer[] myInt = new Integer[]{};
		myIntSortedSet.setBaseArray(new Integer[]{});
		assertArrayEquals(myInt, myIntSortedSet.toArray());
	}
	
	/**
	 * Test .toArray() to make sure it's sorted in ascending order
	 */
	@Test
	public void testToArrayAscendingOrder(){
		Integer[] myInt = new Integer[]{10, 8, 6, 4, 2};
		assertNotEquals(myInt, myIntSortedSet.toArray());
	}
	/************************************************
	 * END TESTING FOR THE .toArray() METHOD
	 *************************************************/

	
	/************************************************
	 * TEST THE .search() METHOD
	 *************************************************/
	@Test
	public void testSearch(){
		Integer[] base = new Integer[100];
		for(int i = 0; i<100; i++){
			base[i] = i;
		}
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.setBaseArray(base);
		
		intSet.search(75);
	}
	/************************************************
	 * END TESTING FOR THE .search() METHOD
	 *************************************************/
	

	/************************************************
	 * TEST A FEW BOUNDARY CASES
	 *************************************************/
	@Test
	public void testResizeArray(){
		ArrayList<Integer> integers = new ArrayList<Integer>();
		for(int i = 0; i<50; i++){
			integers.add(i);
		}
		myIntSortedSet.addAll(integers);
		assertEquals(50, myIntSortedSet.size());
	}
	/************************************************
	 * END TESTING BOUNDARY CASES
	 *************************************************/
	
	/************************************************
	 * TEST SOME COMPARATOR CASES
	 *************************************************/
	
	/**
	 * Should return size 3 if all three books were added
	 */
	@Test
	public void testAddLibraryBookWithComparator(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbn());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		assertEquals(3, myLibraryBookSortedSet.size());
	}
	
	/**
	 * Should return size 3 if all three books were added
	 */
	@Test
	public void testAddLibraryBookWithComparatorReverse(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbnReverse());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		assertEquals(3, myLibraryBookSortedSet.size());
	}
	
	/**
	 * Should return the first item, by ISBN
	 */
	@Test
	public void testLibraryBookFirstISBN(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbn());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		
		LibraryBook actual = myLibraryBookSortedSet.first();
		LibraryBook expected = new LibraryBook(1234567880L, "Thomas Jones", "My Book");
		assertEquals(expected, actual);
	}
	
	/**
	 * Should return the last item, by ISBN
	 */
	@Test
	public void testLibraryBookLastReverseISBN(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbnReverse());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		
		LibraryBook actual = myLibraryBookSortedSet.last();
		LibraryBook expected = new LibraryBook(1234567880L, "Thomas Jones", "My Book");
		assertEquals(expected, actual);
	}
	
	/**
	 * Should return the first item, by author
	 */
	@Test
	public void testLibraryBookFirstAuthor(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByAuthor());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		
		LibraryBook actual = myLibraryBookSortedSet.first();
		LibraryBook expected = new LibraryBook(1234567892L, "James Smith", "The New Story");
		assertEquals(expected, actual);
	}
	
	/**
	 * Should return the last item, by Author in reverse
	 */
	@Test
	public void testLibraryBookLastReverseAuthor(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByAuthorReverse());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		
		LibraryBook actual = myLibraryBookSortedSet.last();
		LibraryBook expected = new LibraryBook(1234567892L, "James Smith", "The New Story");
		assertEquals(expected, actual);
	}
	/**
	 * Should return true that it contains a certain book
	 */
	@Test
	public void testContainsLibraryBookWithISBNComparator(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbn());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		assertTrue(myLibraryBookSortedSet.contains(new LibraryBook(1234567880L, "Thomas Jones", "My Book")));
	}
	
	/**
	 * Should return true that it contains a certain book
	 */
	@Test
	public void testContainsLibraryBookWithAuthorComparator(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByAuthor());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		assertTrue(myLibraryBookSortedSet.contains(new LibraryBook(1234567892L, "James Smith", "The New Story")));
		
	}
	
	/**
	 * Should return true that it removed a certain book
	 */
	@Test
	public void testRemoveLibraryBookWithISBNComparator(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbn());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		assertTrue(myLibraryBookSortedSet.remove(new LibraryBook(1234567880L, "Thomas Jones", "My Book")));
	}
	
	/**
	 * Should return true that it removed a certain book
	 */
	@Test
	public void testRemoveLibraryBookWithAuthorComparator(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByAuthor());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
		assertTrue(myLibraryBookSortedSet.remove(new LibraryBook(1234567892L, "James Smith", "The New Story")));
	}
	
	/**
	 * Should return true if the myLibraryBookTestCollection was added to myLibraryBookSortedSet
	 */
	@Test
	public void testAddAllLibraryBookFirstISBN(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbn());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
			
		myLibraryBookTestCollection.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
			
		assertTrue(myLibraryBookSortedSet.addAll(myLibraryBookTestCollection));
		}
	
	/**
	 * Should return true if the myLibraryBookTestCollection is contained in myLibraryBookSortedSet
	 */
	@Test
	public void testContainsAllLibraryBookFirstISBN(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbn());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
			
		myLibraryBookTestCollection = new ArrayList<LibraryBook>();
		myLibraryBookTestCollection.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookTestCollection.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookTestCollection.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
			
		assertTrue(myLibraryBookSortedSet.containsAll(myLibraryBookTestCollection));
		}
	
	/**
	 * Should return true if the myLibraryBookTestCollection is removed from myLibraryBookSortedSet
	 */
	@Test
	public void testremovesAllLibraryBookFirstISBN(){
		myLibraryBookSortedSet = new MySortedSet<LibraryBook>(new OrderByIsbn());
		myLibraryBookSortedSet.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookSortedSet.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
			
		myLibraryBookTestCollection = new ArrayList<LibraryBook>();
		myLibraryBookTestCollection.add(new LibraryBook(1234567880L, "Thomas Jones", "My Book"));
		myLibraryBookTestCollection.add(new LibraryBook(1234567892L, "James Smith", "The New Story"));
		myLibraryBookTestCollection.add(new LibraryBook(1234567891L, "Riley Waller", "Highlander"));
			
		myLibraryBookSortedSet.removeAll(myLibraryBookTestCollection);
		assertEquals(0, myLibraryBookSortedSet.size());
		}
	
	/************************************************
	 * END TESTING OF SOME COMPARATOR CASES
	 *************************************************/

	/**
	 * Make a comparator to order by ISBN
	 *
	 */
	protected class OrderByIsbn implements Comparator<LibraryBook>{
		@Override
		public int compare(LibraryBook lhs, LibraryBook rhs) {
			return (int) (lhs.getIsbn() - rhs.getIsbn());
		}
	}
	
	/**
	 * Order by ISBN in reverse
	 *
	 */
	protected class OrderByIsbnReverse implements Comparator<LibraryBook>{
		@Override
		public int compare(LibraryBook lhs, LibraryBook rhs){
			return (int) (rhs.getIsbn() - lhs.getIsbn());
		}
	}
	
	/**
	 * Order by Author
	 *
	 */
	protected class OrderByAuthor implements Comparator<LibraryBook>{
		@Override
		public int compare(LibraryBook lhs, LibraryBook rhs) {
			return lhs.getAuthor().compareTo(rhs.getAuthor());
		}
		
	}
	
	/**
	 * Order by Author in reverse
	 *
	 */
	protected class OrderByAuthorReverse implements Comparator<LibraryBook>{
		@Override
		public int compare(LibraryBook lhs, LibraryBook rhs) {
			return rhs.getAuthor().compareTo(lhs.getAuthor());
		}
		
	}
}
