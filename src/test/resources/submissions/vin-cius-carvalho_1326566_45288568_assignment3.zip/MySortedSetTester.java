package assignment3;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

/**
 * Unit tests class for MySortedSet<E>
 * 
 * @author Filipe Wesley - u0957355
 * @author Vinicius Carvalho - u0973889
 */
public class MySortedSetTester {

	private static String[] strings1;
	private static String[] strings2;
	private String[] alphabet;

	private static Integer[] ints1;
	private static Integer[] ints2;
	private Integer[] intsToOneHundred;

	MySortedSet<String> sortedSetString1;
	MySortedSet<String> sortedSetString2;
	MySortedSet<Integer> sortedSetInt;
	MySortedSet<Integer> sortedSetInt2;

	@Before
	public void start() {
		sortedSetString1 = new MySortedSet<String>();
		sortedSetString2 = new MySortedSet<String>();
		strings1 = new String[] { "test1", "test2", "test3", "test4", "test5",
				"test6", "test7" };
		strings2 = new String[] { "avocado", "filipe", "test1", "test2",
				"test3", "test4", "test5", "test6", "test7", "utah", "vinicius" };
		alphabet = new String[] { "a", "b", "c", "d", "e", "f", "g", "h", "i",
				"j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u",
				"v", "w", "x", "y", "z" };

		for (int i = 1; i < 8; i++) {
			sortedSetString1.add("test" + i);
		}

		sortedSetInt = new MySortedSet<Integer>();
		sortedSetInt2 = new MySortedSet<Integer>();
		ints1 = new Integer[] { 0, 1, 2, 3, 4, 5, 6, 7 };
		ints2 = new Integer[] { -5, 0, 1, 2, 3, 4, 5, 6, 7, 9, 10, 15 };
		intsToOneHundred = new Integer[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
				11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
				27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
				43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58,
				59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74,
				75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
				91, 92, 93, 94, 95, 96, 97, 98, 99, 100 };

		for (int i = 0; i < 8; i++) {
			sortedSetInt.add(i);
		}
	}

	@Test
	public void testFirstString() {
		// Tests the first() method for a SortedSet<String>
		assertEquals("test1", sortedSetString1.first());
	}

	@Test
	public void testLastString() {
		// Tests the last() method for a SortedSet<String>
		assertEquals("test7", sortedSetString1.last());
	}

	@Test
	public void testFailString() {
		// Tests the failure for the first() and last() methods for a SortedSet<String>
		try {
			sortedSetString2.first();
			fail("Should throw: NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertTrue(true);
		}
		try {
			sortedSetString2.last();
			fail("Should throw: NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testFirstInt() {
		// Tests the first() method for a SortedSet<Integer>
		assertEquals(new Integer(0), sortedSetInt.first());
	}
	
	@Test
	public void testLastInt() {
		// Tests the last() method for a SortedSet<Integer>
		assertEquals(new Integer(7), sortedSetInt.last());
	}

	@Test
	public void testFailInt() {
		// Tests the failure for the first() and last() methods for a SortedSet<Integer>
		try {
			sortedSetInt2.first();
			fail("Should throw: NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertTrue(true);
		}
		try {
			sortedSetInt2.last();
			fail("Should throw: NoSuchElementException");
		} catch (NoSuchElementException e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testAddAndToArrayString() {
		// Tests the add() and the toArray() methods for a SortedSet<String>
		assertArrayEquals(strings1, sortedSetString1.toArray());
	}

	@Test
	public void testAddStringUnordered() {
		// Tests the add() method for a SortedSet<String> adding unordered
		// values
		sortedSetString1.add("utah");
		sortedSetString1.add("avocado");
		sortedSetString1.add("filipe");
		sortedSetString1.add("vinicius");
		assertArrayEquals(strings2, sortedSetString1.toArray());
	}

	@Test
	public void testAddStringsDuplicate() {
		// Tests the add() method for a SortedSet<String> adding unordered
		// values
		// and duplicates
		for (int i = 1; i < 8; i++) {
			sortedSetString1.add("test" + i);
		}
		sortedSetString1.add("utah");
		sortedSetString1.add("vinicius");
		sortedSetString1.add("filipe");
		sortedSetString1.add("avocado");
		sortedSetString1.add("filipe");
		sortedSetString1.add("utah");
		sortedSetString1.add("vinicius");
		sortedSetString1.add("avocado");
		assertArrayEquals(strings2, sortedSetString1.toArray());
	}

	@Test
	public void testAddAllStrings() {
		// Tests the addAll() method for a SortedSet<String>
		String[] alphabetUnordered = new String[] { "d", "b", "c", "r", "o",
				"g", "w", "i", "j", "k", "e", "l", "s", "n", "f", "t", "u",
				"v", "p", "h", "x", "m", "y", "a", "z", "q" };
		ArrayList<String> alphabetCollection = new ArrayList<String>(
				Arrays.asList(alphabetUnordered));
		sortedSetString2.addAll(alphabetCollection);
		assertArrayEquals(alphabet, sortedSetString2.toArray());
	}

	@Test
	public void testAddAndToArrayInt() {
		// Tests the add() and the toArray() methods for a SortedSet<Integer>
		assertArrayEquals(ints1, sortedSetInt.toArray());
	}

	@Test
	public void testAddIntUnordered() {
		// Tests the add() method for a SortedSet<Integer> adding unordered
		// values
		sortedSetInt.add(15);
		sortedSetInt.add(-5);
		sortedSetInt.add(10);
		sortedSetInt.add(9);
		assertArrayEquals(ints2, sortedSetInt.toArray());
	}

	@Test
	public void testAddIntUnorderedDuplicates() {
		// Tests the add() method for a SortedSet<Integer> adding unordered
		// values
		// and duplicates
		for (int i = 0; i < 8; i++) {
			sortedSetInt.add(i);
		}
		sortedSetInt.add(15);
		sortedSetInt.add(-5);
		sortedSetInt.add(10);
		sortedSetInt.add(15);
		sortedSetInt.add(9);
		sortedSetInt.add(10);
		sortedSetInt.add(9);
		sortedSetInt.add(-5);
		assertArrayEquals(ints2, sortedSetInt.toArray());
	}

	@Test
	public void testAddAllInts() {
		// Tests the addAll() method for a SortedSet<Integer>
		ArrayList<Integer> intsToOneHundredCollection = new ArrayList<Integer>(
				Arrays.asList(intsToOneHundred));
		sortedSetInt.addAll(intsToOneHundredCollection);
		assertArrayEquals(intsToOneHundred, sortedSetInt.toArray());
	}

	@Test
	public void testClearString() {
		// Tests the clear() method for a SortedSet<String>
		sortedSetString1.clear();
		assertArrayEquals(new String[] {}, sortedSetString1.toArray());
	}

	@Test
	public void testClearInt() {
		// Tests the clear() method for a SortedSet<Integer>
		sortedSetInt.clear();
		assertArrayEquals(new Integer[] {}, sortedSetInt.toArray());
	}

	@Test
	public void testContainsString() {
		// Tests the contains() method for a SortedSet<String>
		assertTrue(sortedSetString1.contains("test1"));
	}

	@Test
	public void testContainsInt() {
		// Tests the contains() method for a SortedSet<Integer>
		assertTrue(sortedSetInt.contains(new Integer(5)));
	}

	@Test
	public void testIsEmptyInt() {
		// Tests the isEmpty() method for a SortedSet<Integer>
		sortedSetInt.clear();
		assertTrue(sortedSetInt.isEmpty());
	}

	@Test
	public void testIsEmptyString() {
		// Tests the isEmpty() method for a SortedSet<String>
		sortedSetString1.clear();
		assertTrue(sortedSetString1.isEmpty());
	}

	@Test
	public void testIteratorString() {
		// Tests the iterator() method for a SortedSet<String>
		java.util.Iterator<String> i = sortedSetString1.iterator();
		for (int j = 1; j < 8; j++) {
			assertTrue(i.hasNext());
			assertEquals("test" + j, i.next());
		}
		assertFalse(i.hasNext());
		i = sortedSetString1.iterator();
		while (i.hasNext()) {
			i.remove();
		}
		assertTrue(sortedSetString1.isEmpty());

	}

	@Test
	public void testIteratorInt() {
		// Tests the iterator() method for a SortedSet<Integer>
		java.util.Iterator<Integer> i = sortedSetInt.iterator();
		for (Integer j = 0; j < 8; j++) {
			assertTrue(i.hasNext());
			assertEquals(j, i.next());
		}
		assertFalse(i.hasNext());
		i = sortedSetInt.iterator();
		while (i.hasNext()) {
			i.remove();
		}
		assertTrue(sortedSetInt.isEmpty());
	}

	@Test
	public void testRemoveString() {
		// Tests the remove() method for a SortedSet<String>
		for (int i = 1; i < 8; i++) {
			String s = "test" + i;
			assertTrue(sortedSetString1.contains(s));
			sortedSetString1.remove(s);
			assertFalse(sortedSetString1.contains(s));
		}
		assertArrayEquals(new String[] {}, sortedSetString1.toArray());
	}

	@Test
	public void testRemoveInteger() {
		// Tests the remove() method for a SortedSet<String>
		for (int i = 0; i < 8; i++) {
			assertTrue(sortedSetInt.contains(i));
			sortedSetInt.remove(i);
			assertFalse(sortedSetInt.contains(i));
		}
		assertArrayEquals(new Integer[] {}, sortedSetInt.toArray());
	}

	@Test
	public void testRemoveAllString() {
		// Tests the removeAll() method for a SortedSet<String>
		ArrayList<String> alphabetCollection = new ArrayList<String>(
				Arrays.asList(alphabet));
		sortedSetString2.addAll(alphabetCollection);
		assertArrayEquals(alphabet, sortedSetString2.toArray());
		sortedSetString2.removeAll(alphabetCollection);
		assertArrayEquals(new String[] {}, sortedSetString2.toArray());
	}

	@Test
	public void testRemoveAllInt() {
		// Tests the removeAll() method for a SortedSet<Integer>
		ArrayList<Integer> intsToOneHundredCollection = new ArrayList<Integer>(
				Arrays.asList(intsToOneHundred));
		sortedSetInt.addAll(intsToOneHundredCollection);
		assertArrayEquals(intsToOneHundred, sortedSetInt.toArray());
		sortedSetInt.removeAll(intsToOneHundredCollection);
		assertArrayEquals(new Integer[] {}, sortedSetInt.toArray());
	}

	@Test
	public void testSizeString() {
		// Tests the size() method for a SortedSet<String>
		assertEquals(7, sortedSetString1.size());
		sortedSetString1.add("a");
		assertEquals(8, sortedSetString1.size());
	}

	@Test
	public void testSizeInt() {
		// Tests the size() method for a SortedSet<Integer>
		assertEquals(8, sortedSetInt.size());
		sortedSetInt.add(50);
		assertEquals(9, sortedSetInt.size());
	}
}
