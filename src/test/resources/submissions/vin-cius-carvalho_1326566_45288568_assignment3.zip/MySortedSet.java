package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Miriah Meyer
 * 
 * @author Filipe Wesley - u0957355
 * @author Vinicius Carvalho - u0973889
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] array;
	private Comparator<? super E> comparator;

	public MySortedSet() {
		clear();
	}

	public MySortedSet(Comparator<? super E> comparator) {
		clear();
		setComparator(comparator);
	}

	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * Compares two Objects using either the natural order (If the objects
	 * implement Comparable) or a given comparator
	 * 
	 * @param o1
	 *            -- First argument to be compared
	 * @param o2
	 *            -- Second argument to be compared
	 * @return Returns a negative integer, zero, or a positive integer as the
	 *         first argument is less than, equal to, or greater than the
	 *         second.
	 */
	@SuppressWarnings("unchecked")
	private int compare(E o1, E o2) {
		if (comparator() != null) {
			return comparator().compare(o1, o2);
		}
		return ((Comparable<E>) o1).compareTo(o2);
	}

	@Override
	public E first() throws NoSuchElementException {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		return getArray()[0];
	}

	@Override
	public E last() throws NoSuchElementException {
		if (isEmpty()) {
			throw new NoSuchElementException();
		}
		return getArray()[size() - 1];
	}

	@Override
	public boolean add(E o) {
		if (!(o == null) && !contains(o)) {
			int index = binarySearchAdd(o, 0, size() - 1);
			increaseArraySize();
			if (index == 0 && size() == 2) {
				if (compare(o, getArray()[index]) > 0) {
					array[size() - 1] = o;
				} else {
					array[size() - 1] = array[index];
					array[index] = o;
				}
			} else {
				for (int i = size() - 1; i > index; i--) {
					array[i] = array[i - 1];
				}
			}
			array[index] = o;
			return true;
		}
		return false;
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {
		int size = size();
		for (E e : c) {
			add(e);
		}
		if (size != size()) {
			return true;
		}
		return false;
	}

	/**
	 * Makes a binary search to find the index where the new element must be
	 * added.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @param low
	 *            -- lowest index range of the binary search
	 * @param high
	 *            -- highest index range of the binary search
	 * @return index where the new element must be added.
	 */
	private int binarySearchAdd(E o, int low, int high) {
		int mid = (int) Math.ceil(((low + high) / 2.0));
		if (high >= low && !isEmpty()) {
			if (compare(o, getArray()[mid]) > 0) {
				return binarySearchAdd(o, mid + 1, high);
			} else {
				return binarySearchAdd(o, low, mid - 1);
			}
		}
		return mid;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		array = (E[]) new Object[0];
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		try {
			o = (E) o;
		} catch (ClassCastException e) {
			return false;
		}
		return binarySearchContains(o, 0, (size() - 1));
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		int count = 0;
		for (Object o : c) {
			if (contains(o)) {
				count++;
			}
		}
		if (count == c.size()) {
			return true;
		}
		return false;
	}

	/**
	 * Makes a binary search to determine whether the given element is on the
	 * set or not.
	 * 
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @param low
	 *            -- lowest index range of the binary search
	 * @param high
	 *            -- highest index range of the binary search
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings("unchecked")
	private boolean binarySearchContains(Object o, int low, int high) {
		if (!isEmpty() && high >= low) {
			int mid = (low + high) / 2;
			if (getArray()[mid].equals(o)) {
				return true;
			}
			if (compare((E) o, getArray()[mid]) > 0) {
				return binarySearchContains(o, mid + 1, high);
			} else {
				return binarySearchContains(o, low, mid - 1);
			}
		}
		return false;
	}

	@Override
	public boolean isEmpty() {
		return getArray().length == 0;
	}

	@Override
	public Iterator<E> iterator() {
		Iterator<E> i = new Iterator<E>() {

			private int currentIndex = 0;

			@Override
			public boolean hasNext() {
				return currentIndex < size()
						&& getArray()[currentIndex] != null;
			}

			@Override
			public E next() {
				return getArray()[currentIndex++];
			}

			@Override
			public void remove() {
				MySortedSet.this.remove(getArray()[currentIndex]);
			}
		};
		return i;
	}

	@Override
	@SuppressWarnings("unchecked")
	public boolean remove(Object o) {
		if (contains(o)) {
			int index = binarySearchAdd(((E) o), 0, size() - 1);
			for (int i = index; i < array.length - 1; i++) {
				array[i] = array[i + 1];
				array[i + 1] = null;
			}
			decreaseArraySize();
			return true;
		}
		return false;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		int size = size();
		for (Object o : c) {
			remove(o);
		}
		if (size != size()) {
			return true;
		}
		return false;
	}

	@Override
	public int size() {
		return getArray().length;
	}

	@Override
	public Object[] toArray() {
		return array;
	}

	/**
	 * Reduces the size of the main array by 1;
	 */
	private void decreaseArraySize() {
		array = Arrays.copyOf(getArray(), size() - 1);
	}

	/**
	 * Increases the size of the main array by 1;
	 */
	private void increaseArraySize() {
		array = Arrays.copyOf(getArray(), size() + 1);
	}

	public void setComparator(Comparator<? super E> comparator) {
		this.comparator = comparator;
	}

	@SuppressWarnings("unchecked")
	private E[] getArray() {
		return (E[]) toArray();
	}
}