package assignment2;

/*Anthony Wilkinson and Enrique Ramirez-Holston*/

import java.util.GregorianCalendar;

public class LibraryBookGeneric<Type> extends Book{

	private Type bookHolder; //information about the book holder
	private GregorianCalendar dueDate; // the due date
	
	/**
	 * Creates a library book and checks it in
	 * 
	 * @param _isbn the isbn of the book
	 * @param _author the author of the book
	 * @param _title the title of the book
	 */
	public LibraryBookGeneric(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		bookHolder = null;
		dueDate = null;
	}
	
	/**
	 * Returns the book's holder
	 */
	public Type getHolder() {
		return bookHolder;
	}
	
	/**
	 * Returns the due date of the book
	 */
	public GregorianCalendar getDueDate() {
		return dueDate;
	}
	
	/**
	 * Check the book in by setting the bookHolder to null, 
	 * as well as the book's due date
	 */
	public void checkBookIn() {
		this.bookHolder = null;
		this.dueDate = null;
	}
	
	/**
	 * Checks the book out
	 * @param month month of the due date
	 * @param day day of the due date
	 * @param year year of the due date
	 * @param _bookHolder information that identifies the holder of the book
	 */
	public void checkBookOut(int month, int day, int year, Type _bookHolder) {
		if(_bookHolder == null || (month <= 0 || month > 12)
			|| (day <= 0 || day > 31) || year <= 0){
			throw new IllegalArgumentException();
		}
		this.bookHolder = _bookHolder;
		dueDate = new GregorianCalendar(year, month, day);
	}
	
	/**
	 * Returns whether or not the book is checked out
	 */
	public boolean isCheckedOut() {
		if(this.bookHolder == null) {
			return false;
		}
		return true;
	}

}
