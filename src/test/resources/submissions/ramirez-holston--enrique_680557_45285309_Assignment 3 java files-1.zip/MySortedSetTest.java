package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;

import org.junit.Test;

import assignment2.*;
/**
 * These are the tests that thoroughly test our MySortedSet class.
 * 
 * @author Enrique Ramirez-Holston and Anthony Wilkinson
 *
 */
public class MySortedSetTest {
	
	/** Test contains() method with Strings*/
	@Test
	public void testContainsWithStrings() {
		
		MySortedSet<String> set = new MySortedSet<String>();
		String s = "b";
		set.add(s);
		set.add("c");
		set.add("f");
		set.add("d");
		set.add("e");
		set.add("z");
		
		assertEquals(true, set.contains("d"));
		
		set.remove("d");
		assertEquals(false, set.contains("d"));
		
		assertEquals(false, set.contains("q"));
	}
	
	/** Test contains() method with integers*/
	@Test
	public void testContainsWithIntegers() {
		
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add(1);
		intSet.add(37);
		intSet.add(19);
		intSet.add(2);
		intSet.add(20);
		intSet.add(95);
		
		assertFalse(intSet.contains(99));
		assertFalse(intSet.contains(9999));
		assertTrue(intSet.contains(1));
		assertTrue(intSet.contains(20));
		
		intSet.remove(20);
		intSet.remove(37);
		
		assertFalse(intSet.contains(20));
		assertFalse(intSet.contains(37));
		
		
		
	}
	/** Test next() and hasNext() methods*/
	@Test
	public void testIterator() {
	
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add(1);
		intSet.add(37);
		intSet.add(19);
		intSet.add(2);
		intSet.add(20);
		intSet.add(95);
		
		Iterator i = intSet.iterator();
		
		Integer[] array = new Integer[intSet.size()];
		
		Integer n = 0;
		while(i.hasNext()) {
			array[n] = (Integer) i.next();
			n++;
		}
		
		assertTrue(n == 6);
		assertTrue(Arrays.equals(array, intSet.toArray()));
		assertFalse(i.hasNext());
	}
	
	/** Test addAll() and removeAll() methods */
	@Test
	public void testAddAndRemoveAll() {
		
		//Without duplicates
		Integer[] intArray = new Integer[] {1,2,3,5,7};
		ArrayList<Integer> intList = new ArrayList<Integer>();
		
		for(Integer i : intArray){
			intList.add(i);
		}
				
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		
		assertTrue(intSet.addAll(intList));	
		assertTrue(Arrays.equals(intList.toArray(), intSet.toArray()));
		assertEquals(5, intSet.size());
		
		assertTrue(intSet.removeAll(intList));
		assertEquals(0, intSet.size());		
		
		//with duplicates
		Integer[] intArray2 = new Integer[] {1,2,3,3,5,7};
		ArrayList<Integer> intList2 = new ArrayList<Integer>();
		
		for(Integer i : intArray2){
			intList2.add(i);
		}

		assertTrue(intSet.addAll(intList2));	
		assertFalse(Arrays.equals(intList2.toArray(), intSet.toArray()));
		assertFalse(intSet.size() == intList2.size());
		assertEquals(5, intSet.size());
		
		assertTrue(intSet.removeAll(intList2));
		assertEquals(0, intSet.size());	
	}
	
	/** Test indexOf() method with integers*/
	@Test
	public void TestIndexOfWithInts() {
		
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add(1);
		intSet.add(2);
		intSet.add(6);
		intSet.add(8);
		intSet.add(67);
		intSet.add(33);
		intSet.add(76);
		intSet.add(99);
		intSet.add(-5);
		
		assertEquals(1, intSet.indexOf(1));
		assertEquals(5, intSet.indexOf(33));
		assertEquals(6, intSet.indexOf(67));
		assertEquals(0, intSet.indexOf(-5));
		assertEquals(-1, intSet.indexOf(100));
		assertEquals(-1, intSet.indexOf(-10));
		
		
	}
	
	/** Test indexOf() method with characters*/
	@Test
	public void TestIndexOfWithChars() {
		
		MySortedSet<Character> charSet = new MySortedSet<Character>();
		charSet.add('a');
		charSet.add('z');
		charSet.add('b');
		charSet.add('y');
		charSet.add('c');
		charSet.add('x');
		charSet.add('d');
		charSet.add('w');
		charSet.add('q');
		/**[a, b, c, d, q, w, x, y, z]*/
		
		assertEquals(1, charSet.indexOf('b'));
		assertEquals(4, charSet.indexOf('q'));
		assertEquals(8, charSet.indexOf('z'));
		assertEquals(0, charSet.indexOf('a'));
		assertEquals(-1, charSet.indexOf('g'));
		assertEquals(-1, charSet.indexOf('o'));
		
		
	}
	
	/** Test clear() method */
	@Test
	public void TestClear() {
		
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add (5);
		intSet.add (4);
		intSet.add (3);                 
		intSet.add (2);
		intSet.add (1);

		intSet.clear (); 
		assertEquals(0, intSet.size ());      
		assertEquals(-1, intSet.indexOf (1));
	}

	/** Test remove() method */
	@Test
	public void Testremove() {
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add (5);
		intSet.add (4);
		intSet.add (3);
		intSet.add (2);
		intSet.add (1);

		intSet.remove (1);
		intSet.remove (2);
		intSet.remove(3);

		assertEquals (-1, intSet.indexOf(1));
		assertEquals (-1, intSet.indexOf(2));
		assertEquals (-1, intSet.indexOf(3));
		assertEquals (2, intSet.size ());
	}
	
	/** Test first() method */
	@Test
	public void TestFirst() {
		
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add (5);
		intSet.add (4);
		intSet.add (3);
		intSet.add (2);
		intSet.add (1);
		
		assertTrue(1 == intSet.first());
		
		intSet.add(-1);
		assertTrue(-1 == intSet.first());
	}
	
	/** Test last() method */
	@Test
	public void TestLast() {
		
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add (5);
		intSet.add (4);
		intSet.add (3);
		intSet.add (2);
		intSet.add (1);
		
		assertTrue(5 == intSet.last());
		
		intSet.add(7);
		assertTrue(7 == intSet.last());
	}
	
	/** Test containsAll() method */
	@Test
	public void TestContainsAll() {
		
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add (5);
		intSet.add (4);
		intSet.add (3);
		intSet.add (2);
		intSet.add (1);
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		
		assertTrue(intSet.containsAll(list));
		
	}
	
	/** Test toArray() method */
	@Test
	public void TestToArray() {
		
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add (5);
		intSet.add (4);
		intSet.add (3);
		intSet.add (2);
		intSet.add (1);
		
		Integer[] array = new Integer[]{1, 2, 3, 4, 5};
		assertEquals(array, intSet.toArray());
	}
	
	/** Test toString() method */
	@Test
	public void TestToString() {
		
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add (5);
		intSet.add (4);
		intSet.add (3);
		intSet.add (2);
		intSet.add (1);
		
		String s = "[1, 2, 3, 4, 5]";
	}
	
	/** Test the add() method at large array sizes*/
	@Test
	public void TestGrow()
	{
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		//Default array size is 100, so we'll add 110 elements
		for(int i = 0; i < 110; ++i){ 
			intSet.add(i);
		}
		
		//Sorted array to compare to intSet
		Integer[] intArr = new Integer[110];
		for(int i = 0; i < 110; ++i){ 
			intArr[i] = i;
		}
		
		assertTrue(intSet.size() == 110);
		assertTrue(Arrays.equals(intArr, intSet.toArray()));
		
	}
	
	/**Test sorting using a Comparator rather than Comparable*/
	@Test
	public void TestComparator()
	{
		LibraryGeneric<Integer> library = new LibraryGeneric<Integer>();
		library.addAll("Mushroom_Publishing.txt");
		
		MySortedSet<LibraryBookGeneric<Integer>> bookSet = new MySortedSet<LibraryBookGeneric<Integer>>(library.new OrderByIsbn());
		
		ArrayList<LibraryBookGeneric<Integer>> bookList = library.getOrderedByAuthor();
		
		bookSet.addAll(bookList);
		
		assertFalse(Arrays.equals(bookList.toArray(), bookSet.toArray()));
		
		LibraryBookGeneric<Integer> firstBook = new LibraryBookGeneric<Integer>(9781843190004L, "Moyra Caldecott", "Weapons of the Wolfhound");
		
		assertEquals(firstBook, bookSet.first());
	}
}
