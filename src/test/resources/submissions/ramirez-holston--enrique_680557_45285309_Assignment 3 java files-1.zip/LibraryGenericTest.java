package assignment2;

import java.util.ArrayList;
import java.util.GregorianCalendar;

/*Anthony Wilkinson and Enrique Ramirez-Holston*/

/**
 * Testing class for LibraryGeneric.
 *
 */
public class LibraryGenericTest {

  public static void main(String[] args) {

    // test a library that uses names (String) to id patrons
    LibraryGeneric<String> lib1 = new LibraryGeneric<String>();
    lib1.add(9780374292799L, "Thomas L. Friedman", "The World is Flat");
    lib1.add(9780330351690L, "Jon Krakauer", "Into the Wild");
    lib1.add(9780446580342L, "David Baldacci", "Simple Genius");

    String patron1 = "Jane Doe";

    if (!lib1.checkout(9780330351690L, patron1, 1, 1, 2008))
      System.err.println("TEST FAILED: first checkout");
    if (!lib1.checkout(9780374292799L, patron1, 1, 1, 2008))
      System.err.println("TEST FAILED: second checkout");
    ArrayList<LibraryBookGeneric<String>> booksCheckedOut1 = lib1
        .lookup(patron1);
    if (booksCheckedOut1 == null
        || booksCheckedOut1.size() != 2
        || !booksCheckedOut1.contains(new Book(9780330351690L, "Jon Krakauer",
            "Into the Wild"))
        || !booksCheckedOut1.contains(new Book(9780374292799L,
            "Thomas L. Friedman", "The World is Flat"))
        || !booksCheckedOut1.get(0).getHolder().equals(patron1)
        || !booksCheckedOut1.get(0).getDueDate().equals(
            new GregorianCalendar(2008, 1, 1))
        || !booksCheckedOut1.get(1).getHolder().equals(patron1)
        || !booksCheckedOut1.get(1).getDueDate().equals(
            new GregorianCalendar(2008, 1, 1)))
      System.err.println("TEST FAILED: lookup(holder)");
    if (!lib1.checkin(patron1))
      System.err.println("TEST FAILED: checkin(holder)");

    // test a library that uses phone numbers (PhoneNumber) to id patrons
    LibraryGeneric<PhoneNumber> lib2 = new LibraryGeneric<PhoneNumber>();
    lib2.add(9780374292799L, "Thomas L. Friedman", "The World is Flat");
    lib2.add(9780330351690L, "Jon Krakauer", "Into the Wild");
    lib2.add(9780446580342L, "David Baldacci", "Simple Genius");

    PhoneNumber patron2 = new PhoneNumber("801.555.1234");

    if (!lib2.checkout(9780330351690L, patron2, 1, 1, 2008))
      System.err.println("TEST FAILED: first checkout");
    if (!lib2.checkout(9780374292799L, patron2, 1, 1, 2008))  
      System.err.println("TEST FAILED: second checkout");
    ArrayList<LibraryBookGeneric<PhoneNumber>> booksCheckedOut2 = lib2
        .lookup(patron2);
    if (booksCheckedOut2 == null
        || booksCheckedOut2.size() != 2
        || !booksCheckedOut2.contains(new Book(9780330351690L, "Jon Krakauer",
            "Into the Wild"))
        || !booksCheckedOut2.contains(new Book(9780374292799L,
            "Thomas L. Friedman", "The World is Flat"))
        || !booksCheckedOut2.get(0).getHolder().equals(patron2)
        || !booksCheckedOut2.get(0).getDueDate().equals(
            new GregorianCalendar(2008, 1, 1))
        || !booksCheckedOut2.get(1).getHolder().equals(patron2)
        || !booksCheckedOut2.get(1).getDueDate().equals(
            new GregorianCalendar(2008, 1, 1)))
      System.err.println("TEST FAILED: lookup(holder)");
    if (!lib2.checkin(patron2))                           
      System.err.println("TEST FAILED: checkin(holder)");
    
    //Test a new library that once again uses Strings for its holders
    
    LibraryGeneric<String> lib3 = new LibraryGeneric<String>();
    
    /*Test the getInventoryList method with an empty inventory*/
    try{
    	lib3.getInventoryList().get(0).getIsbn();
    	System.err.println("Test failed -- no exception thrown");
    }
    catch(Exception e){
    	
    }
    
    lib3.addAll("Mushroom_Publishing.txt");
    
    lib3.checkout(9781843190004L, "John Doe", 1,29,2015);
    lib3.checkout(9781843190011L, "John Doe", 2,10,2015);
    lib3.checkout(9781843190028L, "Jane Doe", 2,20,2015);
    
    /*Test the checkout method with a null holder as input*/
    try{
    	lib3.checkout(9781843190400L, null, 1, 29, 2015);
    	System.err.println("Test failed -- no IllegalArgumentException thrown");
    }
    catch(IllegalArgumentException e) {
    	
    }
    
    /*Test the checkout method with an invalid month as input*/
    try{
    	lib3.checkout(9781843190400L, "John Doe", 13, 29, 2015);
    	System.err.println("Test failed -- no IllegalArgumentException thrown");
    }
    catch(IllegalArgumentException e) {
    
    }
    
    /*Test the checkout method with an invalid year and day as input*/
    try{
    	lib3.checkout(9781843190400L, "John Doe", 13, 56, -2504);
    	System.err.println("Test failed -- no IllegalArgumentException thrown");
    }
    catch(IllegalArgumentException e) {
    
    }
    
    /*Test the getOrderedByAuthor method*/
    if(!(lib3.getOrderedByAuthor().get(0).getAuthor().equals("Alan Burt Akers"))
    	|| !(lib3.getOrderedByAuthor().get(1).getAuthor().equals("Anthony J D Burns")))
    	System.err.println("Test failed -- orderByAuthor");
    
    if(!(lib3.getInventoryList().get(0).getIsbn() <
    		lib3.getInventoryList().get(1).getIsbn())){
    	System.err.println("Test failed -- getInventoryList");
    }
    
    /*Test the getOverdueList method*/
    if((lib3.getOverdueList(2, 15, 2015).size() != 2)
    	|| (lib3.getOverdueList(2, 9, 2015).size() != 1)
    	|| (lib3.getOverdueList(1, 9, 2015).size() != 0))
    	System.err.println("Test failed - getOverdueList");
    
    if(!(lib3.getOverdueList(2, 15, 2015).get(0).isCheckedOut())) {
    	System.err.println("Test failed - is checked out");
    }
        
    /*Check getDueDate() and correct ordering of getOverDueList*/
    if(!(lib3.getOverdueList(2, 15, 2015).get(0).getDueDate().equals(new GregorianCalendar(2015,1,29))))
    	System.err.println("Test failed - getDueDate() incorrect");
    if(!(lib3.getOverdueList(2, 15, 2015).get(1).getDueDate().equals(new GregorianCalendar(2015,2,10))))
    	System.err.println("Test failed - getDueDate() incorrect");
    
    /*Test checkIn and isCheckedOut*/
    lib3.getInventoryList().get(0).checkBookIn();
    
    if(lib3.getInventoryList().get(0).isCheckedOut()) {
    	System.err.println("Test failed - is checked out");
    }
    
    
    System.out.println("Testing done.");
  }
}