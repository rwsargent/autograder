package assignment2;

/*Anthony Wilkinson and Enrique Ramirez-Holston*/

import java.util.GregorianCalendar;

public class LibraryBook extends Book{

	private String bookHolder; //the book holder's name
	private GregorianCalendar dueDate; // the due date
	
	/**
	 * Creates a new checked-in library book.
	 * @param _isbn The book's ISBN
	 * @param _author The name of the book's author
	 * @param _title The title of the book
	 */
	public LibraryBook(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		bookHolder = null;
		dueDate = null;
	}
	
	/**
	 * @return The book holder's name as a String
	 */
	public String getHolder() {
		return bookHolder;
	}
	
	/**
	 * @return The due date of the book as a GregorianCalendar
	 */
	public GregorianCalendar getDueDate() {
		return dueDate;
	}
	
	/**
	 * Checks the book in by setting its bookHolder and dueDate variables to null.
	 */
	public void checkBookIn() {
		this.bookHolder = null;
		this.dueDate = null;
	}
	
	/**
	 * Checks the book out.
	 * @param month The month of the due date.
	 * @param day The day of the due date.
	 * @param year The year of the due date.
	 * @param _bookHolder The name of the book holder.
	 */
	public void checkBookOut(int month, int day, int year, String _bookHolder) {
		if(_bookHolder == null || (month <= 0 || month > 12)
				|| (day <= 0 || day > 31) || year <= 0){
			throw new IllegalArgumentException();
		}
		this.bookHolder = _bookHolder;
		dueDate = new GregorianCalendar(year, month, day);
	}
	
	/**
	 * @return True if the book is checked out, false if checked in.
	 */
	public boolean isCheckedOut() {
		if(this.bookHolder == null) {
			return false;
		}
		return true;
	}

}
