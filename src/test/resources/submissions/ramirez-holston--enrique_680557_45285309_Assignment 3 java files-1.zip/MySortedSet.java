package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Iterator;

/**
 * @author Enrique Ramirez and Anthony Wilkinson
 * @param Type The type of object for the set to hold.
 */
public class MySortedSet<E> implements SortedSet<E>{
	
	/**
	 * An array that holds each element in the set.
	 */
	private Object[] array;
	
	/**
	 * The current size of this set.
	 */
	private int size;
	
	/**
	 * The comparator provided at the creation of this MySortedSet object.
	 * If null, no comparator is used for ordering.
	 */
	private Comparator<? super E> comp;
	
	/**
	 * The starting size for a new MySortedSet
	 */
	public static final int START_SIZE = 100;
	
	/**
	 * Creates a sorted set that is ordered using their natural ordering.
	 */
	public MySortedSet(){
		this.size = 0;
		array = new Object[START_SIZE];
	}
	
	/**
	 *  Creates a sorted set assuming that the elements are 
	 *  ordered using the provided comparator.
	 *  
	 * @param c A comparator passed in.
	 */
	public MySortedSet(Comparator<? super E> c) {
		this();
		comp = c;
	}

	@Override
	public Comparator comparator() {
		return comp;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if(size != 0) {
			return (E) array[0];
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if(size != 0) {
			return (E) array[size - 1];
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		
		//return false if o is null or already in the set
		if(this.contains(o) || o == null){
			return false;
		}
		
		//resize if we ran out of room
		if(size == array.length) {
			Object[] newArray = new Object[size * 2];
			for(int i = 0; i < size; i++) {
				newArray[i] = array[i];
			}
			array = newArray;
		}
		
		//Binary search for position to insert at
		int lhs = 0;
		int rhs = size -1;
		int halfwayPoint = size / 2;
		
		if(comp != null) {
			while(lhs <= rhs) {
				if(comp.compare((E) array[halfwayPoint], (E)o) < 0) {
					lhs = halfwayPoint + 1;
				} else {
					if(comp.compare((E)array[halfwayPoint], (E)o) == 0) {
						break;
					} else {
						rhs = halfwayPoint - 1;
					}
				}
				halfwayPoint = (lhs + rhs) / 2;
			}
		} else {
			E item = (E) o;
			while(lhs <= rhs) {
				if( ((Comparable<E>) array[halfwayPoint]).compareTo(item) < 0) {
					lhs = halfwayPoint + 1;
				} else {
					if(((Comparable<E>) array[halfwayPoint]).compareTo(item) == 0) {
						break;
					} else {
						rhs = halfwayPoint - 1;
					}
				}
				halfwayPoint = (lhs + rhs) / 2;
			}
		}		
		
		for(int i = size; i > lhs; --i){
			Object temp = array[i-1];
			array[i-1] = array[i];
			array[i] = temp;
		}
		//insert element
		array[lhs] = o;
		
		//increment size
		size++;
		
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection c) {
		boolean wasChanged = false;
		
		for(Object o : c) {
			E e = (E) o;
			if (this.add(e)) {
				wasChanged = true;
			}
		}
		return wasChanged;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		size = 0;
		array = new Object[START_SIZE];
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		if(indexOf(o) >= 0) 
			return true;
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection c) {
		for(Object o: c) {
			if(!(this.contains(o)))
				return false;
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if(size == 0){
			return true;
		}
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator iterator() {
		
		return new SortedSetIterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		
		if(!(this.contains(o))){
			return false;
		}
		
		int objectIndex = this.indexOf(o);
		array[objectIndex] = null;
		
		for(int i = objectIndex; i < size-1; ++i){
			Object temp = array[i];
			array[i] = array[i+1];
			array[i+1] = temp;
		}
		
		//decrement size
		size--;
		
		return true;
		
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection c) {
		
		boolean wasChanged = false;
		
		for(Object o : c){
			if(remove(o)){
				wasChanged = true;
			}
		}
		
		return wasChanged;
		
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object[] newArray = new Object[this.size];
		for(int i = 0; i < size; ++i){
			newArray[i] = array[i];
		}
		return newArray;
	}

	/**
	 * Find the index of the object that is being looked for
	 * 
	 * @param o the object to be found in the set
	 * @return The index of the item to be found in the set, 
	 * or -1 if the item cannot be found/ is null.
	 */
	public int indexOf(Object o) {
		
		if(size == 0 || o == null) {
			return -1;
		}
		
		int i = size / 2;
		int lhs = 0;
		int rhs = size - 1;
	
		if(comp != null) {
			while(lhs <= rhs) {
				if(comp.compare((E)array[i], (E)o) < 0) {
					lhs = i + 1;
				} else {
					if(comp.compare((E)array[i], (E)o) == 0) {
						return i;
					} else {
						rhs = i - 1;
					}
				}
				i = (lhs + rhs) / 2;
			}
			return -1;
		} else {
			E item = (E) o;
			while(lhs <= rhs) {
				if(((Comparable<E>) array[i]).compareTo(item) < 0) {
					lhs = i + 1;
				} else {
					if(((Comparable<E>) array[i]).compareTo(item) == 0) {
						return i;
					} else {
						rhs = i - 1;
					}
				}
				i = (lhs + rhs) / 2;
			}
			return -1;
		}
	}
	
	public String toString() {
		
		Object[] array = new Object[this.size()];
		for(int i = 0; i < this.size; i++) {
			array[i] = this.array[i];
		}
		return Arrays.toString(array);
	}

	/**
	 * An iterator for MySortedSet.
	 */
	public class SortedSetIterator implements Iterator<E> {

		int position;
		
		public SortedSetIterator() {
			position = 0;
		}
		
		/**
		 * Returns true if the iteration has more elements. (In other words, returns true
		 * if next() would return an element rather than throwing an exception.)
		 * 
		 * @return true if the iteration has more elements
		 */
		@Override
		public boolean hasNext() {
			
			if(array[position] == null){
				return false;
			}
			return true;
		}

		/**
		 * Returns the next element in the iteration.
		 * 
		 * @return the next element in the iteration
		 * @throws NoSuchElementException - if the iteration has no more elements
		 */
		@Override
		public E next() {
			
			try {
				E temp = (E) array[position];
				position++;
				return temp;
			} catch(Exception e) {
				throw new NoSuchElementException();
			}
		}

	}

}
