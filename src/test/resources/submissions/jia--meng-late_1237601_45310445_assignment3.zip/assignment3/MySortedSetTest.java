package assignment3;
/**
 * 
 * @author Brantly Walker and Meng Jia
 *
 * @param <E>
 */

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import assignment3.MySortedSet.MySetIterator;
/**
 * This is a test class to test all the methods found in the MySortedSet 
 * which implements all methods from the SortedSet class.
 * 
 * @author Brantly Walker and Meng Jia
 *
 */
public class MySortedSetTest{

	MySortedSet<Integer> test1;
	MySortedSet<String> test2;
	MySortedSet<Integer> test3;
	MySortedSet<String> test4;

	String string1, string2, string3, string4, string5, string6;

	@Before
	public void setUp() throws Exception {

		test1=new MySortedSet<Integer>();
		test2 =new MySortedSet<String>();
		test3=new MySortedSet<Integer>();
		test4 =new MySortedSet<String>();


		for(int i = 100; i>=0 ; i--){
			test1.add(i);
		}		

		string1="yellow";
		string2="blue";
		string3="red";
		string4="green";
		string5="purple";
		string6="not here";
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test the add and add all method which inherently uses resize, and contains;
	 * 
	 */
	@Test
	public void testADDall() {

		ArrayList<Integer> newSet1 = new ArrayList<Integer>();
		for(int i=10000; i<20000; i++){
			newSet1.add(i);
		}

		ArrayList<String> newSet2 = new ArrayList<String>();
		newSet2.add(string1);
		newSet2.add(string2);
		newSet2.add(string3);
		newSet2.add(string4);
		newSet2.add(string5);

		ArrayList<Integer> newSet3 = new ArrayList<Integer>();
		for(int i=1; i<20000; i++){
			newSet3.add(i);
		}

		//test addAll 
		test1.addAll(newSet1);
		test2.addAll(newSet2);
		test3.addAll(newSet3);


		//check contains methods
		assertTrue("Test1 contains 10001 ",test1.contains(10001));
		assertTrue("Test2 contains string1 ",test2.contains(string1));

		assertFalse("Test1 doesn't contain ",test1.contains(-100));
		assertFalse("Test2 doesn't contain ",test2.contains(string6));


		//check containsAll methods
		assertTrue("Test3 contains all elements of test1", test3.containsAll(newSet1));
		assertFalse("Test4 contains all elements of test1", test4.containsAll(newSet2));
	}

	/**
	 * Testing remove and remove all methods
	 * 
	 */
	@Test
	public void testREMOVE(){
		assertTrue("Test1 contains 1 ",test1.contains(1));
		test1.remove(1);
		assertFalse("Test1 doesn't contain 1 after remove",test1.contains(1));

		ArrayList<Integer> newSet4 = new ArrayList<Integer>();
		for(int i=0; i<21; i++){
			newSet4.add(i);
		}


		assertTrue("Test1 contains all elements from 0 to 60", test1.contains(20));
		test1.removeAll(newSet4);		
		assertFalse("Test1 does not contains all elements from 0 to 60 after remove", test1.contains(20));
	}

	/**
	 * Testing to array
	 * 
	 */
	@Test
	public void testToArray(){
		Object[] toArrayTest = test1.toArray();
		for(int i=0;i<test1.toArray().length;i++){		
			assertTrue(toArrayTest[i]!=null);	
		}
	}

	/**
	 * Testing the iterator by
	 * 
	 */
	@Test
	public void testIterator(){	

		MySetIterator iter = (MySetIterator) test1.iterator();

		while(iter.hasNext())
			assertTrue(iter.next()!=null);

		//checking hasNext after the last item in the previous loop, should be false
		assertFalse(iter.hasNext());

		//remove the last item and check that it shouldn't have
		iter.remove();
		assertFalse(iter.hasNext());


		//removing every element
		int tmp =test1.size();
		for(int i=50; i<tmp; i++){
			assertTrue(test1.remove(i));
		}
		
		tmp=test1.size();
		//removing every other element
		for(int i=0; i<tmp; i+=2){
			assertTrue(test1.remove(i));
		}
	}

	/**
	 * Testing a MySortedSet using a comparator
	 * testing with strings, which contain letters and numbers.
	 * 
	 */
	@Test
	public void testComparator(){
		ComparatorForTest<String> cmp = new ComparatorForTest<String>();
		if(cmp.compare("Brantly", "Mia")  > 0){
			System.out.println("false");
		}
		MySortedSet<String> testCMP=new MySortedSet(cmp);
		//Add multiple strings with numbers
		for(int i=10; i>0; i--){
			assertTrue(testCMP.add("a"+i+"b"));
		}
		//check that all the items were create
		for(int i=0; i<10; i++){
			assertTrue(testCMP.getAt(i)!=null);
		}
	}
	
	/**
	 * @author Brantly Walker and Meng Jia
	 * This class contains a comparator for use in testing a MySortedSet
	 */
	class ComparatorForTest<String> implements Comparator<String>{
		public int compare(String lhs, String rhs) {		  
			int n = 0; 
			int min = 0;
			if( ((java.lang.String) lhs).length() < ((java.lang.String) rhs).length())
				min = ((java.lang.String) rhs).length();
			else min =((java.lang.String) lhs).length();

			for ( int i = 0; i < min; i++){
				if( ((java.lang.String) lhs).charAt(i) != ((java.lang.String) rhs).charAt(i))
					return(int) ((java.lang.String) lhs).charAt(i)-((java.lang.String) rhs).charAt(i);		 
			}
			return 0;
		}
	}
}

