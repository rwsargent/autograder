package assignment3;
/**
 * 
 * @author Brantly Walker and Meng Jia
 *
 * @param <E>
 */
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;


public class MySortedSet<E> implements SortedSet<E> {
	private E[] basicArray;
	/**
	 * If this constructor is used to create the sorted set, it is assumed that the elements are ordered 
	 * using the provided comparator.
	 * 
	 */
	public MySortedSet(Comparator<? super E> cmp) {
		basicArray = (E[])new Object[50];
		totalSize=50;
		totalItems=0;
		mComparator = cmp;
	}
	private int totalItems, totalSize;
	private Comparator<? super E> mComparator;

	/**
	 * If this constructor is used to create the sorted set, it is assumed that the elements are ordered 
	 * using their natural ordering (i.e., E implements Comparable<? super E>).
	 */
	public MySortedSet(){
		basicArray = (E[]) new Object[50];
		totalSize=50;
		totalItems=0;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator(){
		return mComparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException{
		if(size()==0)
			throw new NoSuchElementException();
		return basicArray[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException{
		if(size()==0)
			throw new NoSuchElementException();
		return basicArray[totalItems-1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o){
		int low=0, high=totalItems-1;
		int middle=0;

		if(this.contains(o) || o == null)
			return false;
		else if(totalItems==0){
			basicArray[0]=o;
			totalItems++;
			return true;
		}
		else{

			int index = binarySearch(low, high, (E) o);
			totalItems++;

			if((totalItems)>basicArray.length){
				resize();
			}

			for( int i = totalItems-1; i>=index+1 ;i--){
				basicArray[i]=basicArray[i-1];			
			}
			basicArray[index]=o;


			return true;
		}
	}
	/**
	 * Use Comparator or comparable method  for binary searching to sorted array
	 * 
	 * @param int low, int high, E target
	 *            -- low: index where binary search begins
	 *            -- high: index where binary search ends
	 *            -- target: element whose presence in this set is to be tested
	 * @return index of the new element
	 */

	private int binarySearch(int low, int high, E target){

		if(low > high)
			return low;
		else{
			int mid = low + (high-low)/2;
			int result;
			if(mComparator==null){
				result = ((Comparable<E>) basicArray[mid]).compareTo( (E) target);
			}
			else
				result = mComparator.compare(basicArray[mid], (E) target);

			if(result==0)
				return mid;
			else if(result<0){
				return binarySearch(mid+1, high, target);
			}
			else{
				return binarySearch(low, mid-1, target);
			}
		}

	}

	/**
	 * Creates a new sized array to hold the items that is 2x as large if over 50 items
	 * and 4x as large if less than 50 items
	 */
	public void resize() {
		E[] tmp;
		tmp=(E[])new Object[basicArray.length*2];
		for(int i = 0; i<basicArray.length; i++){
			tmp[i] = basicArray[i];
		}
		basicArray=tmp;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c){
		Object[] c1=c.toArray();
		int itemsWas=totalItems;
		for(int i = 0; i<c1.length;i++){
			this.add((E) c1[i]);
		}
		return itemsWas<totalItems;	
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear(){
		for(int i=0; i<basicArray.length; i++)
			basicArray[i]=null;
		totalItems=0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o){
		int low=0, high=totalItems-1;
		int middle = 0;
		int index = binarySearch(low, high, (E) o);
		if(index==totalItems) return false;
		if(basicArray[index]==null) return false;

		boolean result = false;
		if(mComparator==null){
			if (((Comparable<E>) basicArray[index]).compareTo((E)o)==0){
				result = true;
			}
		}
		else{
			if(mComparator.compare(basicArray[index], (E) o)==0){
				result = true;
			}
		}
		return result;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c){
		Object[] c1=c.toArray();
		int count=0;

		for(int i =0; i<c.size(); i++)
			if(this.contains(c1[i]))
				count++;

		return count == c.size();
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty(){
		if(basicArray.length==0 || basicArray==null)
			return true;
		else
			return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator(){
		MySortedSet<E>.MySetIterator iter = new MySetIterator();
		return (Iterator<E>) iter;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o){

		for(int i = 0; i<totalItems; i++){
			if(basicArray[i]==o){
				delete(i);
				totalItems-=1;
				return true;
			}
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c){
		Object[] tmp=c.toArray();
		boolean wasChanged=true;

		for(int i = 0; i<this.totalItems; i++){
			for(int j=0; j<tmp.length;j++)
				if(basicArray[i]==tmp[j]){
					delete(i);
					wasChanged = true;
				}
		}
		return wasChanged;
	}

	/**
	 * This removes an item by shifting all the elements after the item 
	 */
	public void delete(int index){
		for(int j = index; j<totalItems; j++){
			basicArray[j] = basicArray[j+1];
		}
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size(){
		return this.totalItems;
	}

	/**
	 * 
	 * @param x is the index at which the object will be returned.
	 * @return
	 * 			The Type E Object at the requested index
	 */
	public E getAt(int x){
		return (E) basicArray[x];
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray(){
		Object[] tmp= new Object[totalItems];
		for(int i=0;i<tmp.length;i++){
			tmp[i] = basicArray[i];
		}
		return tmp;
	}

	/**
	 * 
	 * @author Brantly Walker and Meng Jia
	 *
	 */
	class MySetIterator implements Iterator{
		int index=-1;
		boolean isValid=false;

		/**
		 * @return
		 * 			Returns true if the next index item is less than totalItems-1 
		 * 			Returns false if there should be no more objects
		 */
		public boolean hasNext(){
			return (index<totalItems-1);
		}

		/**
		 * @return
		 * 			Returns the next item in the array, according to the current index
		 */
		public E next(){
			if(index+1<=totalItems){
				isValid=true;
				index++;
				return basicArray[index];
			}
			else
				throw new Error();
		}

		/**
		 * Removes the last element returned by this iterator can only be called once after a call to next().
		 */
		public void remove(){
			if(isValid){
				delete(index);
				isValid=false;
				totalItems-=1;
				index-=1;	
			}
			else {throw new Error();}
		}
	}
}