package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.*;

import assignment3.MySortedSet;
import assignment2.*;

/**
 * Tests for MySortedSet constructors, methods, and Iterator
 * @author Nate Merrill and Aleksander Vargas
 *
 */
public class MySortedSetTest {
	
	private MySortedSet<Integer> testSet, compIntSet;
	private ArrayList<Integer> collInt;
	private ArrayList<String> collString;
	private MySortedSet<String> comparatorSet, compStringSet;
	
	@Before
	public void setUp ()
	{
		testSet = new MySortedSet<Integer>(); //MySortedSet of Integers using Natural Ordering
		compIntSet = new MySortedSet<Integer>(); ////MySortedSet of integers for comparing
		collInt = new ArrayList<Integer>(); //collection of integers
		collString = new ArrayList<String>(); //collection of strings
		comparatorSet = new MySortedSet<String>(new OrderByName()); //MySortedSet of Strings using a provided Comparator
		compStringSet = new MySortedSet<String>(); //MySortedSet of Strings using Natural Ordering
	}
	
	@After
	public void takeDown ()
	{
		testSet = null;
		collInt = null;
	}
	
	/**
	 * tests to see if a MySortedSet can add values, which returns true, to non-comparator MySet. 
	 * If you try to add a value that is already in the set, it returns false.
	 */
	@Test
	public void addTest1 ()
	{
		assertTrue(testSet.add(2));
		assertTrue(testSet.add(1));
		assertFalse(testSet.add(1));
	}

	
	/**
	 * tests to see if a MySortedSet can add values and then grow size to non-comparator MySet
	 */
	@Test
	public void addTest2 ()
	{
		for (int i = 0; i < 16; i++)
		{
			testSet.add((Object) i);
		}	
		assertTrue(testSet.add((Object) 17));
		assertTrue(testSet.add((Object) 18));
		assertTrue(testSet.add((Object) 16));
		
	}
	
	/**
	 * tests add method with an object that provides a comparator. 
	 */
	@Test
	public void addTest3 ()
	{
		compStringSet.add("a");
		compStringSet.add("b");
		compStringSet.add("c");
		
		comparatorSet.add("b");
		comparatorSet.add("a");
		comparatorSet.add("c");
		
		assertArrayEquals(compStringSet.toArray(), comparatorSet.toArray());
	}

	
	/**
	 * This tests to see a no such element exception is thrown if set is empty in non-comparator MySet.
	 */
	@Test (expected = NoSuchElementException.class)
	public void firstTest1 ()
	{
			testSet.first();
	}
	
	/**
	 * Checks if the first element was actually added to non-comparator MySet
	 */
	@Test
	public void firstTest2 ()
	{
		assertTrue(testSet.add(2));
		assertTrue(testSet.add(1));
		assertEquals((Object) 1, testSet.first());
	}
	
	/**
	 * Checks to see if first element in MySet is added to comparator MySet
	 */
	@Test
	public void firstTest3 ()
	{
		comparatorSet.add("b");
		comparatorSet.add("a");
		comparatorSet.add("c");
		
		assertEquals("a", comparatorSet.first());
	}
	
	/**
	 * Tests to see if returns Last Object to non-comparator MySet
	 */
	@Test
	public void lastTest1()
	{
		assertTrue(testSet.add(2));
		assertTrue(testSet.add(1));
		assertEquals((Object) 2, testSet.last());
	}
	
	/**
	 * Tests to see if exception is thrown if Set is empty to non-comparator MySet
	 */
	@Test (expected = NoSuchElementException.class)
	public void lastTest2()
	{	
			testSet.last();
	}
	
	/**
	 * Checks to see if last element in MySet is added to comparator MySet
	 */
	@Test
	public void lastTest3 ()
	{
		comparatorSet.add("b");
		comparatorSet.add("a");
		comparatorSet.add("c");
		
		assertEquals("c", comparatorSet.last());
	}
	
	/**
	 * tests to check if a collection with no duplicates is added to a non-comparator MySortedList
	 */
	@Test
	public void addAllTest1 ()
	{
		collInt.add(1);
		collInt.add(2);
		collInt.add(3);
		
		assertTrue(testSet.addAll(collInt));
	}
	
	/**
	 * tests to check if a collection with duplicates is added to a non-comparator MySortedList
	 */
	@Test
	public void addAllTest2 ()
	{
		collInt.add(1);
		collInt.add(2);
		collInt.add(3);
		collInt.add(1);
		collInt.add(2);
		collInt.add(3);
		
		assertTrue(testSet.addAll(collInt));
	}

	/**
	 * tests to check if a collection with no duplicates is added to a MySortedSet
	 * containing some of the values from collection
	 */
	@Test
	public void addAllTest3 ()
	{
		testSet.add(1);
		
		collInt.add(1);
		collInt.add(2);
		collInt.add(3);
		
		assertTrue(testSet.addAll(collInt));
	}
	
	/**
	 * tests to check if a collection with no duplictes is not added to a MySortedSet
	 * that contains all the values in collection. 
	 */
	@Test
	public void addAllTest4 ()
	{
		testSet.add(1);
		testSet.add(2);
		testSet.add(3);
		
		collInt.add(1);
		collInt.add(2);
		
		assertFalse(testSet.addAll(collInt));
	}
	

	/**
	 * tests to check if a collection with no duplictes is added to a comparator MySortedSet
	 * that contains all the values in collection. 
	 */
	@Test
	public void addAllTest5 ()
	{
		collString.add("A");
		collString.add("B");
		
		comparatorSet.add("C");
		comparatorSet.add("D");
		
		assertTrue(comparatorSet.addAll(collString));
	}
	
	/**
	 * tests to check if a collection with no duplictes is added to a comparator MySortedSet
	 * that contains all the values in collection. 
	 */
	@Test
	public void addAllTest6 ()
	{
		collString.add("TA's");
		collString.add("Are");
		
		comparatorSet.add("Amazing");
		comparatorSet.add("Especially");
		comparatorSet.add("Our");
		comparatorSet.add("TA's");
		
		assertTrue(comparatorSet.addAll(collString));
	}
	
	/**
	 * tests to see if testSet will clear after clear() is called
	 */
	@Test
	public void clearTest ()
	{
		testSet.add(1);
		testSet.add(2);
		testSet.clear();
		assertTrue(testSet.isEmpty());
	}
	
	/**
	 * tests to see if contains returns true if the MySortedSet contains the value
	 */
	@Test
	public void containsTest1 ()
	{
		testSet.add(1);
		testSet.add(2);
		
		assertTrue(testSet.contains(1));
	}
	
	/**
	 * tests to see if contains returns False if the MySortedSet contains the value
	 */
	@Test
	public void containsTest2 ()
	{
		testSet.add(1);
		testSet.add(2);
		
		assertFalse(testSet.contains(3));
	}
	
	/**
	 * tests to see if contains will return false if testSet has no values
	 */
	@Test
	public void containsTest3 ()
	{
		assertFalse(testSet.contains(0));
	}
	
	/**
	 * tests to check if a comparator MySet contains() returns the correct value
	 */
	@Test
	public void containsTest4 ()
	{
		comparatorSet.add("C");
		comparatorSet.add("D");
		
		assertTrue(comparatorSet.contains("C"));
		assertFalse(comparatorSet.contains("A"));
	}
	
	/**
	 * Test to see if containsAll can correctly determine if all of the collection is in the set
	 */
	@Test
	public void containsAllTest1()
	{
		testSet.add(1);
		collInt.add(1);
		
		assertTrue(testSet.containsAll(collInt));
	}
	
	/**
	 * Test to see if containsAll can correctly determine if all of the collection is not in the set
	 */
	@Test
	public void containsAllTest2()
	{
		testSet.add(1);
		testSet.add(2);
		testSet.add(3);
		
		collInt.add(3);
		collInt.add(4);
		
		assertFalse(testSet.containsAll(collInt));
	}
	
	/**
	 * More advanced version of conainsAll1
	 */
	@Test
	public void containsAllTest3()
	{
		testSet.add(1);
		testSet.add(2);
		testSet.add(3);
		testSet.add(4);
		testSet.add(5);
		
		collInt.add(3);
		collInt.add(4);
		
		assertTrue(testSet.containsAll(collInt));
	}
	
	/**
	 * tests to check if a comparator MySet containsAll() returns the correct value
	 */
	@Test
	public void containsAllTest4 ()
	{
		collString.add("A");
		collString.add("B");
		collString.add("C");
		
		comparatorSet.add("C");
		comparatorSet.add("D");
		
		assertFalse(comparatorSet.containsAll(collString));
		
		comparatorSet.add("A");
		comparatorSet.add("B");
		
		assertTrue(comparatorSet.containsAll(collString));
	}
	
	/**
	 * Tests to see if isEmpty can correctly determine if testSet is empty
	 */
	@Test
	public void isEmptyTest1()
	{
		assertTrue(testSet.isEmpty());
	}
	
	/**
	 * Tests to see if isEmpty can correctly determine if testSet is not empty
	 */
	@Test
	public void isEmptyTest2()
	{
		testSet.add(1);
		
		assertFalse(testSet.isEmpty());
	}
	
	
	/**
	 * Tests to see if isEmpty can correctly determine if a comparator MySet is empty and not empty
	 */
	@Test
	public void isEmptyTest3()
	{
		assertTrue(comparatorSet.isEmpty());
		
		comparatorSet.add(1);
		
		assertFalse(comparatorSet.isEmpty());
	}
	
	/**
	 * Tests to see if the Remove method works
	 */
	@Test
	public void removeTest1()
	{
		testSet.add(1);
		testSet.add(2);
		
		assertTrue(testSet.remove(2));
	}
	
	/**
	 * Tests to see if Remove method can correctly determine if an integer 
	 * is missing when trying to remove
	 */
	@Test
	public void removeTest2()
	{
		testSet.add(1);
		
		assertFalse(testSet.remove(2));
	}
	
	/**
	 * Tests to see if Remove method can determine when the array is empty
	 */
	@Test
	public void removeTest3()
	{
		assertFalse(testSet.remove(1));
	}
	
	
	/**
	 * Tests to see if Remove method can correctly determine if an integer 
	 * is missing when trying to remove
	 */
	@Test
	public void removeTest4()
	{
		comparatorSet.add("A");
		
		assertTrue(comparatorSet.remove("A"));
		assertFalse(comparatorSet.remove("A"));
	}
	
	/**
	 * Tests to see if remove all will remove all
	 */
	@Test
	public void removeAllTest1()
	{
		testSet.add(1);
		testSet.add(2);
		testSet.add(3);
		
		collInt.add(1);
		collInt.add(2);
		collInt.add(3);
		
		assertTrue(testSet.removeAll(collInt));
	}
	
	/**
	 * Tests to see if removeAll will remove values found in MySortedSet
	 */
	@Test
	public void removeAllTest2 ()
	{
		testSet.add(1);
		testSet.add(2);
		testSet.add(3);
		
		collInt.add(3);
		collInt.add(4);
		
		assertTrue(testSet.removeAll(collInt));
	}
	
	/**
	 * Tests to see if removeAll will not remove values found in MySortedSet
	 * and return false if collection values are not found in MySortedSet
	 */
	@Test
	public void removeAllTest3 ()
	{
		testSet.add(1);
		testSet.add(2);
		testSet.add(3);
		
		collInt.add(4);
		collInt.add(5);
		
		assertFalse(testSet.removeAll(collInt));
	}
	
	/**
	 * tests to check if a collection with no duplictes is removed from a comparator MySortedSet
	 * that contains some of the values in collection. 
	 */
	@Test
	public void removeAllTest6 ()
	{
		collString.add("TA's");
		collString.add("Are");
		collString.add("Amazing");
		
		comparatorSet.add("Amazing");
		comparatorSet.add("Especially");
		comparatorSet.add("Our");
		comparatorSet.add("TA's");
		
		assertTrue(comparatorSet.removeAll(collString));
		
	}
	
	/**
	 * Tests to see if size() can correctly determine the size of an array
	 */
	@Test
	public void sizeTest1()
	{
		testSet.add(1);
		testSet.add(2);
		
		assertEquals(2, testSet.size());
	}
	
	/**
	 * Tests size() with an empty array
	 */
	@Test
	public void sizeTest2()
	{
		assertEquals(0, testSet.size());
	}
	
	/**
	 * Test to assure that an object array is returned as a regular array
	 */
	@Test
	public void toArrayTest1()
	{
		Object[] comArray = {1,2,3};
		
		testSet.add(1);
		testSet.add(2);
		testSet.add(3);
		
		assertArrayEquals(comArray, testSet.toArray());
	}
	
	/**
	 * Test to assure that iterator is able to traverse through a MySortedSet collection
	 */
	@Test
	public void iteratorNextTest1()
	{
		for (int i = 0; i < 100; i++)
		{
			testSet.add(i);
		}
		Iterator itr = testSet.iterator();
			for (int i = 0; i < testSet.size(); i++)
			{
				assertEquals(i, itr.next());
			}
	}


	/**
	 * Test to assure that iterator is able to traverse through a MySortedSet collection
	 */
	@Test
	public void iteratorNextTest2()
	{
		for (int i = 0; i < 100; i++)
		{
			collInt.add(i);
		}
		testSet.addAll(collInt);
		
		Iterator itr = testSet.iterator();
			for (int i = 0; i < testSet.size(); i++)
			{
				assertEquals(i, itr.next());
			}
		
	}
	
	/**
	 * Test to assure that iterator will throw a NoSuchElementException if it is past the alloted size
	 */
	@Test (expected = NoSuchElementException.class)
	public void iteratorNextTest3 ()
	{
		for (int i = 0; i < 100; i++)
		{
			collInt.add(i);
		}
		testSet.addAll(collInt);
		
		Iterator itr = testSet.iterator();
			for (int i = 0; i < 101; i++)
			{
				assertEquals(i, itr.next());
			}
	}
	
	/**
	 * Test to assure that iterator is able to traverse through a MySortedSet collection using hasNext()
	 */
	@Test
	public void iteratorHasNextTest1()
	{
		for (int i = 0; i < 100; i++)
		{
			collInt.add(i);
		}
		testSet.addAll(collInt);
		
		Iterator itr = testSet.iterator();
			while (itr.hasNext())
			{
				assertTrue(true);
				itr.next();
			}
	}
	
	/**
	 * Test to assure that iterator is able to traverse through a MySortedSet collection using hasNext()
	 */
	@Test
	public void iteratorHasNextTest2()
	{

		for (int i = 0; i < 100; i++)
		{
			testSet.add(i);
		}
		
		Iterator itr = testSet.iterator();
			while (itr.hasNext())
			{
				assertTrue(true);
				itr.next();
			}
	
	}
	
	/**
	 * Test to assure that iterator is able to traverse through a MySortedSet collection and then remove an object
	 */
	@Test
	public void iteratorRemoveTest1()
	{
		for (int i = 0; i < 100; i++)
		{
			testSet.add(i);
		}
		
		Iterator itr = testSet.iterator();
		while (itr.hasNext())
		{
			itr.next();
			itr.remove();
		}
		
		assertEquals(0, testSet.size());
	}
	
	/**
	 * Test to assure that if iterator tries to remove before a next is called it will throw a NoSuchElementException
	 */
	@Test (expected = NoSuchElementException.class)
	public void iteratorRemoveTest2()
	{
		for (int i = 0; i < 100; i++)
		{
			testSet.add(i);
		}
		
		Iterator itr = testSet.iterator();
		itr.remove();
	
	}
	
	/**
	 * class used as the Comparator to test MySortedSet Comparator constructor 
	 * @author Nate
	 *
	 */
	public class OrderByName implements Comparator<String>
	{

		@Override
		public int compare(String o1, String o2) 
		{
			return o1.compareTo(o2);
		}
		
	}

}

