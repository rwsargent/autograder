package assignment3;
/**
 * Timing tests for Contains and Add methods of MySortedSet
 *  @author Nate Merrill and Aleksander Vargas
 * @author Nate
 *
 */
public class MySortedSetTimingTest {

double[] containTime, addTime, removeTime;

	public static void main(String[] args)
	{
		System.out.println("Contain");
		containTiming();
		System.out.println("Add");
		addTiming();
	}
	
	public static void containTiming ()
	{
		MySortedSet<Integer> timingSet = new MySortedSet<Integer>();
		int timesToLoop = 100;
		
		long startTime, midTime, stopTime;

		
		for(int i = 0; i < 2000000; i += 10000)
		{
			for (int k = 0; k < i; k++)
	    	{
	    		timingSet.add(k);
	    	}
			
			// First, spin computing stuff until one second has gone by.
			// This allows this thread to stabilize.
			startTime = System.nanoTime();
	    	while (System.nanoTime() - startTime < 1000000000) { // empty block
	    	}
	    	
	    	for (int j = 0; j < timesToLoop; j++)
	    	{
	    		timingSet.contains(j);
	    	}
	    	
		
			// Run an empty loop to capture the cost of running the loop.
			midTime = System.nanoTime();
			
	    	for (long k = 0; k < timesToLoop; k++) { // empty block
	    	}
	    
	    	stopTime = System.nanoTime();
	    
	    	double averageTime = ((midTime - startTime) - (stopTime - midTime))
	            / timesToLoop;
	    
	    	System.out.println(i + "\t" + averageTime);
		}
	}
	
	public static void addTiming ()
	{
		MySortedSet<Integer> timingSet = new MySortedSet<Integer>();
		int timesToLoop = 1024;
		
		long startTime, midTime, stopTime;
		System.out.println("Hello");
		
		for(int i = 0; i < 100000; i += 1000)
		{
			
			// First, spin computing stuff until one second has gone by.
			// This allows this thread to stabilize.
			startTime = System.nanoTime();
	    	while (System.nanoTime() - startTime < 1000000000) { // empty block
	    	}
	    	
	    	for (int j = 0; j < timesToLoop; j++)
	    	{
	    		timingSet.add(i);
	    	}
	    	timingSet.add(i);
		
			// Run an empty loop to capture the cost of running the loop.
			midTime = System.nanoTime();
			
	    	for (long k = 0; k < timesToLoop; k++) { // empty block
	    	}
	    
	    	stopTime = System.nanoTime();
	    
	    	double averageTime = ((midTime - startTime) - (stopTime - midTime))
	            / timesToLoop;
	    
	    	System.out.println(i + "\t" + averageTime);
	    	
	    	timingSet.clear();
		}
	}
}


