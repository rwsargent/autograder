package assignment3;

import java.lang.reflect.Array;
import java.util.*;
/**
 * A Set of non-duplicate E objects in ascending order
 * @author Nate Merrill and Aleksander Vargas
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E>
{
	//an Array represents the ordered set
    // must contain no duplicates
	//must be sorted in ascending order
	private E[] set; 
	
	//Represents the size of the Array. 
	private int size;
	
	private boolean usesComp;
	
	//TODO represents Iterator through set.
	private Iterator<?> itr;
	
	//comparator used between objects contained in Set
	private Comparator<? super E> comp;
	
	/**
	 * If this constructor is used to create the sorted set, 
	 * it is assumed that the elements are ordered using their natural ordering 
	 * (i.e., E implements Comparable<? super E>).
	 */
	public MySortedSet()
	{
		size = 0;
		usesComp = false;
		set = (E[]) new Object[16];
	}
	
	/**
	 * If this constructor is used to create the sorted set, 
	 * it is assumed that the elements are ordered using the provided comparator.
	 * @param comparator
	 */
	public MySortedSet(Comparator<? super E> comparator)
	{
		size = 0;
		usesComp = true;
		set = (E[]) new Object[16];
		this.comp = comparator;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator comparator() 
	{
		return comp;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (size == 0)
		{
			throw new NoSuchElementException();
		}
		else
		{
			return this.set[0];
		}
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException 
	{
		if (size == 0)
		{
			throw new NoSuchElementException();
		}
		else
		{
			return this.set[size-1];
		}

	}
	
	/**
	 * Gives the value of the object at position index
	 * @param index
	 * @return
	 * 		-E object contained at index
	 */
	public E get(int index)
	{
		return set[index];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(Object o) {
		if (this.contains(o))
		{
			return false;
		}
		else if (size == 0)
		{
			set[0] = (E) o;
			size++;
			return true;
		}
		else
		{
			if (set.length-1 == size)
			{
				growSet();
			}
			int position = binarySearch((E) o);
			E temp = set[position];
				for (int i = position; i < set.length; i++)
				{
					if (o == null)
					{
						break;
					}
					set[i] = (E) o;
					o = temp;
					temp = set[i+1];
				}
		}
		size++;
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection c) {
		boolean adding = false;
		for(E temp: (Collection<E>) c)
		{
			if (add(temp))
			{
				adding = true;
			}
		}
		return adding;
		
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		set = (E[]) new Object[16]; 
		size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) 
	{
		if (set[binarySearch((E) o)] == o)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection c) {
		for(E temp: (Collection<E>) c)
		{
			if (!contains(temp))
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (size == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator iterator() {
		return new Iterator<E>()
				{
			int index = -1;
			boolean isValid = false;
			
			@Override
			public boolean hasNext() {
				return (index < (size - 1));
			}

			@Override
			public E next() {
				index++;
				if (index >= size)
				{
					throw new NoSuchElementException();
				}
				isValid = true;
				return set[index];
				
			}
			
			@Override
			public void remove()
			{
				if (isValid)
				{
					delete(set[index]);
					isValid = false;
					index--;
				}
				else
				{
					throw new NoSuchElementException();
				}
			}
		};
		
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		if(this.contains(o))
		{
			delete((E) o);
			return true;
		}
		else return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection c) {
		boolean removing = false;
		for(E temp: (Collection<E>) c)
		{
			if (remove(temp))
			{
				removing = true;
			}
		}
		return removing;
		
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object [] array = new Object[this.size];
		for(int i = 0; i < this.size; i++)
		{
			array[i] = set[i];
		}
		return array;
	}
	
	/**
	 * Searches the specified array of set for the specified value using the binary search algorithm. 
	 * @param searchable
	 * @return
	 */
	public int binarySearch(E searchable)
	{
		int low = 0; //represents the lowest bound of the array
		int mid = 0; //represents the middle of the lowest and highest bounds of the array
		int high = size - 1; //represents the highest bound of the array
		int finalPos = 0; //represents the final position for which the object, searchable, belongs
		
		//for if MySortedSet uses provided Comparator
		if (usesComp)
		{
			//if the value the list is new, thus placing item in the beginning. 
			if (low == high)
			{
				if (comp.compare(searchable, set[0]) <= 0)
				{
					return 0;
				}
				else
				{
					return 1;
				}
			}
			//binary search loop
			while (low <= high)
			{
				
				mid = (low+high)/2;
				int compValue = comp.compare(searchable, set[mid]);
				if (compValue == 0)
				{
					return mid;
				}
				else if (compValue < 0)
				{
					high = mid - 1;
				}
				else if (compValue > 0 )
				{
					low = mid + 1;
				}	
				
				if ((low +1) >= high)
				{
					finalPos = low;
				}
			}//end of loop
			
		}
		//for if MySortedSet object uses Comparable
		else
		{
			Comparable<? super E> objComp = (Comparable<? super E>) searchable;
			int compValue;
			
			if (high == low)
			{
				if(objComp.compareTo(set[0]) <= 0)
				{
					return 0;
				}
				else
				{
					return 1;
				}	
			}
			else
			{
				//binary search loop
				while (low <= high)
				{
					
					mid = (low+high)/2;
					compValue = objComp.compareTo(set[mid]);
					
					if (compValue == 0)
					{
						return mid;
					}
					else if (compValue < 0)
					{
						high = mid - 1;
					}
					else if (compValue > 0)
					{
						low = mid + 1;
					}
					
					if ((low +1) >= high)
					{
						finalPos = low;
					}
				}//end of loop
			}
		}
		return finalPos;
	}
	
	/**
	 * when called, will double the size of the set and place the items within that new set
	 */
	private void growSet ()
	{
		E[] temp = (E[]) new Object[set.length*2];
		for (int i = 0; i < set.length; i++)
		{
			temp[i] = set[i];
		}
		
		set = temp;
	}

	/**
	 * when called, this method will delete the object from set 
	 * and move the remaining variables down the set by 1.
	 */
	private void delete (E object)
	{
		for(int pos = binarySearch(object); pos < (size() - 1); pos++)
		{
			set[pos] = set[pos + 1];
		}
		set[size - 1] = null;
		size--;
	}
}
