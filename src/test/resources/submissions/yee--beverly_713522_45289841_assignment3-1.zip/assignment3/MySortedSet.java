package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * File:	MySortedSet.java
 * @author 	Beverly Yee, Sean Hammond
 *
 * @param <E>
 * Creates a sorted set of whatever Type the clients wants.
 */

public class MySortedSet<E> implements SortedSet<E> {

	private E[] arr;
	private Comparator<? super E> comp;
	private int size, index;
	private boolean compare;
	
	/**
	 * First constructor
	 * If this constructor is used, the elements of the array
	 * are sorted by natural ordering
	 * E implements Comparable<? super E>
	 */
	public MySortedSet(){
		//call to create a new Array of type E
		arr = (E[]) new Object[5];
		comp = null;
		compare = false;
		size = size();
		// a.compareTo(b); where a and b are E objects
	}
	
	/**
	 * Second constructor
	 * If this constructor is used, the elements are sorted according
	 * to the provided comparator
	 * @param comparator
	 */
	public MySortedSet( Comparator<? super E> c ){
		//call to create a new Array of type E
		arr = (E[]) new Object[5];
		comp = c;
		compare = true;
		size = size();
		// c.compare(a, b); where c is a comparator and a and b are E objects
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comp;
	}

	
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		return arr[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		return arr[ size - 1 ];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * The element must be added in the spot that helps retain the order that the
	 * array is now in.
	 * The array cannot have any gaps in between elements - EVER.
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		checkSizeLimit();
		if( o == null || contains(o) )
			return false;
		else if( arr[0] == null ){		//otherwise throws exception
			arr[0] = o;
			size++;
			return true;
		}
		else {
			if( compare )
				index = binaryAdd2(o);
			else
				index = binaryAdd1(o);
			move( index, true );
			arr[index] = o;
			size++;
			return true;
		}
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * Make sure to keep the array in order as the elements are added
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		E[] tmpc = (E[]) c.toArray();
		int chkSize = size;
		for( int i = 0; i < tmpc.length; i++ )
		{
			add( tmpc[i] );
		}
		if( chkSize < size )
			return true;
		return false;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		arr = (E[]) new Object[5];
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		E tmpo = (E) o;
		if( compare )		//if the user provides comparator
		{
			index = binarySearch2(tmpo);	
		}
		else 
			index = binarySearch1(tmpo);
			
		if(index < 0)
			return false;
		else if(index == 0)
		{
			if(arr[0] == null)
				return false;
			else if(!arr[0].equals(o))
				return false;
			else return true;
		}
		else 
			return true;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for(Object o: c)
		{
			if(!contains(o))
				return false;
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		size = size();
		if( size == 0 )
			return true;
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		//hasNext();
		return null;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		E tmpo = (E) o;
		if( this.contains(tmpo) )
		{
			if( compare )
				index = binarySearch2(tmpo);
			else
				index = binarySearch1(tmpo);
			move( index, false );
			size--;
			return true;
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		E[] tmpc = (E[]) c.toArray();
		int chkSize = size;
		for( int i = 0; i < tmpc.length; i++ )
		{
			remove( tmpc[i] );
		}
		if( chkSize > size )
			return true;
		return false;
	}

	/**
	 * Uses binary search to see what's the last part of the array to hold an element
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		int count = 0;
		for( int i = 0; i < arr.length; i++ )
			if( arr[i] != null )
				count++;
		return count;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		size = size();
		Object[] newArr = new Object[size];
		for( int i = 0; i <= size; i++ )
			newArr[i] = arr[i];
		return newArr;
	}
	
	/**
	 * Doubles the array if the size limit is reached
	 * @return
	 */
	public void grow()
	{
		E[] tmparr = (E[]) new Object[arr.length * 2];
		for( int i = 0; i < arr.length; i++ )
			tmparr[i] = arr[i];
		arr = tmparr;
	}
	
	/**
	 * Checks to see if the array we're using has reached its limit
	 * If it does, call the grow function
	 */
	public void checkSizeLimit()
	{
		if(arr.length - size <= 1)
			this.grow();
	}
	
	/**
	 * Does a binary search of the sorted set to find a specified element.
	 * This one is where the comparator was not set by the user
	 * @param o
	 * @return the position of the object in the array
	 */
	public int binarySearch1(E o)
	{
		int left = 0;
		int right = size -1;
		
		while (left <= right) {
			//in the case that right and left = 0
			//check to see if the object is in index 0
			if( left == 0 && right == 0 && compare( o, arr[0]) == 0)
				return 0;
			int mid = (left + right)/2;
			if(compare(o,arr[mid]) < 0){
				right = mid -1;
			}
			else if(compare(o,arr[mid]) > 0){
				left = mid +1;
			}		//added brackets just to be sure else will be called when
					//if fails
			else return mid;
		}
		return -1;		//if none of the conditions above are satisfied
	}
	
	/**
	 * The same as binarySearch1, except this one is for if the user/tester
	 * provides the comparator.
	 * @param o
	 * @return the position of the object
	 */
	public int binarySearch2(E o)
	{
		int left = 0;
		int right = size -1;
		
		while (left <= right){
			if( left == 0 && right == 0 && comp.compare( o, arr[0]) == 0)
				return 0;
			int mid = (left + right)/2;
			if(comp.compare(o,arr[mid]) < 0){
				right = mid -1;
			}
			else if(comp.compare(o,arr[mid]) > 0){
				left = mid +1;
			}
			else return mid;
		}
		return -1;			//if the object is not found
	}
	
	/**
	 * Method binary searches through the array to find the spot where the
	 * new element can be added without disrupting the order the array is already in.
	 * This method is where the array is natural ordering.
	 * Binary search will always be worst case scenario.
	 * @param o
	 * @return int of where the new element should be added.
	 */
	private int binaryAdd1(E o)
	{
		int left = 0;
		int right = size - 1;
		
		//while loop narrows down where the added element should be placed
		while ( left < right ){
			int mid = (left + right)/2;
			if( right == left + 1)
			{
				if( compare( o, arr[left]) < 0 )
					return left;
				return right;
			}
			else if( compare( o, arr[mid]) < 0 ){
				right = mid - 1;
			}
			else if( compare( o, arr[mid] ) > 0 ){
				left = mid + 1;
			}
		}
		//after it finds the place, it exist the loops and checks if statements
		if( left == right && left == 0 ){		//checks against index 0 of array
			if( compare( o, arr[0] ) < 0 || arr[0] == null )
				return 0;
			else
				return 1;
		}
		else if( left == right )
			return left;
		return right;
	}
	
	/**
	 * Basically the same as the first binary add, except with the use of the user
	 * implemented comparator
	 * @param o
	 * @return
	 */
	private int binaryAdd2(E o)
	{
		int left = 0;
		int right = size - 1;
		
		//while loop narrows down where the added element should be placed
		while ( left < right ){
			int mid = (left + right)/2;
			if( right == left + 1)
			{
				if( comp.compare( o, arr[left]) < 0 )
					return left;
				return right;
			}
			else if( comp.compare( o, arr[mid]) < 0 ){
				right = mid - 1;
			}
			else if( comp.compare( o, arr[mid] ) > 0 ){
				left = mid + 1;
			}
		}
		//after it finds the place, it exist the loops and checks if statements
		if( left == right && left == 0 ){		//checks against index 0 of array
			if( comp.compare( o, arr[0] ) < 0 || arr[0] == null )
				return 0;
			else
				return 1;
		}
		else if( left == right )
			return left;
		return right;
	}
	
	/**
	 * 
	 * @param o1
	 * @param o2
	 * @return int -1 if o1 is less than o2
	 * 			1 if o1 is more than o2
	 * 			0 if o1 and o2 is the same
	 */
	private int compare(E o1, E o2)
	{
		return ((Comparable<E>) o1).compareTo(o2);
	} 

	/**
	 * Moves all elements after the place where the new element is to be inserted
	 * Or moves all elements back one to fill up the hole an element left
	 * @param pos - the place where the new element is to be inserted
	 * 				or to be taken out
	 * @param dir - specifies the direction the move will occur
	 */
	private void move(int pos, Boolean right )
	{
		int count = size;
		if( arr[pos] == null){}
		else if( right ){		//the elements are being moved to the right/adding
			for( int i = count; pos <= i; i-- )
				arr[i+1] = arr[i];
		}
		else{		//the elements are being moved to the left/removing
			for( int j = pos; j < count; j++ )
				arr[j] = arr[j+1];
		}
	}
	
	/**
	 * @author Sean Hammond
	 * 
	 * Creates a sub class within in this class to implement the
	 * iterator interface
	 * @param <E>
	 */
	private class MyIterator<E> implements Iterator<E>
	{
		private int pos = 0;
		private MySortedSet set;
		public MyIterator(MySortedSet<E> s)
		{
			set = s;
		}
		@Override
		public boolean hasNext() {
			return set.arr[pos+1] != null;
		}

		@Override
		public E next() {
			return (E)set.arr[pos++];
		}

		@Override
		public void remove() {
			MySortedSet.this.remove(pos);
		}
	}
}
