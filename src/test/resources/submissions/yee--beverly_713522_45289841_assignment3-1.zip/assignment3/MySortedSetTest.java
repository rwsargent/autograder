package assignment3;

import java.util.ArrayList;

/**
 * File:	MySortedSetTest.java
 * @author	Beverly Yee, Sean Hammond
 * 
 * Tests the MySortedSet class. Each set can only contain one object type
 * otherwise the compare method will throw an Exception because you cannot
 * compare objects of differing type.
 */
public class MySortedSetTest {
		
	public static void main( String[] args){
		//the first set will deal with Strings
		MySortedSet set = new MySortedSet();
		if( set.size() != 0 )
			System.err.println("TEST FAILED: size check");
		if( !set.add( "hello" ))
			System.err.println("TEST FAILED: adding new element - String");
		if( !set.add( "world" ))
			System.err.println("TEST FAILED: adding new element - String");
		if( !set.add( "goodbye" ))
			System.err.println("TEST FAILED: adding new element - String");
		if( !set.add( "mother" ))
			System.err.println("TEST FAILED: adding new element - String");
		if( !set.contains( "goodbye" ))
			System.err.println("TEST FAILED: searching element");
		if( !set.contains( "mother" ))
			System.err.println("TEST FAILED: searching element");
		if( !set.remove("goodbye"))
			System.err.println("TEST FAILED: remove element");
		if( set.binarySearch1("hello") != 0 )
			System.err.println("TEST FAILED: remove disruption. Instead received "
					+ set.binarySearch1("Hello"));
		set.clear();
		if( !set.isEmpty() )
			System.err.println("TEST FAILED: size check through isEmpty");

		ArrayList<String> words = new ArrayList<String>(5);
		words.add("hello");
		words.add("world");
		words.add("goodbye");
		words.add("mother");
		words.add("father");
		if( !set.addAll( words ) )
			System.err.println("TEST FAILED: collection add");
		if( !set.containsAll( words ))
			System.err.println("TEST FAILED: not all elements added");
		if( !set.removeAll( words ))
			System.err.println("TEST FAILED: collection remove");
		if( !set.isEmpty() )		//should be empty because everything was removed
			System.err.println("TEST FAILED: size check through isEmpty");
		
		//set2 is numbers
		MySortedSet set2 = new MySortedSet();
		if( !set2.add( 5 ) )
			System.err.println("TEST FAILED: adding new element");
		if( !set2.add( 1 ) )
			System.err.println("TEST FAILED: adding new element");
		if( !set2.add( 15 ))
			System.err.println("TEST FAILED: adding new element");
		if( !set2.contains( 1) )
			System.err.println("TEST FAILED: search element");
		set2.clear();
		if( !set2.isEmpty() )
			System.err.println( "TEST FAILED: size check through isEmpty");

		ArrayList<Integer> numbers = new ArrayList<Integer>(5);
		numbers.add(53);
		numbers.add(25);
		numbers.add(2);
		numbers.add(18);
		numbers.add(7);
		if( !set2.addAll( numbers ) )
			System.err.println("TEST FAILED: collection add");
		if( !set2.containsAll( numbers ))
			System.err.println("TEST FAILED: not all elements added");
		if( !set2.removeAll( numbers ))
			System.err.println("TEST FAILED: removing collection");
		if( !set2.isEmpty() )
			System.err.println("TEST FAILED: size check through empty");
		
		System.out.println("TESTING DONE.");
	}

}
