package assignment3;

import java.util.Random;

/**
 * @author Eli Dalton
 * @author Braden Davis
 * @param args
 */
public class MySortedSetTimer
{

	/**
	 * calls timer method
	 */
	public static void main(String[] args)
	{
		timer();
	}

	public static void timer()
	{
		MySortedSet s;
		MySortedSet t;
		long startTime, midTime, stopTime;

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000)
		{}

		int timesToLoop = 1000;

		System.out.println("Contains: ");

		for(int N = 100000; N <= 2000000; N += 100000)
		{
			for(int i = 0; i < timesToLoop; i ++)
			{
				s = new MySortedSet();
				for( int j = 0; j < N - 1; j++)
				{
					s.add(j);
					s.contains(j);
				}
			}

			midTime = System.nanoTime();

			for(int i = 0; i < timesToLoop; i ++)
			{
				s = new MySortedSet();
				for( int j = 0; j < N - 1; j++)
				{
					s.add(j);
					s.contains(j);
				}
			}

			stopTime = System.nanoTime();	

			double averageTime = ((midTime - startTime) - (stopTime - midTime))/timesToLoop;
			System.out.println(averageTime);
		}
		System.out.println("");
	}


}

