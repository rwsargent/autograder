package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author Eli Dalton & Braden Davis
 *
 * @param <E>
 *            -- the type of elements maintained by this set
 */

public class MySortedSet<E> implements SortedSet<E>
{
	int size;			// Number of objects in the SortedList array NOT the length of the sorted set
	E data[];
	Iterator<E> i = new SortedSetIterator();
	Comparator<? super E> comparer;

	/**
	 * Constructor. Returns an array of objects sorted using their natural sorting.
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet()
	{
		// use compareTo for natural ordering - IE the objects being passed in can be directly compared using the 'built in'
		// compareTo method for them. Int, string, etc. can be compared using their own comparison method.

		// a.compareTo(b); where a and b are E objects
		size = 0;
		data = (E[]) new Object[10];
		comparer = null;
		// User has to tell us whether the source is a compareTo-compliant source
		// We just tell Eclipse that with this method being called there is a compareTo method associated with the source
		// cmp would be null with this one
	}

	/**
	 * Constructor.
	 */
	public MySortedSet(Comparator<? super E> _comparer)
	{
		Comparator comparer = _comparer;
		// t.compare(a, b); if using this for comparison
		// where t is a comparator
		// Uses the compare method below
		// Returns a comparator with type <E>
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator()
	{
		if( MySortedSet.this instanceof Comparable)
			comparer = null;
		return comparer;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException
	{
		try
		{
			if (data[0] == null)
				throw new NoSuchElementException();
			else
				return data[0];
		}

		catch(NoSuchElementException e)
		{
			return null;
		}
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException
	{
		try
		{
			if (data[size] == null)
				throw new NoSuchElementException();
			else
				return data[size];
		}

		catch(NoSuchElementException e)
		{
			return null;
		}		
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(Object o)		// Which constructor to use? Check to see what needs to be created.
	{
		if (o == null)
			return false;
		E e = (E) o;
		if (size >= data.length - 1)
			grow();
		int beginning = 0, end = data.length - 1, middle;
		while (beginning <= end)
		{
			middle = (beginning + end) / 2;

			if (comparer == null)
			{
				if(data[middle] == null)
				{
					data[middle] = e;
					return true;
				}
				if (((Comparable) data[middle]).compareTo(e) == 0)
					return false;
				else if (((Comparable) data[middle]).compareTo(e) < 0)
				{	
					if((middle+1) < size)
					{
						data[middle+1] = e;
						return true;
					}
					if (((Comparable) data[middle + 1]).compareTo(e) > 0)
					{
						insert(e, middle + 1);
						size++;
						return true;
					}
					beginning = middle + 1;
				}
				else if (((Comparable) data[middle]).compareTo(e) > 0)
				{
					if(data[middle] == null)
					{
						data[middle] = e;
						return true;
					}
					if (((Comparable) data[middle - 1]).compareTo(e) < 0)
					{
						insert(e, middle - 1);
						size++;
						return true;
					}
					end = middle - 1;
				}
			}

			else {
				if(data[middle] == null)
				{
					data[middle] = e;
					return true;
				}
				if (comparer.compare(data[middle], e) == 0)
					return false;
				else if (comparer.compare(data[middle], e) < 0)
				{	
					if(data[middle+1] == null)
					{
						data[middle+1] = e;
						return true;
					}
					if (comparer.compare(data[middle + 1], e) > 0)
					{
						insert(e, middle + 1);
						size++;
						return true;
					}
					beginning = middle + 1;
				}
				else if (comparer.compare(data[middle], e) > 0)
				{
					if(data[middle-1] == null)
						data[middle-1] = e;
					if (comparer.compare(data[middle - 1], e) < 0)
					{
						insert(e, middle - 1);
						size++;
						return true;
					}
					end = middle - 1;
				}
			}
		}
		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c)
	{
		boolean flag = false;

		for (E genericThing : c)
			flag = flag || add(genericThing);
		return flag;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear()
	{
		E[] TempArray = (E[]) new Object[50];
		data = TempArray;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o)
	{
		if (this.size() == 0)
			return false;
		E e = (E) o;									// Type cast to E which is generic
		int beginning = 0, end = data.length - 1, middle;
		while (beginning <= end)
		{
			middle = (beginning + end) / 2;				// Calculate middle index

			if(comparer == null)
			{
				if (((Comparable) data[middle]).compareTo(e) == 0)		
					return true;
				else if (((Comparable) data[middle]).compareTo(e) < 0)
					beginning = middle + 1;					// Set the second half of the array to be the 'active' portion to search
				else if (((Comparable) data[middle]).compareTo(e) > 0)
					end = middle - 1;
			}
			else {
				if (comparer.compare(data[middle], e) == 0)		
					return true;
				else if (comparer.compare(data[middle], e) < 0)
					beginning = middle + 1;					// Set the second half of the array to be the 'active' portion to search
				else if (comparer.compare(data[middle], e) > 0)
					end = middle - 1;						// Set the first half of the array to be the 'active' portion to search
			}
		}

		return false;									// If we reach here, the object is not in the sorted set
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c)
	{
		boolean flag = true;
		for(Object item : c)
			flag = flag && contains(c);			// Flag will become false if one element is not in the sorted set
		return flag;
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty()
	{
		return size == 0;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator()
	{
		SortedSetIterator iter = new SortedSetIterator();
		return iter;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o)
	{
		if(!(contains(o)))								// False if the object isn't in there in the first place
			return false;	
		E e = (E) o;									// Type cast o as type E
		if (data[size].equals(e))						// If the object to be removed is the last item, remove it this way
			data[size] = null;			
		int i = 0;
		while (i-1 < size && (!(data[i].equals(e))))	// Iterate through until we stop on the item to be removed
			i++;
		while (i < size)								// Go up until the second to last one
		{
			data[i] = data[i+1];
			i++;										// Shift every item past the one to be removed left by one
		}
		size--;
		return true;									// If we hit this point, the object was successfully removed
	}

	/**
	 * Adds an object at the specified position in the array.
	 * @param e
	 * 		-- the object to insert into the array
	 * @param position
	 * 		-- the array slot at which said item will be inserted
	 */

	private boolean insert (E e, int position)
	{
		int i = position, j = size;
		while (j > i)				// Start at the end, working our way back towards the slot to insert the object at
		{
			data[j] = data[j-1];	// Shift everything over to the right by one
			j--;
			data[i] = e;			// Insert the object at the desired index
			return true;
		}
		return false;				// we shouldn't reach here but we need a return outside of the while statement if we fail
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c)
	{
		boolean flag = false;				// Set up a flag to keep track of progress

		for (Object o : c)					// Iterate through every object in Collection c
			if(o != null)					// As long as c does not contain a null element
				flag = flag || remove(o);	// remove that object from our Sorted Set and update flag
		return flag;						// This will only return false if no items were removed from our sorted set
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size()
	{
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray()
	{
		return (Object[]) data;									// Data is already sorted, we just return it type-cast
		// as an object array
	}

	/**
	 * This method is used to grow an array.
	 */
	@SuppressWarnings("unchecked")
	private void grow()
	{
		E[] TempArray = (E[]) new Object[data.length * 2];		// Create a temp array double the length of data
		for (int i = 0; i < data.length - 1; i++)				// Copy data over to the temp array
			TempArray[i] = data[i];
		data = TempArray;										// Reassign the temp array as data
	}

	/**
	 * This is the SortedSetIterator class.
	 * Methods are included to tell us if the collection has another item in it, what the next item is,
	 * and there is a method to remove the item most recently returned.
	 *
	 * @author Eli Dalton & Braden Davis
	 *
	 */
	private class SortedSetIterator implements Iterator<E>
	{
		int index;
		boolean calledNext;				// This is to keep track of if hasNext() has been called

		public SortedSetIterator()
		{
			index = -1;					// Start at -1 so that next can iterate over the item at index 0
			calledNext = false;
		}

		/**
		 * This method will simply tell us if the collection has another item in it after the one
		 * the index is currently sitting on. 
		 * 
		 * @return true if the collection has an object in the next index, false otherwise
		 */
		public boolean hasNext()
		{
			return (index + 1) < size;
		}

		/**
		 * This method returns the next item in the collection
		 * Throws a NoSuchElementException if no item exists
		 * 
		 * @return returns the item from the next index
		 */
		public E next()
		{
			if (!hasNext())
				throw new NoSuchElementException();
			calledNext = true;
			return data[++index];						// We pre-increment so that the item after the index we were
			// Sitting on is returned, and then we move to the next index
		}

		/**
		 * This method removes the item that was most recently returned by next()
		 * Throws IllegalStateException if next() still needs to be called.
		 */
		public void remove()
		{
			if (calledNext != true)
				throw new IllegalStateException();
			else
			{
				calledNext = false;
				MySortedSet.this.remove(data[index--]);	// We post-decrement so that our index remains unchanged
				// after an item is removed
			}
		}
	}
}