package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTester<E>
{
	// Creating collections to use for testing
	MySortedSet m = new MySortedSet();
	Collection<E> c = new ArrayList<E>();
	Collection<E> c2 = new ArrayList<E>();

	// Creating variables to use for testing. For this round of testing we opted to use Strings
	String s1 = new String("This ");
	String s2 = new String("is ");
	String s3 = new String("a ");
	String s4 = new String("long ");
	String s5 = new String("String.");
	String s6 = new String("the ");
	String s7 = new String("quick ");
	String s8 = new String("brown ");
	String s9 = new String("fox ");
	String s10 = new String("jumps ");
	String s11 = new String("over ");
	String s12 = new String("the ");
	String s13  = new String("lazy ");
	String s14 = new String("dog ");
	String s15 = new String("all ");
	String s16 = new String("day ");
	String s17 = new String("long.");

	@Before
	public void setUp() throws Exception
	{
		m = new MySortedSet();
	}

	@After
	public void tearDown() throws Exception
	{

	}

	@Test
	public void test()
	{
		assertTrue(m.add(s1));
		assertTrue(m.add(s2));
		assertTrue(m.add(s3));
		assertTrue(m.add(s4));
		assertTrue(m.add(s5));

		assertEquals(m.first(), s3);

		assertEquals(m.last(), s1);

		assertEquals(m.size(), 5);

		assertTrue(m.remove(s4));

		assertEquals(m.size(), 4);

		c.add((E) s1);
		c.add((E) s2);
		c.add((E) s3);
		c.add((E) s4);
		c.add((E) s5);

		assertFalse(m.containsAll(c));
		assertTrue(m.removeAll(c));
		assertFalse(m.remove(s4));
		assertFalse(m.remove("I'm not here"));
		assertFalse(m.removeAll(c));

		assertTrue(m.isEmpty());
		assertFalse(m.remove(s1));

		assertTrue(m.add(s6));
		assertTrue(m.add(s7));
		assertTrue(m.add(s8));
		assertTrue(m.add(s9));
		assertTrue(m.add(s10));
		assertTrue(m.add(s11));
		assertFalse(m.add(s12));
		assertTrue(m.add(s13));
		assertTrue(m.add(s14));
		assertTrue(m.add(s15));
		assertTrue(m.add(s16));
		assertTrue(m.add(s17));

		assertTrue(m.size() == 11);
		assertTrue(m.data.length == 20);

		assertFalse(m.add(null));

		assertTrue(m.contains(s15));
		assertFalse(m.contains(s5));
		assertFalse(m.containsAll(c));

		c2.add((E) s7);
		c2.add((E) s8);
		c2.add((E) s9);

		assertTrue(m.removeAll(c2));
		assertTrue(m.size() == 8);

		m.toArray();
		// Since we haven't written our compare implementation, we still need to figure out what order this would be.

		m.clear();

		assertTrue(m.size() == 0);

		assertFalse(m.contains(s10));

		fail("Not yet implemented");
	}
}