package assignment3;

/**
 * Lab 1 Timing Techniques
 * 
 * @author Teaching Staff
 *
 */
public class Timing {

	private static MySortedSet<Integer> m = new MySortedSet<Integer>();

	public static void main(String[] args) {
//		timeContains();
		timeAdd();
	}
	
	public static void timeContains() {
		long startTime, midpointTime, stopTime;

		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) { // empty block
		}

		// Now, run the test.

		long timesToLoop = 100;

		for (int z = 100000; z <= 2000000; z += 100000) {

			startTime = System.nanoTime();

			for (long i = 0; i < timesToLoop; i++)
				for (int j = 0; j < z; j++) {
					m.add(j);
					m.contains(j);
				}

			midpointTime = System.nanoTime();

			// Run an empty loop to capture the cost of running the loop.

			for (long i = 0; i < timesToLoop; i++) {
				for (int j = 0; j < z; j++) {
					m.add(j);
				}
			}

			stopTime = System.nanoTime();

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop;

			System.out.println(averageTime);
		}
	}
	
	public static void timeAdd() {
		long startTime, midpointTime, stopTime;

		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) { // empty block
		}

		// Now, run the test.

		long timesToLoop = 100;

		for (int z = 100000; z <= 2000000; z += 100000) {

			startTime = System.nanoTime();

			for (long i = 0; i < timesToLoop; i++)
				for (int j = 0; j < z; j++) {
					m.add(j);
				}
			midpointTime = System.nanoTime();

			// Run an empty loop to capture the cost of running the loop.

			for (long i = 0; i < timesToLoop; i++) {
				for (int j = 0; j < z; j++) {
				}
			}

			stopTime = System.nanoTime();
			
			for (int j = 0; j < z; j++) {
				m.remove(j);
			}

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop;

			System.out.println(averageTime);
		}
	}
}
