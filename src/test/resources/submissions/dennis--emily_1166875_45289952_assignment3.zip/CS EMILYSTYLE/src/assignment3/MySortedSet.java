package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Class to represent a sorted set
 * 
 * @author Emily Dennis, Rithie Penn
 */

public class MySortedSet<E> implements SortedSet<E> {

	// Member variables
	private E[] basicArray;
	private Comparator<? super E> comparator;
	private int size;

	// Constructor for MySortedSet
	@SuppressWarnings("unchecked")
	public MySortedSet() {
		basicArray = (E[]) new Object[25];
	}

	// Constructor for MySorted Set that takes in a comparator
	public MySortedSet(Comparator<? super E> comparator) {
		this.comparator = comparator;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * Searches for the specified object. Returns true if it is found, and false
	 * if it is not found
	 * 
	 * @param o
	 *            -- object we are searching for
	 * @return boolean -- if it contains the object we are searching for
	 */
	public boolean binarySearch(E o) {
		int maxIndex = size() - 1;
		int minIndex = 0;
		int midIndex = (minIndex + maxIndex) / 2;
		while (maxIndex >= minIndex) {
			int decisionMaker = compare((E) o, basicArray[midIndex]);
			if (decisionMaker == 0) {
				return true;
			} else if (decisionMaker == -1) {
				maxIndex = midIndex - 1;
				midIndex = (minIndex + maxIndex) / 2;
			} else if (decisionMaker == 1) {
				minIndex = midIndex + 1;
				midIndex = (maxIndex + minIndex) / 2;
			}
		}
		return false;
	}

	/**
	 * Searches for the position at which the object should be inserted, and
	 * returns that index
	 * 
	 * @param o
	 *            -- object we are searching for
	 * @return int -- index of insertion
	 */
	public int binarySearchPos(E o) {
		int maxIndex = size() - 1;
		int minIndex = 0;
		int midIndex = (minIndex + maxIndex) / 2;
		while (maxIndex >= minIndex) {
			int decisionMaker = compare((E) o, basicArray[midIndex]);
			if (decisionMaker == 0) {
				return midIndex;
			} else if (decisionMaker == -1) {
				maxIndex = midIndex - 1;
				midIndex = (minIndex + maxIndex) / 2;
			} else if (decisionMaker == 1) {
				minIndex = midIndex + 1;
				midIndex = (maxIndex + minIndex) / 2;
			}
		}
		return minIndex;
	}

	/**
	 * Compares the values of two objects
	 * 
	 * @param item1
	 * @param item2
	 * @return int -- the value of the comparison (e.g. 1, 0, -1)
	 */
	@SuppressWarnings("unchecked")
	private int compare(E item1, E item2) {
		if (comparator != null)
			return comparator.compare(item1, item2);
		return ((Comparable<E>) item1).compareTo(item2);
	}

	/**
	 * Throws indexOutOfBoundsException when a position is called that is out of
	 * bounds
	 * 
	 * @param int -- the index of the element we want
	 * @return E -- the element at the specified index
	 */
	public E get(int i) {
		try {
			return basicArray[i];
		} catch (IndexOutOfBoundsException e) {
			throw new IndexOutOfBoundsException();
		}
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (isEmpty()) {
			throw new NoSuchElementException();
		} else
			return basicArray[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (isEmpty()) {
			throw new NoSuchElementException();
		} else
			return basicArray[size() - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {
		// If the array is currently empty, just do simple add
		if (basicArray[0] == null) {
			basicArray[0] = o;
			size++;
			return true;
		}

		// if element is already present within array
		if (binarySearch(o)) {
			return false;
		}

		int pos = binarySearchPos(o);
		E[] tempArray = (E[]) new Object[0];
		if (basicArray.length == size()) {
			tempArray = (E[]) new Object[size() * 2];

			for (int j = 0; j < basicArray.length; j++) {
				tempArray[j] = basicArray[j];
			}
			basicArray = tempArray;

		}
		for (int i = basicArray.length - 1; i > pos; i--) {
			basicArray[i] = basicArray[i - 1];
		}

		basicArray[pos] = o;
		size++;
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean flag = false;
		for (E args : c) {
			if (this.add(args))
				flag = true;
		}
		return flag;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		for (int i = 0; i < basicArray.length; i++) {
			basicArray[i] = null;
		}
		size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */

	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		if (binarySearch((E) o)) {
			return true;
		} else
			return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		boolean flag = false;
		for (Object args : c) {
			if (this.contains(args))
				flag = true;
		}
		return flag;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (basicArray[0] != null) {
			return false;
		}
		return true;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new SortedSetIterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	@SuppressWarnings("unchecked")
	public boolean remove(Object o) { 
		if (binarySearch((E) o)) {
			int pos = binarySearchPos((E) o);
			E[] tempArray = (E[]) new Object[size() - 1];
			for (int j = 0; j < pos; j++) {
				tempArray[j] = basicArray[j];
			}
			if (pos < size() - 1) {
				for (int k = pos; k < size(); k++) {
					tempArray[k] = basicArray[k - 1];
				}
			}
			basicArray = tempArray;
			size--;
			return true;
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean flag = false;
		for (Object args : c) {
			if (this.remove(args))
				flag = true;
		}
		return flag;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		return basicArray;
	}

	/**
	 * Class that represents the implementation of the interface, Iterator
	 * 
	 * @author Emily Dennis, Rithie Penn
	 *
	 */
	private class SortedSetIterator implements Iterator<E> {

		int index = -1;
		boolean isnext = false;

		/**
		 * If there is a next item, return true.
		 */
		@Override
		public boolean hasNext() {
			if (index < size - 1) {
				return true;
			} else {
				return false;
			}
		}

		/**
		 * Returns the next item
		 */
		@Override
		public E next() {
			if (index >= size - 1) {
				throw new NoSuchElementException();
			}
			index++;
			isnext = true;
			return basicArray[index];
		}

		/**
		 * Removes the next index
		 */
		@Override
		public void remove() {
			if (isnext) {
				MySortedSet.this.remove(basicArray[index]);
			}
			isnext = false;
			index--;
		}

	}
}
