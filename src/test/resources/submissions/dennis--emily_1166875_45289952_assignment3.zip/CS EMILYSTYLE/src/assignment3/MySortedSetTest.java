package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest {

	private MySortedSet<Integer> emptySet, simpleSet1, simpleSet2, simpleSet3;
	private ArrayList<Integer> arrayToAddRemove, arrayToCompare;
	Iterator<Integer> iteratorInt;

	@Before
	public void setUp() throws Exception {
		emptySet = new MySortedSet<Integer>();

		simpleSet1 = new MySortedSet<Integer>();
		
		simpleSet2 = new MySortedSet<Integer>();
		simpleSet2.add(1);
		simpleSet2.add(2);
		simpleSet2.add(3);
		simpleSet2.add(4);
		simpleSet2.add(5);
		
		simpleSet3 = new MySortedSet<Integer>();
		simpleSet3.add(3);
		simpleSet3.add(7);
		simpleSet3.add(2);
		
		arrayToAddRemove = new ArrayList<Integer>();
		arrayToAddRemove.add(3);
		arrayToAddRemove.add(6);
		arrayToAddRemove.add(4);
		arrayToAddRemove.add(1);
		
		arrayToCompare = new ArrayList<Integer>();
		arrayToCompare.add(3);
		arrayToCompare.add(6);
		arrayToCompare.add(4);
		arrayToCompare.add(1);
		
		iteratorInt = simpleSet3.iterator();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFirst() {
		assertEquals((int) 1, (int) simpleSet2.first());
		assertEquals((int) 2, (int) simpleSet3.first());
	}

	@Test(expected = NoSuchElementException.class)
	public void testFirstException() {
		emptySet.first();
	}

	@Test
	public void testLast() {
		assertEquals((int) 5, (int) simpleSet2.last());
		assertEquals((int) 7, (int) simpleSet3.last());
	}

	@Test(expected = NoSuchElementException.class)
	public void testLastException() {
		emptySet.last();
	}

	@Test
	public void testBinarySearch() {
		assertEquals(true, simpleSet2.binarySearch(3));
		assertEquals(true, simpleSet3.binarySearch(7));
		assertEquals(false, simpleSet2.binarySearch(7));
		assertEquals(false, simpleSet3.binarySearch(1));
	}
	
	@Test
	public void testBinarySearchPos(){
		assertEquals(2, simpleSet3.binarySearchPos(4));
		assertEquals(0, simpleSet3.binarySearchPos(1));
		assertEquals(5, simpleSet2.binarySearchPos(6));
	}

	@Test
	public void testAdd() {
		simpleSet1.add(2);
		assertEquals(true, simpleSet1.contains(2));
		assertEquals(1, simpleSet1.size());
		
		simpleSet1.add(4);
		assertEquals(true, simpleSet1.contains(4));
		assertEquals(2, simpleSet1.size());
		
		simpleSet1.add(6);
		assertEquals(true, simpleSet1.contains(6));
		assertEquals(3, simpleSet1.size());
		
		simpleSet1.add(7);
		assertEquals(true, simpleSet1.contains(7));
		assertEquals(4, simpleSet1.size());
		
		simpleSet1.add(9);
		assertEquals(true, simpleSet1.contains(9));
		assertEquals(5, simpleSet1.size());
		
		simpleSet1.clear();
	}

	@Test
	public void testAddAll() {
		simpleSet1.addAll(arrayToAddRemove);
		assertEquals(1, (int) simpleSet1.get(0));
		assertEquals(3, (int) simpleSet1.get(1));
		assertEquals(4, (int) simpleSet1.get(2));
		assertEquals(6, (int) simpleSet1.get(3));
	}

	@Test
	public void testClear() {
		simpleSet1.clear();
		assertEquals(true, simpleSet1.isEmpty());
	}

	@Test
	public void testContains() {
		assertEquals(true, simpleSet2.contains(2));
		assertEquals(false, simpleSet3.contains(1));
	}

	@Test
	public void testContainsAll() {
		assertEquals(false, simpleSet1.containsAll(arrayToCompare));
		simpleSet1.addAll(arrayToAddRemove);
		assertEquals(true, simpleSet1.containsAll(arrayToCompare));
	}

	@Test
	public void testIsEmpty() {
		assertEquals(true, emptySet.isEmpty());
		simpleSet1.add(4);
		assertEquals(false, simpleSet1.isEmpty());
	}

	@Test
	public void testIterator() {
		assertEquals(true, iteratorInt.hasNext());
		assertEquals(2, (int) iteratorInt.next());
		assertEquals(3, (int) iteratorInt.next());
		assertEquals(7, (int) iteratorInt.next());
		
		iteratorInt.remove();
		assertEquals(2, simpleSet3.size());
	}

	@Test
	public void testRemove() {
		simpleSet3.remove(7);
		assertEquals(false, simpleSet3.contains(7));
	}

	@Test
	public void testRemoveAll() {
		simpleSet1.removeAll(arrayToAddRemove);
		assertEquals(false, simpleSet1.containsAll(arrayToCompare));
	}

	@Test
	public void testSize() {
		assertEquals(0, emptySet.size());
		assertEquals(5, simpleSet2.size());
		assertEquals(3, simpleSet3.size());
	}

	@Test
	public void testToArray() {
		Object[] referenceArray = {1, 2, 3, 4, 5};
		assertEquals(referenceArray[0], simpleSet2.toArray()[0]);
		assertEquals(referenceArray[1], simpleSet2.toArray()[1]);
		assertEquals(referenceArray[2], simpleSet2.toArray()[2]);
		assertEquals(referenceArray[3], simpleSet2.toArray()[3]);
		assertEquals(referenceArray[4], simpleSet2.toArray()[4]);
	}
}
