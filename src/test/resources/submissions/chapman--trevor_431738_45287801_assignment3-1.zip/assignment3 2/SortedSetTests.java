package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;

import org.junit.Test;

/**
 * Series of tests for the MySortedSet class
 * @author Trevor Chapman
 * @author Shibo Tang
 */
public class SortedSetTests
{
	@Test
	/**
	 * Tests that the add method adds in sorted order, and does not add duplicates
	 */
	public void testAdd1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(3);
		set.add(8);
		set.add(-1);
		set.add(0);
		set.add(-5);
		String correct = "-5 -1 0 1 2 3 8 ";
		assertEquals(correct, set.toString());
	}
	
	@Test
	/**
	 * Tests that the set can grow properly. If this test does not explode it works
	 */
	public void testAdd2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		Random rng = new Random(10);
		for(int i = 0; i < 100; i++)
		{
			int number = rng.nextInt(20);
			set.add(number); 
		}
	}
	
	@Test
	/**
	 * Tests to confirm first() works correctly
	 */
	public void testFirst1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(1);
		set.add(2);
		set.add(3);
		int first = set.first();
		assertEquals(first, 1);
	}
	
	@Test
	/**
	 * Test to confirm first() throws an error if no element is in the list
	 */
	public void testFirst2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		try
		{
			set.first();
		}
		catch(NoSuchElementException e)
		{
			
		}
	}
	
	@Test
	/**
	 * Test to confirm last() works
	 */
	public void testLast1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(1);
		set.add(2);
		set.add(3);
		int last = set.last();
		assertEquals(last, 3);
	}
	
	@Test
	/**
	 * Test to confirm last throws an error if empty
	 */
	public void testLast2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		try
		{
			set.last();
		}
		catch(NoSuchElementException e)
		{
			assertTrue(true);
		}
		
	}
	
	@Test
	/**
	 * Test to confirm isEmpty works if the set is empty
	 */
	public void testIsEmpty()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		assertTrue(set.isEmpty());
	}
	
	@Test
	/**
	 * Test to confirm isEmpty works correctly if the set is not empty
	 */
	public void testIsEmpty2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(0);
		assertFalse(set.isEmpty());
	}
	
	@Test
	/**
	 * Test to confirm size() works if set is empty
	 */
	public void sizeTest1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		assertEquals(set.size(), 0);
	}
	
	@Test
	/**
	 * Test to confirm size() works if set is not empty
	 */
	public void sizeTest2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(0);
		assertEquals(set.size(), 1);
	}
	
	@SuppressWarnings("deprecation")
	@Test
	/**
	 * Test to confirm toArray works correctly
	 */
	public void toArrayTest1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		Object[] arr = new Object[10];
		for(int i = 0; i < 5; i++)
		{
			set.add(i);
			arr[i] = i;
		}
		
		assertEquals(set.toArray(), arr);
	}
	
	@SuppressWarnings("deprecation")
	@Test
	/**
	 * Test to confirm toArray works if the set is empty
	 */
	public void toArrayTest2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		Object[] arr = new Object[10];
		assertEquals(set.toArray(), arr);
	}
	
	@Test
	/**
	 * Test to confirm clear() works correctly
	 */
	public void clearTest1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(0);
		set.add(1);
		set.clear();
		assertTrue(set.size() == 0);
		assertFalse(set.contains(0));
		assertFalse(set.contains(1));
	}
	
	@Test
	/**
	 * Test to confirm clear() works correctly if the set is empty
	 */
	public void clearTest2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.clear();
		assertTrue(set.size() == 0);
	}
	
	@Test
	/**
	 * Test to confirm that if the set is using natural ordering, it returns null
	 */
	public void comparatorTest1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		assertNull(set.comparator());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	/**
	 * Test to check that the comparator is correctly returned
	 */
	public void comparatorTest2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>(new ComparatorTest());
		Comparator<Integer> comparator = (Comparator<Integer>) set.comparator();
		assertNotNull(comparator);
	}
	
	@Test
	/**
	 * Test to confirm addAll works 
	 */
	public void addAllTest1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		ArrayList<Integer> set1 = new ArrayList<Integer>();
		
		for(int i = 0; i < 9; i++ ){
			set1.add(i);
		}
		assertTrue(set.addAll(set1));
		String correct = "0 1 2 3 4 5 6 7 8 ";
		assertEquals(correct, set.toString());
	}
	
	@Test
	/**
	 * Test to confirm contains returns true if everything is contained
	 */
	public void containsAllTest()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		ArrayList<Integer> set1 = new ArrayList<Integer>();
	
		for(int i = 0; i < 9; i++ ){
			set1.add(i);
		}
		set.addAll(set1);
		
		assertTrue(set.containsAll(set1));
	}
	
	@Test
	/**
	 * Test to confirm containAll returns false if it does not contain all
	 */
	public void containsAllTest2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		ArrayList<Integer> set1 = new ArrayList<Integer>();
		for(int i = 0; i < 9; i++ ){
			set1.add(i);
		}
		set.addAll(set1);
		set1.add(10);
		
		assertFalse(set.containsAll(set1));		
	}
	
	@Test
	/**
	 * Tests that the contains method works correctly 
	 */
	public void testContains1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(1);
		set.add(2);
		set.add(4);
		
		assertTrue(set.contains(1));
		assertTrue(set.contains(2));
		assertTrue(set.contains(4));
	}
	
	@Test
	/**
	 * Tests that the contains method does not cause an error if the set is empty
	 */
	public void testContains2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		assertFalse(set.contains(1));
	}
	
	@Test
	/**
	 * Test to confirm contains returns false if it does not contain
	 */
	public void testContains3()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(1);
		set.add(2);
		set.add(4);
		
		assertFalse(set.contains(3));
	}
	
	@Test
	/**
	 * Test to confirm remove works
	 */
	public void testRemove1()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(1);
		set.add(2);
		set.add(3);
		
		assertTrue(set.remove(2));
		
		assertFalse(set.contains(2));
		
	}
	
	@Test
	/**
	 * Test to confirm remove works if it tries to remove something not in the set
	 */
	public void testRemove2()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);
		set.add(5);
		
		set.remove(6);
		
		assertFalse(set.contains(6));		
	}

	@Test
	/**
	 * Test to confirm removeAll works
	 */
	public void removeAllTest()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		ArrayList<Integer> set1 = new ArrayList<Integer>(); 
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);
		set.add(5);
		set.add(6);
		
		for(int i = 0; i < 5; i ++)
			set1.add(i);
		
		set.removeAll(set1);
		
		assertFalse(set.contains(0));
		assertFalse(set.contains(1));
		assertFalse(set.contains(2));
		assertFalse(set.contains(3));
		assertFalse(set.contains(4));
		assertTrue(set.contains(5));
		assertTrue(set.contains(6));
		
		assertFalse(set.contains(4));		
		
		//System.out.println(set.toString());
	}
	
	/**
	 * Test to confirm the iterator works
	 */
	@Test
	public void iteratorTest()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		Iterator<Integer> iterator = set.iterator();
		
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);
		set.add(5);
		set.add(6);
		
		String correct = "1 2 3 4 5 6 ";
		String setString = "";
		
		while(iterator.hasNext())
			setString += iterator.next() + " ";
		
		assertEquals(correct, setString);
	}
	
	/**
	 * Test to confirm add works correctly with a comparator
	 */
	@Test
	public void addWithComparator()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>(new ComparatorTest());
		
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);
		set.add(5);
		set.add(6);
		
		String correct = "6 5 4 3 2 1 ";
		String setString = set.toString();
		
		assertEquals(correct, setString);
	}
	
	/**
	 * Test to confirm remove works with a comparator
	 */
	@Test
	public void removeWithComparator()
	{
		MySortedSet<Integer> set = new MySortedSet<Integer>(new ComparatorTest());
		
		set.add(1);
		set.add(2);
		set.add(3);
		set.add(4);
		set.add(5);
		set.add(6);
		
		set.remove(4);
		
		assertFalse(set.contains(4));
		
		String correct = "6 5 3 2 1 ";
		String setString = set.toString();
		assertEquals(correct, setString);
	}
	
	/**
	 * A protected comparator used in the *WithComparator tests
	 */
	  protected class ComparatorTest implements Comparator<Integer> 
	  {

		@Override
		/**
		 * Sorts in descending order
		 */
		public int compare(Integer o1, Integer o2)
		{
			int compareTo = o2.compareTo(o1);
			return -compareTo;
		}
	  }
}
