package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Trevor Chapman
 * @author Shibo Tang
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E>, Iterable<E>
{
	private int size;
	private Object array[];
	private Comparator<? super E> comparator;
	private boolean usingDefaultCompator;
	
	/**
	 * If no comparator is provided, it is assumed it is assumed to be using it's natural ordering for comparisons
	 */
	public MySortedSet()
	{
		array = new Object[10];
		comparator = new DefaultComparator();
		usingDefaultCompator = true;
		size = 0;
	}
	
	/**
	 * 
	 * @param e A custom comparator for sorting
	 */
	public MySortedSet(Comparator<? super E> e)
	{
		comparator = e;
		array = new Object[10];
		usingDefaultCompator = false;
		size = 0;
	}
	
	@Override
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator()
	{
		if(usingDefaultCompator)
			return null;
		
		return comparator;
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException
	{
		if(isEmpty())
			throw new NoSuchElementException();
		return (E) array[0];
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException
	{
		if(isEmpty())
			throw new NoSuchElementException();
		
		return (E) array[size-1];
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E target)
	{
		//If set is empty, add to first element and return true
		if(size == 0)
		{
			array[0] = target;
			size++;
			return true;
		}
		
		@SuppressWarnings("unused")
		
		int comparison = comparator.compare((E) array[size-1], target); //Compares target to last item in the array
		
		//If the last item in the array is smaller than the new item, add the new item to the end
		if(comparator.compare((E) array[size-1], target) > 0)
		{
			if(size+1 == array.length)
				grow();
			array[size] = target;
			size++;
			return true;
		}
		
		int position = binarySearch(target);
		
		//If the item is already in the array, return false
		if(array[position].equals(target))
			return false;
		
		//If the array is filled, grow the size of the array
		if(size+1 == array.length)
			grow();
		
		//Loop through moving everything in the array over one index
		for(int i = size; i >= position; i--)
		{
			array[i + 1] = array[i];
		}
		
		array[position] = target; //Places the target in the proper index
		size++;
		
		return true;
	}
	
	/**
	 * Increases the capacity of the array
	 */
	private void grow()
	{
		Object[] tempArr = new Object[size * 2];
		for(int i = 0; i < size; i++)
			tempArr[i] = array[i];
		
		array = tempArr;
	}

	@Override
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c)
	{
		boolean changedSet = false;
		
		for(E target : c)
		{
			if(add(target))
				changedSet = true;
		}
		
		return changedSet;
	}

	@Override
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear()
	{
		array = new Object[10];
		size = 0;
	}

	@SuppressWarnings("unchecked")
	@Override
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o)
	{
		if(isEmpty())
			return false;
		
		int index = binarySearch((E) o); //Get the index where the item is
		
		//If the item is in the array, return true. Else return false.
		if(o.equals(array[index]))
			return true;
		
		return false;
	}

	@Override
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c)
	{
		for(Object target: c)
			if(!contains(target))
				return false; //If an item is not in the set, return false
		
		return true;
	}

	@Override
	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty()
	{
		if(size == 0)
			return true;
		
		return false;
	}

	@Override
	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator()
	{
		return new newIterator();
	}

	@Override
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o)
	{
		if(size == 0)
			return false;
		
		int position = binarySearch((E) o);
		
		if(!contains(o))
			return false;
		
		
		for(int i = position; i < size-1; i++)
			array[i] = array[i+1];
		
		size--;
		
		return true;
	}

	@Override
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c)
	{
		boolean changedSet = false;
		
		for(Object target : c)
			if(remove(target)) //If the array is changed, flag it as true
				changedSet = true;
		
		return changedSet;
	}

	@Override
	/**
	 * @return the number of elements in this set
	 */
	public int size()
	{
		return size;
	}

	@Override
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray()
	{
		return array;
	}
	
	/**
	 * A private method that performs a binary search on the array. 
	 * @param o The object to search for
	 * @return If the element is in the set, the position where the element is located.
	 * 			If the element is not in the set, the position where the element should be added
	 */
	@SuppressWarnings("unchecked")
	private int binarySearch(E o)
	{
		int start = 0;
		int end = size-1;
		int mid = 0;
		while(start <= end)
		{
			mid = (start + end) / 2;
			int comparison = comparator.compare((E) array[mid], o);
			if(comparison == 0)
				return mid;
			if(comparison > 0)
				start = mid+1;
			if(comparison < 0)
				end = mid-1;
		}
		
		if(mid == start)
		{
			return mid;
		}
		
		return mid+1;
	}
	
	/**
	 * Returns a string representation of the array. Used mostly for testing
	 */
	public String toString()
	{
		String string = "";
		for(int i = 0; i < size; i++)
			string += array[i] + " ";
		return string;
	}
	
	private class newIterator implements Iterator<E>
	{
		int position = -1;
		
		@Override
		public boolean hasNext()
		{
			if(++position >= size)
				return false;
			return true;
		}

		@Override
		public E next()
		{	
			return (E) array[position];
		}

		@Override
		public void remove()
		{
			array[position] = null;
		}
		
	}
	
	/**
	 * If no comparator is provided, this class creates a comparator using the object's natural ordering
	 * @param <E>
	 */
	private static class DefaultComparator<E extends Comparable<? super E>> implements Comparator<E>
	{

		@Override
		public int compare(E o1, E o2)
		{
			return o2.compareTo(o1);
		}

	}
	
	

}
