package assignment3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;

import org.junit.Test;

import assignment2.LibraryBookGeneric;
import junit.framework.TestCase;

/**
 * 
 * @author Bolun Gao
 * @author Xiaohang Ding
 *
 * @param <E>
 */

public class MySortedSetTester extends TestCase {

	/**
	 * @throws java.lang.Exception
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

	/**
	 * first test add
	 */
	@Test
	public void test000() {
		OrderReverse comparator = new OrderReverse();
		MySortedSet<Object> arr = new MySortedSet<Object>();
		assertEquals(true, arr.size() == 0);
		arr.add("a");
		assertEquals(true, arr.size() == 1);
	}

	@Test
	/**
	 * test size method
	 */
	public void testSize() {
		MySortedSet<Object> arr = new MySortedSet<Object>();
		assertEquals(0, arr.size());

		int random = 100 + new Random().nextInt(50);
		for (int i = 0; i < random; i++) {
			arr.add(i);
		}

		assertEquals(true, random == arr.size());
	}

	/**
	 * test contains method
	 */
	@Test
	public void testcontains() {
		MySortedSet<Integer> arr = new MySortedSet<Integer>();
		int random = 100 + new Random().nextInt(50);

		for (int i = 0; i < random; i++) {

			arr.add(i);
		}
		for (int i = 0; i < random; i++) {
			assertTrue(arr.contains(i));
		}
	}

	/**
	 * test containsAll method.
	 */
	public void testcontainsAll() {
		MySortedSet<String> arr = new MySortedSet<String>();
		ArrayList<Object> arrObj = new ArrayList<Object>();
		int random = 100 + new Random().nextInt(50);
		for (int i = 0; i < random; i++) {

			arr.add("TEST" + i);
		}
		for (int i = 0; i < random; i += 3) {

			arrObj.add("TEST" + i);
		}

		assertEquals(true, arr.containsAll(arrObj));
	}

	/**
	 * test add method.
	 */
	public void testAddandReverse() {
		OrderReverse comparator = new OrderReverse();
		MySortedSet<Integer> arr = new MySortedSet<Integer>(comparator);
		int random = 100 + new Random().nextInt(50);

		for (int i = 5; i < random; i++) {

			arr.add(i);
		}
		int result = random - 1;
		assertEquals((Object) result, arr.first());

	}

	/**
	 * test the addAll method.
	 */
	public void testaddAll() {
		MySortedSet<String> arr = new MySortedSet<String>();
		ArrayList<String> arrObj = new ArrayList<String>();
		int random = 100 + new Random().nextInt(50);
		for (int i = 0; i < random; i++) {

			arr.add("TEST" + i);
		}
		for (int i = random; i < random + 100; i++) {

			arrObj.add("TEST" + i);
		}
		assertEquals(true, arr.addAll(arrObj));
		for (int i = 0; i < random; i++) {
			assertEquals(true, arr.contains("TEST" + i));
		}
	}

	/**
	 * test remove method
	 */
	public void testRemove() {
		MySortedSet<Integer> arr = new MySortedSet<Integer>();

		int random = 100 + new Random().nextInt(50);

		for (int i = 0; i < random + 1; i++) {

			arr.add(i);
		}
		for (int i = random; i > 5; i--) {
			arr.remove(i);
		}
		assertEquals(6, arr.size());
	}

	/**
	 * test removeAll method
	 */
	public void testRemoveAll() {
		MySortedSet<String> arr = new MySortedSet<String>();
		ArrayList<Object> arrObj = new ArrayList<Object>();
		int random = 100 + new Random().nextInt(50);
		for (int i = 0; i < random; i++) {

			arr.add("TEST" + i);
		}
		for (int i = 0; i < random; i += 3) {

			arrObj.add("TEST" + i);
		}
		assertEquals(true, arr.removeAll(arrObj));
		for (int i = 0; i < random; i++) {
			if (i % 3 != 0) {
				assertEquals(true, arr.contains("TEST" + i));
			} else {
				assertEquals(false, arr.contains("TEST" + i));
			}
		}
	}

	/**
	 * test isEmpty and clear method
	 */
	@Test
	public void testisEmptyandClear() {
		MySortedSet<Object> arr = new MySortedSet<Object>();
		int random = 100 + new Random().nextInt(50);
		for (int i = 0; i < random; i++) {
			arr.add(i);
		}
		arr.clear();
		assertTrue(arr.isEmpty());
	}

	/**
	 * @throws java.lang.Exception
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	protected class OrderReverse implements Comparator<Integer> {

		@Override
		public int compare(Integer o1, Integer o2) {
			return o2 - o1;
		}

	}

}
