package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import assignment2.LibraryBookGeneric;

/**
 * This is a class to make a basic array to store the elements which are type E
 * It allow user to add or remove the element and check if it is contain in the set 
 * @author Bolun Gao
 * @author Xiaohang Ding
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] arr;
	private Comparator<? super E> comparator;
	private int size;

	/**
	 * Constructer
	 */
	public MySortedSet() {
		size = 0;
		arr = (E[]) (new Object[10]);

	}

	/**
	 * Constructer
	 * 
	 * @param _comparator
	 */
	public MySortedSet(Comparator<? super E> _comparator) {
		this();
		comparator = _comparator;
	}

	/**
	 * comparator method
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * get first element
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (!isEmpty()) {
			return arr[0];
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * get last element
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (!isEmpty()) {
			return arr[size - 1];
		} else {
			throw new NoSuchElementException();
		}
	}

	/**
	 * add element into array
	 */
	@Override
	public boolean add(E o) {
		if (contains(o)) {
			return false;
		} else {
			E[] temp;

			if (size < arr.length)
				temp = (E[]) (new Object[arr.length]);
			else
				temp = (E[]) (new Object[arr.length * 2]);

			int low = 0;
			int high = size;
			int pos = 0;

			while (high > low) {
				if (comparator == null) {
					if (((Comparable<E>) o).compareTo(arr[(high + low) / 2]) > 0) {
						low = (high + low) / 2 + 1;
						pos = low;
					} else if (((Comparable<E>) o)
							.compareTo(arr[(high + low) / 2]) < 0) {
						high = (high + low) / 2;
						pos = high;
					}

				} else {
					if (comparator.compare(o, arr[(high + low) / 2]) > 0) {
						low = (high + low) / 2 + 1;
						pos = low;
					} else if (comparator.compare(o, arr[(high + low) / 2]) < 0) {
						high = (high + low) / 2;
						pos = high;
					}
				}
			}

			for (int i = 0; i < pos; i++) {
				temp[i] = arr[i];
			}

			temp[pos] = o;
			size++;
			for (int i = pos + 1; i < size; i++) {
				temp[i] = arr[i - 1];
			}
			arr = temp;
			return true;
		}
	}
/**
 * add a collection into array
 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		if (!containsAll(c)) {
			for (Object o : c) {
				if (!contains((E) o))
					add((E) o);
			}
			return true;
		} else
			return false;
	}
/**
 * clear all the elements in array
 */
	@Override
	public void clear() {
		for (int i = 0; i < size; i++) {
			arr[i] = null;
		}
		size = 0;
	}
	/**
	 *  check element whether in the array or not
	 */
	@Override
	public boolean contains(Object o) {
		if (size == 0) {
			return false;
		}
		int start = 0;
		int last = size;
		while (start <= last && (start + last) / 2 < size) {
			int mid = (start + last) / 2;
			if (arr[mid].equals(o)) {
				return true;
			} else if (comparator == null) {
				try {
					if (((Comparable<E>) o).compareTo(arr[mid]) > 0) {
						start = mid + 1;
					} else {
						last = mid - 1;
					}
				} catch (Exception e) {
					return false;
				}
			} else {
				if (comparator.compare((E) o, arr[mid]) > 0) {
					start = mid + 1;
				} else {
					last = mid - 1;
				}
			}
		}
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		for (int i = 0; i < c.size(); i++) {
			if (!contains((E) c.toArray()[i]))
				return false;
		}
		return true;
	}
/**
 * check the array is empty or not
 */
	@Override
	public boolean isEmpty() {
		if (size == 0)
			return true;
		else
			return false;
	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return new MySortedSetIterator();
	}
	/**
	 * remove element from that array
	 */
	@Override
	public boolean remove(Object o) {
		if (!contains((E) o)) {
			return false;
		} else {

			int low = 0;
			int high = size - 1;
			int pos = 0;

			while (!arr[pos].equals(o)) {
				if (comparator == null) {
					if (((Comparable<E>) o).compareTo(arr[(high + low) / 2]) > 0) {
						low = (high + low) / 2 + 1;
						pos = low;
					} else if (((Comparable<E>) o)
							.compareTo(arr[(high + low) / 2]) < 0) {
						high = (high + low) / 2 - 1;
						pos = high;
					} else
						pos = (high + low) / 2;

				} else {
					if (comparator.compare((E) o, arr[(high + low) / 2]) > 0) {
						low = (high + low) / 2 + 1;
						pos = low;
					} else if (comparator.compare((E) o, arr[(high + low) / 2]) < 0) {
						high = (high + low) / 2 - 1;
						pos = high;
					} else
						pos = (high + low) / 2;
				}
			}

			for (int i = pos; i < size - 1; i++) {
				arr[i] = arr[i + 1];
			}
			arr[size - 1] = null;
			size--;
			return true;
		}
	}

	@Override
	public boolean removeAll(Collection<?> c) {

		boolean bool = false;
		for (Object o : c) {
			if (remove((E) o))
				bool = true;
		}
		return bool;
	}
	/**
	 *  get array
	 */
	@Override
	public int size() {
		return size;
	}

	@Override
	public Object[] toArray() {

		return arr;
	}

	/**
	 *  This is a class for Iterator
	 *  
	 *  
	 * @author Bolun Gao & Xiaohang Ding
	 *
	 */
	private class MySortedSetIterator implements Iterator<E> {
		int index;
		boolean gotNext;

		public MySortedSetIterator() {
			index = 0;
			gotNext = false;
		}

		/**
		 * 
		 * @return true if has next
		 */
		public boolean hasNext() {
			return index < size;
		}

		/**
		 * 
		 * @return an element(E) in the index+1
		 * 
		 * @throws NoSuchElementException
		 * 			if there are nothing in the index next+1
		 * 
		 */
		public E next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			index += 1;
			gotNext = true;
			return MySortedSet.this.arr[index - 1];
		}

		/**
		 * remove the element
		 * 
		 * @throws IllegalStateException
		 */
		public void remove() {
			if (!gotNext) {
				throw new IllegalStateException();
			}
			gotNext = false;
			MySortedSet.this.remove(MySortedSet.this.arr[index]);
			index--;
		}
	}

}
