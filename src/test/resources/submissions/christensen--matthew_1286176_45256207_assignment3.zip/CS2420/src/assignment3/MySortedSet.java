package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Arrays;

/**
 * A list which can take in any comparable object or an object that uses a comparator.
 * Whenever elements are added to the set, they are placed such that the set maintains
 * the natural ordering of the elements, that is, it is always sorted.
 * 
 * @author Matthew Christensen (u0899251) & Patrick McHugh (u0883718)
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] set;
	private int size;
	private Comparator<? super E> comparator;
	private boolean usesComparator;

	/**
	 * Create a new empty MySortedSet without using a comparator. Elements added
	 * should implement the Comparable interface
	 */
	public MySortedSet() {
		set = (E[]) new Object[8];
		size = 0;
		comparator = null;
		usesComparator = false;
	}

	/**
	 * Create a new MySortedSet using a comparator. Elements added to the list
	 * must be accepted by the comparator.
	 * 
	 * @param c
	 */
	public MySortedSet(Comparator<? super E> c) {
		set = (E[]) new Object[8];
		size = 0;
		comparator = c;
		usesComparator = true;

	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first element currently in this set (which will be the smallest, since it is sorted)
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		return set[0];
	}

	/**
	 * @return the last element currently in this set (which will be the largest since the set is sorted)
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		return set[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E e) {
		//Returns false if the set already contains the element, or the element is null
		if (this.contains(e) || e == null) {
			return false;
		}
		//If the array that we are using internally runs out of space
		//this creates a new array that is double the length, and copies
		//the old array into the new one
		if (set.length == size) {
			set = Arrays.copyOf(set, set.length * 2);
		}
		//Adds the first element in the list, without a sort (since it's unnecessary)
		if(size == 0){
			set[size++]= e;
			return true;
		}
		//Adds the element into the list with the sortedInsert() method
		//which will place the element into the array at the correct, sorted, spot.
		sortedInsert(e, 0, size - 1);
		size++;

		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		//Changed will remain false if no elements are added into the set
		boolean changed = false;
		//Goes through every element in the collection of type E and 
		//attempts to add each into MySortedSet
		for (E e : c)
			if (add(e))
				//Since an element was successfully added into the set, the
				//method will return true
				changed = true;
		return changed;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		//Goes through every element in the internal array, set, and sets 
		//each to null
		for (int i = 0; i < size; i++) {
			set[i] = null;
		}
		//Sets the size of the set to 0
		size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		try {
			//Performs a binary search of the set to see if 
			//it contains the element.  The binarySearch will return -1 if the element is not in the set,
			//so if the result is not -1, then the set must contain the element
			if (binarySearch((E) o, 0, size - 1) != -1)
				return true;

		} 
		//if the search throws any exception, then the element is not contained in the set
		catch (Exception e) {
			return false;
		}

		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		//Goes through every element in the set and checks if each
		//element is contained in the set individually.  If any of the
		//elements is not contained in the set, the method returns false.
		for (Object o : c)
			if (!contains(o))
				return false;
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {

		return new MySortedSetIterator(this);
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int index;
		
		try {
			index = binarySearch((E) o, 0, size - 1);
		} 
		catch (ClassCastException e) {
			return false;
		}
		if (index == -1)
			return false;
		int elementsMoved = size - index - 1; // Insipired by the remove() method in ArrayList.class
		if (elementsMoved > 0)
			//Takes every element after the specified element and copies
			//it to the left by one element in the same array 
			System.arraycopy(set, index + 1, set, index, elementsMoved);
		//Deletes the last element of the former array and decrements size,
		//so it is no longer considered a part of the set
		set[--size] = null;
		return true;
	}
	/**
	 * A method which allows you to remove an element in the set by an index
	 * @param index
	 */
	private void removeByIndex(int index) {
		if (index < 0 || index > size -1){
			throw new IndexOutOfBoundsException();
		}
		int elementsMoved = size - index - 1; // Insipired by the remove() method in ArrayList.class
		if (elementsMoved > 0)
			//Takes every element after the specified element and copies
			//it to the right by one element in the same array 
			System.arraycopy(set, index + 1, set, index, elementsMoved);
		//Deletes the last element of the former array and decrements size,
		//so it is no longer considered a part of the set
		set[--size] = null;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean changed = false;
		//Goes through every element in the collection and tries to remove
		//each element individually.
		for (Object o : c)
			if (remove(o))
				changed = true;
		return changed;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		return Arrays.copyOf(set, size);
	}

	/**
	 * 
	 * @param element
	 * @param start
	 * @param end
	 * @return the index of the element being searched for in the MySortedSet.
	 *         If the element is not present, returns -1
	 */
	private int binarySearch(E element, int start, int end) {
		int midpoint = (start + end) / 2;
		//Tests if the set is using a comparator
		if (usesComparator) {
			//If the starting index has surpassed the ending index, then the element
			//is not present, since all elements that were between the starting and ending index
			//have already been tested.
			if (start > end) {
				return -1;
			}
			//comparison will be -1 if the element is less than the midpoint,
			//0, if the element is the midpoint, and 1 if the element is greater than the midpoint
			int comparison = comparator.compare(element, set[midpoint]);
			if (comparison < 0) {
				//Does a new binary search with half of the previous set
				return binarySearch(element, start, midpoint - 1);
			} 
			else if (comparison == 0) {
				return midpoint;
			} 
			else {
				return binarySearch(element, midpoint + 1, end);
			}

		} 
		//Does a binarySearch assuming that the element is comparable
		else if (element instanceof Comparable<?>) {
			Comparable<? super E> compElement;
			try {
				compElement = (Comparable<? super E>) element;
			} 
			//If there is any problem with casting the type of the element
			//returns -1, as it can't be in the set
			catch (ClassCastException e) {
				return -1;
			}
			//If the starting index has surpassed the ending index, then the element
			//is not present 
			if (start > end) {
				return -1;
			}
			//comparison will be -1 if the element is less than the midpoint,
			//0, if the element is the midpoint, and 1 if the element is greater than the midpoint
			int comparison = compElement.compareTo(set[midpoint]);
			if (comparison < 0) {
				//Performs a new binary search on half of the previous set
				return binarySearch(element, start, midpoint - 1);
			} 
			else if (comparison == 0) {
				return midpoint;
			} 
			else {
				//Performs a new binary search on half of the previous set
				return binarySearch(element, midpoint + 1, end);
			}
		}
		//If the element is not comparable and does not use a Comparator, it 
		//must not be in the set.
		return -1;
	}

	/**
	 * A method for inserting a new element into MySortedSet so that it is added
	 * in sorted order. Assumes that the element is not in the set array.
	 * 
	 * @param element
	 *            --The element that is being inserted
	 * @param start
	 *            --The index whose element will be compared to element.
	 * @param end
	 *            --The index whose element will be compared to element.
	 */
	private void sortedInsert(E element, int start, int end) {
		int midpoint = (start + end) / 2;
		//Checks if the element uses a Comparator
		if (usesComparator) {
			//If the starting index is equal to the ending index, then that is the index that we want to 
			//insert the element at
			if (start >= end) {
				//If the element is less than the element at the starting index, copies the array
				//from that index one spot to the right, and sets that index (which is now "empty") 
				//to the element
				if (comparator.compare(element, set[start]) < 0) {
					System.arraycopy(set, start, set, start + 1, size - start);
					set[start] = element;
				} 
				//If the element is greater than the element at starting index, copies the array after that index one spot
				//to the right, and sets the element at the index one spot to the right of the starting index to the element passed in
				else {
					System.arraycopy(set, start + 1, set, start + 2, size
							- (start + 1));
					set[start + 1] = element;
				}
			} 
			//If the starting index does not equal the ending index, performs another insert, halving the size of the set until the
			//starting index does equal the ending index
			else {
				int comparison = comparator.compare(element, set[midpoint]);
				if (comparison < 0) {
					sortedInsert(element, start, midpoint - 1);
				} 
				else if (comparison == 0) {
					return;
				} 
				else {
					sortedInsert(element, midpoint + 1, end);
				}
			}
		}
		//The case when the element implements Comparable
		else if (element instanceof Comparable<?>){
			Comparable<E> compElement;
			
			try {
				compElement = (Comparable<E>) element;
			} 
			//If there is any sort of exception trying to cast the element, then 
			//it can't be inserted into the set.
			catch (ClassCastException e) {
				return;
			}
			//If the starting index is equal to the ending index, then that is the index that we want to 
			//insert the element at
			if (start >= end) {
				//If the element is less than the element at the starting index, copies the array
				//from that index one spot to the right, and sets that index (which is now "empty") 
				//to the element
				if (compElement.compareTo(set[start]) < 0) {
					System.arraycopy(set, start, set, start + 1, size - start);
					set[start] = element;
				} 
				//If the element is greater than the element at starting index, copies the array after that index one spot
				//to the right, and sets the element at the index one spot to the right of the starting index to the element passed in
				else {
					System.arraycopy(set, start + 1, set, start + 2, size
							- (start + 1));
					set[start + 1] = element;
				}
			} 
			//If the starting index does not equal the ending index, performs another insert, halving the size of the set until the
			//starting index does equal the ending index
			else {
				
				int comparison = compElement.compareTo( set[midpoint]);
				if (comparison < 0) {
					sortedInsert(element, start, midpoint - 1);
				} 
				else if (comparison == 0) {
					return;
				} 
				else {
					sortedInsert(element, midpoint + 1, end);
				}
			}
		}
	}

	/**
	 * 
	 * @param index
	 * @return element at the given index
	 */
	public E get(int index) {
		if (index < size) {
			return set[index];
		} else {
			throw new ArrayIndexOutOfBoundsException();
		}
	}

	/**
	 * Returns a string representation of the list.
	 */
	@Override
	public String toString() {
		String string = "[";
		int currentIndex = 0;
		for (E e : set) {
			if (e != null)
				//Make use of each element's toString() method
				string = string + e.toString();
			//Add commas between elements
			if (currentIndex < size() - 1)
				string = string + ", ";
			currentIndex++;
		}
		return string + "]";
	}
	
	public String toStringln(){
		String string = "[";
		int currentIndex = 0;
		for (E e : set) {
			if (e != null)
				//Make use of each element's toString() method
				string = string + e.toString();
			//Add commas between elements
			if (currentIndex < size() - 1)
				string = string + "\n";
			currentIndex++;
		}
		return string + "]";
	}

	/**
	 * An iterator that moves through a MySortedSet.
	 * @author Matt Christensen & Patrick McHugh
	 *
	 */
	protected class MySortedSetIterator implements Iterator<E> {

		/*
		 * memory representation: the list being iterated through, and the current index in that list. 
		 * (also, whether or not the list is currently capable of running remove)
		 */
		private int currentIndex;
		private MySortedSet<E> sortedSet;
		private boolean ableToRemove;

		/**
		 * Creates a new MSSIterator using the provided set.
		 * @param mySortedSet
		 */
		public MySortedSetIterator(MySortedSet<E> mySortedSet) {
			sortedSet = mySortedSet;
			ableToRemove = false;
			currentIndex = 0;
		}

		/**
		 * If there are elements left in the iterator, returns true. If there are none, returns false.
		 */
		@Override
		public boolean hasNext() {
			if (currentIndex >= sortedSet.size()) {
				return false;
			}
			return true;
		}

		/**
		 * Returns the next element in the iterator from the set.
		 */
		@Override
		public E next() {
			if (this.hasNext()) {
				ableToRemove = true;
				return sortedSet.get(currentIndex++);
			} else {
				throw new NoSuchElementException();
			}
		}

		/**
		 * Removes the last element passed over by the iterator from the sorted set.
		 */
		@Override
		public void remove() {
			if (ableToRemove) {
				sortedSet.removeByIndex(currentIndex - 1);
				//Change currentIndex to account for the shift in the list
				currentIndex--;
				ableToRemove = false;
			} else {
				throw new IllegalStateException();
			}
		}

	}

}
