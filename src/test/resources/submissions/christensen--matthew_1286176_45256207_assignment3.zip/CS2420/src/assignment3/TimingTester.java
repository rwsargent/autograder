package assignment3;

/**
 * A class built solely for testing the running times of contains and add methods.
 * @author Matthew Christensen	& Patrick McHugh
 *
 */
public class TimingTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		long startTime, stopTime;

		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000L) { // empty block
		}

		long timesToLoop = 10000L;

		for (long i = 100000; i <= 2000000; i += 100000) {

			MySortedSet<Integer> set = new MySortedSet<Integer>();
			for (int d = 1; d <= i; d++)
				set.add(d);
			Integer inte = new Integer(-1);

			long time = 0;
			for (int j = 0; j < timesToLoop; j++) {
				
				startTime = System.nanoTime();
				set.add(inte);					//Currently setup to test the add method.
				stopTime = System.nanoTime();
				set.remove(inte);
				
				time += (stopTime - startTime);
			}
			long average = time/timesToLoop;
			System.out.println(average);

		}

	}
}
