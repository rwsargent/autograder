package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.NoSuchElementException;

import assignment2.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * A JUnit tester class for MySortedSet
 * (Uses the classes in the assignment2 package for testing.)
 * @author Matthew Christensen & Patrick McHugh
 *
 */
public class MySortedSetTester {

	private MySortedSet<LibraryBookGeneric<String>> bookSet;

	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}
	/**
	 * A test for making sure that MySortedSet can handle an arbitrary class that uses a comparator,
	 * and that a few of the methods work
	 * 
	 * IMPORTANT: requires a completed assignment2 package to be in the project. If no such package is available, just comment these tests out.
	 * an assignment 2 package was provided when this was turned in
	 */
	@Test
	public void testLibraryBookSortedSet() {		
		LibraryGeneric<String> library = new LibraryGeneric<String>();
		library.addAll("Mushroom_Publishing.txt");
		ArrayList<LibraryBookGeneric<String>> inventory = library.getInventoryList();
		bookSet = new MySortedSet<LibraryBookGeneric<String>>(library.new OrderByAuthor());
		bookSet.addAll(inventory);
		//Tests the arrangement to make sure the books are sorted by author alphabetically
		assertEquals (9781843193319L, bookSet.get(0).getIsbn());
	    assertEquals (9781843192039L, bookSet.get(bookSet.size() - 1).getIsbn());
	    assertEquals (9781843190479L, bookSet.get(1).getIsbn());
	    //Prints out a string representation of the set for visual confirmation
	    System.out.print(bookSet.toStringln());
	}
	/**
	 * Tests that MySortedSet can hold an arbitrary type that implements comparable,
	 * and that a few of the methods work
	 */
	@Test 
	public void testComparableSortedSet () {
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(3);
		set.add(5);
		set.add(1);
		set.add(4);
		set.add(2);
		set.add(3);//Duplicates, should not be in set
		set.add(1);
		
		assertEquals (new Integer (1), set.first());
		assertEquals (new Integer(5), set.last());
		assertEquals (5, set.size());
		assertEquals (true, set.contains(new Integer (2)));
		assertTrue (set.remove(new Integer(4)));
		assertEquals (4, set.size());
		assertFalse (set.remove(new Integer (25)));
		assertFalse (set.contains(25));
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(3);
		list.add(5);
		assertTrue (set.removeAll(list));
		assertFalse (set.removeAll(list));
		assertEquals (1, set.size());
	}
	
	/**
	 * A test for the add() and addAll() methods (using GregorianCalendars for style points)
	 */
	@Test 
	public void testAdding() {
		MySortedSet<GregorianCalendar> set = new MySortedSet<GregorianCalendar>();
		assertTrue (set.add(new GregorianCalendar(1980, 9, 2)));
		assertTrue (set.add(new GregorianCalendar(1981, 8, 4)));
		assertTrue (set.add(new GregorianCalendar(1982, 1, 13)));
		assertTrue (set.add(new GregorianCalendar(1985, 7, 5)));
		assertTrue (set.add(new GregorianCalendar(1985, 12, 7)));
		assertTrue (set.add(new GregorianCalendar(1985, 5, 4)));
		
		ArrayList<GregorianCalendar> list = new ArrayList<GregorianCalendar>();
		list.add(new GregorianCalendar (1782,1, 1));
		list.add(new GregorianCalendar (1582,11, 4));
		list.add(new GregorianCalendar (1776,7, 4));
		list.add(new GregorianCalendar (1941,12, 7));
		
		assertTrue (set.addAll(list));
		assertFalse (set.addAll(list));
		assertFalse (set.add(new GregorianCalendar(1982, 1, 13)));
	}
	
	/**
	 * A test for the remove(), removeAll(), and clear() methods.
	 */
	@Test
	public void testClearAndRemove() {
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(3);
		set.add(5);
		set.add(1);
		set.add(4);
		set.add(2);
		
		assertTrue (set.remove(new Integer(5)));
		assertTrue (set.remove(new Integer(1)));
		assertFalse (set.remove("Hello World"));
		assertFalse (set.remove("Daddy"));
		assertFalse (set.remove(new GregorianCalendar (2020, 11, 1)));
		
		set.clear();
		assertEquals (0, set.size());
		assertFalse (set.remove(new Integer (2)));
		
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(3);
		list.add(5);
		list.add(1);
		list.add(4);
		list.add(2);
		set.addAll(list);
		
		assertTrue (set.removeAll(list));
		assertFalse (set.removeAll(list));
	}
	
	/**
	 * Tests the toArray() method
	 */
	@Test
	public void testToArray() {
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		assertArrayEquals (new Integer[] {}, set.toArray());
		
		set.add(new Integer(1));
		set.add(new Integer(2));
		set.add(new Integer(-1));
		set.add(new Integer(-6));
		set.add(new Integer(20));
		Integer[] array = new Integer[] {-6, -1, 1, 2, 20};
		
		assertArrayEquals (array, set.toArray());
		set.clear();
		assertArrayEquals (new Integer[] {}, set.toArray());
	}
	
	/**
	 * Tests the MySortedSetIterator to be sure that it performs its job acceptably
	 */
	@Test
	public void testIterator () {
		//Create a set and add some stuff to it
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		set.add(new Integer(1));
		set.add(new Integer(2));
		set.add(new Integer(-1));
		set.add(new Integer(-6));
		set.add(new Integer(20));
		
		Iterator<Integer> iterator = set.iterator();
		
		
		
		//Go through and ensure that the iterator returns the same values that the set contains by using the .next() method
		while(iterator.hasNext()){
			assertEquals(iterator.next(), set.first());
			
			iterator.remove();
		}
		
		//Iterator should have consumed all of the elements by now, so calling .next() should throw an exception
		try{
			iterator.next();
			fail("You failed it!");
		} catch(NoSuchElementException e){
			System.out.println("        vvv Required readings vvv");
		}
		
		assertFalse(iterator.hasNext());
	}
	

}
