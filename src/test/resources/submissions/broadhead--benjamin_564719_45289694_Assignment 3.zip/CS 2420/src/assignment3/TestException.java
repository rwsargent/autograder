package assignment3;

/**
 * @author Ben Broadhead, Christian Luciani
 * 
 */

/**
 * Generic Testing class for Java. Used in place of Junit Testing because result are displayed to the console.
 * Represents test generated exceptions
 */
public class TestException extends RuntimeException {
	
	private static final String EXCEPTION_PREFIX = "Test Exception: ";

	private static final long serialVersionUID = 1L;

	/**
	 * Customizes the exception message
	 * 
	 * @param message A description of the issue
	 */
	public TestException(String message) {
		super(EXCEPTION_PREFIX + message);
	}

}
