	package assignment3;
     
    import java.util.ArrayList;
    import java.util.Iterator;
    import static org.junit.Assert.*;
    
    /**
     * @author Ben Broadhead, Christian Luciani
     * 
     */
     
    public class TestMySortedSet extends TestBase {
     
     
            public static void main(String[] args) {
                    new TestMySortedSet().runTests();
     
            }
     
            public void testAdd() {
                    int addList[] = {7, 1, 5, 3, 11, 9};
                    Object expectedList[] = {1, 3, 5, 7, 9, 11};
                    SortedSet<Integer> sortedSet = new MySortedSet<Integer>();
                   
                    // Make sure that an unordered list is automatically converted to an ordered list
                    for (int i = 0; i < addList.length; i++) {
                            sortedSet.add(addList[i]);
                    }
                   
                    Object actualList[] = sortedSet.toArray();
                   
                    assertEquals(actualList.length, 6);
                    assertTrue(areEqual(actualList, expectedList));
                   
                    // Make sure that you can't insert an existing number
                    expectedList = actualList;
                    assertFalse(sortedSet.add(7));
                    actualList = sortedSet.toArray();
                    assertTrue(areEqual(actualList, expectedList));
            }
           
           
            public void testRemoveAll()     {
                    int addList[] = {1, -10, 3, 14, 12, 20};
                   
                    ArrayList<Integer> removalList = new ArrayList<Integer>();
                    removalList.add(01);
                    removalList.add(-10);
                    removalList.add(14);
                    removalList.add(25);
                   
                    Object expectedList[] = {3, 12, 20};
                   
                    SortedSet<Integer> sortedSet = new MySortedSet<Integer>();
                   
                    for(int i = 0; i < addList.length; i++){
                            sortedSet.add(addList[i]);
                    }
                   
                    //Test removeAll() with last element not in the set
                    assertTrue(sortedSet.removeAll(removalList));
                   
                    Object actualList[] = sortedSet.toArray();
                    assertEquals(actualList.length, expectedList.length);
                    assertTrue(areEqual(actualList, expectedList));
            }
           
           
            public void testAllMethods(){
                    //Create a new instance of MySortedSet
                    SortedSet<Integer> sortedSet = new MySortedSet<Integer>();
                   
                    //Create a collection of 12 unique elements
                    ArrayList<Integer> list1 = new ArrayList<Integer>();
                    for(int i = 0; i < 12; i ++){
                            list1.add(i);
                    }
                   
                    //Test addAll() by adding all elements from list1 to sortedSet
                    sortedSet.addAll(list1);
                    assertEquals(sortedSet.size(), list1.size());
                   
                    //Test removeAll() then re-add elements
                    sortedSet.removeAll(list1);
                    assertEquals(sortedSet.size(), 0);
                    sortedSet.addAll(list1);
                   
                   
                    //Test toArray() and size()
                    assertEquals(sortedSet.toArray().length, sortedSet.size());
                   
                    //Create a new collection of elements even indexed elements from the sortedSet using iterator()
                    ArrayList<Integer> list2 = new ArrayList<Integer>();
                   
                    Iterator<Integer> itr = sortedSet.iterator();
                   
                    while (itr.hasNext()){
                            list2.add(itr.next());
                           
                            if(itr.hasNext())
                                    itr.next();
                    }
                   
                    //Test conatinsAll()
                    assertTrue(sortedSet.containsAll(list2));
                   
                    //Test contains()
                    assertTrue(sortedSet.contains(sortedSet.first()));
                   
                    //Test remove()
                    assertTrue(sortedSet.remove(sortedSet.last()));
                   
                    //Test clear() & isEmpty()
                    sortedSet.clear();
                    assertTrue(sortedSet.isEmpty());
            }
           
            private boolean areEqual(Object[] arr1, Object[] arr2) {
                    for (int i = 0; i < arr1.length; i++) {
                            if (!arr1[i].equals(arr2[i])) {
                                    return false;
                            }
                    }
                   
                    return true;
            }
    }

