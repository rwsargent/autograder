package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author Ben Broadhead, Christian Luciani
 * 
 */

public class MySortedSet<E> implements SortedSet<E> {
	private int size_init = 10;
	private int size_increment = 10;

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	private Comparator<? super E> comparator;
	private E[] item;

	private int item_count;

	private class sortedSetIterator implements Iterator<E> {
		/**
		 * starting index is zero
		 */
		int pos = 0;

		@Override
		public boolean hasNext() {
			// if position < last position return true
			if (pos < (item_count - 1)) {
				return true;
			}
			// if position == last position return false
			else {
				return false;
			}
		}

		@Override
		public E next() {
			// increment position and return the element at the incrementED
			// position
			if (this.hasNext()) {
				pos++;
				return item[pos];
			} else {
				throw new NoSuchElementException("NO REMAINING ITEMS");
			}
		}

		@Override
		public void remove() {
			MySortedSet.this.remove(item[pos]);
		}

	}

	public MySortedSet() {
		initializeItems();
	}

	public MySortedSet(Comparator<? super E> comparator) {
		this.comparator = comparator;
		initializeItems();
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		if (o == null) {
			// handle null values
			return false;
		}
		// find location
		int add_index = this.findInsertionPoint(o);
		if (add_index == -1) {
			// handle duplicates
			return false;
		}

		// insert
		insertItem(add_index, o);
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		int initialSize = this.size();
		// try to add each item
		for (E e : c) {
			this.add(e);
		}
		// return true if size has changed
		return (this.size() != initialSize);
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		initializeItems();
	}

	@Override
	public Comparator<? super E> comparator() {
		return this.comparator;
	}

	@SuppressWarnings("unchecked")
	private int compare(E item1, E item2) {
		if (this.comparator == null) {
			Comparable<E> comparableElement;

			if (item1 instanceof Comparable) {
				comparableElement = (Comparable<E>) item1;
				return comparableElement.compareTo(item2);
			}

			throw new IllegalArgumentException("item1 cannot be compared");
		}

		return this.comparator.compare(item1, item2);
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		return (findIndex((E) o) != -1);
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		// iterate over each item
		for (Object o : c) {
			// return false if not found
			if (!this.contains(o)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Build array of <E> *
	 * 
	 * @param size
	 *            *
	 * @return new array
	 */
	@SuppressWarnings("unchecked")
	private E[] buildArray(int size) {
		return (E[]) new Object[size];
	}

	private int findIndex(E o) {
		int mid = 0;
		int start = 0;
		int end = item_count - 1;

		while (start <= end) {
			mid = (start + end) / 2;

			int result = compare(o, item[mid]);
			if (result < 0) {
				end = mid - 1;
			} else if (result > 0) {
				start = mid + 1;
			} else {
				return mid;
			}
		}

		return -1;
	}

	private int findInsertionPoint(E o) {
		int mid = 0;
		int start = 0;
		int end = item_count - 1;

		while (start <= end) {
			mid = (start + end) / 2;

			int result = compare(o, item[mid]);
			if (result < 0) {
				end = mid - 1;
			} else if (result > 0) {
				start = mid + 1;
			} else {
				// already exists
				return -1;
			}
		}

		// if mid == start, mid == insertion point
		if (mid == start) {
			return mid;
		}
		// else insertion point is mid+1
		return mid + 1;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (this.item_count == 0) {
			throw new NoSuchElementException("EMPTY SET");
		}

		// handle empty sets
		return this.item[0];
	}

	private void growWithBlank(int gap_index) {
		if (gap_index < 0 || gap_index > this.item_count) {
			throw new IllegalArgumentException("gap_index out of bounds!");
		}

		E[] newArray = buildArray(this.item.length + this.size_increment);

		for (int i = 0; i < this.item.length; i++) {
			if (i == gap_index) {
				// move to position above blank
				i++;
			}
			newArray[i] = this.item[i];
		}

		this.item = newArray;
	}

	/**
	 * Creates new array
	 */
	private void initializeItems() {
		this.item_count = 0;
		this.item = buildArray(this.size_init);
	}

	private void insertItem(int index, E element) {
		if (index < 0 || index > this.item_count) {
			throw new IllegalArgumentException("out of bounds");
		}
		if (this.item.length <= this.item_count) {
			growWithBlank(index);
		} else {
			for (int i = this.item_count - 1; i >= index; i--) {
				this.item[i + 1] = this.item[i];
			}
		}
		this.item[index] = element;
		this.item_count++;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		return (this.item_count == 0);
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new sortedSetIterator();
	}

	@Override
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if (this.item_count == 0) {
			throw new NoSuchElementException(
					"Cannot extract last from an empty set!");
		}

		// last = end
		return this.item[this.item_count - 1];
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object o) {
		// Find item
		int index = findIndex((E) o);
		if (index >= 0) {
			removeItem(index);
			return true;
		}

		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean modified = false;

		// remove all removable objects
		for (Object o : c) {
			if (remove(o)) {
				// notify of modification
				modified = true;
			}
		}

		return modified;
	}

	/**
	 * removes item at index and repositions accordingly
	 * 
	 * @param index
	 *            the index of the item to remove
	 */
	private void removeItem(int index) {
		if (index >= this.item_count || index < 0) {
			throw new IllegalArgumentException("index out of bounds!");
		}
		if (this.item.length >= this.item_count + this.size_increment) {
			// if true, shrink
			closeBlank(index);
		} else {
			for (int i = index; i < this.item_count - 1; i++) {
				this.item[i] = this.item[i + 1];
			}
		}
		this.item[item_count - 1] = null;
		this.item_count--;
	}

	private void closeBlank(int gap_index) {
		E[] newArray = buildArray(this.item_count + this.size_increment);
		for (int i = 0; i < this.item_count - 1; i++) {
			if (i >= gap_index) {
				newArray[i] = this.item[i + 1];
			} else {
				newArray[i] = this.item[i];
			}
		}
		this.item = newArray;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return this.item_count;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object[] toArray() {
		E[] copiedArray = (E[]) new Object[this.item_count];
		for (int i = 0; i < this.item_count; i++) {
			copiedArray[i] = this.item[i];
		}

		return copiedArray;
	}

}
