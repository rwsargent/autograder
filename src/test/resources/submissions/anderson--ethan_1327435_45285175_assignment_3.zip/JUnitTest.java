package assignment3;



import java.util.ArrayList;

import java.util.Comparator;


import org.junit.Test;
/**
 * 
 * @author Ethan Anderson and Brennan Myers
 *
 */

public class JUnitTest {
	/**
	 * Tests our set for string types, and makes sure they are sorted.
	 * Also checks the first and last strings in the set, and checks to array.
	 * We also check the contains method
	 */
	@Test
	public void stringAddTest(){
		MySortedSet<String> mySet = new MySortedSet<String>();


		mySet.add("John");
		mySet.add("Frank");
		mySet.add("Ethan");
		mySet.add("Brennan");
		mySet.add("Brennan");
		mySet.add("Jane");
		mySet.add("Ericka");
		mySet.add("Zenith");
		for(int i = 0; i < mySet.size(); i++){
			System.out.print(mySet.toArray()[i]+" , ");
		}
		System.out.println();
		System.out.print("The first object in this array is "+mySet.first()+"\n");
		System.out.print("The last object in this array is "+mySet.last()+"\n");
		System.out.print("Does this method contain a John? "+mySet.contains("John")+"\n");
		System.out.println("This should return false: "+mySet.contains("Obama"));
	}

	/**
	 * This tests adding 50 random integers to our array from 0-900 making sure that there are no duplicates and that 
	 * the array grows properly are both very important tests.  This test is done using the compareTo() method.
	 */
	@Test
	public void integerAddTest() {
		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		mySet.add(3);
		for(int i = 0; i < 50; i++){
			int c = (int) Math.round(Math.random()*30);
			mySet.add(c);
		}
		for(int i = 0; i < mySet.size(); i++){
			System.out.print(mySet.toArray()[i]+" , ");
		}
		System.out.println();
		System.out.print("The first object in this array is "+mySet.first()+"\n");
		System.out.print("The last object in this array is "+mySet.last()+"\n");
		System.out.print("Does this method contain a 3? "+mySet.contains(3)+"\n");
	}
	/**
	 * This test is done adding an array of random characters using the ascii codes for characters 
	 * (http://www.asciitable.com/)
	 * this test is also done using the compareTo() method.
	 */
	@Test
	public void characterAddTest(){
		char c[] = new char[50];
		MySortedSet<Character> mySet = new MySortedSet<Character>();
		for(int i = 0; i < 50; i++){
			c[i] = (char)Math.round(65+Math.random()*25);
		}
		for (int i = 0; i < 50; i++) {
			mySet.add(c[i]);
		}
		for(int i = 0; i < mySet.size(); i++){
			System.out.print(mySet.toArray()[i]+" , ");
		}
		System.out.println();
		System.out.print("The first object in this array is "+mySet.first()+"\n");
		System.out.print("The last object in this array is "+mySet.last()+"\n");
	}
	/**
	 * This tests our addall, removeall, and containsall methods.
	 * at it works
	 */
	@Test
	public void addAllTest()
	{
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		mySet.add(9);
		mySet.add(7);
		mySet.add(6);
		numbers.add(10);
		numbers.add(3);
		numbers.add(5);
		numbers.add(9);
		mySet.addAll(numbers);

		System.out.print("This adds numbers to mySet ");
		for(int i = 0; i < mySet.size(); i++){
			System.out.print(mySet.toArray()[i]+" , ");
		}
		System.out.print("This is to see if the set contains the numbers ");
		System.out.print(mySet.containsAll(numbers));

		System.out.println();
		System.out.print("We are now removing the numbers set ");
		mySet.removeAll(numbers);
		for(int i = 0; i < mySet.size(); i++){
			System.out.print(mySet.toArray()[i]+" , ");
		}
		System.out.println();

	}
	/**
	 * This tests our removemethod
	 * and it works
	 */
	@Test
	public void removeTest(){
		MySortedSet<Integer> myIntSet = new MySortedSet<Integer>();
		//MySortedSet<Character> myCharSet = new MySortedSet<Character>();

		int c[] = {1,9,8,4,5,6,7,3,2};

		for(int i = 0; i < c.length; i++){
			myIntSet.add(c[i]);
		}
		myIntSet.remove(3);
		myIntSet.remove(9);
		myIntSet.remove(1);
		//System.out.print(c[3]);
		System.out.print("Ints 1-9 added to the set and then 1,3,9 removed: "+"\n");
		for(int i = 0; i < myIntSet.size(); i++){
			System.out.print(myIntSet.toArray()[i]+" , ");
		}
		System.out.println();
	}
/**
 * 
 * This returns the list in descending order
 *
 */

	protected class ReverseOrder implements Comparator<Integer> {
		/**
		 * Returns a negative value if lhs is smaller than rhs. Returns a positive
		 * value if lhs is larger than rhs. Returns 0 if lhs and rhs are equal.
		 */

		@Override
		public int compare(Integer lhs, Integer rhs) {
			return (rhs - lhs);

		}


	}
}
