package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Brennan Myers and Ethan Anderson
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E> {
	private int size;
	private E[] myList;
	private Comparator<? super E> myComparator;


	/**
	 * If this constructor is used to create the sorted set, it is assumed that
	 * the elements are ordered using their natural ordering
	 * We set the size and create an array
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet() {
		size = 0;
		myList =  (E[]) new Object[10];
	}

	/**
	 * If this constructor is used to create the sorted set, it is assumed that
	 * the elements are ordered using the provided comparator.
	 * We set the size, create an array and take a comparator
	 * 
	 * @param myComparator
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> myComparator) {
		size = 0;
		myList =  (E[]) new Object[10];
		this.myComparator = myComparator;

	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return myComparator;
	}

	/**
	 * @return the first (myList[0]) element currently in this set
	 * @throws NoSuchElementException if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if(myList[0] == null){
			throw new NoSuchElementException();
		}
		return myList[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if(myList[size-1] == null){
			throw new NoSuchElementException();
		}

		return myList[size-1];
	}

	/**
	 * This method fist calls binary search on the object that is given, 
	 * we also check in the object is null or if the index is illigal
	 * we then grow our array if we have to according to our size
	 * If the index spot in the array is not null then we  make it null and move what needs to move
	 * in the array
	 * we then add it to the index spot and grow our size
	 * @param o -- element to be added to this set   
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {
		int index = binarySearch(o); // makes index from binarySearch number returned so we dont need to keep calling

		if(o == null || o == myList[index] ){  
			return false;
		}
		if(size == myList.length-1){						// this if statement grows the array and copies everything inside of it
			E[]	temp =  (E[]) new Object[myList.length*2];
			for (int i = 0; i < size; i++)
			{
				temp[i] = myList[i];
			}
			myList = temp;
		}

		if(myList[index] != null)
		{
			for(int i = size; i >= index ; i--){
				myList[i+1] = myList[i];
			}
			myList[index] = null;
		}

		if (myList[index] == null)
		{
			myList[index] = o;
			size++;
			return true;
		}

		return false;
	}


	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * We call our add method for each item in c.
	 * 
	 * @param c  -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean addAll(Collection<? extends E> c) {

		for(Object item : c) {
			add((E)item);
		}
		while(c.iterator().hasNext()){
			return true;
		}
		return false;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		for(int i = 0; i < myList.length; i++){
			myList[i] = null;
		}
	}

	/**
	 * This method calls a binarySearch on an object to see if it is in the array
	 * it then finds if the spot is in the array and returns true if that is true
	 * @param o -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {//binary search
		int index = binarySearch((E)o);
		if(myList[index].equals(o)){
			return true;
		}
		return false;
	}

	/**
	 * This method calls contains for every item in the collection and returns true if they are there
	 * while the iterator has next
	 * @param c -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean containsAll(Collection<?> c) {

		for(Object item : c) {
			contains((E)item);
		}
		while(c.iterator().hasNext()){
			return true;
		}
		return false;
	}


	/**
	 * @return true if this set contains no elements
	 */
	//done

	@Override
	public boolean isEmpty() {
		if(size == 0){
			return true;
		}
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return new IteratorClass();
	}
	/**
	 * This is a new class to create an Iterator
	 * we start at position 0 
	 * hasNext() returns true if there is more to check
	 * next returns the spot that the position is at
	 * remove calls our remove method.
	 */
	private class IteratorClass implements Iterator<E>{
		int position = 0; //keep track of position while iterating 
		@Override
		public boolean hasNext(){
			if(position < size){
				return true;
			}
			else return false;
		}

		@Override
		public E next() throws NoSuchElementException {//java docs for all of this
			position++;
			if(hasNext() == false){
				throw new NoSuchElementException();
			}
			// TODO Auto-generated method stub
			return MySortedSet.this.myList[position];
		}
		@Override
		public void remove() throws UnsupportedOperationException , IllegalStateException{
			MySortedSet.this.remove(MySortedSet.this.myList[position]);
		}
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object o) {
		boolean check = false;

		for (int i = 0; i <= size; i++)
		{
			if(myList[i] == (E)o)
			{
				myList[i] = null;
				size--;
			}
			if(myList[i] == null || check){
				check = true;
				myList[i] = myList[i+1];;
			}
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c -- collection containing elements to be removed from this set
	 * @return -- true if this set changed as a result of the call
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean removeAll(Collection<?> c) {
		for(Object item : c) {
			remove((E)item);
		}
		while(c.iterator().hasNext()){
			return true;
		}
		return false;
	}


	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {

		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, 
	 * in sorted (ascending) order.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object[] toArray() {
		E[]	arrayReturn =  (E[]) new Object[myList.length];
		for(int i = 0; i < myList.length; i++){
			arrayReturn[i]=myList[i];
		}
		return arrayReturn;
	}
	/**
	 * Takes an object that will be used to search through myList. Checks to see if a 
	 * comparator is supplied, and if so, searches according to the comparator. It takes the list and
	 * divides it in half.  Once the list is in half, it checks if the object is greater
	 * or less than it. It then throws away its midpoints.  It continues this process 
	 * until it has split enough times that only one item left in the list.  If the right
	 * side is greater than the left side, the loop is broken. The index is then returned.
	 * @param o - The object that is given
	 * @return - We either retun the index, or -1 if no possible index was found
	 */
	@SuppressWarnings("unchecked")
	private int binarySearch(E o){
		int lH = 0;
		int rH = size-1;
		int midpoint = lH+(rH-lH)/2;


		if(myComparator == null){
			if(size == 0){
				return midpoint;
			}
			while(rH >= lH){
				midpoint = lH+(rH-lH)/2;
				if(((Comparable<E>) myList[midpoint]).compareTo(o) == 0){
					return midpoint;
				}
				else if(((Comparable<E>) myList[midpoint]).compareTo(o) < 0){
					lH = midpoint + 1;
				}
				else if(((Comparable<E>) myList[midpoint]).compareTo(o) > 0){
					rH = midpoint - 1;
				}
			}
			if(((Comparable<E>) myList[midpoint]).compareTo(o) < 0){
				return midpoint + 1;
			}

			else{
				return midpoint;
			}
		}

		if (myComparator != null){
			if(size == 0){
				return midpoint;
			}
			while(rH >= lH){
				midpoint = lH+(rH-lH)/2;
				if(myComparator.compare(myList[midpoint], o) == 0){
					return midpoint;
				}
				else if(myComparator.compare(myList[midpoint], o) < 0){
					lH = midpoint + 1;
				}
				else if(myComparator.compare(myList[midpoint], o) > 0){
					rH = midpoint - 1;
				}
			}
			if(myComparator.compare(myList[midpoint], o) < 0){
				return midpoint + 1;
			}

			else{
				return midpoint;
			}

		}
		return midpoint;
	}
}


