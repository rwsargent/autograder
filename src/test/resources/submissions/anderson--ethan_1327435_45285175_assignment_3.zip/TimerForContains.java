package assignment3;

public class TimerForContains {

	public static void main(String[] args){
		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		//mySet.add();
		for(int i = 0; i < 750000; i++){
			int c = (int) Math.round(Math.random()*10000000);
			mySet.add(c);
		}
		System.out.println("Array created "+"\n");
		    long startTime, midpointTime, stopTime;

		    // First, spin computing stuff until one second has gone by.
		    // This allows this thread to stabilize.

		    startTime = System.nanoTime();
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    // Now, run the test.

		    long timesToLoop = 10000;

		    startTime = System.nanoTime();

		    for (long i = 0; i < timesToLoop; i++)
		      mySet.contains(-1);

		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.

		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		    System.out.println("It takes exactly " + averageTime);
		  }
		}