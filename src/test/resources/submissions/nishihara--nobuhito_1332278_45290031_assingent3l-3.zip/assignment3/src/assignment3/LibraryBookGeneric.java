/**
 * author: Nobuhito Nishihara and Adrian Clark
 * 
 */

package assignment3;
import java.util.GregorianCalendar;
public class LibraryBookGeneric <Type> extends Book {
    private Type holder;
	private GregorianCalendar due;
	
	public LibraryBookGeneric (long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		// TODO Auto-generated constructor stub
	}
//constructor

	public Type getHolder()
	{
		return holder;
	}
	public GregorianCalendar getDueDate()
	{
		return due;
	}
	public void checkedIn()
	{
		this.holder=null;
		this.due=null;
	}
	
	public void checkOut(Type holder, GregorianCalendar due,long isbn){
        this.holder=holder;
        this.due=due;
		this.isbn=isbn;		
	
	} 

			
}
	


