/**
 * author: Nobuhito Nishihara and Adrian Clark
 * 
 */

package assignment3;
import java.util.GregorianCalendar;
public class LibraryBook extends Book {
    private String holder;
	private GregorianCalendar due;
	
	public LibraryBook(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		// TODO Auto-generated constructor stub
	}
//constructor

	public String getHolder()
	{
		return holder;
	}
	public GregorianCalendar getDueDate()
	{
		return due;
	}
	public void checkedIn()
	{
		this.holder=null;
		this.due=null;
	}
	
	public void checkOut(String holder, GregorianCalendar due,long isbn){
        this.holder=holder;
        this.due=due;
		this.isbn=isbn;		
	
	} 

			
}
	


