/**
 * Nobuhito Nishihara, Adrian Clark
 */
package assignment3;

import static org.junit.Assert.*;

import java.util.Comparator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest {
	
	
	
	private MySortedSet<String> my1;
	private MySortedSet<Integer> my2;
	private MySortedSet<Book> my3;
	
	// how to set up the generic class object?
	@Before
	public void setUp() throws Exception {
		// my1= new MySortedSet<String>();
		//my2= new MySortedSet<Integer>();
		 Comparator<Book> authorsort = new AuthorSort();
	     my3= new MySortedSet<Book>(authorsort);
	     Book a= new Book(1,"a","a");
	     Book b= new Book(2,"b","b");
	     my3.add(a);     
	     my3.add(b);
	
	}
	
	
	
// Should be null?
	@After
	public void tearDown() throws Exception {
	my1=null;
	my2=null;
	my3=null;
	}

	// what kind of thing should I sort in this case?
	@Test
	public void testMySortedSet() {
	
	}
	
	@Test
	public void testMySortedSetComparatorOfQsuperE() {
		fail("Not yet implemented");
	}

	@Test
	public void testComparator() {
		fail("Not yet implemented");
	}

	@Test
	public void testFirst() {
		assertEquals(new Book(1,"a","a"),my3);
	}

	@Test
	public void testLast() {
		
	}

	@Test
	public void testAdd() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testClear() {
		fail("Not yet implemented");
	}

	@Test
	public void testContains() {
		fail("Not yet implemented");
	}

	@Test
	public void testContainsAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsEmpty() {
		fail("Not yet implemented");
	}

	@Test
	public void testIterator() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemove() {
		fail("Not yet implemented");
	}

	@Test
	public void testRemoveAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testSize() {
		fail("Not yet implemented");
	}

	@Test
	public void testToArray() {
		fail("Not yet implemented");
	}

	 /**
	   * Comparator that defines an ordering among library books using the author,  and book title as a tie-breaker.
	   */
	  protected class OrderByAuthor implements 
	   Comparator<LibraryBookGeneric<PhoneNumber>> {

		@Override
		public int compare(LibraryBookGeneric<PhoneNumber> o1,
				LibraryBookGeneric<PhoneNumber> o2) {
			
			String author1=o1.getAuthor();
			String author2=o2.getAuthor();
			if(author1!=author2){
			return author1.compareTo(author2);
			}
			else{
			String title1= o1.getTitle();
			String title2= o2.getTitle();
			return title1.compareTo(title2);
			}
		}

	  
	  }

	  /**
	   * Comparator that defines an ordering among library books using the due date.
	   */
	  protected class OrderByDueDate implements Comparator<LibraryBookGeneric<PhoneNumber>> {

		@Override
		public int compare(LibraryBookGeneric<PhoneNumber> o1,
				LibraryBookGeneric<PhoneNumber> o2) {
			return o1.getDueDate().compareTo(o2.getDueDate());
		}

	    // FILL IN
	  }
      
	protected class AuthorSort implements Comparator<Book>{

		@Override
		public int compare(Book o1, Book o2) {
			String author1=o1.getAuthor();
			String author2=o2.getAuthor();
			return author1.compareTo(author2);
		}
		  
	  }
  
}
