/**
 * Nobuhito Nishihara Adrin Clark
 */
package assignment3;


/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author 
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> {
    
	private Comparator<? super E> comparator;
	private E[] mylist;
	private Comparable[] myComList;
	private int size;
	public MySortedSet(){
		myComList=(Comparable[]) new Object[10];
		
		this.size=10;
		
		// a.compareTo(b); where and b are E object;
	}
	
	public MySortedSet(Comparator<? super E> comparator){
	   mylist=(E[]) new Object[10];
	   this.comparator=comparator;
	   this.size=10;
	}
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	*/
	@Override
	public Comparator<? super E> comparator() {
	  return comparator;
    }

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	
	@Override
	public E first() throws NoSuchElementException {
    if(mylist[0]==null){
    	return null;
    }
	
	if(comparator==null){
		E smallest= mylist[0];
	    for(int j=1; j<mylist.length; j++){
	     int compare=smallest.toString().compareTo((String) mylist[j]);
	    	if(compare>0){
	    	  smallest=mylist[j];
	    		
	}
     	
	}
	    return smallest;
	}
	 else{	
    E smallest= mylist[0];
    for(int j=1; j<mylist.length; j++){
     int compare=comparator.compare(smallest, mylist[j]);
    	if(compare>0){
    	  smallest=mylist[j];
    	
    	}
    }
     
    return smallest;
    }
    
    }

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	
	@Override
	public E last() throws NoSuchElementException {
		
		    if(mylist[0]==null){
		    	return null;
		    }
		    else{	
			E largest= mylist[0];
		    for(int i=1; i<mylist.length; i++){
		     int compare=comparator.compare(largest, mylist[i]);
		    	if(compare<0){
		    	  largest=mylist[i];
		      }
		    }
		     
		    return largest;
		    
		    }

	}
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *         	   -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		if(o==null){
			return false;
		}
		
		else if(this.comparator==null){
			int low=0;
			int high =mylist.length-1;
			int mid;
			if(this.size()+1>high){
				E temp[] = (E[])new Object [2*(mylist.length-1)];
				for(int i=0; i<high+1;i++){
					temp[i]=mylist[i];
				   
				}
				mylist=temp;
			}
			while(low<= high){
				mid =(low+ high)/2;
				if(mylist[mid].toString().compareTo(o.toString())<0){
					low=mid+1;
				}
			
				else if(mylist[mid].toString().compareTo(o.toString())>0){
				   high=mid-1;
				}
				
				else{   
			       for(int i=low+1;i<mylist.length;i++){
			    	E temp2[] = (E[]) new Object [mylist.length-1];
			        temp2[i]=mylist[i];
			        mylist[i]=temp2[i-1];
			        size=size+1;
			       }
			       }
				  
			   }
		     return true;
			}
				
		else{
		int low=0;
		int high = mylist.length-1;
		int mid;
		if(this.size()+1>high){
			E temp[] = (E[])new Object [2*mylist.length];
			for(int i=0; i<high+1;i++){
				temp[i]=mylist[i];
			   
			}
		     mylist=temp;
		}
		while(low<= high){
			mid =(low+ high)/2;
			if(comparator.compare(mylist[mid],o)>0){
				low=mid+1;
			}
		
			else if(comparator.compare(mylist[low], o)<0){
			   high=mid-1;
			}
			
			else{   
		       for(int i=low+1;i<mylist.length;i++){
		    	E temp2[] = (E[]) new Object [mylist.length-1];
		        temp2[i]=mylist[i];
		        mylist[i]=temp2[i-1];
		        size=size+1;
		       }
		       }
			  
		   }
	     return true;
		}
		}
		 
		
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	  
	

	@Override
	public boolean addAll(Collection<? extends E> c) {
		if(c.contains(null)){
			return false;
		}
		else {
	     while(c.iterator().hasNext()){ 	 
			this.add(c.iterator().next());
		 }
		}
	    return true;
	}
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	
	@Override
	public void clear() {
		for(int i=0;i<mylist.length; i++){
			mylist[i]=null;
		}
		
	}
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	
	@Override
	public boolean contains(Object o) {
		
		if(comparator==null){
			int low =0;
			int high= myComList.length-1;
			int mid;
			
			while(low<=high){
				mid= (low+high)/2;
				if(myComList[mid].compareTo((E)o)<0){
					low=mid+1;
				}
			    else if(myComList[mid].compareTo((E)o)>0){
					high= mid-1;
				}
				else {
					return true;
				}
				
		}
		return false;
		}
			else{
		int low =0;
		int high= mylist.length-1;
		int mid;
		
		while(low<=high){
			mid= (low+high)/2;
			if(comparator.compare(mylist[mid],(E) o)<0){
				low=mid+1;
			}
			else if(comparator.compare(mylist[mid], (E) o)>0){
				high= mid-1;
			}
			else {
				return true;
			}
		
			  		  
		}
			
		return false;
			}
		}
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */

	@Override
	public boolean containsAll(Collection<?> c) {
	    boolean contains = false;  
		while(c.iterator().hasNext()){
	    	  if(this.contains(c.iterator().next())){
	         contains=true;
	    	  }
	    	  }
	return contains;	
	}
	/**
	 * @return true if this set contains no elements
	 */
	
	@Override
	public boolean isEmpty() {
		boolean isEmpty=false;
		for(int i=0;i<mylist.length ; i++){
			   if(mylist[i]==null){
				   isEmpty=true;
			   }
			   else {
				   isEmpty=false;
			   }   
		}	
		
		return isEmpty;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		
		if(comparator==null){
			int low=0;
			int high= myComList.length-1;
			int mid;
			Comparable temp[]= (Comparable[]) new Object[myComList.length-1];  
			
			for(int i=0;i<myComList.length;i++){
				temp[i]=myComList[i];
			}
			while(low<=high){
				mid=(low+high)/2;
				if(myComList[mid].compareTo((E)o)<0){
					low=mid+1;
				}
				else if(myComList[mid].compareTo((E)o)>0){
					high=mid-1;
				}
				else{
					for(int i=0;i<mid;i++){
						temp[i]=myComList[i];
					}
						for(int j=mid;j<mylist.length-1;j++){
						temp[j]=myComList[j+1];
					}
						myComList=temp;			
			        return true;
				}
			
			
		}
		return false;
			
		}
		
		int low=0;
		int high= mylist.length-1;
		int mid;
		E temp[]= (E[]) new Object[mylist.length-1];  
		
		for(int i=0;i<mylist.length;i++){
			temp[i]=mylist[i];
		}
		while(low<=high){
			mid=(low+high)/2;
			if(comparator.compare(mylist[mid],(E)o)<0){
				low=mid+1;
			}
			else if(comparator.compare(mylist[mid],(E)o)>0){
				high=mid-1;
			}
			else{
				for(int i=0;i<mid;i++){
					temp[i]=mylist[i];
				}
					for(int j=mid;j<mylist.length-1;j++){
					temp[j]=mylist[j+1];
				}
                mylist=temp;			
		        return true;
			}
		
		
	}
	return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	
	@Override
	public boolean removeAll(Collection<?> c) {
		
		boolean remove=false;
		if(c.contains(null)){
			return false;
		}
		while(c.iterator().hasNext()){
			this.remove(c.iterator().next());
		    remove=true;
		}	
		return remove;
	}
	/**
	 * @return the number of elements in this set
	 */
	
	@Override
	public int size() {
	return size;
	}
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	
	@Override
	public Object[] toArray() {
		if(comparator==null){
			return myComList;
		}
		return mylist; 
	}
    /**
     * 
     * @author nobuhito
     * this protected class is for Iterator constractor to call the iterator method in 
     * main class.
     * @param <E>
     */
	
	
	protected class Iterator<E> {
          int container=-1;
          boolean remove=true;	 
          public Iterator(){
        	  
          }
        public boolean hasNext(){
        	if(mylist.length>size){
        		return true;
        	}
        	else{
        	return false;
        	}
        	}
        public E next() throws NoSuchElementException {
            if(container+1>mylist.length){
              throw new NoSuchElementException();
            }
            	container++;
        	return (E) mylist[container];
        }    
       public void remove() throws NoSuchElementException{
    	   if(remove=false){
    		   throw new IllegalStateException();
    	   }
    	   else if(container<0){
    		   throw new IllegalStateException();
    	   }
    	   else{
    		   mylist[container]=null;
    	       remove=false;
    	   }
       } 	
    	
    }
		@Override
		public java.util.Iterator<E> iterator() {
			Iterator<E> iterator= new Iterator<E>();
			return (java.util.Iterator<E>) iterator;
		}	
	


	
}
 