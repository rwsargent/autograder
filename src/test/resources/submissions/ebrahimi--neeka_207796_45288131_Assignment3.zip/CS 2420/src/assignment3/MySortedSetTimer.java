package assignment3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *Times the contains method for MySortedSet
 *This class is used to test both the Add and contain functions on a large scale.
 *
 *@author Stacey Kirby
 *@author Neeka Ebrahimi
 */

public class MySortedSetTimer {
	
	public static void main(String[] args) {
		timeContains();
//		timeAdd();
	}
	
	/**
	 * Times the contains method for MySortedSet
	 */
	@SuppressWarnings("unused")
	/**
	 * This program checks to see how long it takes for the contains Method to loop 500000
	 * times with an increasing number of objects and arraySizes.
	 * 
	 * @param-NONE
	 * @return-NONE
	 */
	private static void timeContains(){
		long startTime, midpointTime = 0, stopTime;
		List<Double> times = new ArrayList<Double>();
		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) { // empty block
		}

		// Now, run the test.

		int timesToLoop = 500000;
		int[] randomValues = createRandomIntegers(timesToLoop); // Generate a random array of ints to test contains
		
		for(int setSize = 100000; setSize <= 2000000; setSize+=100000){
			
			MySortedSet<Integer> timedSet = createRandomSet(setSize); // Generate a set with random ints at the specified size before the timer starts
			
			startTime = System.nanoTime();
			
			boolean contains;
			for (int i = 0; i < timesToLoop; i++)
				contains = timedSet.contains(randomValues[i]);

			midpointTime = System.nanoTime();

			// Run an empty loop to capture the cost of running the loop.

			for (long i = 0; i < timesToLoop; i++) { // empty block
			}

			stopTime = System.nanoTime();

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop;

			times.add(averageTime);
		}
		for(Double time : times)
			System.out.println(time);
	}
	
	/**
	 * This program checks to see how long it takes for the add Method to loop 500000
	 * times with an increasing number of objects and arraySizes.
	 * 
	 * @param NONE
	 * @return NONE
	 */
	@SuppressWarnings("unused")
	private static void timeAdd(){
		long startTime, midpointTime = 0, stopTime;
		List<Double> times = new ArrayList<Double>();
		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) { // empty block
		}

		// Now, run the test.

		int timesToLoop = 50000;
		for(int setSize = 100000; setSize <= 2000000; setSize+=100000){
			
			MySortedSet<Integer> timedSet = createRandomSet(setSize); // Generate a set with random ints at the specified size before the timer starts
			Random rnd = new Random();
			int valueAdded = rnd.nextInt();
			
			startTime = System.nanoTime();
		
			for (int i = 0; i < timesToLoop; i++)
				timedSet.add(valueAdded);

			midpointTime = System.nanoTime();

			// Run an empty loop to capture the cost of running the loop.

			for (long i = 0; i < timesToLoop; i++) { // empty block
			}

			stopTime = System.nanoTime();
			
			timedSet.remove(valueAdded);

			// Compute the time, subtract the cost of running the loop
			// from the cost of running the loop and computing square roots.
			// Average it over the number of runs.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
					/ timesToLoop;

			times.add(averageTime);
		}
		for(Double time : times)
			System.out.println(time);
	}
	
	/**
	 * Creates an array with random integers for timing contains and add function
	 * 
	 * @param int timesToLoop -- the amount of integers to add the the array
	 * @return int[] random -- an array of random integers
 	 */
	private static int[] createRandomIntegers(int  timesToLoop){
		Random rnd = new Random();
		int[] random = new int[timesToLoop];
		for(int i = 0; i < timesToLoop; i++)
			random[i] = rnd.nextInt();
		return random;
	}
	
	/**
	 * Creates a MySortedSet with random integers for timing contains and the add function
	 * 
	 * @param NONE
	 * @return random -- a MySortedSet with random integers
	 */
	private static MySortedSet<Integer> createRandomSet(int setSize){
		Random rnd = new Random();
		MySortedSet<Integer> random = new MySortedSet<Integer>();
		for(int i = 0; i < 10000; i++)
			random.add(rnd.nextInt());
		return random;
	}
	
}
