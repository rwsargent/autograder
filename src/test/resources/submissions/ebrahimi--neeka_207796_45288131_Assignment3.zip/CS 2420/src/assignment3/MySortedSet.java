package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Stacey Kirby
 * @author Neeka Ebrahimi
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */

public class MySortedSet<E> implements SortedSet<E> {

	E[] data; // Storage for holding the items
	int size; // Keeps track of the amount of items in the set
	Comparator<? super E> cmp; // The comparator being used
	E largest; // Keeps track of the largest element in the set

	/**
	 * A constructor  that is used to create the sorted set.
	 * It is assumed that the elements are ordered using their natural ordering 
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(){
		this.size = 0;
		this.data = (E[]) new Object[15];
	}

	/**
	 * A constructor that is used to create the sorted set.
	 * Contains a comparator for objects that do not use natural ordering
	 * @param cmp Comparator<? super E> --
	 * 				a comparator of Type is needed
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> cmp){
		this.size = 0;
		this.data = (E[]) new Object[15];
		this.cmp = cmp;
	}

	/**
	 * A comparator used to order objects in the Natural Ordering
	 * @param-- NONE
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		return this.cmp;
	}

	/**
	 * This function returns the first value in the object list.
	 * @param NONE
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 *             
	 */
	public E first() throws NoSuchElementException {
		if(this.isEmpty())
			throw new NoSuchElementException();

		return this.data[0];
	}

	/**
	 * This functions returns the last value in the object list.
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if(this.isEmpty())
			throw new NoSuchElementException();

		return data[this.size-1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) {
		if(this.contains(o) || o == null) // If the item is already in the array or it is null, return false
			return false;

		if(this.size()==this.data.length) // If the array is full, double it
			this.data = this.doubleArray();
		
		if(this.size == 0){ // If there is nothing in the array, add it to to first spot in the set and set it as the largest element
			this.data[0] = o;
			largest = o;
		}
		else if(compare(o, largest) > 0){ // If this element is the largest, add it to the end of the set
			largest = o;
			this.data[this.size] = o;
		}
		else // Otherwise, find the insertion point and insert it.
			this.insertSort(o); 
		
		this.size++;
	
		return true;
	}

	/**
	 * This method find the insertion point of the object, and inserts it
	 * in accordance with either the comparator or its natural ordering.
	 * @param E o -- the object to be inserted
	 * 
	 * @return NONE 
	 */
	private void insertSort(E o){
		int insertPoint = 0;
	
		for(int i = 0; i < this.size; i++){
			if(compare(o, this.data[i]) > 0) // If o is bigger than the element in the array, increment the insertionPoint
				insertPoint++;
		}
		if(insertPoint < this.size){
			for(int i = this.size; i > insertPoint; i--) // Move each item over by one to make room for the element being added
				this.data[i] = this.data[i-1];
			this.data[insertPoint] = o; // Insert the element at the correct spot
		}
	}

	/**
	 * Compares the two values depending on if they use natural ordering
	 * or if they have a defined comparator
	 * @param E value1 -- the first value to compare 
	 * @param E value2 -- the second value to compare
	 * @return a number < 0 if value1 is smaller than value2
	 * 		   a number > 0 if value1 is bigger than value2
	 * 		   or 0 if they are equal
	 */
	@SuppressWarnings("unchecked")
	private int compare(E value1, E value2){
		int compared = 0; 
		if(this.cmp == null && value1 instanceof Comparable){ // If this element doesn't have a cmp then it uses natural ordering 
			Comparable<? super E> compareValue1 = (Comparable<? super E>) value1;
			compared = compareValue1.compareTo(value2); // Return the value of the items compared with comparable
		} else{
			compared = this.cmp.compare(value1, value2); // Otherwise, return the value of the items compared with the comparator
		}
		return compared;
	}

	/**
	 * Creates a new array with double the space when there is not
	 * any more room left to add to data. The old array is then added to the larger
	 * array
	 * 
	 * @param NONE
	 * @return array with twice the space and same the elements
	 * 
	 */
	@SuppressWarnings("unchecked")
	public E[] doubleArray(){
		E[] temp = (E[]) new Object[this.data.length*2]; // Create a temp array that's twice as large
		for(int i=0; i<this.size;i++)
			temp[i]=this.data[i]; // Copy the data from the old array to the new, larger one
		return temp;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
		int originalSize=this.size();

		for(E item : c) // Add each item in the collection
			this.add(item);

		if(this.size()==originalSize) // Return false if the size has not increased (nothing has been added)
			return false;

		return true;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 * 
	 * @param NONE 
	 * @return NONE
	 */
	public void clear() {
		this.size = 0; //Set the size of the set to 0
		for(int i = 0; i < this.data.length; i++) //Set each item in data to null
			this.data[i] = null;
	}

	/**
	 * This function checks if an object is with the an objects lists. Such as the 
	 * data' array.
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) {
		if(this.size == 0) // Return false if there are no items in the set
			return false;

		for(E item : this.data){
			if(item==o) // If the item is found, return true
				return true;
		}

		return false; // Otherwise, return false
	}

	/**
	 * This function checks to see if an objects list contains all of the objects on a 
	 * secondary list. 
	 * 
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c) {
		boolean inSet = true;

		for(Object item : c)
			if(this.contains(item)) // If this item is in the set, continue
				continue;
			else
				inSet = false; // Otherwise, set boolean to false

		return inSet;
	}

	/**
	 * This function checks to see if the objects list is empty
	 * 
	 * @param NONE
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		return this.size == 0;
	}

	/**
	 * This function inititializes an iterator
	 * @param- NONE
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		return new Iterator<E>() {
			int index = 0;

			/**
			 * This function checks if there is another object after the one it is currently 
			 * on within the object's list
			 * 
			 * @param- NONE
			 * @return true if there is an element after the current element. 
			 * 			Otherwise, return false.
			 */
			public boolean hasNext() {
				return (index < size);
			}

			/**
			 * Gives the next item in the set. Throws an exception if there are
			 * no more items to iterate through.
			 * 
			 * @param NONE
			 * @return the next item in the set
			 */
			public E next() {
				if(!hasNext())
					throw new NoSuchElementException(); // Throw an exception if there are no more items to iterate through

				index++;
				return data[index];
			}

			/**
			 * Removes the last item that was returned by next. Throw an exception 
			 * if next has not been called since the last remove
			 * 
			 * @param NONE
			 * @return NONE
			 */
			public void remove() {
				MySortedSet.this.remove(data[index]);
			}
		}; 
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		if(!this.contains(o)) // If the object is not in the set, return false
			return false;

		for(int i = 0; i < this.size; i++){
			if(data[i].equals(o)){ // When the item to be removed is found, shift elements over to remove the item
				for(int j=i; j<this.size-1;j++)
					data[j]=data[j+1];
				break;

			}
		}
		size--; // Decrement size by one
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		int originalSize=this.size();

		for(Object item : c) // Remove each item in the collection from the set
			this.remove(item);
		if(this.size()==originalSize) // If the size is still the same, return false (nothing has been removed)
			return false;

		return true;
	}

	/**
	 * This function returns the size of the Object's list
	 * 
	 * @param-NONE
	 * @return the number of elements in this set
	 */
	public int size() {
		return this.size;
	}

	/**
	 * This function turns an Objects list into an array.
	 * 
	 * @param NONE
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		Object[] temp ;
		if(this.size==0)
			temp = new Object[1];
		else{
		temp = new Object[this.size];
		if(this.size==0)
			return temp;
		 // Create a new temp array
		for(int i = 0; i < this.size; i++) // Copy the items in the array over
			temp[i] = this.data[i];
		}
		return temp;
	}
}
