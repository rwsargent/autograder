package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit tests for MySortedSte
 * @author Stacey Kirby
 * @author Neeka Ebrahimi
 */

public class MySortedSetTester {

	MySortedSet<String> set1, set2, set3, set4, set5, set6, set7;
	MySortedSet<Integer> set8, set10,set11, set12;
	MySortedSet<Float> set9;
	MySortedSet<Double> setDouble;
	ArrayList<String> test1,test2,test3, test4 , test5;
	ArrayList<Integer> test6, test8;
	ArrayList<Float> test7;
	ArrayList<Double> testDouble;
	Object[] temp, temp1, temp2;

	@Before
	public void setUp() throws Exception {
		temp = new Object[]{"1","2","3","4","a","b","c"};
		temp1 = new Object[]{"0"};
		temp2 = new Object[]{"0"};
		set1 = new MySortedSet<String>();
		set2 = new MySortedSet<String>();
		set3 = new MySortedSet<String>();
		set4 = new MySortedSet<String>();
		set5 = new MySortedSet<String>();
		set6 = new MySortedSet<String>();
		set7 = new MySortedSet<String>();
		set8 = new MySortedSet<Integer>();
		set10 = new MySortedSet<Integer>();
		set11 = new MySortedSet<Integer>();
		set12 = new MySortedSet<Integer>();
		set9 = new MySortedSet<Float>();
		setDouble = new MySortedSet<Double>();
		test1 = new ArrayList<String>();
		test2 = new ArrayList<String>();
		test3 = new ArrayList<String>();
		test4 = new ArrayList<String>();
		test5 = new ArrayList<String>();
		test6 = new ArrayList<Integer>();
		test7= new ArrayList<Float>();
		test8 = new ArrayList<Integer>();
		testDouble= new ArrayList<Double>();
		test1.add("a");
		test1.add("b");
		test1.add("c");
		test1.add("1");
		test1.add("2");
		test1.add("3");		
		test3.add("f");
		test3.add("g");
		test3.add("h");
		test4.add("k");
		test4.add("k");
		test4.add("k");
		test4.add("k");
		test4.add("k");
		test4.add(""); //// I'm not sure how this will work
		test5.add(null);
		test5.add(null);
		test5.add(null);
		test5.add(null);
		test5.add(null);
		test5.add(null);
		test6.add(1);
		test6.add(3);
		test6.add(7);
		test6.add(1);
		test6.add(3);
		test6.add(10);
		test7.add((float) 7.5);
		test7.add((float) 9.1);
		test7.add(null);
		test7.add((float) 9.1);
		testDouble.add(9.8);
		testDouble.add(9.8);
		testDouble.add(9.8);
		testDouble.add(20.8);
		set5.addAll(test4);
		set6.addAll(test5);
		set7.addAll(test3);
		set11.addAll(test6);

	}

	@After
	public void tearDown() throws Exception {
	}

	public void testComparator(){
		assertNull(set1.comparator());
	}
	@Test
	public void testIsEmpty1(){
		assertTrue(set1.isEmpty());
	}
	@Test
	public void testIsEmpty2(){
		assertFalse(set5.isEmpty());
	}
	@Test
	public void testIsEmpty3(){
		assertTrue(set6.isEmpty());
	}

	@Test
	public void testAdd1() {
		assertTrue(set1.add("1"));
		assertTrue(set1.add("2"));
		assertTrue(set1.add("3")); 
		assertTrue(set1.add("4"));
		assertFalse(set1.add("1"));
		assertFalse(set1.add(null));
		assertEquals(4, set1.size());
		assertTrue(set1.addAll(test1));
		assertEquals(7, set1.size());
		assertFalse(set1.isEmpty());
		assertTrue(set1.containsAll(test1));
		assertArrayEquals(temp, set1.toArray());	
	}
	@Test
	public void testAdd2() {
		assertFalse(set5.add(null));
		assertFalse(set5.add(null));
		assertFalse(set5.add(null));
		assertFalse(set5.add(null));
		assertFalse(set5.add(null));
		assertFalse(set5.add(null));
		assertEquals(2, set5.size());
		assertFalse(set5.isEmpty());
	}
	@Test
	public void testAdd3() {
		assertTrue(set4.add("0"));
		assertFalse(set4.add("0"));
		assertFalse(set4.add("0"));
		assertFalse(set4.add("0"));
		assertFalse(set4.add("0"));
		assertFalse(set4.add("0"));
		assertFalse(set4.add("0"));
		assertEquals(1, set4.size());
		assertFalse(set4.isEmpty());
	}
	@Test
	public void testAddAll1(){
		assertTrue(set1.addAll(test1));
		assertFalse(set1.addAll(test2));
		assertEquals(6, set1.size());
	}
	@Test
	public void testAddAll2(){
		assertTrue(set3.addAll(test4));
		assertFalse(set3.addAll(test2));
		assertNotEquals(1, set3.size());
	}
	@Test
	public void testAddAll3(){
		assertFalse(set4.addAll(test5));
		assertFalse(set4.addAll(test2));
		assertEquals(0, set4.size());
	}

	@Test
	public void testAddAll4(){
		assertTrue(set8.addAll(test6));
		Integer[] tester = new Integer[]{1,3,7,10};
		assertArrayEquals(set8.toArray(), tester);
		assertFalse(set8.isEmpty());
		assertEquals(4, set8.size());
		assertTrue(set8.contains(1));
		assertEquals((int)1, (int)set8.first());
		assertEquals((int)10, (int)set8.last());
	}
	@Test
	public void testContains1(){
		set1.addAll(test1);
		assertTrue(set1.contains("a"));
		assertTrue(set1.contains("1"));
		assertFalse(set1.contains("z"));
	}
	@Test
	public void testContains2(){
		set5.addAll(test5);
		assertTrue(set5.contains(null));
		assertFalse(set5.contains("9"));
		assertFalse(set5.contains("u"));
	}
	@Test
	public void testContains3(){
		set4.add("o");
		set4.add("");
		assertTrue(set4.contains("o"));
		assertFalse(set1.contains(""));
		assertFalse(set1.contains("z"));
	}
	@Test
	public void testContains4(){
		set8.addAll(test6);
		assertTrue(set8.contains(3));
		assertTrue(set8.contains(1));
		assertFalse(set8.contains(90));
	}

	@Test
	public void testContainsAll1(){
		assertFalse(set1.containsAll(test1));
		assertTrue(set1.containsAll(test2));
		assertFalse(set1.containsAll(test3));
	}
	@Test
	public void testContainsAll2(){
		assertFalse(set4.containsAll(test5));
		assertFalse(set4.containsAll(test4));
	}
	@Test
	public void testContainsAll3(){
		set3.addAll(test4);
		assertTrue(set3.containsAll(test4));
		assertTrue(set3.containsAll(test5));
	}
	@Test
	public void testContainsAll4(){
		set8.addAll(test6); 
		assertTrue(set8.containsAll(test6));
		assertTrue(set8.containsAll(test6));
	}
	@Test
	public void testContainsAll5(){
		setDouble.addAll(testDouble);
		assertTrue(setDouble.containsAll(testDouble));
		assertTrue(setDouble.containsAll(testDouble));
	}

	@Test
	public void testFirst1(){ 
		set1.add("1");
		set1.add("0");
		set1.add("3");
		assertEquals("0", set1.first());
	}
	@Test
	public void testFirst2(){
		set3.addAll(test3);
		assertNotEquals("k", set3.first());
	}
	@Test
	public void testFirst3(){
		setDouble.addAll(testDouble);
		assertNotEquals(9.7, setDouble.first());
	}
	@Test
	public void testFirst4(){
		set8.addAll(test6);
		assertEquals(((int)1),(int)set8.first());
	}
	@Test
	public void testLast1(){
		set1.addAll(test1);
		assertEquals("c", set1.last());
	}
	@Test
	public void testLast2(){
		set4.addAll(test4);
		set4.add("o");
		assertEquals("o", set4.last());
	}
	@Test
	public void testLast3(){
		set5.add("j");
		assertNotEquals("j", set5.last());
	}

	@Test
	public void testSort(){	
		assertTrue(set1.add("3"));
		assertTrue(set1.add("1"));
		assertTrue(set1.add("0"));
		assertTrue(set1.add("4"));
		assertTrue(set1.add("-1"));
		Object[] sortTest = new Object[]{"-1","0","1","3","4"};
		assertArrayEquals(sortTest, set1.toArray());
		//		Object[] tester = set1.toArray(); 
		//		for(Object i : tester)
		//			System.out.println(i);
	}
	@Test
	public void testSort1(){	
		assertTrue(set1.add("3"));
		assertTrue(set1.add("1"));
		assertTrue(set1.add("0"));
		assertTrue(set1.add("4"));
		assertTrue(set1.add("-1"));
		Object[] sortTest = new Object[]{"-1","0","1","3","4"};
		assertArrayEquals(sortTest, set1.toArray());
		//		Object[] tester = set1.toArray(); 
		//		for(Object i : tester)
		//			System.out.println(i);
	}
	@Test
	public void testSort2(){	
		assertTrue(set12.add(-7));
		assertTrue(set12.add(1));
		assertTrue(set12.add(0));
		assertTrue(set12.add(23));
		assertTrue(set12.add(5));
		assertFalse(set12.add(-7));
		Object[] sortTest = new Object[]{-7, 0, 1, 5, 23};
		assertArrayEquals(sortTest, set12.toArray());
	}


	@Test
	public void testRemove1(){
		set1.add("2");
		assertEquals(1, set1.size());
		assertTrue(set1.remove("2"));
		assertEquals(0, set1.size());
		assertFalse(set1.remove("z"));
	}
	@Test
	public void testRemove2(){
		assertFalse(set1.remove("z"));
		assertFalse(set1.remove("j"));
		assertFalse(set1.remove(null));
	}
	@Test
	public void testRemove3(){
		assertTrue(set7.remove("g"));
		assertEquals(2, set7.size());
		assertFalse(set7.remove("4"));
	}
	@Test
	public void testRemove4(){
		assertTrue(set11.remove(7));
		assertEquals(3, set11.size());
		assertFalse(set11.remove(21));
	}


	@Test
	public void testRemoveAll1(){
		set1.addAll(test1);
		assertTrue(set1.removeAll(test1));
		assertEquals(0, set1.size());
		assertTrue(set1.isEmpty());
		assertFalse(set1.remove(test1));
	}
	@Test
	public void testRemoveAll2(){
		assertFalse(set6.removeAll(test4));
		assertNotEquals(3, set6.size());
	}
	@Test
	public void testRemoveAll3(){
		set5.addAll(test4);
		assertTrue(set5.removeAll(test4));
		assertEquals(0, set5.size());
		set5.add("4");
		assertEquals("4", set5.last());
	}
	@Test
	public void testRemoveAll4(){
		set8.addAll(test6);
		assertTrue(set8.removeAll(test6));
		assertEquals(0, set8.size());
		set8.add(4);
		assertEquals((Integer)4, set8.last());
	}

	@Test
	public void testClear1(){
		set1.clear();
		assertEquals(0, set1.size());
		assertTrue(set1.isEmpty());
		assertNull(set1.toArray()[0]);
	}
	@Test
	public void testClear2(){
		set5.clear();
		assertEquals(0, set5.size());
		assertTrue(set5.isEmpty());
		assertNull(set5.toArray()[0]);
	}
	@Test
	public void testClear3(){
		set4.clear();
		assertTrue(set4.isEmpty());
		assertNull(set4.toArray()[0]);
	}
	@Test
	public void testClear4(){
		set8.clear();
		assertTrue(set8.isEmpty());
		assertNull(set8.toArray()[0]);
	}
	@Test
	public void testIterator1(){
		test8.add(1);
		test8.add(2);
		Iterator<Integer> list=test8.iterator();
		assertTrue(list.hasNext());
		list.next();
		list.next();
		assertFalse(list.hasNext());
	}
	@Test
	public void testIterator2(){
		Iterator<String> list=test3.iterator();
		assertTrue(list.hasNext());
		list.next();
		list.next();
		list.next();
		assertFalse(list.hasNext());
	}
	@Test
	public void testIterator3(){
		Iterator<String> list=test5.iterator();
		assertTrue(list.hasNext());
		list.next();
		list.next();
		list.next();
		list.next();
		list.next();
		list.next();
		assertFalse(list.hasNext());
	}
}