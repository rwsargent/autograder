package assignment3;

/**
 * Tyler Centini and Stefan Kapetanovic
 * u0758592 and u0871074
 * CS 2420 Assignment 3 - Spring 2015
 * Professor Miriah Meyer
 * 2-5-15
 */

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import java.awt.List;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;

public class MySortedSetTest<E> {
	private MySortedSet set2;

	@Before
	public void setUp() throws Exception {
		set2 = new MySortedSet();
		set2.add(10);
		set2.add(1);
		set2.add(5);
		set2.add(0);
		set2.add(1);

		MySortedSet setString = new MySortedSet();
		setString.add("apples");
		setString.add("bananna");
		setString.add("fog");

		Collection<String> stuff = Arrays.asList(new String[] {"fog", "apples","babies"});
		Set set2 = new HashSet((Collection) stuff);
	}
	// Tests the exceptions
	@Test
	public void firstTest() throws NoSuchElementException {
		MySortedSet set = new MySortedSet();
		set.add(10);
		set.add(1);
		set.add(5);
		set.add(0);
		set.add(1);
		assertEquals(0, set.first());
	}

	@Test
	public void lastTest() throws NoSuchElementException {
		MySortedSet set = new MySortedSet();
		set.add(10);
		set.add(1);
		set.add(5);
		set.add(0);
		set.add(1);
		assertEquals(10, set.last());
	}

	// The following tests all methods created 
	@Test
	public void addTest() {
		MySortedSet set = new MySortedSet();
		set.add(10);
		set.add(1);
		set.add(5);
		set.add(0);
		set.add(1);
		assertEquals(true, set.add(11));
		assertEquals(11, set.last());
	}

	@Test
	public void addAllTest() {

		Collection<String> stuff = Arrays.asList(new String[] {"fog", "apples","babies"});
		Set collection = new HashSet((Collection) stuff);
		MySortedSet setString = new MySortedSet();
		Object[] expected = {"fog", "apples","babies"}; 
		assertEquals(true, setString.addAll(stuff));
		assertEquals(false, setString.addAll(stuff));
	}

	@Test
	public void clearTest() {
		MySortedSet set = new MySortedSet();
		set.add(10);
		set.add(1);
		set.add(5);
		set.add(0);
		set.add(1);
		assertEquals(0,set.first());
		set.clear();
		assertEquals(0,set.size());
	}

	@Test
	public void containsTest() {
		MySortedSet set = new MySortedSet();
		set.add(10);
		set.add(1);
		set.add(5);
		set.add(0);
		set.add(1);
		assertEquals(true, set.contains(10));
		assertEquals(false, set.contains(100));
	}

	@Test
	public void containsAllTest() {
		Collection<String> stuff = Arrays.asList(new String[] {"fog", "apples","babies"});
		Set collection = new HashSet((Collection) stuff);
		MySortedSet setString = new MySortedSet();
		Object[] expected = {"fog", "apples","babies"}; 
		setString.addAll(stuff);
		assertEquals(true, setString.containsAll(stuff));
	}

	@Test
	public void isEmptyTest() {
		MySortedSet set = new MySortedSet();
		assertEquals(true, set.isEmpty());
		set.add(1);
		assertEquals(false, set.isEmpty());
	}

	@Test
	public void iteratorTest() {
		MySortedSet newSet = new MySortedSet();
		newSet.add(1);
		newSet.add(3);
		newSet.add(2);

		Iterator<Integer> testIterator = newSet.iterator();
		assertSame(1,testIterator.next());
		assertEquals(true, testIterator.hasNext());
		testIterator.next();
		testIterator.next();
		testIterator.remove();
		assertEquals(2, newSet.last());
	}

	@Test
	public void removeTest() {
		MySortedSet set = new MySortedSet();
		set.add(10);
		set.add(1);
		set.add(5);
		set.add(0);
		set.add(1);
		assertEquals(true, set.remove(5));
		assertEquals(false, set.contains(5));
	}

	@Test
	public void removeAllTest() {
		Collection<String> stuff = Arrays.asList(new String[] {"fog", "apples","babies"});
		Set collection = new HashSet((Collection) stuff);
		MySortedSet setString = new MySortedSet();
		setString.addAll(stuff);
		assertEquals(true, setString.containsAll(stuff));
		assertEquals(true, setString.removeAll(stuff));
	}

	@Test
	public void sizeTest() {
		MySortedSet set = new MySortedSet();
		set.add(10);
		set.add(1);
		set.add(5);
		set.add(0);
		set.add(1);
		assertEquals(4, set.size());
	}

	@Test
	public void toArrayTest() {
		MySortedSet set = new MySortedSet();
		set.add("fog");
		set.add("apples");
		set.add("babies");
		Object[] transfered = set.toArray();
		Object[] expected = new Object[10];
		expected[0] = "apples";
		expected[1] = "babies";
		expected[2] = "fog";
		assertArrayEquals(expected,transfered);
	}

	@After
	public void tearDown() throws Exception {
	}

	// Tests the exceptions
	@Test(expected = NoSuchElementException.class)
	public void clearTest1() {
		set2.clear();
		set2.first();

	}
	// Tests the Comparator 
	public class AgeComparator implements Comparator<Dog> {
		@Override
		public int compare(Dog o1, Dog o2) {
			return o1.getAge() - o2.getAge();
		}
	}
}