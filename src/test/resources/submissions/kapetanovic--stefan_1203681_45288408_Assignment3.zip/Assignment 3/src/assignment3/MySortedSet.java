package assignment3;

/**
 * Tyler Centini and Stefan Kapetanovic
 * u0758592 and u0871074
 * CS 2420 Assinment 3 - Spring 2015
 * Professor Miriah Meyer
 * 2-5-15
 */

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * @author  Tyler Centini and Stefan Kapetanovic 
 * @param <E> the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E data[];
	private Comparator cmp;
	private int size;
	private int elementfound;

	public MySortedSet() {
		data = (E[]) new Object[10];
		size = 0;
	}

	@SuppressWarnings("unchecked")
	/**
	 * Establishes a Comparator to be used/ tested later in the class 
	 * @param cmp
	 */
	public MySortedSet(Comparator<? super E> cmp) {
		data = (E[]) new Object[10];
		this.cmp = cmp;
	}

	@Override
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 * this set uses the natural ordering of its elements (i.e., uses
	 * Comparable).
	 */
	public Comparator<? super E> comparator() {
		return cmp;
	}

	@Override
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException if the set is empty
	 */
	public E first() throws NoSuchElementException {
		if(data[0] == null) {
			throw new NoSuchElementException();
		}
		return data[0];
	}

	@Override
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException if the set is empty
	 */
	public E last() throws NoSuchElementException {

		if(data[size-1] == null) {
			throw new NoSuchElementException();
		}
		return data[size - 1];
	}

	@Override
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * @param o an element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) {
		E temp = null;
		E temparr[] = null;
		int index = 0;

		if(o == null) {
			return false;
		}
		// Adds to the size of the array if not contained already
		if(size == 0) {
			data[index] = o;
			size++;
		}
		// Searches the data for a repeat
		else if(size > 0) {
			index = binarySearch(o);
			if(index == - 1) {
				return false;
			}
			// Doubles the array if max size is reached
			if(size == data.length) {
				temparr = (E[]) new Object[size * 2];
				for(int i = 0; i <= data.length - 1; i++) {
					temparr[i] = data[i];
				}
				data = temparr;
			}
			// The elements are shifted over one spot leaving a blank index
			for(int i = size - 1; i >= index; i--){
				temp = data[i];
				data[i + 1] = temp;
			}
			// Then the size increases with the additional object
			data[index] = o;
			size++;
		}
		return true;
	}

	@Override
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * @param c a collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
		E temparr[] = null;
		temparr = (E[]) c.toArray();
		boolean check = false;
		// Adds all elements if they are not already present and not null
		for(int i = 0; i < temparr.length; i++) {
			if(add(temparr[i])) {
				check = true;
			}
		}
		if(check) {
			return true;
		}
		return false;
	}

	@Override
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		E[] temparr = (E[]) new Object[size];
		data = temparr;
		size = 0;
	}

	@Override
	/**
	 * @param o an element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) {
		int check = binarySearch(o);
		// The binary search checks the objects if it's contained -1 is shown
		if(check == -1) {
			return true;
		}
		return false;
	}

	@Override
	/**
	 * @param c a collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified collection
	 */
	public boolean containsAll(Collection<?> c) {
		E temparr[] = null;
		temparr = (E[]) c.toArray();
		boolean check = true;
		int totalchecked = 0;

		// Goes through the array and all of its elements
		for(int i = 0; i < temparr.length; i++) {
			if(contains(temparr[i])) {
				totalchecked++;
			}
		}
		// All the data has been searched 
		if(totalchecked == temparr.length) {
			return true;
		}
		return false;
	}

	@Override
	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		if(size == 0) {
			return true;
		}
		return false;
	}

	@Override
	/**
	 * @return an iterator over the elements in this set, where the elements are returned in sorted
	 * (ascending) order
	 */
	public Iterator<E> iterator() {
		MyIterator iterator = new MyIterator();
		return iterator;
	}

	@Override
	/**
	 * Removes the specified element from this set if it is present.
	 * @param o a object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		E temp = null;
		// Searches for a specific element and removes it from the array once found
		int check = binarySearch(o); {
			if(check == - 1) {
				data[elementfound] = null;
				size--;

				// Readjusts the size of the array from the empty position
				for(int i = elementfound; i <= size - 1; i++) {
					temp = data[i + 1];
					data[i + 1] = null;
					data[i] = temp;
				}
				return true;
			}
		}
		return false;
	}

	@Override
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * @param c a collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		E temparr[] = null;
		temparr = (E[]) c.toArray();
		boolean check = true;
		int totalchecked = 0;

		// Goes through the array and if the array contains an element it is removed for 
		// every position
		for(int i = 0; i < temparr.length; i++) {
			if(contains(temparr[i])) {
				remove(data[elementfound]);
				totalchecked++;
			}
		}
		if(totalchecked == 0) {
			return false;
		}
		return true;
	}

	@Override
	/**
	 * @return the number of elements in this set
	 */
	public int size() {
		return size;
	}

	@Override
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 * (ascending) order.
	 */
	public Object[] toArray() {
		return data;
	}

	/**
	 * 
	 * @param o
	 * @return
	 */
	public int binarySearch(Object o) {
		elementfound = 0;
		int low = 0;
		int high = size - 1;
		int mid = (high + low) / 2;

		if(o instanceof Comparable<?>) {
			while(low <= high) {
				mid = (high + low) / 2;
				// If the element is found returns a -1 and becomes the index in the array
				if(((Comparable) o).compareTo(data[mid]) == 0) {
					elementfound = mid;
					return -1;
				}
				// If the element is found and greater than zero it is used to resize where 
				// the search occurs within the array
				if(((Comparable) o).compareTo(data[mid]) > 0) {
					low = mid + 1;
				}
				// If the element is found and less than zero it is used to resize where 
				// the search occurs within the array
				if(((Comparable) o).compareTo(data[mid]) < 0) {
					high = mid -1;
				}
			}
			// Finds the element spot needed for placement
			if(((Comparable) o).compareTo(data[mid]) < 0) {
				return mid;
			}
			// Finds the element spot needed for placement one ahead 
			else if(((Comparable) o).compareTo(data[mid]) > 0) {
				return mid + 1;
			}
		}
		else {
			while(low <= high) {
				mid = (high + low) / 2;
				// If the element is found returns a -1 and becomes the index in the array (Comparator)
				if(((Comparator) o).compare(o,data[mid]) == 0) {
					elementfound = mid;
					return - 1;
				}
				// If the element is found and greater than zero it is used to resize where 
				// the search occurs within the array (Comparator)
				if(((Comparator) o).compare(o,data[mid]) > 0) {
					low = mid + 1;
				}
				// If the element is found and less than zero it is used to resize where 
				// the search occurs within the array (Comparator)
				if(((Comparator) o).compare(o,data[mid]) < 0) {
					high = mid -1;
				}
			}
			// Finds the element spot needed for placement (Comparator)
			if(((Comparator) o).compare(o,data[mid]) < 0) {
				return mid;
			}
			// Finds the element spot needed for placement one ahead (Comparator)
			else if(((Comparator) o).compare(o,data[mid]) > 0) {
				return mid + 1;
			}
		}
		return mid;
	}

	/**
	 * This class was created in order for the iterator to work properly.
	 * @author Tyler Centini and Stefan Kapetanovic
	 * @param <E>
	 */
	private class MyIterator implements Iterator {

		private int index = -1;
		@Override
		/**
		 * Determines whether the iterator has a "next" element.
		 */
		public boolean hasNext() {
			return(index < size);
		}

		@Override
		/**
		 * Goes to the next element in the iterator data.
		 */
		public E next() {
			if(size > index) {
				index++;
				return data[index];
			}
			else {
				throw new NoSuchElementException();
			}
		}

		@Override
		/**
		 * Removes elements from the iterator.
		 */
		public void remove() { 
			MySortedSet.this.remove(data[index]);
		}
	}
}
