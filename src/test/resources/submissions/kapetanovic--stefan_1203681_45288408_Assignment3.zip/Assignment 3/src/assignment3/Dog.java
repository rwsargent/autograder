package assignment3;

/**
 * Tyler Centini and Stefan Kapetanovic
 * u0758592 and u0871074
 * CS 2420 Assignment 3 - Spring 2015
 * Professor Miriah Meyer
 * 2-5-15
 */

import java.util.Comparator;

/**
 * This custom Comparator class is allows us to fully test our implemented Comparator.
 */
public class Dog {
	private int age;
	private String name;
	private int weight;

	public Dog() {
	}

	public Dog(int age, String name, int weight) {
		super();
		this.age = age;
		this.name = name;
		this.age = weight;
	}

	/**
	 * Returns the age.
	 * @return age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * Sets the age.
	 * @param an integer age
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * Returns the name.
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 * @param a String name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Returns the weight.
	 * @return weight
	 */
	public int getWeight() {
		return weight;
	}

	/**
	 * Sets the weight. 
	 * @param an integer weight
	 */
	public void setWeight(int weight) {
		this.weight = weight;
	}

	@Override
	/**
	 * Creates a string with age, name, and weight details.
	 */
	public String toString() {
		return "[age =" + this.age + ", name=" + this.name + ", weight=" + this.weight + "]";
	}

	public class AgeComparator implements Comparator<Dog> {
		@Override
		// Compares two objects and both of the ages 
		public int compare(Dog o1, Dog o2) {
			return o1.getAge()-o2.getAge();
		}
	}
}