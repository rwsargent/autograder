package assignment3;

/**
 * Tyler Centini and Stefan Kapetanovic
 * u0758592 and u0871074
 * CS 2420 Assignment 3 - Spring 2015
 * Professor Miriah Meyer
 * 2-5-15
 */

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Tester {
	public static void main(String[] args) {
		MySortedSet setTest = new MySortedSet();
		MySortedSet setTest2 = new MySortedSet();

		// Additional contains timer for analysis
		for(int i = 100000; i <= 2000000;i += 100000) {
			long startTime = System.nanoTime();
			for(int j = 0; j < i ;j++) {
				setTest.add(j);
			}
			setTest.contains(4738746);
			long stopTime = System.nanoTime();
			System.out.println(i + "\t" + (stopTime - startTime));
		}

		// Additional add timer for analysis
		for(int i = 100000; i <= 2000000;i += 100000) {
			long startTime = System.nanoTime();
			for(int j = 0; j < i ;j++) {
				setTest.add(j);
			}
			setTest2.add(4);
			long stopTime = System.nanoTime();
			System.out.println(i + "\t" + (stopTime - startTime));
		}

		// Additional tests for personal clarification
		MySortedSet set = new MySortedSet();
		MySortedSet settest = new MySortedSet();
		set.add(10);
		set.add(1);
		set.add(5);
		set.add(0);
		set.add(1);
		set.add(11);
		set.add(7);
		set.add(9);
		set.add(15);
		set.add(20);
		set.add(25);
		set.add(40);
		set.add(90);
		set.add(100);
		set.add(1000);
		set.add(1001);
		set.add(200);
		set.add(67);
		set.add(234);
		set.add(33);
		set.add(87);
		set.add(45);
		set.add(34);
		set.add(23);
		set.add(2);

		MySortedSet setString = new MySortedSet();
		setString.add("apples");
		setString.add("bananna");
		setString.add("fog");
		setString.add("fog");
		setString.remove("fog");
		setString.remove("bananna");
		setString.add("fog");

		Collection<String> stuff = Arrays.asList(new String[] {"fog", "apples","babies"});
		Set set2 = new HashSet((Collection) stuff);
		setString.addAll(set2);

		setString.add("apples");
		setString.add("bananna");
		setString.add("fog");
		setString.removeAll(set2);
		setString.addAll(set2);
	}
}
