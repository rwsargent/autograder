package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Implementation of SortedSet for CS 2420 Assignment 3
 * 
 * @author Scott Dowell
 *
 * @param <E> -- Data type to hold in the SortedSet
 */
public class MySortedSet<E> implements SortedSet<E>, Iterator<E>{

	private final int DATA_STARTING_SIZE = 8;
	
	// Array to hold the data of the SortedSet
	private Object[] data;
	// Keeps track of the 'size' of the array
	private int dataSize;
	
	private int cursorPosition;
	// Comparator to use if one is specified, left null if a comparator is not specified
	private Comparator<? super E> comparator;
	
	
	/**
	 * Constructor for a MySortedSet using Comparable ordering
	 */
	public MySortedSet() {
		data = new Object[DATA_STARTING_SIZE];
		dataSize = 0;
		cursorPosition = 0;
	}
	
	/**
	 * Constructor for a MySortedSet using a specified Comparator
	 * @param comparator -- The Comparator to use for the MySortedSet
	 */
	public MySortedSet(Comparator<? super E> comparator) {
		data = new Object[DATA_STARTING_SIZE];
		dataSize = 0;
		cursorPosition = 0;
		this.comparator = comparator;
	}
	
	// --- Begin SortedSet Overrides ---
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (data[0] != null) {
			return (E) data[0];
		}	
		throw new NoSuchElementException();
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (dataSize > 0) {
			return (E) data[dataSize - 1];
		}			
		throw new NoSuchElementException();
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		
		int insertionIndex = insertionBinarySearch(o);
		if (insertionIndex == -1) {
			return false;
		}
		
		Object[] tempData = new Object[dataSize - insertionIndex];
		
		for (int i = 0; i < tempData.length; i ++) {
			tempData[i] = data[insertionIndex + i];
		}
		
		data[insertionIndex] = o;
		dataSize ++;
		
		if (dataSize == data.length - 1) {
			grow();
		}
		
		for (int i = 0; i < tempData.length; i ++) {
			data[insertionIndex + i + 1] = tempData[i];
		}
		
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean listModified = false;
		for(E element : c) {
			listModified = add(element) || listModified;
		}
		return listModified;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		data = new Object[DATA_STARTING_SIZE];
		dataSize = 0;	
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		return (binarySearch(o) != -1);
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for(Object element : c) {
			 if(! contains(element)){
				 return false;
			 }
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		return dataSize == 0;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return this;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int index = binarySearch(o);
		// If Object o exists in the list
		if (index >= 0) {
			// Move everything following o back one
			for (int i = index; i < dataSize - 1; i ++) {
				data[i] = data[i + 1];
			}
			// Remove the last data point then decrement the currentEndpoint
			data[dataSize --] = null;
			// Return true since the array was modified
			return true;
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean listModified = false;
		for(Object element : c) {
			listModified = remove(element) || listModified;
		}
		return listModified;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return dataSize;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object[] outputArray = new Object[dataSize];
		
		// Fill the output array with values from data
		for (int i = 0; i < outputArray.length; i ++) {
			outputArray[i] = data[i];
		}
		
		return outputArray;
	}
	
	// --- Begin Helper Methods ---
	/**
	 * @param query -- the object to search for
	 * @return the index of query or -1 if query is not in the list
	 */
	private int binarySearch(Object query) {
		int leftBound = 0;
		int rightBound = dataSize - 1;
		
		while (leftBound <= rightBound){
			int centerPoint = leftBound + (rightBound - leftBound) / 2;
			int comparison;
			
			// Compare the centerPoint to the query
			if (comparator == null) {
				comparison = ((Comparable<E>) data[centerPoint]).compareTo((E) query);
			}	
			else {
				comparison = comparator.compare((E) data[centerPoint], (E) query);
			}
			
			// Move the bounds respectively
			if (comparison < 0) {
				leftBound = centerPoint + 1;
			}
			else if (comparison > 0) {
				rightBound = centerPoint - 1;
			}
			// or return the index if they match
			else {
				return centerPoint;
			}
		}
		return -1;
	}
	
	/**
	 * @param query -- The object to search for
	 * @return the index of where query should be inserted into the list or -1
	 * if query already exists in the list
	 */
	private int insertionBinarySearch(Object query) {
		int leftBound = 0;
		int rightBound = dataSize - 1;
		
		while (leftBound <= rightBound){
			int centerPoint = leftBound + (rightBound - leftBound) / 2;
			int comparison;
			
			// Compare the centerPoint to the query
			if (comparator == null) {
				comparison = ((Comparable<E>) data[centerPoint]).compareTo((E) query);
			}	
			else {
				comparison = comparator.compare((E) data[centerPoint], (E) query);
			}
			
			// Move the bounds respectively
			if (comparison < 0) {
				leftBound = centerPoint + 1;
			}
			else if (comparison > 0) {
				rightBound = centerPoint - 1;
			}
			// or return -1 if the query already exists
			else {
				return -1;
			}
		}
		return leftBound;
	}
	
	/**
	 * Doubles the size of the data array
	 */
	private void grow() {
		// Copy the contents of data to a temporary array
		Object[] oldData = data;
		// Create a new data array twice the size
		data = new Object[oldData.length * 2];
		// Fill the new data array with values from the old array
		for(int i = 0; i < oldData.length; i ++){
			data[i] = oldData[i];
		}
	}

	// --- Begin Iterator Overrides ---
	/**
     * Returns {@code true} if the iteration has more elements.
     * (In other words, returns {@code true} if {@link #next} would
     * return an element rather than throwing an exception.)
     *
     * @return {@code true} if the iteration has more elements
     */
	@Override
	public boolean hasNext() {
		return cursorPosition < dataSize;
	}

	/**
     * Returns the next element in the iteration.
     *
     * @return the next element in the iteration
     * @throws NoSuchElementException if the iteration has no more elements
     */
	@Override
	public E next() {
		if(this.hasNext()) {
			return (E) data[cursorPosition ++];
		}
		throw new NoSuchElementException();
	}
}