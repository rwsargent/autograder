package assignment3;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

/**
 * JUnit tests for MySortedSet in assignment3
 * 
 * @author Scott Dowell
 */
public class MySortedSetTester {

	MySortedSet<Integer> set1;
	MySortedSet<Integer> set2;
	MySortedSet<Integer> set3;
	
	@Before
	public void setUp() {
		// Populate set1
		set1 = new MySortedSet<>();
		set1.addAll(Arrays.asList(1, 2, 3, 5));
		set2 = new MySortedSet<>(new ReverseIntegerComparator());
		set2.addAll(Arrays.asList(1, 2, 3, 5));
		set3 = new MySortedSet<>();
	}
	
	@Test
	public void addTest() {
		// Try adding a number not in the set
		assertTrue(set1.add(4));
		// Try adding a number in the set
		assertFalse(set1.add(2));
	}
	
	@Test
	public void addAllTest() {
		// Try adding a list
		assertTrue(set3.addAll(Arrays.asList(1, 3, 2, 3, 6, 4)));
		// Try adding just duplicates
		assertFalse(set3.addAll(Arrays.asList(1, 3)));
	}
	
	@Test
	public void clearTest() {
		set1.clear();
		Integer[] clearArray = {};
		assertTrue(Arrays.equals(set1.toArray(), clearArray));
	}
	
	@Test
	public void comparatorTest() {
		assertNull(set1.comparator());
		assertTrue(set2.comparator() instanceof ReverseIntegerComparator);
	}
	
	@Test
	public void containsTest() {
		assertTrue(set1.contains(1));
		assertFalse(set1.contains(4));
	}
	
	@Test
	public void containsAllTest() {
		assertTrue(set1.containsAll(Arrays.asList(1, 2, 5)));
		assertFalse(set1.containsAll(Arrays.asList(1, 2, 4)));
	}
	
	@Test
	public void firstTest() {
		assertTrue(set1.first() == 1);
	}
	
	@Test(expected = NoSuchElementException.class)
	public void firstEmptyTest() {
		set3.first();
	}
	
	@Test
	public void hasNextTest() {
		assertTrue(set1.hasNext());
		assertFalse(set3.hasNext());
	}
	
	@Test
	public void isEmptyTest() {
		assertFalse(set1.isEmpty());
		assertTrue(set3.isEmpty());
	}
	
	@Test
	public void iteratorTest() {
		Iterator<Integer> iterator = set1.iterator();
		assertTrue(iterator.hasNext());
		assertTrue(iterator.next() == 1);
	}
	
	@Test
	public void lastTest() {
		assertTrue(set1.last() == 5);
	}
	
	@Test(expected = NoSuchElementException.class)
	public void lastEmptyTest() {
		set3.last();
	}
	
	@Test
	public void nextTest() {
		assertTrue(set1.next() == 1);
		assertTrue(set1.next() == 2);
		assertTrue(set1.next() == 3);
	}
	
	@Test(expected = NoSuchElementException.class)
	public void nextTest2() {
		// Keep calling next until we reach the end of set1
		while(true) {
			set1.next();
		}
	}
	
	@Test
	public void removeTest() {
		assertTrue(set1.remove(1));
		assertFalse(set1.remove(1));
	}
	
	@Test
	public void removeAllTest() {
		assertTrue(set1.removeAll(Arrays.asList(1, 2)));
		assertTrue(set1.removeAll(Arrays.asList(3, 2)));
		assertFalse(set1.removeAll(Arrays.asList(1, 2)));
	}
	
	@Test
	public void sizeTest() {
		assertEquals(4, set1.size());
	}
	
	@Test
	public void toArrayTest() {
		Integer[] array1 = {1, 2, 3, 5};
		assertTrue(Arrays.equals(set1.toArray(), array1));
	}
}
