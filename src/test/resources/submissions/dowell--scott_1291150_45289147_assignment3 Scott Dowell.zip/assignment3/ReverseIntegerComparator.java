package assignment3;

import java.util.Comparator;

/**
 * Basic comparator to test MySortedSet(Comparator)
 * @author Scott Dowell
 */
public class ReverseIntegerComparator implements Comparator<Integer>{

	@Override
	public int compare(Integer o1, Integer o2) {
		return o2 - o1;
	}

}
