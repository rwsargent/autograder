/**
 * @author 	Patrick Armstrong, Devin McPolin
 * @since  	February 5, 2015
 */

package assignment3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.NoSuchElementException;

public class MySortedSetTest {
	
	public static void main(String[] args) {
		MySortedSet<String> list = new MySortedSet<String>();
		
		/*
		 * Empty Sorted Set
		 */
		
		//Size and empty of empty set
		if (list.size() != 0)
			System.out.println("TEST FAILED -- empty set: .size()");
		if (list.isEmpty() != true)
			System.out.println("TEST FAILED -- empty set: .isEmpty()");
		
		//First and last of empty set
		boolean emptyThrown = false;
		try {
			list.first();
			list.last();
		} catch (NoSuchElementException e){
			emptyThrown = true;
		}
		if (emptyThrown == false)
			System.out.println("TEST FAILED -- empty set: .first() and .last()");
		
		list.clear();
		
		/*
		 * Adding one item to the Sorted Set
		 */
		
		//Adding a single element
		if (list.add("A") != true)
			System.out.println("TEST FAILED -- Adding to set: .add()");
		if (list.size() != 1)
			System.out.println("TEST FAILED -- Adding to set: .size()");
		if (list.isEmpty() != false)
			System.out.println("TEST FAILED -- Adding to set: .isEmpty()");
		
		//First and last for single item
		if (list.first() != list.last())
			System.out.println("TEST FAILED -- Adding to set: .first() == .last()");
		System.out.println(list.first());
		System.out.println(list.last());
		
		//Contains for single item
		if (list.contains("A") != true)
			System.out.println("TEST FAILED -- Adding to set: .contains()");
		
		System.out.println(Arrays.toString(list.toArray()));
		
		//Remove for single item
		if (list.remove("A") != true)
			System.out.println("TEST FAILED -- Adding to set: .remove()");
		
		System.out.println(Arrays.toString(list.toArray()));
		
		/*
		 * Adding multiple item to the Sorted Set with .add()
		 */
		
		if (list.add("A") != true)
			System.out.println("TEST FAILED -- Adding to set: .add(A)");
		if (list.add("B") != true)
			System.out.println("TEST FAILED -- Adding to set: .add(B)");
		if (list.add("D") != true)
			System.out.println("TEST FAILED -- Adding to set: .add(D)");
		if (list.add("C") != true)
			System.out.println("TEST FAILED -- Adding to set: .add(C)");
		if (list.add("G") != true)
			System.out.println("TEST FAILED -- Adding to set: .add(G)");
		if (list.add("P") != true)
			System.out.println("TEST FAILED -- Adding to set: .add(P)");
		if (list.add("M") != true)
			System.out.println("TEST FAILED -- Adding to set: .add(M)");
		
		System.out.println(Arrays.toString(list.toArray()));
		
		//Already Containing C
		if (list.add("C") != false)
			System.out.println("TEST FAILED -- Adding to set: .add(C)");
		
		//First and last
		if (list.first() == list.last())
			System.out.println("TEST FAILED -- Adding to set: .first() != .last()");
		System.out.println(list.first());
		System.out.println(list.last());
		
		//Remove some things
		if (list.remove("D") != true)
			System.out.println("TEST FAILED -- Removing to set: .remove(D)");
		if (list.remove("C") != true)
			System.out.println("TEST FAILED -- Removing to set: .remove(C)");
		if (list.remove("G") != true)
			System.out.println("TEST FAILED -- Removing to set: .remove(G)");
		
		System.out.println(Arrays.toString(list.toArray()));
		
		//Check list clear
		list.clear();
		System.out.println(Arrays.toString(list.toArray()));
		
		/*
		 * Adding multiple item to the Sorted Set with .addAll()
		 */
		
		ArrayList<String> smallList = new ArrayList<String>();
		
		smallList.add("Q");
		smallList.add("W");
		smallList.add("E");
		smallList.add("R");
		smallList.add("T");
		smallList.add("Y");
		smallList.add("U");
		smallList.add("I");
		smallList.add("O");
		smallList.add("P");
		smallList.add("A");
		smallList.add("S");
		smallList.add("D");
		smallList.add("F");
		smallList.add("G");
		smallList.add("H");
		smallList.add("J");
		smallList.add("K");
		smallList.add("L");
		smallList.add("Z");
		smallList.add("X");
		smallList.add("C");
		smallList.add("V");
		smallList.add("B");
		smallList.add("N");
		smallList.add("M");
		
		if (list.addAll(smallList) != true)
			System.out.println("TEST FAILED -- Adding a collection to set: .addAll()");
		
		System.out.println(Arrays.toString(list.toArray()));
		
		//ContainsAll check
		
		if (list.containsAll(smallList) != true)
			System.out.println("TEST FAILED -- Checking a collection to set: .containsAll()");
		
		if (list.removeAll(smallList) != true)
			System.out.println("TEST FAILED -- Remove a collection to set: .removeAll()");
		
		System.out.println(Arrays.toString(list.toArray()));
	}
}
