/**
 * @author 	Patrick Armstrong, Devin McPolin
 * @since  	February 5, 2015
 */

package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E extends Comparable<E>> implements SortedSet<E>{

	private Object[] mySet;
	private int mySetLength;
	private Comparator<? super E> compare;
	
	//Default Constructor
	public MySortedSet(){
		mySet = new Object[20];
		mySetLength = 0;
		compare = null;
	}
	
	//Constructor with a give comparator
	public MySortedSet(Comparator<? super E> comp){
		mySet = new Object[20];
		mySetLength = 0;
		compare = comp;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator(){
		return compare;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException{
		if (this.isEmpty())
			throw new NoSuchElementException();
		return (E) mySet[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException{
		if (this.isEmpty())
			throw new NoSuchElementException();
		return (E) mySet[mySetLength -1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o){
		if (this.isEmpty())
		{
			mySet[0] = o;
			mySetLength = 1;
			return true;
		}
		
		if (this.contains(o) || o == null)
			return false;
		
		// Adds with binary search to the needed position
			
		// If the array size needs to be increased, double size
		Object[] tmp;
		
		if (mySet.length - 1 == mySetLength){
			tmp = new Object[mySet.length * 2];
			
			for(int element = 0; element < mySet.length; element++)
			{
				tmp[element] = mySet[element];
			}
			mySet = tmp;
		}
		
		int elementMid = this.search(o);
		
		if (this.compare(o, (E) mySet[elementMid]) >= 1)
		{
			for (int element = mySetLength; element >= elementMid; element --)
				mySet[element+1] = mySet[element];
			mySet[elementMid + 1] = o;
		}
		if (this.compare(o, (E) mySet[elementMid]) <= -1)
		{
			for (int element = mySetLength; element > elementMid; element --)
				mySet[element] = mySet[element-1];
			mySet[elementMid] = o;
		}
		
		mySetLength++;
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> collect){
		if (collect.isEmpty())
			return false;
		
		Iterator itr = collect.iterator();
		
		if (this.isEmpty())
		{
			mySet[0] = itr.next();
			mySetLength = 1;
		}
		
		while (itr.hasNext()){
			this.add((E) itr.next());
		}
		
		return true;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear(){
		for (int elements = 0; elements < mySetLength; elements++)
			mySet[elements] = null;
		
		mySetLength = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o){
		int element = this.search((E)o);
		
		if (this.compare((E) o, (E) mySet[element]) == 0)
			return true;
		
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> collect){
		if (collect.isEmpty())
			return false;
		
		Iterator itr = collect.iterator();
		
		while (itr.hasNext()){
			this.contains((E) itr.next());
		}
			
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty(){
		if (mySetLength == 0)
			return true;
		
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator(){
		return new mySetIterator<E>();
	}
	
	private class mySetIterator<E> implements Iterator<E>{
		
		private int pos = -1;
		private boolean hasCalled = false;

		@Override
		public boolean hasNext() {
			if (pos <= mySetLength - 1)
				return true;
			return false;
		}

		@Override
		public E next() {
			if (pos > mySetLength - 1)
				throw new NoSuchElementException();
			
			pos++;
			hasCalled = true;
			
			return (E) mySet[pos];
		}
		
		public void remove(){
			if (hasCalled){
				
			MySortedSet.this.remove(mySet[pos]);
			pos --;
			
			hasCalled = false;
			}else{
				throw new IllegalStateException();
			}
		}
	}
	

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o){
		if (!(this.contains(o)) || o == null)
			return false;
		
		int elementMid = this.search((E)o);
		
		for (int element = elementMid; element < mySetLength; element ++){
			if (mySet[element + 1] == null)
				mySet[element] = null;
			mySet[element] = mySet[element+1];
		}
		
		mySetLength --;
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> collect){
		if (this.containsAll(collect)){
			Iterator itr = collect.iterator();
			
			while (itr.hasNext()){
				this.remove((E) itr.next());
			}
			return true;
		}
		
		return false;
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size(){
		return mySetLength;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray(){
		Object[] tmp = new Object[mySetLength];
		
		for(int element = 0; element < mySetLength; element++)
		{
			tmp[element] = mySet[element];
		}
		
		return tmp;
	}
	
	/**
	 * Searches the array for the element, or where the element should be placed
	 * 
	 * @param o
	 *            -- object to be searched from this set
	 * @return the element placement that is nearest to the element
	 */
	private int search(E o){
		int low = 0;
		int high = mySetLength - 1;
		int mid = 0;
		
		while (low <= high) {
			mid = (high + low) / 2;
			
			if (this.compare(o, (E) mySet[mid]) >= 1)
            	low = mid + 1;
            else if (this.compare(o, (E) mySet[mid]) <= -1)
            	high = mid - 1;
            else
            	return mid;
		}
		return mid;
	}
	/**
	 * @return the needed comparator
	 */
	private int compare(E lhs, E rhs){
		if (this.comparator() == null)
			return lhs.compareTo(rhs);
		return comparator().compare(lhs, rhs);
	}
}