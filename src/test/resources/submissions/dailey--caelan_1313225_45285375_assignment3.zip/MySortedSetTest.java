/*
 * Caelan Dailey
 * Jeremy Wu
 * 
 * 2/5/2015
 * 
 * 
 */



package assignment3;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest {
	
	MySortedSet<Integer> tester;

	@Before
	public void setUp() throws Exception {
		
		
		
		tester = new MySortedSet<Integer>();
		
		//test add
		tester.add(2);
		tester.add(12);
		tester.add(7);
		tester.add(19);
		tester.add(21);
		tester.add(1);
		tester.add(21);
		tester.add(17);
		tester.add(49);
		tester.add(56);
		tester.add(11);
		tester.add(95);
		
		//test remove
		tester.remove(0);
		tester.remove(1);
		tester.contains(2);
		
		//test clear
		tester.clear();
		
		//addall
		tester.addAll(c);
		
		//removeall
		tester.removeAll(c);
		
	}
	//last
	@Test
	public void test1() {
		
		assertEquals(21, (int) tester.last());
	}
	//contains
	@Test
	public void test2() {
		
		assertEquals(false,  tester.contains(2));
	}
	//first
	@Test
	public void test3() {
		
		assertEquals(1, (int) tester.first());
	}
	//first
	@Test
	public void test4() {
		
		assertEquals(21, (int) tester.first());
	}
	//first
	@Test
	public void test5() {
		
		assertEquals(null, (int) tester.first());
	}
	//contains
	@Test
	public void test6() {
		
		assertEquals(false, tester.contains(21));
	}
	//isEmpty
	@Test
	public void test7() {
		
		assertEquals(true, tester.isEmpty());
	}
	//size
	@Test
	public void test8() {
		
		assertEquals(0, tester.size());
	} 
	//toArray
	@Test
	public void test9() {
		
		assertEquals(tester, tester.toArray());
	}
	//containsall
	@Test
	public void test10() {
		
		assertEquals(tester, tester.containsAll(c));
	}
	//add all
	@Test
	public void test11() {
		
		assertEquals(1, (int) tester.first());
	}
}
