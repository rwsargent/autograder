/*
 * Caelan Dailey
 * Jeremy Wu
 * 
 * 2/5/2015
 * 
 * 
 */



package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;


public class MySortedSet<E> {
	
	//set private variables
	private E[] array;
	private Comparator<? super E> _comparator;
	private int size = 0;
	private int capacity = 10;
	
	//boolean comparator;
	@SuppressWarnings("unchecked")
	
	/**
	 * Creates the array with capacity
	 * 
	 * @param none
	 *            
	 * @return none
	 */
	public MySortedSet() {
		//create array with capacity
		array = (E[])new Object[capacity];
		_comparator = null;
	}
	/**
	 * Creates the comparator
	 * 
	 * @param none
	 *            
	 * @return none
	 */
	public MySortedSet(Comparator<? super E> compare) {
	_comparator = compare;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator(){
		return _comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException 
	{
		//if set is empty
		if (this.size == 0) {
			throw new NoSuchElementException();
		}
	    //return first element
		return (array[0]);
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException 
	{
		//if set is empty
		if (this.size == 0) {
			throw new NoSuchElementException();
		}
		//return last element
		return (array[size-1]);
	}

	
	
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) 
	{
		//create variables high and low for binary search
		int low = 0;
		int high = size -1;
		
		//if it does not already contain the element(contain returns true if it has it)
		//if the element is not equal to null
		if (contains(o) == false && o != null)
		{
			//check if o is an comparable
			if (o instanceof Comparable)
			{
				//set o as comparable(compare)
				Comparable compare = (Comparable) o;
			//if there's nothing in there, just add at the first position
			if (size == 0)
			{
				array[0] = o;
				size++;
				return true;
			}
			
			//while searching high != low. When search is done they're equal
			while(high >= low)
			{
				//middle is equal to the middle of high and low
				int middle = (high+low)/2;
				//if the middle is equal to the object
				while(array[middle] == null)
				{
					
				
				if (array[middle] == null)
				{
					middle--;
				}
				}
				if (compare.compareTo(array[middle]) == 0)
				{
					//get ready to add by increasing capacity if needed
					if (size == capacity)
					{
						capacity = capacity*2;
					}
					
					//in order to add, need to move everything over first. Start at position(middle)
					for (int i = middle; i < (size-1); i++)
					{
					//add positions over	
					array[i+1] = array[i];
					}
					//add object afterwards
					array[middle] = o;
					size++;
					//return true when done adding because it did not already contain it
					return true;
				}
				//if it's greater than the middle then get more specific
				if(compare.compareTo(array[middle]) > 0)
				{
					low = middle+1;
				}
				//if it's less than the middle then get more specific inbetween 0 and the middle
				if(compare.compareTo(array[middle]) < 0)
				{
					high = middle-1;
				}

			}	
		}
			//else is for objects that cannot be comparable
			else
			{
				//increase size if needed
				if (size == 0)
				{
					array[0] = o;
					size++;
				}
				//while searching high >= low. When search is done they're equal
				while(high >= low)
				{
					//middle is equal to the middle of high and low
					int middle = (high+low)/2;
					//if middle is equal to o. Uses _comparator instead now
					if (array[middle] == null ||_comparator.compare(o, array[middle]) == 0)
					{
						//get ready to add object, increase size if needed
						if (size == capacity)
						{
							capacity = capacity*2;
						}
						
						//move objects over in order to add object
						for (int i = middle; i < (size-1); i++)
						{
						array[i+1] = array[i];
						}
						array[middle] = o;
						size++;
						//return true after adding because it didn't contain it
						return true;
					}
					//get more specific in the search
					if(_comparator.compare(o, array[middle]) > 0)
					{
						low = middle+1;
					}
					if(_comparator.compare(o, array[middle]) < 0)
					{
						high = middle-1;
					}
				}
			}
		}
		//return false if it already contained it
		return false;
		
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
		//change the form of the collection inoder to be able to use it
		@SuppressWarnings("unchecked")
		E[] collect = (E[])(c.toArray(new Object[c.size()]));
		//Use check to see when we make changes as a result of the call
		int check = 0;
		for (int i = 0; i<array.length; i++)
		{
			for(int k = 0; k<collect.length;k++)
			{
				if (collect[k] == array[i])
				{
					add(collect[k]);
					check++;
				}
			}
		}
		//if we made changes check increased. Return true if check changed
		if (check > 0)
			return true;
		//if check didn't change it means no changes where made. return false
		return false;
		
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 * We can basically call remove to remove everything
	 */
	public void clear() {
		
		//go through all the positions
		for(int i = 0; i < size; i++)
		{
			remove(i);
		}
		
		//reset the values to the beginning values
		size = 0;
		capacity = 10;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) {
		//set values for binary search
		int low = 0;
		int high = array.length - 1;
		
		//if ((MySortedSet.isInstance(o) != null)
		//{
			//while high is >= low. Equal when done
			while(high >= low)
			{
			//check if o is comparable
				if (o instanceof Comparable)
				{
					//set o as comparable compare
					Comparable compare = (Comparable) o;
				
					//middle is set to high+low/2
					int middle = (high+low)/2;
					//if the middle is equal to o return true
					if (size == 0)
					{
						return false;
					}
					if (array[middle] != null)
					{
						if (compare.compareTo(array[middle]) == 0)
						{
							return true;
						}
						else if (compare.compareTo(array[middle]) > 0)
						{
							high = middle-1;
						}
						
						//if not equal to middle continue searching
						else if (compare.compareTo(array[middle]) < 0)
						{
							low = middle+1;
						}
					}
					return false;
				}	
			
			//if o is not an instance of comparable
			else
			{
				//set oo as E of o.
				E oo = (E) o;
				int middle = (high+low)/2;
				//if it's equal
				if (array[middle] != null)
				{
					if (_comparator.compare(oo, array[middle]) == 0)
					{
						return true;
					}
					//if it's greater
					if(_comparator.compare(oo, array[middle]) > 0)
					{
						low = middle+1;
					}
					//if it's less
					if(_comparator.compare(oo, array[middle]) < 0)
					{
						high = middle-1;
					}
				}
			}
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c) {
		//check counts the amount of times it finds the specific object
		int check = 0;
		//create new object of c
		@SuppressWarnings("unchecked")
		E[] collect = (E[])(c.toArray(new Object[c.size()]));
		//go through array
		for (int i = 0; i < size; i++)
		{
		//go through collection c
		for (int k = 0; k<collect.length; k++)
			{
			//if they're equal, check++
			if (collect[k] == array[i])
				{
				check++;
				}
			}
		}
		//if check is = the length of collection, it means they all exists in the list
		if (check == collect.length)
			return true;
		//if not equal its not all in there, return false
			return false;
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		//if the size is 0 it's empty
		if (size == 0)
			return true;
		//if it's not 0 it has something
			return false;
		
		
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		
		//create class for hasNext and next
		class theIterator<E> implements Iterator<E> {
			//variable for the position of the iterator
			private int iteratorPos;
			
			/**
			 * @return true if the next position is not null
			 *         
			 */
			@Override
			public boolean hasNext() {
				//if the next position is not null
				if (array[iteratorPos+1] != null)
				{
					return true;
				}
				//if it's null there's no position
				return false;
			}
			/**
			 * @return what the iterator is at iterator position
			 *         
			 */
			@Override
			public E next() {
				//move iterator
				iteratorPos++;
				return (E) array[iteratorPos];
			}
		}
		return new theIterator<E>();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) 
	{
		int pos = 0;
		
		//go through positions and get position
		for (int p = 0; p < size; p++)
		{
			if(o == array[p])
				break;
			pos++;
		}	
		//if it contains it
		if (contains(o) == true)
		{
			for (int i = pos; i < (size-1); i++)
			{
			//move position over to delete them(overriding them)
			array[i] = array[i+1];
			}
			//decrease size after removal
			size--;
		}
		//if it contains it return true
		return (contains(o));
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		//check to see if it's been changed
		int check = 0;
		@SuppressWarnings("unchecked")
		//create object
		E[] collect = (E[])(c.toArray(new Object[c.size()]));
		//go through array
		for (int i = 0; i < size; i++)
		{
			//go through collection
			for (int k = 0; k<collect.length; k++)
			{
				//if equal remove it and check++
				if (collect[k] == array[i])
				{
					remove(array[i]);
					check++;
				}
			}
		}
		//if check is above 0 there's been a change. Return true
		if (check > 0)
			return true;
		//return false if check is = 0(no change)
		return false;
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size() {
		//size is just equal to the private variable
		return (size);
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		//the array is already sorted. Just return the array
		return array;
	}

}
