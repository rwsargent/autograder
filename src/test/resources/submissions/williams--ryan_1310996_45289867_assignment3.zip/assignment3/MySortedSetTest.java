package assignment3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

/**
 * 
 * @author Ryan Williams and Lonnie Lund 
 * 
 * This classes primary purpose is to test the MySortedSet code written by me (Ryan) and Lonnie
 * It's purpose is to thoroughly test MySortedSet<E> by manipulating its data.  
 *
 */
public class MySortedSetTest
{
	public static void main(String[] args)
	{
		//Create a bunch of String objects to test MySortedSet
		String msst = new String("Ryan");
		String msst1 = new String("David");
		String  msst2 = new String("William");
		String msst3 = new String("Paul");
		String msst4 = new String("Christian");
		String msst5 = new String("Jim");
		
		MySortedSet<String> mss = new MySortedSet<String>(); //create the sorted set of type String 
		
		//test the add function 
		mss.add(msst);
		mss.add(msst1);
		mss.add(msst2);
		mss.add(msst3);
		mss.add(msst4);
		mss.add(msst4);
		
		//test the remove function
		mss.remove(msst1);
		
		//test toArray to make sure it works, notice it didn't print out msst4 twice? Nor did it print out the object we removed 
		System.out.println(mss.toArray()[0]);
		System.out.println(mss.toArray()[1]);
		System.out.println(mss.toArray()[2]);
		System.out.println(mss.toArray()[3]);
		System.out.println(mss.toArray()[4]);
		System.out.println(mss.toArray()[5]);
		System.out.println(mss.toArray()[6]);
		System.out.println(mss.toArray()[7]);
		System.out.println(mss.toArray()[8]);
		System.out.println(mss.toArray()[9]);
		
		System.out.println("The size of the sorted set is: " + mss.size() + '\n'); // size should be five 
		
		//now test to make sure we can't remove an item that isn't there
		
		mss.remove(msst1);
		
		System.out.println(mss.toArray()[0]);
		System.out.println(mss.toArray()[1]);
		System.out.println(mss.toArray()[2]);
		System.out.println(mss.toArray()[3]);
		System.out.println(mss.toArray()[4]);
		System.out.println(mss.toArray()[5]);
		System.out.println(mss.toArray()[6]);
		System.out.println(mss.toArray()[7]);
		System.out.println(mss.toArray()[8]);
		System.out.println(mss.toArray()[9]);
		
		System.out.println("The size of the sorted set is: " + mss.size() + '\n'); // size should still be five 
		
		
		//now we want to see if our array grows accordingly 
		
		String msst6 = new String("Lonnie");
		String msst7 = new String("Sabrina");
		String msst8 = new String("Tayler");
		String msst9 = new String("Joe");
		String msst10 = new String("Bob");
		
		mss.add(msst1); //add David back in after we removed him 
		mss.add(msst5);
		mss.add(msst6);
		mss.add(msst7);
		mss.add(msst8);
		mss.add(msst9);
		mss.add(msst10);
		
		System.out.println(mss.toArray()[0]);
		System.out.println(mss.toArray()[1]);
		System.out.println(mss.toArray()[2]);
		System.out.println(mss.toArray()[3]);
		System.out.println(mss.toArray()[4]);
		System.out.println(mss.toArray()[5]);
		System.out.println(mss.toArray()[6]);
		System.out.println(mss.toArray()[7]);
		System.out.println(mss.toArray()[8]);
		System.out.println(mss.toArray()[9]);
		System.out.println(mss.toArray()[10]);
		System.out.println(mss.toArray()[11]);
		System.out.println(mss.toArray()[12]);
		System.out.println(mss.toArray()[13]);
		System.out.println(mss.toArray()[14]);
		System.out.println(mss.toArray()[15]);
		
		System.out.println("The size of the sorted set is: " + mss.size() + '\n'); //we've added more elements than what the initial array could hold, as you can see we did not throw a index out of bounds exception 
		
		//now test to see if last() and first() work we know first is bob (msst10) and last is William (msst2)
		if(mss.last() == msst2 && mss.first() == msst10)
		{
			System.out.println("The test passed: last() && first()");
		}
		else
		{
			System.out.println("The test failed!");
		}
		
		//now we want to test contains 
		
		if(mss.contains(msst5))
		{
			System.out.println("The test passed: contains()" + '\n');
		}
		
		mss.remove(msst5);
		if(mss.contains(msst5))
		{
			System.out.println("The test failed: contains()" + '\n'); //this shouldn't print out seems we removed msst5 from the set 
		}  
		
		//now we want to test our iterator that MySortedSet returns, but with type Integer this time 
		
		MySortedSet<Integer> mss1 = new MySortedSet<Integer>();
		
		mss1.add(13);
		mss1.add(17);
		mss1.add(3);
		mss1.add(5);
		
		System.out.println(mss1.toArray()[0]);
		System.out.println(mss1.toArray()[1]);
		System.out.println(mss1.toArray()[2]);
		System.out.println(mss1.toArray()[3]);
		System.out.println(mss1.toArray()[4]);
		
		Iterator<Integer> it = mss1.iterator();
		
		if(it.hasNext())//this should print true seems we should be able to advance one 
		{
			System.out.println("The test passed: hasNext()" + '\n');
		}
		
		System.out.println(it.next()); //as we iterate along our array we can see that it is consuming the element and then moving onto the next one 
		System.out.println(it.next());
		System.out.println(it.next());
		
		it.remove();
		
		System.out.println(mss1.toArray()[0]); //when we reprint out the array we can see that 
		System.out.println(mss1.toArray()[1]); //everything prints out but the 17, because we removed
		System.out.println(mss1.toArray()[2]); //seems thats where counter was poiting when we removed it 
		System.out.println(mss1.toArray()[3]);
		System.out.println(mss1.toArray()[4]);
		
		//now we want to verify addAll(), removeAll(), and containsAll()
		
		//we need to create a collection to add to MySortedSet<E>
		
		ArrayList<Integer> array = new ArrayList<Integer>();
		MySortedSet<Integer> mss2 = new MySortedSet<Integer>();
		
		array.add(4);
		array.add(2);
		array.add(1);
		array.add(8);
		array.add(17);
		array.add(12);
		
		
		mss2.addAll(array);
		
		System.out.println("");
		System.out.println(mss2.toArray()[0]);  
		System.out.println(mss2.toArray()[1]); //as you can see, everything in the arraylist (which is a collection)
		System.out.println(mss2.toArray()[2]); //was added to MySortedSet, in ascending order. then we verify the size of the array
		System.out.println(mss2.toArray()[3]); //with what was in the array list
		System.out.println(mss2.toArray()[4]);
		System.out.println(mss2.toArray()[5]); 
		System.out.println(mss2.toArray()[6]);
		System.out.println(mss2.toArray()[7]);
		System.out.println("The size of the array is: " + mss2.size());
		
		if(mss2.containsAll(array))
		{
			System.out.println("Test passed: containsAll()");
		}
		
		//removeAll()
		ArrayList<Integer> array1 = new ArrayList<Integer>();
		MySortedSet<Integer> mss3 = new MySortedSet<Integer>();
		
		mss3.add(14);
		mss3.add(13);
		mss3.add(1);
		mss3.add(20);
		mss3.add(11);
		mss3.add(2);
		
		array1.add(2);
		array1.add(1);
		array1.add(20);
		array1.add(14);
		
		mss3.removeAll(array1);
		
		System.out.println("");
		System.out.println(mss3.toArray()[0]);  
		System.out.println(mss3.toArray()[1]); 
		System.out.println(mss3.toArray()[2]); //here you can see that only numbers you can see left in 
		System.out.println(mss3.toArray()[3]); //MySortedSet is 11 and 13, because those were the only things 
		System.out.println(mss3.toArray()[4]); //not in the array list
		System.out.println(mss3.toArray()[5]);
		
		
		//here is where I time the code to answer the analysis doc questions 
		
		MySortedSet<Integer> mss4 = new MySortedSet<Integer>();
	//	mss4.add(827);
		
		long startTime, midpointTime, stopTime;

	    // First, spin computing stuff until one second has gone by.
	    // This allows this thread to stabilize.

	    startTime = System.nanoTime();
	    while (System.nanoTime() - startTime < 1000000000) { // empty block
	    }

	    // Now, run the test.

	    long timesToLoop = 2000000;

	    startTime = System.nanoTime();
	    
	    for (long i = 0; i < timesToLoop; i++)
		      for (double d = 1; d <= 10; d++)
		      {
		    	  mss4.contains(827); 
		      }
	    
	    midpointTime = System.nanoTime();
	    
	    // Run an empty loop to capture the cost of running the loop.

	    for (long i = 0; i < timesToLoop; i++) { // empty block
	    }

	    stopTime = System.nanoTime();

	    // Compute the time, subtract the cost of running the loop
	    // from the cost of running the loop and computing square roots.
	    // Average it over the number of runs.

	    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
	        / timesToLoop;

	    System.out.println("It takes exactly " + averageTime
	        + " nanoseconds to compute where the number is contained in the set ");
	    
//------------------ Timing code to answer question 7 in analysis doc --------------------------------------//
		
	  		mss4.add(621);
	  		mss4.add(826);
	  		mss4.add(6);
	  		mss4.add(86);
	  		mss4.add(527);
	  	    // First, spin computing stuff until one second has gone by.
	  	    // This allows this thread to stabilize.

	  	    startTime = System.nanoTime();
	  	    while (System.nanoTime() - startTime < 1000000000) { // empty block
	  	    }

	  	    // Now, run the test.

	  	    timesToLoop = 80000;

	  	    startTime = System.nanoTime();
	  	    
	  	    for (long i = 0; i < timesToLoop; i++)
	  		      for (double d = 1; d <= 10; d++)
	  		      {
	  		    	  mss4.add(827); 
	  		      }
	  	    
	  	    midpointTime = System.nanoTime();
	  	    
	  	    // Run an empty loop to capture the cost of running the loop.

	  	    for (long i = 0; i < timesToLoop; i++) { // empty block
	  	    }

	  	    stopTime = System.nanoTime();

	  	    // Compute the time, subtract the cost of running the loop
	  	    // from the cost of running the loop and computing square roots.
	  	    // Average it over the number of runs.

	  	    averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
	  	        / timesToLoop;

	  	    System.out.println("It takes exactly " + averageTime
	  	        + " nanoseconds to add the number to the sorted set ");
	  }
}

