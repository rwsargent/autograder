package assignment3;

import java.util.Collection;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 * @author Ryan Williams and Lonnie Lund 
 *
 * @param <E>
 * 
 * MySortedSet implements the SortedSet Interface that is provided by java
 * This implementation is backed by an array of generic type E
 * The array grows accordingly when it runs out of room (doubles in size every time)
 * The class also contains an Iterator object that also implements Java's Iterator  
 */
public class MySortedSet<E> implements SortedSet<E>
{
	private E[] mySortedArray;
	private Comparator<? super E> _comparator = null;
	private int _counter;
	private boolean _isComparator = false;
	private int _whatindex;
	
	public MySortedSet()
	{
		mySortedArray =  (E[]) new Object[10]; //create a new object array and cast it to type E
		_counter = 0;
		// a.compareTo(b); where a and b are E objects
	}
	
	
	public MySortedSet(Comparator<? super E> comparator)
	{
		this(); //when calling this constructor we need to pass up to the no param. constructor to create the object 
		_comparator = comparator;
		_isComparator = true;
		// comparator.compare(a, b); where a and b are E objects
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() 
	{	
		if(_comparator == null) //we don't wan't to return a comparator for objects using comparable 
		{
			return null;
		}
		
		return _comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException 
	{
		if(_counter == 0)//if counter is equal to zero then we know the set is empty 
		{
			throw new NoSuchElementException();
		}
		return mySortedArray[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException 
	{
		if(_counter == 0)//if counter is equal to zero then we know the set is empty
		{
			throw new NoSuchElementException();
		}
		return mySortedArray[_counter - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o)
	{   
		if(this.contains(o) || o == null) //if the element we want to add is set to null then we do not add it to the set 
		{
			return false;
		} 
		
		//check to see if we need to grow our array (are we out of space?)
		if(_counter == mySortedArray.length - 1)//check to see if we need to grow our array (are we out of space?)
		{
			E[] tempArray = (E[]) new Object[mySortedArray.length * 2]; //create a temp array to double the size accordingly
			for(int i = 0; i < mySortedArray.length; i++)
			{
				tempArray[i] = mySortedArray[i]; //copy everything over 
			}
			mySortedArray = tempArray; //give the pointer of the new array to our old array mySortedArray
		}
		
		if(_isComparator) //check to see whether we have a comparator object or not, when we created our object 
		{
			_whatindex = comparatorBinarySearch(o);
			if(_whatindex < 0) //if we get a negative number than we don't know where to put it 
			{
				mySortedArray[_counter] = o;
				_counter++;
				return true;
			}
			else //we put it in the indicated spot
			{
				E temp = mySortedArray[_whatindex];
				mySortedArray[_whatindex] = o;
				
				for(int i = _whatindex + 1; i < mySortedArray.length; i++)
				{
					E temp1 = mySortedArray[i];
					mySortedArray[i] = temp;
					temp = temp1;
				}
				_counter++;
				return true;
			}
		}
		else //here is where we compare with comparable 
		{
			Comparable<E> _comp = (Comparable<E>) o;
			_whatindex = comparableBinarySearch(_comp);
			if(_whatindex < 0) //if we get a negative number than we put it at the end 
			{
				mySortedArray[_counter] = o;
				_counter++;
				return true;
			}
			else //we put it in the indicated spot
			{
				E temp = mySortedArray[_whatindex];
				mySortedArray[_whatindex] = o;
				
				for(int i = _whatindex + 1; i < mySortedArray.length; i++)
				{
					E temp1 = mySortedArray[i];
					mySortedArray[i] = temp;
					temp = temp1;
				}
				_counter++;
				return true;
			}
		}
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) 
	{
		boolean bool = false;
		for(E e: c) //we want to add each element e of type E from c to our array 
		{
			bool |= this.add(e); //if we change just one thing we will get at least one true value then giving us bool = true 
		}
		return bool;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() 
	{
		for(int i = 0; i < mySortedArray.length; i++)//loop through and clear all values of the array, null elements signify empty elements 
		{
			mySortedArray[i] = null;
		}
		_counter = 0;//set size of our array to zero since we just cleared it
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o)
	{
		if(_counter == 0) //if the set is empty then we automatically know the element is not in there 
		{
			return false;
		}
		
		if(_isComparator) //check to see if we have a comparator to use it or not in our binary search 
		{
			_whatindex = comparatorBinarySearch((E) o);
			
			if(o == mySortedArray[_whatindex])
			{
				return true;
			}
			return false;
		}
		else 
		{
			Comparable<E> comp = (Comparable<E>) o;
			_whatindex = comparableBinarySearch(comp);
			
			if(o == mySortedArray[_whatindex])
			{
				return true;
			}
			return false;
		}
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) 
	{
		boolean bool = true;
		for(Object e : c) //check for containment of each element e of type Object from our collection in our array 
		{
			bool &= contains(e); //only true if the set contains all of them, so they all need to return true, not just one
		}
		return bool;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty()
	{
		return (_counter == 0);
	}
	
	/**
	 * This binary search has been implemented using the class book 
	 * (Data Structures Problem Solving Using Java, 4th Edition), by Mark Allen Weiss. 
	 * Found on page: 247
	 * 
	 * @param -- comparable object of type E
	 * 
	 * @return -- returns the position of where to add the element 
	 */
	public int comparableBinarySearch(Comparable<E> c)
	{
		int lower = 0;
		int upper = _counter;
		int middle = 0;
		while(lower < upper)
		{
			middle = (lower + upper) / 2;
			if(c.compareTo(mySortedArray[middle]) > 0)
			{
				lower = middle + 1;
			}
			else 
			{
				upper = middle;
			}
		}
		return lower;
	}
	
	/**
	 * This binary search has been implemented using the class book 
	 * (Data Structures Problem Solving Using Java, 4th Edition), by Mark Allen Weiss. 
	 * Found on page: 247
	 * 
	 * @param -- object o of type E
	 * 
	 * @return -- returns the position of where to add the element 
	 */
	public int comparatorBinarySearch(E o)
	{
		int lower = 0;
		int upper = _counter;
		int middle = 0;
		while(lower < upper)
		{
			middle = (lower + upper) / 2;
			if(_comparator.compare(o, mySortedArray[middle]) > 0)
			{
				lower = middle + 1;
			}
			else 
			{
				upper = middle;
			}
		}
		return lower;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator()
	{
		return new MyIterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o)
	{
		if(_counter == 0) //we can't remove items from an array that is empty
		{
			return false;
		} 
		
		for(int i = 0; i < mySortedArray.length; i++)
		{
			if(mySortedArray[i] == o) //we only want to remove items that actually exist in the array
			{
				for(int j = i; j < _counter; j++) //loop through to shift everything over by one to remove the element 
				{
					mySortedArray[j] = mySortedArray[j+1];
				}
				mySortedArray[_counter] = null;
				_counter--; //now we have one less item in the array
				return true;
			}
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) 
	{
		boolean bool = false;
		for(Object e : c) //we want to remove each element e of type Object in c from our array 
		{
			bool |= remove(e);
		}
		return bool;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() 
	{
		return _counter;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() 
	{
		return mySortedArray;
	}

	public class MyIterator implements Iterator<E>
	{
		int counter;
		boolean nextCalled;

		/**
		 * Constructor for MyIterator class that implements the Iterator Class in java 
		 */
		public MyIterator()
		{
			counter = 0;
		    nextCalled = false;
		}
		
		/**
		 * Determines whether there is another space to move to in the array 
		 * 
		 * @return -- true if we can advance 
		 *         -- false if we can not advance 
		 */
		@Override
		public boolean hasNext() 
		{
				return (counter < mySortedArray.length); //check to see if we can continue advancing 
		}

		/**
		 * Advances along our array while consuming the elements at the given spot 
		 * Also sets nextCalled to true so we know it is safe to call removes() after calling it 
		 * 
		 * @return -- returns the next element in the array
		 */
		@Override
		public E next() 
		{	
			if(counter >= mySortedArray.length)
			{
				throw new NoSuchElementException();
			}
			
			nextCalled = true; //set nextCalled to true so we know whether we can call remove next or not 
			
			return mySortedArray[counter++]; //consume the place and then advance where we are in the array
		}

		/**
		 * Removes the element where the counter is currently at 
		 */
		@Override
		public void remove() 
		{
			if(!(nextCalled)) //checking to make sure next() was called BEFORE remove()
			{
				throw new IllegalStateException();
			}
			
			//no need to implement UnsupportedOperationException seems remove will always be supported in this class 
			
			MySortedSet.this.remove(mySortedArray[counter]);
			nextCalled = false; //set to false to make sure next() gets called before remove() does again 
			
		}
	}
}
