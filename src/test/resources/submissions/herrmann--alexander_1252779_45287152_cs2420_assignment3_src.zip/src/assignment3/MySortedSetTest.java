package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.Computer;

public class MySortedSetTest
{

    MySortedSet<String> test1;

    private class CaseInsensitiveStringComparator implements Comparator <String>
    {

        @Override
        public int compare(String o1, String o2)
        {
            return o1.compareToIgnoreCase(o2);
        }

    }

    @Before
    public void setUp() throws Exception
    {
        String[] tarr1 = new String[] {"BC", "zz", "BB", "A1", "B1", "Zx", "bb", "BD"};


        ArrayList<String> arrl1 = new ArrayList<String>(Arrays.asList(tarr1));
        this.test1 = new MySortedSet<String>(null);
//        System.out.println("adding");
        this.test1.addAll(arrl1);


    }

    @Test
    public void testFirst()
    {
        assertEquals("A1", test1.first());
    }

    @Test
    public void testLast()
    {
        assertEquals("zz", test1.last());
    }

    @Test
    public void testAdd()
    {
        assertFalse(this.test1.contains("zy"));
        assertFalse(this.test1.contains("DO IT"));

        this.test1.add("zy");
        this.test1.add("DO IT");
        this.test1.add("I'M A LIGER");
        assertEquals(11, this.test1.size());

        assertTrue(this.test1.contains("zy"));
        assertTrue(this.test1.contains("DO IT"));
        assertTrue(this.test1.contains("I'M A LIGER"));
    }

    @Test
    public void testAddAll()
    {
        this.test1.addAll(Arrays.asList(new String[] {"zzz", "DO IT", "I'M NOT A LIGER"}));
        assertTrue(this.test1.contains("zzz"));
        assertTrue(this.test1.contains("DO IT"));
        assertTrue(this.test1.contains("I'M NOT A LIGER"));
        assertEquals("zzz", this.test1.last());
    }

    @Test
    public void testClear()
    {
        assertEquals(8, this.test1.size());
        this.test1.clear();
        assertEquals(0, this.test1.size());
    }

    @Test
    public void testContains()
    {
        assertTrue(this.test1.contains("Zx"));
        assertTrue(this.test1.contains("BD"));
        assertTrue(this.test1.contains("bb"));

        assertFalse(this.test1.contains("Zy"));
        assertFalse(this.test1.contains("B2"));
    }

    @Test
    public void testContainsAll()
    {
        String[] tarr1 = new String[] {"BC", "zz", "BB", "A1", "B1", "Zx", "bb", "BD"};
        this.test1.containsAll(Arrays.asList(tarr1));
    }

    @Test
    public void testIsEmpty()
    {
        assertFalse(this.test1.isEmpty());
        this.test1.clear();
        assertTrue(this.test1.isEmpty());
    }

    @Test
    public void testIterator()
    {
        ArrayList<String> compdata = new ArrayList<String>();
        for(String c : this.test1)
        {
            compdata.add(c);
        }
        boolean hasall = this.test1.containsAll(compdata);
        assertTrue(hasall);

        this.test1.add("bzz like a bee");

        compdata.clear();
        for(String c : this.test1)
        {
            compdata.add(c);
        }
        assertTrue(compdata.contains("bzz like a bee"));
        assertTrue(compdata.contains("B1"));
    }

    @Test
    public void testRemove()
    {
        assertTrue(this.test1.contains("Zx"));
        assertTrue(this.test1.remove("Zx"));
        assertFalse(this.test1.remove("Not here"));
        assertFalse(this.test1.contains("Zx"));
    }

    @Test
    public void testRemoveAll()
    {
        this.test1.removeAll(Arrays.asList(new String[] {"Zx", "A1"} ));

        assertFalse(test1.contains("A1"));
        assertFalse(test1.contains("Zx"));

    }

    @Test
    public void testSize()
    {
        assertEquals(8, this.test1.size());
    }

    @Test
    public void testToArray()
    {
//        assertArrayEquals(new String[] {"BC", "zz", "BB", "A1", "B1", "Zx", "bb", "BD"}, this.test1.toArray());
        this.test1.add("zz");
        this.test1.add("A1");
        this.test1.add("Zx");
        assertEquals(8, this.test1.size());
        assertArrayEquals(new String[] {"A1", "B1", "BB", "BC", "BD", "Zx", "bb", "zz"}, this.test1.toArray());


    }

}
