package assignment3;

import java.util.Random;

public class TimingTheSortedSet
{
    public static void main(String[] args)
    {
        long startTime, midpointTime, stopTime;

        // First, spin computing stuff until one second has gone by.
        // This allows this thread to stabilize.

        int avg_unique = 0;
        startTime = System.nanoTime();
        while (System.nanoTime() - startTime < 1_000_000_000)
        { // empty block
        }

        // Now, run the test.

        int do_it_x_times = 5;
        int timesToLoop = 50;

        startTime = System.nanoTime();
        MySortedSet<Integer> do_da_set;

        Random randr = new Random();

        long number_start, number_end;

        for (int doit = 0; doit < do_it_x_times; doit++)
        {
            for (int d = 100_000; d <= 2_000_000; d += 100_000)
            {
                number_start = System.nanoTime();
                for (int i = 0; i < timesToLoop; i++)
                {
                    do_da_set = new MySortedSet<>();
                    for (int k = 0; k < d; k++)
                    {
                        do_da_set.add(Integer.valueOf(k));
                    }
                    avg_unique += do_da_set.size();
                }
                number_end = System.nanoTime();
                System.out.println("It took an average time of "
                        + (number_end - number_start) / timesToLoop / 1_000_000
                        + "ms for " + d + " elements");
            }
        }

        midpointTime = System.nanoTime();

        // Run an empty loop to capture the cost of running the loop.

        for (long i = 0; i < timesToLoop; i++)
        { // empty block
        }

        stopTime = System.nanoTime();

        // Compute the time, subtract the cost of running the loop
        // from the cost of running the loop and computing square roots.
        // Average it over the number of runs.

        double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
                / timesToLoop;

        avg_unique /= timesToLoop;
        avg_unique /= 20;
        System.out.println("there were an average of " + avg_unique
                + "numbers per run");
    }
}
