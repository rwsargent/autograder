package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E>, Iterable<E>
{

    private boolean iscomparable_;
    private final int STOP_SCALE_NUMBER = 50;
    private final int ADD_AFTER_SCALESTOP = 20;

    private int size_;

    private Comparator<E> comper_;

    private Object[] back_;

    public MySortedSet()
    {
        this(null);
    }

    /**
     * create the new MySortedSet
     *
     * @param comp
     *            null if using an object that extends Comparable, or the
     *            comparator used to sort non-comparables
     */
    public MySortedSet(Comparator<E> comp)
    {

        // System.out.println("Initializing");
        this.back_ = new Object[10];
        this.size_ = 0;

        if (comp != null && comp instanceof Comparator)
        {
            this.iscomparable_ = false;
            this.comper_ = comp;
        }
        else
        {
            this.iscomparable_ = true;
            this.comper_ = new ComparableComparator<E>();
        }

    }

    /**
     * this is a wrapper for the comparable class implemented as a comparator
     * finally gave 
     * 
     * @author Alex
     *
     * @param <T>
     */
    private class ComparableComparator<T> implements Comparator<E>
    {
        @Override
        public int compare(E o1, E o2)
        {
            if (o1 instanceof Comparable)
            {
                return ((Comparable) o1).compareTo(o2);
            }
            return 0;
        }

    }

    private int compare(E o1, E o2)
    {
        // System.out.println("Comparing, iscomparable: " + this.iscomparable_);
        // if (!iscomparable_)

        int rval;
        // System.out.println("Comparing [" + o1 + "] to [" + o2 + "]");
        rval = this.comper_.compare(o1, o2);
        // System.out.println("[" + o1 + "] " + " is [" + rval +
        // "] compared to ["
        // + o2 + "]");

        return rval;

    }

    /**
     * will return the comparator that we use to determine the ordering of
     * elements, or null
     */
    @Override
    public Comparator<? super E> comparator()
    {
        if (iscomparable_)
            return null;
        else
            return this.comper_;
    }

    /**
     * return the first element
     */
    @Override
    public E first() throws NoSuchElementException
    {
        if (this.size_ <= 1)
            throw new NoSuchElementException();
        return (E) back_[0];
    }

    /**
     * Return the last element
     */
    @Override
    public E last() throws NoSuchElementException
    {
        if (this.size_ <= 1)
            throw new NoSuchElementException();
        return (E) back_[size_ - 1];
    }

    /**
     * find the position that the E should go in returns -1 if the element is
     * already in the array
     *
     * @return
     */
    @SuppressWarnings("unchecked")
    protected int lookUpPositionFor(E lookfor)
    {
        // if(this.size_ > 2)
        if (this.size_ == 0)
        {
            return 0;
        }

        int cpos = -1;
        int start = 0;
        int end = this.size_ - 1;
        int pivot = end / 2;

        E compto = (E) this.back_[start];
        int comped = this.compare(lookfor, compto);
        if (comped < 0)
            return 0;

        compto = (E) this.back_[end];
        comped = this.compare(lookfor, compto);
        if (comped > 0)
            return this.size_;

        while (start <= end)
        {
            pivot = (start + end) / 2;

            compto = (E) this.back_[pivot];
            comped = this.compare(lookfor, compto);

            if (comped < 0)
            {
                end = pivot - 1;
                if (start > end)
                    return pivot;
            }
            else if (comped > 0)
            {
                start = pivot + 1;
                if (start > end)
                    return pivot + 1;
            }
            else
            {
                cpos = pivot;
                break;
            }

        }

        // System.out.println("returning position: " + cpos);

        return cpos;
    }

    /**
     * shift everything over to the left
     *
     * @param index
     */
    private void removeRoomAt(int index)
    {
        for (int i = index; i < this.size_; i++)
        {
            this.back_[i] = this.back_[i + 1];
            // this.back_[i - 1] = null;
        }

    }

    /**
     * move all elements after index to the one after so we can put something in
     * there
     *
     * @param index
     */
    private void makeRoomAt(int index)
    {
        if (index == this.size_)
        {
            return;
        }
        else
        {
            for (int i = this.size_; i > index; i--)
            {
                this.back_[i] = this.back_[i - 1];
                this.back_[i - 1] = null;
            }
        }
    }

    @Override
    public boolean add(E o)
    {

        // terribly inefficient
        // System.out.println("Attempting to  add: " + o.toString());
        // if (this.contains(o))
        // return false;

        if (!this.checkRoomFor(1))
        {
            this.increaseCapacity();
        }

        int place = this.lookUpPositionFor(o);

        if (this.back_[place] != null)
            if (o.equals(this.back_[place]))
                return false;

        this.makeRoomAt(place);

        this.back_[place] = o;

        this.size_ += 1;

        return true;
    }

    /**
     *
     * Now I just double the size :( that's okay
     *
     */
    private void increaseCapacity()
    {
        int existing = this.back_.length;

        // copy the existing data
        Object[] cdata = new Object[existing * 2];

        // add all the old objects in, wish there was a memcpy like function for
        // java

        for (int i = 0; i < this.size_; i++)
        {
            cdata[i] = this.back_[i];
        }
        this.back_ = cdata;
    }

    private boolean checkRoomFor(int numtocheck)
    {
        boolean rval = false;

        if (this.size_ + numtocheck < this.back_.length)
            rval = true;
        return rval;
    }

    /**
     * will return true if all were added.
     */
    @Override
    public boolean addAll(Collection<? extends E> c)
    {
        // System.out.println("Adding all");

        // check that we have room
        if (!this.checkRoomFor(c.size()))
        {
            // System.out.println("Doing something");
            this.increaseCapacity();
        }

        // now add all the elements

        for (E toadd : c)
        {
            // System.out.println("Adding an element from c");
            this.add(toadd);
        }

        return true;
    }

    /**
     * Clear the array
     */
    @Override
    public void clear()
    {
        // just create a new array
        int existing = this.back_.length;
        this.back_ = new Object[existing];
        this.size_ = 0;

    }

    /**
     * Check to see that the object is contained within the array
     */
    @Override
    public boolean contains(Object o)
    {
        // use a binary search
        E oase = (E) o;

        // use the faser binary search method
        if (this.back_[this.lookUpPositionFor(oase)].equals(oase))
            return true;
        else
            return false;
    }

    @Override
    public boolean containsAll(Collection<?> c)
    {
        boolean rval = true;
        for (Object tocomp : c)
        {
            if (!this.contains(tocomp))
            {
                rval = false;
                break;
            }
        }
        return rval;
    }

    @Override
    public boolean isEmpty()
    {
        if (size_ == 0)
            return true;
        return false;
    }

    private class Listerator implements Iterator<E>
    {
        MySortedSet data;
        Object[] iterate_data;
        int element;

        public Listerator(MySortedSet misset)
        {
            this.data = misset;
            this.iterate_data = this.data.toArray();
            this.element = 0;
        }

        @Override
        public boolean hasNext()
        {
            if (element < this.iterate_data.length)
                return true;
            return false;

        }

        @Override
        public E next()
        {
            E toreturn;
            if (this.hasNext())
            {
                toreturn = (E) iterate_data[element];
                this.remove();
            }
            else
            {
                toreturn = null;
            }

            return toreturn;

        }

        @Override
        public void remove()
        {
            this.element += 1;
        }

    }

    @Override
    public Iterator<E> iterator()
    {
        return new Listerator(this);
    }

    @Override
    public boolean remove(Object o)
    {
        boolean rval = false;
        int pos = this.lookUpPositionFor((E) o);
        E comped = (E) this.back_[pos];
        if (o.equals(comped))
        {
            this.back_[pos] = null;
            this.removeRoomAt(pos);
            rval = true;
        }
        this.size_ -= 1;
        return rval;
    }

    @Override
    public boolean removeAll(Collection<?> c)
    {
        boolean rval = false;

        for (Object inc : c)
        {
            if (this.remove(inc))
                rval = true;
        }

        return rval;
    }

    @Override
    public int size()
    {
        return this.size_;
    }

    @Override
    public Object[] toArray()
    {
        Object[] temp = new Object[this.size_];
        for (int i = 0; i < this.size_; i++)
            temp[i] = this.back_[i];
        return temp;
    }

}
