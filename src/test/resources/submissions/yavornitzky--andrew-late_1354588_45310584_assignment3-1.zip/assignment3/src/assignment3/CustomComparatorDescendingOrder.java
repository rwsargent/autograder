package assignment3;

import java.util.Comparator;

public class CustomComparatorDescendingOrder implements Comparator<Integer>
{
    @Override
    /**
     * Compares o1 to o2, if o2 is greater than o1, returns positive, if o1 is greater that o2, returns negative, 
     * if o1 and o2 are equal, returns 0.
     */
	public int compare(Integer o1, Integer o2)
    {
        int result = o2 - o1;
        return result;
    }
}
