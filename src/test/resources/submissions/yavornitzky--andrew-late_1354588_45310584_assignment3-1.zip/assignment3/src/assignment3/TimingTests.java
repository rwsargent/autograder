package assignment3;

import java.util.Random;

public class TimingTests {

	public static void main(String[] args) 
	{
		long time = 0;
		MySortedSet<Integer> testSet = new MySortedSet<Integer>();
		Random randomNum = new Random();
		long avg = 0;
		int testInt = 100000;	
		int randomInt = (randomNum.nextInt(100000));
		
		/*for(int j = 0; j <= 20; j++)
		{
			for(int i = 0; i < testInt; i++)
			{
				testSet.add(i);
				randomInt = (randomNum.nextInt(testInt));
			}
			
			for(int k = 0; k < testInt; k++)
			{
				randomInt = (randomNum.nextInt(testInt));
				long startTime = System.nanoTime();
				testSet.contains(randomInt);
				long endTime = System.nanoTime();
				avg += endTime - startTime;
			}
			System.out.println(avg/testInt);
			testInt += 100000;
			avg = 0;
			testSet.clear();
		}*/
		
		for(int j = 0; j <= 20; j++)
		{
			//System.out.println(testInt + ":");
			for(int k = 0; k < testInt; k++)
			{
				testSet.add(k);
			}
			for(int k = 0; k < 100000; k++)
			{
				randomInt = (randomNum.nextInt(testInt));
				long startTime = System.nanoTime();
				testSet.add(randomInt);
				long endTime = System.nanoTime();
				avg += endTime - startTime;
			}
			System.out.println(avg/100000);
			testInt += 100000;
			avg = 0;
			testSet.clear();
		}

	}

}
