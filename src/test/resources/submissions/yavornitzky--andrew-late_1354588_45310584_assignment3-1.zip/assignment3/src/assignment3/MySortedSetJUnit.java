package assignment3;

import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Random;

import org.junit.Test;

public class MySortedSetJUnit {
	
	@Test
	public void constructorTest()
	{
		MySortedSet sortedSet = new MySortedSet();
	}
	
	@Test
	public void constructor2Test()
	{
		MySortedSet sortedSet = new MySortedSet(new CustomComparatorDescendingOrder());
	}
	
	@Test
	public void comparatorTest()
	{
		MySortedSet sortedSet = new MySortedSet(new CustomComparatorDescendingOrder());
		assertEquals(sortedSet.comparator().getClass().getName(), "assignment3.CustomComparatorDescendingOrder");
	}
	
	@Test
	public void addTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i < 20; i++)
		{
			sortedSet.add(i);
		}
	}
	
	@Test
	public void addTestWithCustomComparator()
	{
		MySortedSet sortedSet = new MySortedSet(new CustomComparatorDescendingOrder());
		for(int i = 0; i < 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		assertEquals(new Integer(19), sortedSet.first());
		assertEquals(new Integer(0), sortedSet.last());
	}
	
	@Test
	public void isEmptyTest()
	{
		MySortedSet sortedSet = new MySortedSet();		
		assertEquals(true, sortedSet.isEmpty());
	}
	
	@Test
	public void sizeTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		
		assertEquals(21, sortedSet.size());
	}
	
	@Test
	public void toArrayTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		sortedSet.add(1);
		sortedSet.add(2);
	
		assertEquals(2, sortedSet.toArray().length);
	}
	
	@Test
	public void clearTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		
		sortedSet.clear();
		assertEquals(0, sortedSet.size());
	}
	
	@Test
	public void binarySearchTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		
		assertEquals(20, sortedSet.binarySearch(20));
		assertEquals(-1, sortedSet.binarySearch(21));
	}
	
	@Test
	public void binarySearchBestIndex()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		
		assertEquals(21, sortedSet.binarySearchBestIndex(21));
	}
	
	@Test
	public void addAllTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		Collection c = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5));
		sortedSet.addAll(c);
		assertEquals(5, sortedSet.size());
	}
	
	@Test
	public void iteratorTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i < 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		assertEquals(true, sortedSet.iterator().hasNext());
		assertEquals(0, sortedSet.iterator().next());
	}
	
	@Test
	public void firstTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		assertEquals(new Integer(0), sortedSet.first());
	}
	
	@Test
	public void lastTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		assertEquals(new Integer(20), sortedSet.last());
	}
	
	@Test
	public void containsTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		assertEquals(true, sortedSet.contains(new Integer(4)));
		assertEquals(true, sortedSet.contains(new Integer(3)));
		assertEquals(true, sortedSet.contains(new Integer(2)));
		assertEquals(true, sortedSet.contains(new Integer(1)));
		assertEquals(false, sortedSet.contains(new Integer(21)));
	}
	
	@Test
	public void containsAllTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		Collection c = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5));
		assertEquals(true, sortedSet.containsAll(c));
	}
	
	@Test
	public void removeTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		
		assertEquals(true, sortedSet.remove(new Integer(20)));
		assertEquals(20, sortedSet.size());
	}
	
	@Test
	public void removeAllTest()
	{
		MySortedSet sortedSet = new MySortedSet();
		for(int i = 0; i <= 20; i++)
		{
			sortedSet.add(new Integer(i));
		}
		Collection c = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5));
		sortedSet.removeAll(c);
		assertEquals(16, sortedSet.size());
	}

}
