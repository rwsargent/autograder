package assignment3;

import java.util.Collection;
import java.util.Iterator;


public class CustomCollection implements java.io.Serializable
{
	private Integer placeholder;
	
	public CustomCollection(Integer o1)
    {
        this.placeholder = o1;
    }
}
