package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> 
{

	public Object[] sortedSet;
	private Comparator sorter;
	private int numberOfItems;
	private boolean useComp;

	public MySortedSet() 
	{
		sortedSet = new Object[numberOfItems + 10];
		numberOfItems = 0;
		useComp = false;
	}

	public MySortedSet(Comparator<? super E> sorterParam)
	{
		sortedSet = new Object[numberOfItems + 10];
		sorter = sorterParam;
		numberOfItems = 0;
		useComp = true;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() 
	{
		return sorter;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException
	{
		// TODO Auto-generated method stub
		if (sortedSet[0] == null) 
		{
			throw new NoSuchElementException();
		}
		return (E) sortedSet[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException 
	{
		// TODO Auto-generated method stub
		if (numberOfItems == 0)
		{
			throw new NoSuchElementException();
		}
		return (E) sortedSet[numberOfItems - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) 
	{
		// Dynamically expands array to fit stuff.
		if (sortedSet.length == numberOfItems + 1)
		{
			sortedSet = Arrays.copyOf(sortedSet, sortedSet.length * 2);
		}
		// Adds a value to a null array.
		if (sortedSet[0] == null)
		{
			sortedSet[0] = o;
			numberOfItems++;
			return true;
		}
		int binarySearchPosition = binarySearchBestIndex(o);
		if(binarySearchPosition == -1)
		{
			return false;
		}
		for(int j = numberOfItems + 1; j > binarySearchPosition; j--)
		{
			sortedSet[j] = sortedSet[j - 1];
		}
		numberOfItems++;
		sortedSet[binarySearchPosition] =  o;
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection c) 
	{
		// TODO Auto-generated method stub
		if(containsAll(c))
		{
			return false;
		}
		for(Object i : c)
		{
			add((E) i);
		}
		return true;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear()
	{
		// TODO Auto-generated method stub
		numberOfItems = 0;
		sortedSet = new Object[numberOfItems + 10];
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o)
	{
		// TODO Auto-generated method stub
		if(binarySearch(o) != -1)
		{
			return true;
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection c)
	{
		// TODO Auto-generated method stub
		for(Object i : c)
		{
			if(!contains(i))
			{
				return false;
			}
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() 
	{
		// TODO Auto-generated method stub
		if(numberOfItems == 0)
		{
			return true;
		}
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() 
	{
		// TODO Auto-generated method stub
		return new MyIterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o)
	{
		// TODO Auto-generated method stub
		int removalIndex = binarySearch(o);
		if(binarySearch(o) == -1)
		{
			return false;
		}
		sortedSet[removalIndex] = null;
		for(int i = removalIndex; i < numberOfItems; i++)
		{
			sortedSet[i] = sortedSet[i + 1];
		}
		numberOfItems--;
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection c) 
	{
		// TODO Auto-generated method stub
		if(! containsAll(c))
		{
			return false;
		}
		for(Object i : c)
		{
			remove(i);
		}
		return true;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size()
	{
		// TODO Auto-generated method stub
		return numberOfItems;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() 
	{
		// TODO Auto-generated method stub
		return Arrays.copyOf(sortedSet, numberOfItems);
	}
	
	/**
	 * Takes an Object o, and returns the array index where o best fits, otherwise, returns -1 if the element is present.
	 */
	public int binarySearchBestIndex(Object o)
	{
		int low = 0;
		int high = numberOfItems - 1;
		int mid = 0;
		if (useComp == false)
		{
			while(low <= high)
			{
				mid = low + ((high-low)/2);
				if(((Comparable) o).compareTo((Comparable) sortedSet[mid]) == 0)
				{
					return -1;
				}
				else if(((Comparable) o).compareTo((Comparable) sortedSet[mid]) < 0)
				{
					high = mid - 1;
				}
				else if(((Comparable) o).compareTo((Comparable) sortedSet[mid]) > 0)
				{
					low = mid + 1;
				}
			}
			return low;
		}
		if (useComp == true) 
		{
			while(low <= high)
			{
				mid = low + ((high-low)/2);
				if(sorter.compare(o, sortedSet[mid]) == 0)
				{
					return -1;
				}
				else if(sorter.compare(o, sortedSet[mid]) < 0)
				{
					high = mid - 1;
				}
				else if(sorter.compare(o, sortedSet[mid]) > 0)
				{
					low = mid + 1;
				}
			}
			return low;
		}
		return 0;
	}
	
	/**
	 * Takes an Object o, and returns the array index where it finds the specified Object. If it can't find the object, returns -1.
	 */
	public int binarySearch(Object o)
	{
		int low = 0;
		int high = numberOfItems - 1;
		int mid = 0;
		while(low <= high)
		{
			mid = low + ((high-low)/2);
			if(((Comparable) o).compareTo((Comparable) sortedSet[mid]) == 0)
			{
				return mid;
			}
			else if(((Comparable) o).compareTo((Comparable) sortedSet[mid]) < 0)
			{
				high = mid - 1;
			}
			else if(((Comparable) o).compareTo((Comparable) sortedSet[mid]) > 0)
			{
				low = mid + 1;
			}
		}
		return -1;
	}
	
	protected class MyIterator implements Iterator<E>
	{
		private int position = 0;
		private boolean nextCalled = false;
		
		@Override
		public boolean hasNext() 
		{
			if (position < numberOfItems)
			{
				return true;
			}
			return false;
		}

		@Override
		public E next() {
			if (this.hasNext())
			{
				E temp = (E) sortedSet[position];
				position++;
				nextCalled = true;
				return temp;
			}
			return null;
		}

		@Override
		public void remove() 
		{
			if(nextCalled)
			{
				position--;
				MySortedSet.this.remove(sortedSet[position]);
				nextCalled = false;
			}
			
		}
		
	}
}
