/**
 * @author John Chambers, Seth Kingston
 * CS 2420 - Assignment 3
 */


package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E>{

	private Comparator<? super E> comparator;
	private E[] myArray;
	int arrayCount;
	private int ARRAYSIZE = 10;
	
	/**
	 * Constructor for our sorted set. This is used to 
	 * create the sorted set, assuming that the elements 
	 * are ordered using their natural ordering 
	 */
	public MySortedSet(){
		this.arrayCount = 0;
		this.myArray = (E[]) new Object[ARRAYSIZE];
	}
	
	/**
	 * A constructor that is used to create the sorted set, 
	 * assuming that the elements are ordered using the 
	 * provided comparator.
	 * @param comparator
	 */
	public MySortedSet(Comparator<? super E> comparator){
		this.arrayCount = 0;
		this.myArray = (E[]) new Object[ARRAYSIZE];
		this.comparator = comparator;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return this.comparator();
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		//check to see if the array even has anything in it
		if(this.arrayCount==0)
		{
			throw new NoSuchElementException("The set is empty");
		}
		//returns the first element in the set
		return this.myArray[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		//tests to see if it is even possible to find the last object
		if(this.arrayCount==0)
		{
			throw new NoSuchElementException("The set is empty");
		}
		
		return this.myArray[this.arrayCount-1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		//if the object is null, returns false
		if(o == null){
			return false;
		}
		
		//this is the index that we will end up putting the object into.
		int index;
		
		//set values to begin binary search
		int endOfArray;
		
		if(arrayCount == 0){
			endOfArray = 0;
			insertObject(0,o);
			return true;
		}else {
			endOfArray = this.myArray.length - 1;
		}
		
		index = binarySearch(o);
		if(index < 0)
		{
			return false;
		}

		//put the object into the right position in the array
		insertObject(index, o);
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		
		int setSize = this.size();
		
		for(E collectionObject : c)
		{
			this.add(collectionObject);
		}
		
		//if the initial size of the set changed, return true, else false
		return (this.size() != setSize);
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		//it's more efficient to just make a whole new array rather than clear each index.
		E[] emptyArray = (E[]) new Object[this.myArray.length];
		this.myArray = emptyArray;
	}

	/**
	 * searches thru the array with binary search to see if the object
	 * is contained in it.
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o){
		
		if(binarySearch(o)==-1){
			return true;
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		
		for(Object collectionObject : c)
		{
			//runs the contains method to see if this collection object is in the set 
			//returns false if it isn't
			if(!this.contains(collectionObject))
			{
				return false;
			}
		}
		
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		return (this.arrayCount==0);
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MySetIterator();
	}
	
	private class MySetIterator implements Iterator<E>{
		
		//start position at -1
		int index = -1;
		//tells us if we have called the next() method
		boolean gotNext = false;

		/**
		 * Returns true if the iteration has more elements. (In other words, returns 
		 * true if next() would return an element rather than throwing an exception.)
		 */
		@Override
		public boolean hasNext() {
			return(index < arrayCount -1);
		}

		/**
		 * Returns the next element in the iteration. throws 
		 * NoSuchElementException - if the iteration has no more elements
		 */
		@Override
		public E next() {
			//checks to see if we can call next
			if (index >= arrayCount -1){
				throw new NoSuchElementException("This iteration has no more elements.");
			} 
			else{
				index++;
				gotNext = true;
				return(myArray[index]);
			}
		}
	
		/**
		 * Removes from the underlying collection the last element returned by this iterator (optional operation). 
		 * This method can be called only once per call to next(). The behavior of an iterator 
		 * is unspecified if the underlying collection is modified while the iteration is in progress in any way 
		 * other than by calling this method. 
		 */
		public void remove(){
			//check to see if the next method has been called
			if (gotNext){
				//calls the remove method and sets gotNext back to false
				MySortedSet.this.remove(myArray[index]);
				gotNext = false;
				index--;
			} 
			else {
				throw new IllegalStateException("The next method has not yet been called.");
			}
		}	
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) 
	{
		// set values to begin binary search
		int startOfArray = 0;
		int middleOfArray = 0;
		int endOfArray = arrayCount - 1;
		
		if(!contains(o)){
			return false;
		}

		// begin searching thru the array using binary search.
		while (startOfArray <= endOfArray) {
			// set the middle of the array to be the middle
			middleOfArray = (startOfArray + endOfArray) / 2;

			// compare o with the object in the middle position
			int result = compare((E) o, myArray[middleOfArray]);
			if (result > 0) 
			{
				startOfArray = middleOfArray - 1;
			} 
			else if (result < 0)
			{
				endOfArray = middleOfArray - 1;
			} 
			else {
				// if result = 0, then o is in the array,
				// thus we continue on to remove it
				removeObject(middleOfArray);
				return true;
			}
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		
		int setSize = this.size();
		
		for(Object collectionObject : c)
		{
			this.remove(collectionObject);
		}
		
		//if the initial size of the set changed, return true, else false
		return (this.size() != setSize);
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return this.arrayCount;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		//create new array
		E[] newArray = (E[])new Object[this.arrayCount];
		
		//iterate thru it and add all the values of myArray to the new one
		for(int i = 0; i < this.arrayCount; i++)
		{
			newArray[i] = this.myArray[i];
		}
		return newArray;
	}
	
	/**
	 * Inserts an object into the right ordered position in an array, 
	 * and grows the array if needed. (array grows by ten each time) 
	 * @param index
	 * @param o
	 */
	private void insertObject(int index, E o)
	{
		// checks to see if the index is out of the bounds of the array. if it is throws exception 
		if(index < 0 || index > this.arrayCount) {
			throw new IllegalArgumentException("index is not valid.");
		}
		
		//tests to see if we need to add more indexes to the array (it's too small to hold the new object)
		if (this.myArray.length <= this.arrayCount){
			
			//creates a new array with the length of myArray plus 10
			E[] tmpArray = (E[]) new Object[this.myArray.length + ARRAYSIZE];
			
			for(int i = 0; i < this.myArray.length; i++){
				
				//tests to see if we come to the specified index
				if(i == index) 
				{
					//move over and create a gap
					i++;
					//set the new array's index to be the same as the old array's index minus 1
					tmpArray[i] = this.myArray[i - 1];
				} 
				else {
					//set the new array's index to be the same as the old array
					tmpArray[i] = this.myArray[i];
				}
			}
			
			//initialize our array to the new array we created
			this.myArray = tmpArray;
		}
		else {
			//iterates and moves each value over until it reached the specified index
			for (int i = this.arrayCount - 1; i >= index; i--){
				this.myArray[i+1] = this.myArray[i];
			}
		}
		
		//finally, insert the object into the specified index
		this.myArray[index] = o;
		this.arrayCount++;
	}
	
	/**
	 * removes the object from the set in the given index.
	 * 
	 * @param index-- the index that will be removed
	 */
	private void removeObject(int index)
	{
		if (index >= this.arrayCount || index < 0) {
			throw new IllegalArgumentException("this index is not valid");
		}
		
		//tests to see if our array is at most the length of the array plus 10
		//if it isn't, we decrease the size of it by one.
		//this is so we don't still have hundreds of empty indexes after calling remove 100 times
		if(this.myArray.length >= this.arrayCount + ARRAYSIZE){
			//create a new array with the right amount of indexes
			E[] tmpArray =  (E[]) new Object[this.arrayCount + ARRAYSIZE - 1];
			
			//iterates thru the array and, starting with the specified index,
			// it replaces each value with the one after it.
			for (int i =0; i < this.arrayCount + ARRAYSIZE; i++){
				if(i >= index)
				{
					tmpArray[i] = this.myArray[i + 1];
				}
				else{
					tmpArray[i] = this.myArray[i];
				}
			}
			
			//set the main array to be the new array
			this.myArray = tmpArray;
			
		} 
		else {
			//iterates thru the array, starting at the specified index,
			//then replaces that value with the one after it, and continues until
			//we get to the end of the array
			for (int i = index; i < this.arrayCount - 1; i++)
			{
				this.myArray[i] = this.myArray[i + 1];
			}
		}
		//set the last value of the array to null and decrease the count
		this.myArray[arrayCount -1] = null;
		this.arrayCount--;
	}
	
	
	/**
	 * Compares the two objects and returns their compare value
	 * 
	 * @param object --This is the object that is being put into the array
	 * @param arrayObject -- this is the object that is being compared to 'object'
	 * @return 1 if the 'object' is greater than 'arrayObject', 0 if they are equal,
	 * 			and -1 if 'arrayObject' is greater than 'object'
	 */
	private int compare(E object, E arrayObject)
	{
		// if the comparator 
		if(this.comparator == null)
		{
			Comparable<E> tmpObject;
			
			//checks to see if 'object' can be compared throws exception if it cant
			if(object instanceof Comparable)
			{
				//creates temporary object and sets it to 'object' and compares and returns it
				tmpObject = (Comparable<E>) object;
				return tmpObject.compareTo(arrayObject);
			}
			
			// throws exception if it can't be compared 
			throw new IllegalArgumentException("Cannot compare object.");
		}
		
		//compares and returns object
		return this.comparator.compare(object, arrayObject);
	}
	
	public int binarySearch(Object o){
		// set values to begin binary search
		int foundObject = 0;
		int startOfArray = 0;
		int middleOfArray = 0;
		int endOfArray = arrayCount - 1;

		if (o instanceof Comparable) {
			// begin searching thru the array using binary search.
			while (startOfArray <= endOfArray) {
				// set the middle of the array to be the middle
				middleOfArray = (startOfArray + endOfArray) / 2;
				// compare o with the object in the middle position
				int result = ((Comparable) o).compareTo(myArray[middleOfArray]);
				if (result == 0) {
					foundObject = middleOfArray;
					return -1;
				}
				if (result > 0) {
					startOfArray = middleOfArray + 1;
				} else if (result < 0) {
					endOfArray = middleOfArray - 1;
				}

			}
			if (((Comparable) o).compareTo(myArray[middleOfArray]) < 0) {
				return middleOfArray;
			} else if (((Comparable) o).compareTo(myArray[middleOfArray]) > 0) {
				return middleOfArray + 1;
			}
		} else {
			while (startOfArray <= endOfArray) {
				// set the middle of the array to be the middle
				middleOfArray = (startOfArray + endOfArray) / 2;
				// compare o with the object in the middle position
				int result = ((Comparator) o)
						.compare(o, myArray[middleOfArray]);
				if (result == 0) {
					foundObject = middleOfArray;
					return -1;
				}
				if (result > 0) {
					startOfArray = middleOfArray + 1;
				} else if (result < 0) {
					endOfArray = middleOfArray - 1;
				}

			}
			if (((Comparator) o).compare(o, myArray[middleOfArray]) < 0) {
				return middleOfArray;
			} else if (((Comparator) o).compare(o, myArray[middleOfArray]) > 0) {
				return middleOfArray + 1;
			}
		}

		return middleOfArray;
	}
}