/**
 * @author John Chambers, Seth Kingston
 * CS 2420 - Assignment 3
 */

package assignment3;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest<E>{

	@Test
	public void testFirst() {
		MySortedSet test = new MySortedSet();
		test.add(30);
		test.add(15);
		test.add(4);
		test.add(1);
		test.add(23);
		
		assertEquals(1, test.first());
	}

	@Test
	public void testLast() {
		MySortedSet test = new MySortedSet();
		test.add(30);
		test.add(15);
		test.add(4);
		test.add(1);
		test.add(23);
		
		assertEquals(30, test.last());
	}

	@Test
	public void testAdd() {
		MySortedSet test = new MySortedSet();
		test.add(30);
		test.add(15);
		test.add(4);
		test.add(1);
		test.add(23);
		
		assertEquals(1, test.first());
	}

	@Test
	public void testAddAll() {
		Collection<String> test = Arrays.asList(new String[] {"one", "two", "three"});
		Set collection = new HashSet((Collection) test);
		MySortedSet setString = new MySortedSet();
		Object[] expected = {"one", "two", "three"};
		assertEquals(true, setString.addAll(test));
		assertEquals(false, setString.addAll(test));
	}

	@Test
	public void testClear() {
		MySortedSet test = new MySortedSet();
		test.add(30);
		test.add(15);
		test.add(4);
		test.add(1);
		test.add(23);
		test.clear();
		
		assertEquals(null, test.first());
	}

	@Test
	public void testContains() {
		MySortedSet test = new MySortedSet();
		test.add(30);
		test.add(15);
		test.add(4);
		test.add(1);
		test.add(23);
		
		assertEquals(true, test.contains(4));
		assertEquals(false, test.contains(7));
	}

	@Test
	public void testContainsAll() {
		Collection<String> test = Arrays.asList(new String[] {"one", "two", "three", "four", "five"});
		Set collection = new HashSet((Collection) test);
		MySortedSet setString = new MySortedSet();
		Object[] expected = {"one", "two", "three", "four", "five"};
		assertEquals(true, test.containsAll(test));
	}

	@Test
	public void testIsEmpty() {
		MySortedSet test = new MySortedSet();
		test.add(30);
		test.add(15);
		test.add(4);
		test.add(1);
		test.add(23);
		
		MySortedSet test2 = new MySortedSet();
		
		assertEquals(false, test.isEmpty());
		assertEquals(true, test2.isEmpty());
	}

	@Test
	public void testRemove() {
		MySortedSet test = new MySortedSet();
		test.add(30);
		test.add(15);
		test.add(4);
		test.add(1);
		test.add(23);
		
		assertEquals(true, test.remove(15));
	}

	@Test
	public void testSize() {
		MySortedSet test = new MySortedSet();
		test.add(30);
		test.add(15);
		test.add(4);
		test.add(1);
		test.add(23);
		
		assertEquals(5, test.size());
	}

}
