package assignment2;

import java.util.ArrayList;

/**
 * Domas Piragas (u0768585) Jordan Hendley (u0500250)
 *
 */
public class LibraryGenericTest2 {

	public static void main(String[] args) {

		// Creates a library where the books are pre-sorted by ISBN
		LibraryGeneric<String> libTest1 = new LibraryGeneric<String>();
		libTest1.addAll("Mushroom_Publishing.txt");
		ArrayList<LibraryBookGeneric<String>> booksByIsbn = libTest1.lookup(null);

		// Creates a library where the books are pre-sorted by Author
		LibraryGeneric<String> libTest2 = new LibraryGeneric<String>();
		libTest2.addAll("Mushroom_Publishing_Author.txt");
		ArrayList<LibraryBookGeneric<String>> booksByAuthor = libTest2.lookup(null);

		// Tests sorting the books by author and compares it to the pre-sorted
		// library
		for (int i = 0; i < booksByAuthor.size(); i++) {
			if (!libTest1.getOrderedByAuthor().get(i).equals(booksByAuthor.get(i))) {
				System.err.println("TEST FAILED -- getOrderedByAuthor()");
			}
		}

		// Tests sorting the books by isbn and compares it to the pre-sorted
		// library
		for (int i = 0; i < booksByIsbn.size(); i++) {
			if (!libTest2.getInventoryList().get(i).equals(booksByIsbn.get(i))) {
				System.err.println("TEST FAILED -- getInventoryList()");
			}
		}
		// test if getDueDate returns an empty list if no books are overdue.
		if (libTest1.getOverdueList(1, 1, 1998).size() != 0) {
			System.err.println("TEST FAILED -- getOrderedByDueDate() (Empty List)");

		}
		// checkout books that will be used to test getOvedueList method
		libTest1.checkout(9781843193319L, "Jane Doe", 1, 1, 2000);
		libTest1.checkout(9781843190479L, "Jane Doe", 1, 2, 2000);
		libTest1.checkout(9781843190936L, "Jane Doe", 1, 3, 2000);
		libTest1.checkout(9781843190677L, "Jane Doe", 2, 4, 2000);
		libTest1.checkout(9781843190516L, "Jane Doe", 3, 5, 2000);
		libTest1.checkout(9781843190110L, "Jane Doe", 4, 6, 2000);
		libTest1.checkout(9781843192954L, "Jane Doe", 4, 7, 2001);
		libTest1.checkout(9781843190363L, "Jane Doe", 4, 8, 2002);
		libTest1.checkout(9781843190349L, "Jane Doe", 4, 9, 2003);

		// Tests sorting the books by author and compares it to the pre-sorted
		// library
		for (int i = 6; i < libTest1.getOverdueList(12, 31, 2000).size(); i++) {
			if (!libTest1.getOverdueList(12, 31, 2000).get(i - 6).equals(booksByAuthor.get(i))) {
				System.err.println("TEST FAILED -- getOrderedByDueDate()");
			}
		}

		System.out.println("Testing Complete");
	}

}
