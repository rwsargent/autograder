package assignment2;


import java.util.GregorianCalendar;

/**
 * Domas Piragas (u0768585) Jordan Hendley (u0500250)
 * Represents a book from a library which has an isbn, an author, and a title (which don't change).
 * If it is checked out, the book also has a holder that can be represented with any type and a due date.
 */
public class LibraryBookGeneric<Type> extends Book {
	// the name of the book holder
	private Type holder;
	// the date the book is to be returned
	private GregorianCalendar dueDate = new GregorianCalendar();

	/**
	 * Creates an instance of a Library book containing ISBN, author, title, the
	 * holder's name, and the due date
	 */
	public LibraryBookGeneric(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		holder = null;
		dueDate = null;
	}

	/**
	 * returns the name of the Library book's current holder
	 */
	public Type getHolder() {
		return holder;
	}

	/**
	 * returns the current due date for a Library book
	 */
	public GregorianCalendar getDueDate() {
		return dueDate;
	}

	/**
	 * sets the holder and due date of a library book to null
	 */
	public void checkIn() {
		holder = null;
		dueDate = null;
	}

	/**
	 * sets the holder and due date of a library book
	 * 
	 * @param patron
	 *            represents the holder
	 * @param _dueDate
	 *            represents the dueDate
	 * 
	 */
	public void checkOut(Type patron, GregorianCalendar _dueDate) {
		holder = patron;
		dueDate = _dueDate;

	}

	/**
	 * checks to see if the book is currently checked out
	 * 
	 * @returns false if the books is not checked out
	 * @returns true if the books is checked out
	 */
	public boolean isCheckedOut() {
		if (holder == null || dueDate == null) {
			return false;
		}
		return true;
	}
}
