package assignment2;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 * Domas Piragas (u0768585) Jordan Hendley (u0500250) Testing class for
 * LibraryGeneric.
 *
 */
public class LibraryGenericTest {

	public static void main(String[] args) {

		// test a library that uses names (String) to id patrons
		LibraryGeneric<String> lib1 = new LibraryGeneric<String>();
		lib1.add(9780374292799L, "Thomas L. Friedman", "The World is Flat");
		lib1.add(9780330351690L, "Jon Krakauer", "Into the Wild");
		lib1.add(9780446580342L, "David Baldacci", "Simple Genius");

		String patron1 = "Jane Doe";

		if (!lib1.checkout(9780330351690L, patron1, 1, 1, 2008))
			System.err.println("TEST FAILED: first checkout");
		if (!lib1.checkout(9780374292799L, patron1, 1, 1, 2008))
			System.err.println("TEST FAILED: second checkout");
		ArrayList<LibraryBookGeneric<String>> booksCheckedOut1 = lib1.lookup(patron1);
		if (booksCheckedOut1 == null || booksCheckedOut1.size() != 2
				|| !booksCheckedOut1.contains(new Book(9780330351690L, "Jon Krakauer", "Into the Wild"))
				|| !booksCheckedOut1.contains(new Book(9780374292799L, "Thomas L. Friedman", "The World is Flat"))
				|| !booksCheckedOut1.get(0).getHolder().equals(patron1)
				|| !booksCheckedOut1.get(0).getDueDate().equals(new GregorianCalendar(2008, 1, 1))
				|| !booksCheckedOut1.get(1).getHolder().equals(patron1)
				|| !booksCheckedOut1.get(1).getDueDate().equals(new GregorianCalendar(2008, 1, 1)))
			System.err.println("TEST FAILED: lookup(holder)");
		if (!lib1.checkin(patron1))
			System.err.println("TEST FAILED: checkin(holder)");

		// test a library that uses phone numbers (PhoneNumber) to id patrons
		LibraryGeneric<PhoneNumber> lib2 = new LibraryGeneric<PhoneNumber>();
		lib2.add(9780374292799L, "Thomas L. Friedman", "The World is Flat");
		lib2.add(9780330351690L, "Jon Krakauer", "Into the Wild");
		lib2.add(9780446580342L, "David Baldacci", "Simple Genius");

		PhoneNumber patron2 = new PhoneNumber("801.555.1234");

		if (!lib2.checkout(9780330351690L, patron2, 1, 1, 2008))
			System.err.println("TEST FAILED: first checkout");
		if (!lib2.checkout(9780374292799L, patron2, 1, 1, 2008))
			System.err.println("TEST FAILED: second checkout");
		ArrayList<LibraryBookGeneric<PhoneNumber>> booksCheckedOut2 = lib2.lookup(patron2);
		if (booksCheckedOut2 == null || booksCheckedOut2.size() != 2
				|| !booksCheckedOut2.contains(new Book(9780330351690L, "Jon Krakauer", "Into the Wild"))
				|| !booksCheckedOut2.contains(new Book(9780374292799L, "Thomas L. Friedman", "The World is Flat"))
				|| !booksCheckedOut2.get(0).getHolder().equals(patron2)
				|| !booksCheckedOut2.get(0).getDueDate().equals(new GregorianCalendar(2008, 1, 1))
				|| !booksCheckedOut2.get(1).getHolder().equals(patron2)
				|| !booksCheckedOut2.get(1).getDueDate().equals(new GregorianCalendar(2008, 1, 1)))
			System.err.println("TEST FAILED: lookup(holder)");
		if (!lib2.checkin(patron2))
			System.err.println("TEST FAILED: checkin(holder)");

		// test a large library with Strings

		// Created a new blank library
		lib1 = new LibraryGeneric<String>();
		// Fills the library with randomly generated LibraryBooks
		lib1.addAll(generateLibraryString(100));
		// Pulls the randomly generated library into an ArrayList so
		// we can access the isbn by index for testing purposes
		ArrayList<LibraryBookGeneric<String>> library = lib1.lookup(null);

		lib1.checkout(library.get(0).getIsbn(), "Steve Rogers", 1, 1, 1945);
		lib1.checkout(library.get(1).getIsbn(), "Steve Rogers", 1, 1, 1945);
		lib1.checkout(library.get(2).getIsbn(), "Steve Rogers", 1, 1, 1945);
		lib1.checkout(library.get(98).getIsbn(), "Peter Parker", 1, 1, 2011);
		lib1.checkout(library.get(99).getIsbn(), "Peter Parker", 1, 1, 2011);

		// Tests to see if a book that is already checked out will fail to be
		// checked out
		if (lib1.checkout(library.get(0).getIsbn(), "Bruce Banner", 1, 1, 2015))
			System.err.println("TEST FAILED -- large library: fail checkout");
		if (lib1.checkout(library.get(99).getIsbn(), "Gwen Stacey", 1, 1, 2015))
			System.err.println("TEST FAILED -- large library: fail checkout");
		if (!lib1.checkin("Steve Rogers"))
			System.err.println("TEST FAILED -- large library: checkin(holder)");

		if (lib1.lookup(library.get(45).getIsbn()) != null)
			System.err.println("TEST FAILED -- large library: lookup(isbn)");
		if (!lib1.checkout(library.get(45).getIsbn(), "Jane Doe", 1, 1, 2008))
			System.err.println("TEST FAILED -- large library: checkout");
		ArrayList<LibraryBookGeneric<String>> booksCheckedOut = lib1.lookup("Peter Parker");
		if (booksCheckedOut == null || booksCheckedOut.size() != 2
				|| !booksCheckedOut.get(0).equals(new Book(library.get(98).getIsbn(), "An author", "A title"))
				|| !booksCheckedOut.get(0).getHolder().equals("Peter Parker")
				|| !booksCheckedOut.get(0).getDueDate().equals(new GregorianCalendar(2011, 1, 1)))
			System.err.println("TEST FAILED -- large library: lookup(holder)");
		if (!lib1.checkin(library.get(45).getIsbn()))
			System.err.println("TEST FAILED -- large library: checkin(isbn)");
		if (lib1.checkin("Jane Doe"))
			System.err.println("TEST FAILED -- large library: checkin(holder)");

		// test a large library with PhoneNumbers

		// Created a new blank library
		lib2 = new LibraryGeneric<PhoneNumber>();
		// Fills the library with randomly generated LibraryBookGenerics
		lib2.addAll(generateLibraryPhone(100));
		// Pulls the randomly generated library into an ArrayList so
		// we can access the isbn by index for testing purposes
		ArrayList<LibraryBookGeneric<PhoneNumber>> libraryPhone = lib2.lookup(null);

		// Initialize a couple phone numbers for testing
		PhoneNumber steveRogers = new PhoneNumber("888.555.6660");
		PhoneNumber peterParker = new PhoneNumber("888.555.9876");
		lib2.checkout(libraryPhone.get(0).getIsbn(), steveRogers, 1, 1, 1945);
		lib2.checkout(libraryPhone.get(1).getIsbn(), steveRogers, 1, 1, 1945);
		lib2.checkout(libraryPhone.get(2).getIsbn(), steveRogers, 1, 1, 1945);
		lib2.checkout(libraryPhone.get(98).getIsbn(), peterParker, 1, 1, 2011);
		lib2.checkout(libraryPhone.get(99).getIsbn(), peterParker, 1, 1, 2011);

		// Tests to see if a book that is already checked out will fail to be
		// checked out
		if (lib2.checkout(libraryPhone.get(0).getIsbn(), new PhoneNumber("800.555.9876"), 1, 1, 2015))
			System.err.println("TEST FAILED -- large libraryPhone: fail checkout");
		if (lib2.checkout(libraryPhone.get(99).getIsbn(), new PhoneNumber("888.444.9876"), 1, 1, 2015))
			System.err.println("TEST FAILED -- large libraryPhone: fail checkout");
		if (!lib2.checkin(steveRogers))
			System.err.println("TEST FAILED -- large libraryPhone: checkin(holder)");

		if (lib2.lookup(libraryPhone.get(45).getIsbn()) != null)
			System.err.println("TEST FAILED -- large libraryPhone: lookup(isbn)");
		if (!lib2.checkout(libraryPhone.get(45).getIsbn(), new PhoneNumber("000.000.0000"), 1, 1, 2008))
			System.err.println("TEST FAILED -- large libraryPhone: checkout");
		ArrayList<LibraryBookGeneric<PhoneNumber>> booksCheckedOutPhone = lib2.lookup(peterParker);
		if (booksCheckedOutPhone == null
				|| booksCheckedOutPhone.size() != 2
				|| !booksCheckedOutPhone.get(0)
						.equals(new Book(libraryPhone.get(98).getIsbn(), "An author", "A title"))
				|| !booksCheckedOutPhone.get(0).getHolder().equals(peterParker)
				|| !booksCheckedOutPhone.get(0).getDueDate().equals(new GregorianCalendar(2011, 1, 1)))
			System.err.println("TEST FAILED -- large libraryPhone: lookup(holder)");
		if (!lib2.checkin(libraryPhone.get(45).getIsbn()))
			System.err.println("TEST FAILED -- large libraryPhone: checkin(isbn)");
		if (lib2.checkin(new PhoneNumber("000.000.0000")))
			System.err.println("TEST FAILED -- large libraryPhone: checkin(holder)");

		System.out.println("Testing done.");
	}

	public static ArrayList<LibraryBookGeneric<PhoneNumber>> generateLibraryPhone(int size) {
		ArrayList<LibraryBookGeneric<PhoneNumber>> result = new ArrayList<LibraryBookGeneric<PhoneNumber>>();

		for (int i = 0; i < size; i++) {
			// generate random ISBN
			Random randomNumGen = new Random();
			String isbn = "";
			for (int j = 0; j < 13; j++)
				isbn += randomNumGen.nextInt(10);

			result.add(new LibraryBookGeneric(Long.parseLong(isbn), "An author", "A title"));
		}

		return result;
	}

	public static ArrayList<LibraryBookGeneric<String>> generateLibraryString(int size) {
		ArrayList<LibraryBookGeneric<String>> result = new ArrayList<LibraryBookGeneric<String>>();

		for (int i = 0; i < size; i++) {
			// generate random ISBN
			Random randomNumGen = new Random();
			String isbn = "";
			for (int j = 0; j < 13; j++)
				isbn += randomNumGen.nextInt(10);

			result.add(new LibraryBookGeneric(Long.parseLong(isbn), "An author", "A title"));
		}

		return result;
	}

	/**
	 * Returns a randomly-generated ISBN (a long with 13 digits).
	 * 
	 * Useful for collecting running times for operations on libraries of
	 * varying size.
	 */
	public static long generateIsbn() {
		Random randomNumGen = new Random();

		String isbn = "";
		for (int j = 0; j < 13; j++)
			isbn += randomNumGen.nextInt(10);

		return Long.parseLong(isbn);
	}
}