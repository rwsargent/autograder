package assignment2;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 * Domas Piragas (u0768585) Jordan Hendley (u0500250)
 * 
 * Testing class for Library.
 */
public class LibraryTest {

	public static void main(String[] args) {
		// test an empty library
		Library lib = new Library();

		if (lib.lookup(978037429279L) != null)
			System.err.println("TEST FAILED -- empty library: lookup(isbn)");
		ArrayList<LibraryBook> booksCheckedOut = lib.lookup("Jane Doe");
		if (booksCheckedOut == null || booksCheckedOut.size() != 0)
			System.err.println("TEST FAILED -- empty library: lookup(holder)");
		if (lib.checkout(978037429279L, "Jane Doe", 1, 1, 2008))
			System.err.println("TEST FAILED -- empty library: checkout");
		if (lib.checkin(978037429279L))
			System.err.println("TEST FAILED -- empty library: checkin(isbn)");
		if (lib.checkin("Jane Doe"))
			System.err.println("TEST FAILED -- empty library: checkin(holder)");

		// test a small library
		lib.add(9780374292799L, "Thomas L. Friedman", "The World is Flat");
		lib.add(9780330351690L, "Jon Krakauer", "Into the Wild");
		lib.add(9780446580342L, "David Baldacci", "Simple Genius");

		if (lib.lookup(9780330351690L) != null)
			System.err.println("TEST FAILED -- small library: lookup(isbn)");
		if (!lib.checkout(9780330351690L, "Jane Doe", 1, 1, 2008))
			System.err.println("TEST FAILED -- small library: checkout");
		booksCheckedOut = lib.lookup("Jane Doe");
		if (booksCheckedOut == null || booksCheckedOut.size() != 1
				|| !booksCheckedOut.get(0).equals(new Book(9780330351690L, "Jon Krakauer", "Into the Wild"))
				|| !booksCheckedOut.get(0).getHolder().equals("Jane Doe")
				|| !booksCheckedOut.get(0).getDueDate().equals(new GregorianCalendar(2008, 1, 1)))
			System.err.println("TEST FAILED -- small library: lookup(holder)");
		if (!lib.checkin(9780330351690L))
			System.err.println("TEST FAILED -- small library: checkin(isbn)");
		if (lib.checkin("Jane Doe"))
			System.err.println("TEST FAILED -- small library: checkin(holder)");

		// test a medium library
		lib.addAll("Mushroom_Publishing.txt");

		// Check out several books
		lib.checkout(9781843190004L, "Steve Rogers", 1, 1, 1945);
		lib.checkout(9781843190011L, "Steve Rogers", 1, 1, 1945);
		lib.checkout(9781843190028L, "Steve Rogers", 1, 1, 1945);
		lib.checkout(9781843190042L, "Peter Parker", 1, 1, 2011);
		lib.checkout(9781843190073L, "Peter Parker", 1, 1, 2011);
		// Tests to see if a book that is already checked out will fail to be
		// checked out
		if (lib.checkout(9781843190004L, "Bruce Banner", 1, 1, 2015))
			System.err.println("TEST FAILED -- medium library: fail checkout");
		// Tests to check in the books checked out by a particular holder
		if (!lib.checkin("Steve Rogers"))
			System.err.println("TEST FAILED -- medium library: checkin(holder)");

		if (lib.lookup(9781843190110L) != null)
			System.err.println("TEST FAILED -- medium library: lookup(isbn)");
		if (!lib.checkout(9781843190110L, "Jane Doe", 1, 1, 2008))
			System.err.println("TEST FAILED -- medium library: checkout");
		booksCheckedOut = lib.lookup("Peter Parker");
		if (booksCheckedOut == null
				|| booksCheckedOut.size() != 2
				|| !booksCheckedOut.get(0).equals(
						new Book(9781843190042L, "Martyn Folkes", "Bath City Centre Street Map and Guide"))
				|| !booksCheckedOut.get(0).getHolder().equals("Peter Parker")
				|| !booksCheckedOut.get(0).getDueDate().equals(new GregorianCalendar(2011, 1, 1)))
			System.err.println("TEST FAILED -- medium library: lookup(holder)");
		if (!lib.checkin(9781843190110L))
			System.err.println("TEST FAILED -- medium library: checkin(isbn)");
		if (lib.checkin("Jane Doe"))
			System.err.println("TEST FAILED -- medium library: checkin(holder)");

		// test a large library

		// Created a new blank library
		lib = new Library();
		// Fills the library with randomly generated LibraryBooks
		lib.addAll(generateLibrary(100));
		// Pulls the randomly generated library into an ArrayList so
		// we can access the isbn by index for testing purposes
		ArrayList<LibraryBook> library = lib.lookup(null);

		lib.checkout(library.get(0).getIsbn(), "Steve Rogers", 1, 1, 1945);
		lib.checkout(library.get(1).getIsbn(), "Steve Rogers", 1, 1, 1945);
		lib.checkout(library.get(2).getIsbn(), "Steve Rogers", 1, 1, 1945);
		lib.checkout(library.get(98).getIsbn(), "Peter Parker", 1, 1, 2011);
		lib.checkout(library.get(99).getIsbn(), "Peter Parker", 1, 1, 2011);

		// Tests to see if a book that is already checked out will fail to be
		// checked out
		if (lib.checkout(library.get(0).getIsbn(), "Bruce Banner", 1, 1, 2015))
			System.err.println("TEST FAILED -- large library: fail checkout");
		if (lib.checkout(library.get(99).getIsbn(), "Gwen Stacey", 1, 1, 2015))
			System.err.println("TEST FAILED -- large library: fail checkout");
		if (!lib.checkin("Steve Rogers"))
			System.err.println("TEST FAILED -- large library: checkin(holder)");

		if (lib.lookup(library.get(45).getIsbn()) != null)
			System.err.println("TEST FAILED -- large library: lookup(isbn)");
		if (!lib.checkout(library.get(45).getIsbn(), "Jane Doe", 1, 1, 2008))
			System.err.println("TEST FAILED -- large library: checkout");
		booksCheckedOut = lib.lookup("Peter Parker");
		if (booksCheckedOut == null || booksCheckedOut.size() != 2
				|| !booksCheckedOut.get(0).equals(new Book(library.get(98).getIsbn(), "An author", "A title"))
				|| !booksCheckedOut.get(0).getHolder().equals("Peter Parker")
				|| !booksCheckedOut.get(0).getDueDate().equals(new GregorianCalendar(2011, 1, 1)))
			System.err.println("TEST FAILED -- large library: lookup(holder)");
		if (!lib.checkin(library.get(45).getIsbn()))
			System.err.println("TEST FAILED -- large library: checkin(isbn)");
		if (lib.checkin("Jane Doe"))
			System.err.println("TEST FAILED -- large library: checkin(holder)");

		System.out.println("Testing done.");
	}

	/**
	 * Returns a library of "dummy" books (random ISBN and placeholders for
	 * author and title).
	 * 
	 * Useful for collecting running times for operations on libraries of
	 * varying size.
	 * 
	 * @param size
	 *            -- size of the library to be generated
	 */
	public static ArrayList<LibraryBook> generateLibrary(int size) {
		ArrayList<LibraryBook> result = new ArrayList<LibraryBook>();

		for (int i = 0; i < size; i++) {
			// generate random ISBN
			Random randomNumGen = new Random();
			String isbn = "";
			for (int j = 0; j < 13; j++)
				isbn += randomNumGen.nextInt(10);

			result.add(new LibraryBook(Long.parseLong(isbn), "An author", "A title"));
		}

		return result;
	}

	/**
	 * Returns a randomly-generated ISBN (a long with 13 digits).
	 * 
	 * Useful for collecting running times for operations on libraries of
	 * varying size.
	 */
	public static long generateIsbn() {
		Random randomNumGen = new Random();

		String isbn = "";
		for (int j = 0; j < 13; j++)
			isbn += randomNumGen.nextInt(10);

		return Long.parseLong(isbn);
	}
}