package assignment2;

import java.util.GregorianCalendar;

/**
 * Domas Piragas (u0768585) Jordan Hendley (u0500250)
 * 
 * Represents a book from a library which has an isbn, an author, and a title (which don't change).
 * If it is checked out, the book also has a holder and a due date.
 *
 */
public class LibraryBook extends Book {
	// the name of the book holder
	private String holder;
	// the date the book is to be returned
	private GregorianCalendar dueDate = new GregorianCalendar();

	/**
	 * Creates an instance of a Library book containing ISBN, author, title, the
	 * holder's name, and the due date
	 */
	public LibraryBook(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		holder = null;
		dueDate = null;
	}

	/**
	 * gets the name of the Library book's current holder
	 */
	public String getHolder() {
		return holder;
	}

	/**
	 * gets the current due date for a Library book
	 */
	public GregorianCalendar getDueDate() {
		return dueDate;
	}

	/**
	 * sets the holder and due date of a library book to null
	 */
	public void checkIn() {
		holder = null;
		dueDate = null;
	}

	/**
	 * sets the holder and due date of a library book
	 */
	public void checkOut(String patron, GregorianCalendar _dueDate) {
		holder = patron;
		dueDate = _dueDate;

	}

	/**
	 * checks to see if the book is currently checked out
	 */
	public boolean isCheckedOut() {
		if (holder == null || dueDate == null) {
			return false;
		}
		return true;
	}
}
