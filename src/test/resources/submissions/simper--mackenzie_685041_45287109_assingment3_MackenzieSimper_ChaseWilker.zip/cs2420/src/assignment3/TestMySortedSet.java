package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Tests for MySortedSet
 * @author Mackenzie Simper
 * Chase Wilker
 *
 */
public class TestMySortedSet {
	
	//Note: I know JUnit tests are supposed to be small "units" but due to the nature of MySortedSet, I found it easiest
	//to test several methods at once. 
	
	private MySortedSet<String> strings;
	private MySortedSet<Book> books;
	
	private Comparator<Book> orderByIsbn;
	private ArrayList<Book> listOfBooks;
	private HashSet<String> setOfStrings;
	
	@Before
	public void setUp() throws Exception {
		
		strings = new MySortedSet<String>();
		
		orderByIsbn = new OrderByIsbn();
		books = new MySortedSet<Book>(orderByIsbn);
		
		listOfBooks = new ArrayList<Book>();
		Book book1 = new Book(112233445566L, "Brian Selznick", "Wonderstruck");
		Book book2 = new Book(112233445533L, "Andy Weir", "The Martian");
		Book book3 = new Book(112233445511L, "Persuasion", "Jane Austen");
		Book book4 = new Book(112233445522L, "The Lorax", "Doctor Suess");
		listOfBooks.add(book1);
		listOfBooks.add(book2);
		listOfBooks.add(book3);
		listOfBooks.add(book4);
		
		setOfStrings = new HashSet<String>();
		setOfStrings.add("hello");
		setOfStrings.add("guten tag");
		setOfStrings.add("hola");
		setOfStrings.add("au revoir");
		setOfStrings.add("buenos dias");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testComparator() {
		assertEquals(orderByIsbn, books.comparator());
		assertNull(strings.comparator());
	}
	
	@Test
	public void testAddBooks() {
		assertTrue(books.add(listOfBooks.get(0)));
		assertEquals("Wonderstruck", books.first().getTitle());
		assertEquals("Wonderstruck", books.first().getTitle());
		assertEquals(1, books.size());
		assertFalse(books.isEmpty());
		assertFalse(books.add(listOfBooks.get(0)));
	}
	
	@Test
	public void testAddStrings() {
		assertTrue(strings.add("hello"));
		assertEquals("hello", strings.first());
		assertEquals("hello", strings.last());
		assertEquals(1, strings.size());
		assertFalse(strings.isEmpty());
		assertFalse(strings.add("hello"));
	}
	
	
	@Test
	public void testAddAllBooks() {
		assertTrue(books.addAll(listOfBooks));
		assertEquals(4, books.size());
	}
	
	@Test
	public void testContainsBooks() {
		assertTrue(books.addAll(listOfBooks));
		assertTrue(books.contains(listOfBooks.get(3)));
		assertTrue(books.containsAll(listOfBooks));
		
		assertFalse(books.contains(new Book(123456123456L, "Daybreak", "James Nelley")));
		assertFalse(books.contains("hola"));
	}
	
	@Test
	public void testContainsStrings() {
		assertTrue(strings.addAll(setOfStrings));
		assertTrue(strings.contains("hola"));
		assertTrue(strings.contains("guten tag"));
		
		assertFalse(strings.contains(1));
		assertFalse(strings.contains("adios"));
	}
	
	@Test (expected=NoSuchElementException.class)
	public void testFirstException() {
		books.first();
	}
	
	@Test (expected=NoSuchElementException.class)
	public void testLastException() {
		books.last();
	}
	
	@Test
	public void testClearBooks() {
		assertTrue(books.addAll(listOfBooks));
		books.clear();
		assertTrue(books.isEmpty());
		assertEquals(0, books.size());
	}
	
	@Test
	public void testRemoveStrings() {
		assertTrue(strings.addAll(setOfStrings));
		assertEquals(5, strings.size());
		assertTrue(strings.remove("hello"));
		assertEquals(4, strings.size());
		
		assertFalse(strings.remove("hello"));
		assertFalse(strings.remove('A'));
	}
	
	@Test
	public void testIteratorBooks() {
		assertTrue(books.addAll(listOfBooks));
		Iterator<Book> iterator = books.iterator();
		assertTrue(iterator.hasNext());
		assertEquals(listOfBooks.get(2), iterator.next());
		iterator.remove();
		assertFalse(books.contains(listOfBooks.get(2)));
	}
	
	@Test
	public void testIteratorStrings() {
		assertTrue(strings.addAll(setOfStrings));
		Iterator<String> iterator = strings.iterator();
		assertTrue(iterator.hasNext());
		assertEquals("au revoir", iterator.next());
		assertTrue(iterator.hasNext());		
		assertEquals("buenos dias", iterator.next());
		assertTrue(iterator.hasNext());
		assertEquals("guten tag", iterator.next());
		assertTrue(iterator.hasNext());
		assertEquals("hello", iterator.next());
		assertTrue(iterator.hasNext());
		assertEquals("hola", iterator.next());
		assertFalse(iterator.hasNext());	
		
		try {
			iterator.next();
			fail("No exception thrown");
		}
		catch (NoSuchElementException e) {
		}
		
	}
	

	@Test 
	public void testIteratorRemoveStrings() {
		assertTrue(strings.addAll(setOfStrings));
		Iterator<String> iterator = strings.iterator();
		try {
			iterator.remove();
			fail("No exception thrown");
		}
		catch (IllegalStateException e) {
		}
		
		iterator.next();
		iterator.remove();
		try {
			iterator.remove();
			fail("No exception thrown");
		}
		catch (IllegalStateException e) {
		}
	}
	
	@Test
	public void testAddMoreThanTen() {
		MySortedSet<Integer> numbers = new MySortedSet<Integer>();
		for (int i = 22; i > 0; i--) {
			assertTrue(numbers.add(i));
		}
		assertEquals(22, numbers.size());
		assertEquals((Integer) 1, numbers.first());
		assertEquals((Integer) 22, numbers.last());
	}
	
	@Test
	public void testToArrayBooks() {
		assertTrue(books.addAll(listOfBooks));
		Object[] arrayOfBooks = new Object[]{listOfBooks.get(2), listOfBooks.get(3), listOfBooks.get(1), listOfBooks.get(0)};
		assertArrayEquals(arrayOfBooks, books.toArray());
	}
	
	@Test
	public void testAddNull() {
		assertFalse(books.add(null));
		assertFalse(strings.add(null));
	}
	
	@Test
	public void testFirst() {
		MySortedSet<Integer> mSsetInteger = new MySortedSet<Integer>();
		mSsetInteger.add(1);
		assertEquals((int) 1, (int) mSsetInteger.first());
		mSsetInteger.add(0);
		assertEquals((int) 0, (int) mSsetInteger.first());
		OrderByIsbn comparator = new OrderByIsbn();
		MySortedSet<Book> testComparator = new MySortedSet<Book>(comparator);
		testComparator.add(new Book(9780330351690L, "Jon Krakauer", "Into the Wild"));
		testComparator.add(new Book(9780374292799L, "Thomas L. Friedman", "The World is Flat"));
		testComparator.add(new Book(9780446580342L, "David Baldacci", "Simple Genius"));
		assertEquals(true, testComparator.contains(new Book(9780330351690L, "Jon Krakauer", "Into the Wild")));
		
		
	}


	@Test
	public void testLast() {
		MySortedSet<Integer> mSsetInteger = new MySortedSet<Integer>();
		mSsetInteger.add(1);
		assertEquals((int) 1, (int) mSsetInteger.last());
		mSsetInteger.add(0);
		assertEquals((int) 1, (int) mSsetInteger.last());
	}


	@Test
	public void testAdd() {
		MySortedSet<Integer> mSsetInteger = new MySortedSet<Integer>();
		assertEquals(true, mSsetInteger.add(1));
		assertEquals(false, mSsetInteger.add(1));
		
		OrderByIsbn comparator = new OrderByIsbn();
		MySortedSet<Book> testComparator = new MySortedSet<Book>(comparator);
		testComparator.add(new Book(9780330351690L, "Jon Krakauer", "Into the Wild"));
		testComparator.add(new Book(9780374292799L, "Thomas L. Friedman", "The World is Flat"));
		testComparator.add(new Book(9780446580342L, "David Baldacci", "Simple Genius"));
		assertEquals(true, testComparator.contains(new Book(9780330351690L, "Jon Krakauer", "Into the Wild")));
		assertEquals(true, testComparator.contains(new Book(9780446580342L, "David Baldacci", "Simple Genius")));
		assertEquals(true, testComparator.contains(new Book(9780374292799L, "Thomas L. Friedman", "The World is Flat")));
		
		
	}

	@Test
	public void testContains() {
		MySortedSet<Integer> mSsetInteger = new MySortedSet<Integer>();
		mSsetInteger.add(1);
		mSsetInteger.add(2);
		mSsetInteger.add(3);
		mSsetInteger.add(4);
		mSsetInteger.add(5);
		mSsetInteger.add(6);
		mSsetInteger.add(7);
		assertEquals(false, mSsetInteger.contains('1'));
		assertEquals(true, mSsetInteger.contains(5));
		assertEquals(false, mSsetInteger.contains(0));
	}


	@Test
	public void testContainsAll() {
		MySortedSet<Integer> mSsetInteger = new MySortedSet<Integer>();
		mSsetInteger.add(1);
		mSsetInteger.add(2);
		mSsetInteger.add(3);
		mSsetInteger.add(4);
		mSsetInteger.add(5);
		mSsetInteger.add(6);
		mSsetInteger.add(7);
		ArrayList<Integer> test = new ArrayList<Integer>();
		test.add(1);
		test.add(4);
		assertEquals(true, mSsetInteger.containsAll(test));
		test.add(8);
		assertEquals(false, mSsetInteger.containsAll(test));
		
	}


	@Test
	public void testIsEmpty() {
		MySortedSet<Integer> mSsetInteger = new MySortedSet<Integer>();
		assertEquals(true, mSsetInteger.isEmpty());
		assertEquals(true, mSsetInteger.add(1));
		assertEquals(false, mSsetInteger.isEmpty());

	}
	
	  /**
	   * Comparator that defines an ordering among books using the ISBN.
	   */
	  protected class OrderByIsbn implements Comparator<Book> {

	    /**
	     * Returns a negative value if lhs is smaller than rhs. Returns a positive
	     * value if lhs is larger than rhs. Returns 0 if lhs and rhs are equal.
	     */
	    public int compare(Book lhs,
	        Book rhs) {
	      return (int) (lhs.getIsbn() - rhs.getIsbn());
	    }
	  }

}
