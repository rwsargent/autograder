package assignment3;

import java.util.Random;

/**
 * Used for timing the add method.
 * This is based off of TimingExperiment08 from lab 1. 
 * @author Mackenzie Simper
 *Chase Wilker
 */
public class TimingAdd {

	public static void main(String[] args) {
		long startTime, midpointTime, stopTime, threeQuarterTime;
		  
		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) { // empty block 
		}
		
		long sizeOfSet = 2000000;
		// Create a MySortedSet of random longs. (This part is not timed). Note: it is possible (though very unlikely)
		//that the same random long could be generated twice, and since the set does not contain duplicates, 
		// the size of the set will be less than sizeOfSet.
		MySortedSet<Long> set = new MySortedSet<Long>();
		Random r = new Random();
		for (long i = 0; i < sizeOfSet; i++)
			set.add(r.nextLong());
		
		// Test the worst case scenario.
		long number = set.first() - 1;

		// Now, run the test.
		long timesToLoop = 10000;

		startTime = System.nanoTime();

		for (long i = 0; i < timesToLoop; i++) {
			//set.remove(number);
			set.add(number);
		}

		midpointTime = System.nanoTime();

		// Run an empty loop to capture the cost of running the loop.

		for (long i = 0; i < timesToLoop; i++) { // empty block
			
		}
		
		// Find how long it takes to remove the number.
		threeQuarterTime = System.nanoTime();
		
		set.remove(number);

		stopTime = System.nanoTime();

		// Compute the time, subtract the cost of running the loop and calling remove
		// from the cost of running the loop and calling contains.
		// Average it over the number of runs.

		double averageTime = ((midpointTime - startTime) - (threeQuarterTime - midpointTime) - (timesToLoop*(stopTime-threeQuarterTime)))
		        / timesToLoop;

		System.out.println("It takes exactly " + averageTime
		        + " nanoseconds to call add(r) for a random long on a randomly generated set of longs of size " +
				sizeOfSet);
		
	}
}
