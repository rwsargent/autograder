package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A sorted set of type E.
 * @author Mackenzie Simper
 * Chase Wilker
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E> {
	
	private Object[] set; // The sorted array of elements in the set.
	private Comparator<? super E> comparator; // The comparator used for ordering, or null if no comparator was given.
	private int size; // The size of the set. 
	
	public MySortedSet() {
		comparator = null;
		set = new Object[10];
		size = 0;
	}
	
	public MySortedSet(Comparator<? super E> comp) {
		comparator = comp;
		set = new Object[10]; //Begin with an array of size 10.
		size = 0;
	}

	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (size == 0) //Check that there are actually elements in the set.
			throw new NoSuchElementException();
		
		return (E) set[0];
	}

	
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (size == 0) //Check that there are actually elements in the set.
			throw new NoSuchElementException();
		
		return (E) set[size - 1];
	}

	
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {
		if (o == null ) //Check o is not null.
			return false;
		
		if (size == set.length - 1) { //Check that the array has not run out of size. If it has, double the size.
			Object[] temp = new Object[size*2];
			for (int i = 0; i < set.length; i++) 
				temp[i] = set[i];
			set = temp;
		}
		
		// Perform a binary search to find the correct position.
		int pos = 0;
		int high = size - 1;
		int low = 0;
		int middle = 0;
		
		if (comparator != null) {
	        while (low <= high) {
	            middle = (low + high)/2;
	            if (comparator.compare((E) set[middle], o) < 0)
	                low = middle + 1;
	            else if (comparator.compare((E) set[middle], o) > 0)
	                high = middle - 1;
	            else //If this happens, o is already in the set, so return false.
	                return false;
	        }
	        pos = low;  
		}
		
		else if ((o instanceof Comparable)) { //Make sure o actually implements Comparable.
			Comparable<E> o2 = (Comparable<E>) o; //Cast o as comparable to access the compareTo method.
			while (low <= high) {
				middle = (low + high)/2;
				if (o2.compareTo((E) set[middle]) > 0)
					low = middle + 1;
				else if (o2.compareTo((E) set[middle]) < 0)
					high = middle - 1;
				else 
					return false;
			}			
			
			pos = low;
		}
		
		//Insert the object at the found position and shift everything else over.
		for (int i = size; i > pos; i--)
			set[i] = set[i-1];
		
		set[pos] = o;
			
		size++; //Increase the size by one.
		return true;
	}
	

	
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean wasChanged = false; //Variable to let me know if the set has changed.
		
		for (E element: c) {
			boolean b = add(element);
			if (b) 
				wasChanged = true;
		}
		
		return wasChanged;
	}

	
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {		
		set = new Object[10]; //Create a new (empty) array and set the size to 0.
		size = 0;
		
	}

	
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		return !(indexOf(o) == -1); //As long as indexOf(o) does not return -1, the object is in the set.
	}
    
	/**
	 * Helper method used for the contains and removes methods. 
	 * It returns the index the object is located in the set or -1 if the object is not in the set. 
	 * @param o - the object being checked
	 * @return the index of the object or -1 if the object is not in the set
	 */
	private int indexOf(Object o) {
		
		if (size == 0) //First, make sure there are elements in the set.
			return -1;
		
        int low = 0;
        int high = size - 1;
        int middle;

        if (comparator != null) {
        	
    		try { //Try one comparison and catch the exception thrown if the types don't match. 
    			comparator.compare((E) set[0], (E) o);
    		}
    		catch (ClassCastException e){
    			return -1;
    		}
    		
    		E o1 = (E) o; //Cast the object as an E	
    		
    		//Perform a binary search.
	        while( low <= high )
	        {
	            middle = (low + high) / 2;
	            if(comparator.compare((E) set[middle], o1) < 0 )
	                low = middle + 1;
	            else if(comparator.compare((E) set[middle], o1) > 0 )
	                high = middle - 1;
	            else
	                return middle;
	        }
        }
        
        else if ((o instanceof Comparable)){ //Check that o implements comparable
			Comparable<E> o2 = (Comparable<E>) o; //Cast o as a comparable
			
			try { //Try one initial comparison and catch the exception if the types don't match
				o2.compareTo((E) set[0]);
			}
			catch (ClassCastException e) {
				return -1;
			}
			
	        while( low <= high )
	        {
	            middle = (low + high) / 2;
	            if(o2.compareTo((E) set[middle]) > 0 )
	                low = middle + 1;
	            else if(o2.compareTo((E) set[middle]) < 0 )
	                high = middle - 1;
	            else
	                return middle;
	        }
        }
        
        return -1; //If the searches didn't turn up anything, return -1.
	}
	
	
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for (Object element: c) { 
			if (!contains(element))
				return false;
		}
		
		return true;
	}

	
	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	
	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Iterator<E> iterator() {
		return new MyIterator(this);
	}

	
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int pos = indexOf(o); //Get the indexOf(o). If it is -1, the object is not in the set, so return false.
		if (pos == -1)
			return false;
        
		//Remove the object and shift everything over.
        for (int i = pos; i < size; i++) {
        	set[i] = set[i+1];
        }
        
        size--; //Decrement the size
        
        return true;
	}

	
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean wasChanged = false; //Variable to let me know if remove(o) ever returns true (i.e. the set was changed).
		
		for (Object o: c) {
			boolean b = remove(o);
			if (b)
				wasChanged = true;
		}
		
		return wasChanged;
	}

	
	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {		
		return size;
	}

	
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object[] temp = new Object[size]; //Create a new array of the correct length and copy everything over.
		for (int i = 0; i < size; i++)
			temp[i] = set[i];
		
		return temp;
	}
	
	
	
	/**
	 * An iterator for MySortedSet.
	 * 
	 * @author Mackenzie Simper
	 *
	 */
	private class MyIterator implements Iterator<E> {
		
		private int position;
		private MySortedSet sortedSet;
		//Variable to let me know the position that remove() was called from. Initially -1.
		private int removeCalled; 
		
		public MyIterator (MySortedSet s) {
			position = 0;
			sortedSet = s;
			removeCalled = -1;
		}

		/**
		 * Returns whether or not the iterator has a next element.
		 */
		@Override
		public boolean hasNext() {
			return position < size;
		}

		/**
		 * Returns the next element in the iterator or NoSuchElementException if we have reached the end
		 * of the iterator.
		 */
		@Override
		public E next() {
			if (!hasNext()) 
				throw new NoSuchElementException();
			
			return (E) set[position++];
		}
		
		/**
		 * Removes the object that was returned when next() was last called. Return IllegalStateException if
		 * this object has already been removed or next() has not yet been called.
		 */
		@Override
		public void remove() {
			if (position == 0 || removeCalled == position)
				throw new IllegalStateException();
			
			sortedSet.remove(set[position - 1]);
			removeCalled = position;
			
		}
		
	}

}
