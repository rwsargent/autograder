package assignment3;

import java.util.Random;

/**
 * Used for timing the contains method.
 * This is based off of TimingExperiment08 from lab 1. 
 * @author Mackenzie Simper
 * Chase Wilker
 *
 */
public class TimingContains {

	public static void main(String[] args) {
		long startTime, midpointTime, stopTime;
	
		long sizeOfSet = 100000;
		// Create a MySortedSet of random longs. (This part is not timed). Note: it is possible (though very unlikely)
		//that the same random long could be generated twice, and since the set does not contain duplicates, 
		// the size of the set will be less than sizeOfSet.
		MySortedSet<Long> set = new MySortedSet<Long>();
		Random r = new Random();
		for (long i = 0; i < sizeOfSet; i++)
			set.add(r.nextLong());
			
		// To check the worst-case scenario. I will pick a number at the very end of the set.
		long number = set.first();

		// Now, run the test.
		long timesToLoop = 100000;

		startTime = System.nanoTime();

		for (long i = 0; i < timesToLoop; i++)
			set.contains(number);

		midpointTime = System.nanoTime();

		// Run an empty loop to capture the cost of running the loop.

		for (long i = 0; i < timesToLoop; i++) { // empty block
		}

		stopTime = System.nanoTime();

		// Compute the time, subtract the cost of running the loop
		// from the cost of running the loop and calling contains.
		// Average it over the number of runs.

		double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;

		System.out.println("It takes exactly " + averageTime
		        + " nanoseconds to call contains(r) for a random long on a randomly generated set of longs of size " +
				sizeOfSet);
	}
}
