/**
 * 
 */
package assignment3;

import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

//import assignment2.LibraryGeneric.OrderByDueDate;

/**
 * @author Ajmal Mohamad Esa u0766202 and Sierra Orten u0740878
 * 
 * Class used to test MySortedSet.
 */
public class TestMySortedSet {

	MySortedSet<Integer> m1;
	Integer integer1, integer2, integer3, integer4, integer5, integer6, integer7, integer8, integer9, integer10;
	String string1, string2;
	Collection<Integer> integerArray = new ArrayList<Integer>();
	Collection<Integer> integerArray2 = new ArrayList<Integer>();
	Iterator<Integer> myIterator;
	Object[] basicIntArray;
	
	

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		m1 = new MySortedSet<Integer>();
		

		MySortedSet<String> stringTest = new MySortedSet<String>();

		stringTest.add("a");
		stringTest.add("b");

		myIterator = m1.iterator();

		integerArray.add(22);
		integerArray.add(55);
		integerArray.add(19);

		integerArray2.add(6);
		integerArray2.add(2);

		integer1 = new Integer(3);
		integer2 = new Integer(4);
		integer3 = new Integer(6);
		integer4 = new Integer(5);
		integer5 = new Integer(2);
		integer6 = new Integer(7);
		integer7 = new Integer(1);
		integer8 = new Integer(9);
		integer9 = new Integer(10);
		integer10 = new Integer(12);

		m1.add(integer1);
		m1.add(integer2);
		m1.add(integer3);
		m1.add(integer4);
		m1.add(integer5);
		m1.add(integer6);
		m1.add(integer7);
		m1.add(integer8);

		basicIntArray = new Object[8];
		basicIntArray[0] = 1;
		basicIntArray[1] = 2;
		basicIntArray[2] = 3;
		basicIntArray[3] = 4;
		basicIntArray[4] = 5;
		basicIntArray[5] = 6;
		basicIntArray[6] = 7;
		basicIntArray[7] = 9;

	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}


	/**
	 * Test method for {@link assignment3.MySortedSet#first()}.
	 */
	@Test
	public void testFirst() {
		assertEquals("1", m1.first().toString());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#last()}.
	 */
	@Test
	public void testLast() {
		assertEquals("9", m1.last().toString());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#add(java.lang.Object)}.
	 */
	@Test
	public void testAdd() {
		assertEquals(true, m1.add(integer9));

	}

	/**
	 * Test method for {@link assignment3.MySortedSet#size()}.
	 */
	@Test
	public void testSize() {
		assertEquals(8, m1.size());
		assertEquals(3, integerArray.size());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#addAll(java.util.Collection)}.
	 */
	@Test
	public void testAddAll() {
		assertEquals(true, m1.addAll(integerArray));
		assertEquals(true, m1.contains(22));
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#clear()}.
	 */
	@Test
	public void testClear() {
		m1.clear();
		assertEquals(true, m1.isEmpty());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#contains(java.lang.Object)}.
	 */
	@Test
	public void testContains() {
		assertEquals(true, m1.contains(4));
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#containsAll(java.util.Collection)}.
	 */
	@Test
	public void testContainsAll() {
		assertEquals(false, m1.containsAll(integerArray));
		assertEquals(true, m1.containsAll(integerArray2));
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#isEmpty()}.
	 */
	@Test
	public void testIsEmpty() {
		assertEquals(false, m1.isEmpty());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#iterator()}.
	 */
	@Test
	public void testIterator() {
		assertEquals(true, myIterator.hasNext());
		assertEquals(1, (int) m1.iterator().next());

	}

	/**
	 * Test method for {@link assignment3.MySortedSet#remove(java.lang.Object)}.
	 */
	@Test
	public void testRemove() {
		assertEquals(false, m1.remove(22));
		assertEquals(true, integerArray.remove(22));
		assertEquals(true, m1.remove(6));
		assertEquals(false, m1.contains(6));
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#removeAll(java.util.Collection)}.
	 */
	@Test
	public void testRemoveAll() {
		assertEquals(false, m1.removeAll(integerArray));
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#toArray()}.
	 */
	@Test
	public void testToArray() {
		assertArrayEquals(basicIntArray, m1.toArray());
	}

}
