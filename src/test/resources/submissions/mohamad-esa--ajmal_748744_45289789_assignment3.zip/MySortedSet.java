package assignment3;


import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 *
 * @author Ajmal Mohamad Esa u0766202 and Sierra Orten u0740878
 * 
 * 
 *         This class uses and manipulates a generic dynamic array, sorting it
 *         using a given comparator or by comparable.
 * 
 * @param <E>
 *            Generic Type to place in an array
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] genericArray;
	private Comparator<? super E> order;
	private int size;

	public MySortedSet() {

		// a.compareTo(b)
		genericArray = (E[]) new Object[8];
		size = 0;
		order = null;

	}

	public MySortedSet(Comparator<? super E> _order) {
		// _order.compare(a, b)
		order = _order;
		genericArray = (E[]) new Object[8];
		size = 0;

	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		if (order == null)
			return null;

		return order;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		return genericArray[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {

		return genericArray[this.size() - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {

		// If the number of array items is equal to the length of the array, make
		// a new array double the size of the old one and store everything from the 
		// old array into the new array and use that as the main array.
		if (this.size() == genericArray.length) {
			E[] newArray = (E[]) new Object[size * 2];

			for (int i = 0; i < genericArray.length; i++) {
				newArray[i] = genericArray[i];
			}

			genericArray = newArray;

		}

		Comparable<E> theComparableObjecto = (Comparable<E>) o;

		int indexToAddTo;

		if (!(o == null)) {

			if (!this.contains(o)) {

				if (size > 0) {

					indexToAddTo = this.binarySearchPosition(o);

					if (order == null) {

						if (theComparableObjecto.compareTo(genericArray[indexToAddTo]) > 0) {
							indexToAddTo++;
						}

					}

					if (order != null) {

						if (order.compare(genericArray[indexToAddTo], o) < 0) {
							indexToAddTo++;
						}

					}

					int j = size;
					while (j > indexToAddTo) {
						genericArray[j] = genericArray[j - 1];
						j--;
					}

					genericArray[indexToAddTo] = o;
					size++;

				} else if (size == 0) {

					genericArray[0] = o;

					size++;
				}

				return true;

			}

		}

		return false;
	}

	/**
	 * /**
	 * 
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {

		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order. Adds all of the elements in the specified
	 *         collection to this set if they are not already present and not
	 *         set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {

		E[] arrayC = (E[]) c.toArray();
		
		for (int i = 0; i < arrayC.length; i++) {
			this.add(arrayC[i]);
		}
		
	      return this.containsAll(c);
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		this.genericArray = (E[]) new Object[8];
		size = 0;

	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {

		E ObjectE = (E) o;

		// Use binary search to determine if object o is in the array,
		// If it is not in the array, return false, otherwise return true
		if (binarySearchContains(ObjectE) == -1) {
			return false;
		}
		return true;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {

		E[] arrayC = (E[]) c.toArray();

		for (int i = 0; i < arrayC.length - 1; i++) {
			if (!this.contains(arrayC[i])) {
				return false;
			}
		}
		return true;

	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (this.size() == 0) {
			return true;
		}
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new Iterator<E>() {

			int pointer = -1;			// used to keep track of where we are in the iteration
			boolean hasRemoved = true;  // used to determine whether we have removed and object from where we are

			@Override
			public boolean hasNext() {
				return (pointer < size - 1);

			}

			@Override
			public E next() {
				if (!(pointer < size - 1)) {
					throw new NoSuchElementException(
							"There are no more elements in the array.");
				}

				pointer++;
				hasRemoved = false;

				return genericArray[pointer];
			}

			@Override
			public void remove() {
				if (hasRemoved) {
					throw new IllegalStateException(
							"Cannot remove until next iteration.");
				}
				if (!hasRemoved) {
					MySortedSet.this.remove(genericArray[pointer]);
					hasRemoved = true;
				}

			}

		};
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {

		E ObjectE = (E) o;

		int indexToRemove;

		if (this.contains(o)) {
			indexToRemove = this.binarySearchContains(ObjectE);
			int i = indexToRemove;

			while (i < size - 1) {
				genericArray[i] = genericArray[i + 1];
				i++;

			}

			size--;
			return true;
		}

		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		E[] arrayC = (E[]) c.toArray();

		E[] arrayOld = genericArray;

		for (int i = 0; i < arrayC.length - 1; i++) {
			this.remove(arrayC[i]);

			if (!(arrayOld == genericArray)) {
				return true;
			}
		}
		return false;
		
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		E[] arrayNotGeneric = (E[]) new Object[size];

		for(int i = 0; i < size; i++) {
			arrayNotGeneric[i] = genericArray[i];
		}
		
		return arrayNotGeneric;
	}

	/**
	 * 
	 * @param objectE
	 * @return The index of the the object searched for, or -1 if it does not
	 *         exist.
	 */
	private int binarySearchContains(E objectE) {

		if (size == 0)
			return -1;

		if (order != null) {

			int low = 0;
			int high = size - 1;
			int mid;

			while (low <= high) {

				mid = (high + low) / 2;

				if (order.compare(objectE, genericArray[mid]) < 0) {
					high = mid - 1;
				} else if (order.compare(objectE, genericArray[mid]) > 0) {
					low = mid + 1;
				} else {
					return mid;
				}

			}

		}

		if (order == null) {

			int low = 0;
			int high = size - 1;
			int mid;

			// Comparable<E> theComparableObject = (Comparable<E>) objectE;
			// theComparableObject = objectE;
			while (low <= high) {

				mid = (high + low) / 2;

				// if(mid == mSize)
				// return mid;

				if (((Comparable<E>) objectE).compareTo(genericArray[mid]) < 0) {
					high = mid - 1;
				} else if (((Comparable<E>) objectE).compareTo(genericArray[mid]) > 0) {
					low = mid + 1;
				} else {
					return mid;
				}

			}

		}

		return -1; // Not Found

	}

	private int binarySearchPosition(E objectE) {

		if (order != null) {

			int low = 0;
			int high = size - 1;
			int mid;

			while (low <= high) {

				mid = (high + low) / 2;

				if (high == low) {
					return mid;
				} else if (order.compare(objectE, genericArray[mid]) < 0) {
					high = mid - 1;
				} else if (order.compare(objectE, genericArray[mid]) > 0) {
					low = mid + 1;
				} else {
					break;
				}

			}

		}

		if (order == null) {

			int low = 0;
			int high = size - 1;
			int mid = (low + high) / 2;

			Comparable<E> theComparableObject = (Comparable<E>) objectE;

			while (low <= high) {

				mid = (high + low) / 2;

				if (high == low) {
					return mid;
				}
					if (theComparableObject.compareTo(genericArray[mid]) < 0) {
						high = mid - 1;
					} else if (theComparableObject.compareTo(genericArray[mid]) > 0) {
						low = mid + 1;
					} else {
						return mid;
					}

				}
				return mid;

			}

			return -1; // Not Found

		}
	
}
