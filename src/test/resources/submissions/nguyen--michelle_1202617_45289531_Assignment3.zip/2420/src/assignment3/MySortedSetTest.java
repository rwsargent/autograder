package assignment3;

import static org.junit.Assert.*;

import java.awt.Window.Type;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit tests for MySortedSet class.
 * 
 * @author Kenny Ho & Michelle Nguyen
 */
public class MySortedSetTest
{

	// Declares variables for constructor that does not use a comparator
	// private E[] mySetNatural;
	private MySortedSet<Integer> mySortedSetNatural;

	// Declares variabes for constructor that uses comparator
	private Comparator<Person> mComparator;
	private MySortedSet<Person> mySortedSet;
	private Person Sally = new Person("", "");
	private Person Bobby = new Person("", "");
	private Person Amy = new Person("", "");
	private Person Bill = new Person("", "");
	private Person Janice = new Person("", "");

	// Other necessary variables
	private MySortedSet<Type> emptySet;
	private int[] expectedArray;
	private Person[] expectedArrayPerson;

	/**
	 * Sets up a comparator, people, array, and SortedSet for testing purposes.
	 */
	@Before
	public void setUp ()
	{
		// Set up for constructor of a MySortedSet that contains elements which
		// have a natural ordering
		mySortedSetNatural = new MySortedSet<Integer>();
		mySortedSetNatural.add(1);
		mySortedSetNatural.add(2);
		mySortedSetNatural.add(3);
		mySortedSetNatural.add(5);
		mySortedSetNatural.add(9);

		// Set up expected array of
		expectedArray = new int[]
		{ 1, 2, 3, 5, 9 };

		// Set up for constructor of MySortedSet that contains elements which do
		// not have a natural ordering
		mComparator = personComparator;
		mySortedSet = new MySortedSet<Person>(mComparator);
		Sally = new Person("Sally", "Jones");
		Bobby = new Person("Bobby", "Smith");
		Amy = new Person("Amy", "Brown");
		Bill = new Person("Bill", "Green");
		Janice = new Person("Janice", "Walker");
		mySortedSet.add(Sally);
		mySortedSet.add(Bobby);
		mySortedSet.add(Amy);
		mySortedSet.add(Janice);

		// Set up an empty set
		emptySet = new MySortedSet<Type>();

		// Set up expected results for array
		expectedArrayPerson = new Person[]
		{ Amy, Bobby, Janice, Sally };

	}

	@After
	public void tearDown () throws Exception
	{
	}

	/**
	 * Tests that the first method returns the first element of the set if the
	 * set exists and containts at least one element.
	 */
	@Test
	public void testFirst1 ()
	{
		// Tests the natural ordered set
		assertEquals(1, mySortedSetNatural.first().intValue());

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(Amy, mySortedSet.first());
	}

	/**
	 * Tests that the first method throws a NoSuchElementException if the set is
	 * empty.
	 */
	@Test
	public void testFirst2 ()
	{
		try
		{
			emptySet.last();
			assertTrue(false);
		} catch (NoSuchElementException e)
		{
			assertTrue(true);
		}
	}

	/**
	 * Tests that the last method returns the last element of the set if the set
	 * exists and contains at least one element.
	 */
	@Test
	public void testLast1 ()
	{
		// Tests the natural ordered set
		assertEquals(9, mySortedSetNatural.last().intValue());

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(Sally, mySortedSet.last());
	}

	/**
	 * Tests that the last method throws a NoSuchElementException if the set is
	 * empty.
	 */
	@Test
	public void testLast2 ()
	{
		try
		{
			emptySet.last();
			assertTrue(false);
		} catch (NoSuchElementException e)
		{
			assertTrue(true);
		}
	}

	/**
	 * Tests that the add method returns true and adds the specified element to
	 * the set if it isn't already included or equal to null.
	 */
	@Test
	public void testAdd1 ()
	{
		// Tests the natural ordered set
		assertEquals(true, mySortedSetNatural.add(4));

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(true, mySortedSet.add(Bill));
	}

	/**
	 * Tests that the add method returns false and does not add the specified
	 * element to the set if it already included or equal to null.
	 */
	@Test
	public void testAdd2 ()
	{
		// Tests the natural ordered set
		assertEquals(false, mySortedSetNatural.add(1));

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(false, mySortedSet.add(Bobby));
	}

	/**
	 * Tests that the addAll method returns true and adds the elements in the
	 * specified collection to the set if it isn't already included or equal to
	 * null.
	 */
	@Test
	public void testAddAll1 ()
	{
		// Tests the natural ordered set
		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(4);
		collection.add(6);
		collection.add(9);

		assertEquals(true, mySortedSetNatural.addAll(collection));
		assertEquals(7, mySortedSetNatural.size());

		// Tests the non-natural ordered class type that takes a comparator
		ArrayList<Person> collectionPeople = new ArrayList<Person>();
		collectionPeople.add(new Person("John", "Smith"));
		collectionPeople.add(new Person("Felicia", "Ho"));
		collectionPeople.add(new Person("Michelle", "Nguyen"));
		collectionPeople.add(Sally);
		assertEquals(true, mySortedSet.addAll(collectionPeople));
		assertEquals(7, mySortedSet.size());
	}

	/**
	 * Tests that the addAll method returns false and does not add elements in
	 * the specified collection to the set if they are already included or equal
	 * to null.
	 */
	@Test
	public void testAddAll2 ()
	{
		// Tests the natural ordered set
		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(2);
		collection.add(3);

		assertEquals(false, mySortedSetNatural.addAll(collection));
		assertEquals(5, mySortedSetNatural.size());

		// Tests the non-natural ordered class type that takes a comparator
		ArrayList<Person> collectionPeople = new ArrayList<Person>();
		collectionPeople.add(Bobby);
		collectionPeople.add(Janice);
		collectionPeople.add(Amy);
		collectionPeople.add(Sally);
		assertEquals(false, mySortedSet.addAll(collectionPeople));
		assertEquals(4, mySortedSet.size());
	}

	/**
	 * Tests that the clear method removes all of the elements from the set.
	 */
	@Test
	public void testClear ()
	{
		// Clear the sorted set then check that it fulfills requirements for
		// being an empty set
		// Tests the natural ordered set
		mySortedSetNatural.clear();
		try
		{
			mySortedSetNatural.first();
			assertTrue(false);
		} catch (NoSuchElementException e)
		{
			assertTrue(true);
		}
		try
		{
			mySortedSetNatural.last();
			assertTrue(false);
		} catch (NoSuchElementException e)
		{
			assertTrue(true);
		}
		assertEquals(0, mySortedSetNatural.size());

		// Tests the non-natural ordered class type that takes a comparator
		mySortedSet.clear();
		try
		{
			mySortedSet.first();
			assertTrue(false);
		} catch (NoSuchElementException e)
		{
			assertTrue(true);
		}
		try
		{
			mySortedSet.last();
			assertTrue(false);
		} catch (NoSuchElementException e)
		{
			assertTrue(true);
		}
		assertEquals(0, mySortedSet.size());
	}

	/**
	 * Tests that the contain method returns true if the set contains the
	 * specified element.
	 */
	@Test
	public void testContains1 ()
	{
		// Tests the natural ordered set
		assertEquals(true, mySortedSetNatural.contains(1));

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(true, mySortedSet.contains(Amy));
	}

	/**
	 * Tests that the contain method returns fale if the set does not contain
	 * the specified element.
	 */
	@Test
	public void testContains2 ()
	{
		// Tests the natural ordered set
		assertEquals(false, mySortedSetNatural.contains(4));

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(false, mySortedSet.contains(Bill));
	}

	/**
	 * Tests that the containsAll method returns true if the set contains all of
	 * the elements from the specified collection.
	 */
	@Test
	public void testContainsAll1 ()
	{
		// Tests the natural ordered set
		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(2);
		collection.add(3);

		assertEquals(true, mySortedSetNatural.containsAll(collection));

		// Tests the non-natural ordered class type that takes a comparator
		ArrayList<Person> collectionPeople = new ArrayList<Person>();
		collectionPeople.add(Bobby);
		collectionPeople.add(Janice);
		collectionPeople.add(Amy);
		collectionPeople.add(Sally);
		assertEquals(true, mySortedSet.containsAll(collectionPeople));
	}

	/**
	 * Tests that the containsAll method returns false if the set does not
	 * contain all of the elements from the specified collection.
	 */
	@Test
	public void testContainsAll2 ()
	{
		// Tests the natural ordered set
		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(4);
		collection.add(6);
		collection.add(9);

		assertEquals(false, mySortedSetNatural.containsAll(collection));

		// Tests the non-natural ordered class type that takes a comparator
		ArrayList<Person> collectionPeople = new ArrayList<Person>();
		collectionPeople.add(new Person("John", "Smith"));
		collectionPeople.add(new Person("Felicia", "Ho"));
		collectionPeople.add(new Person("Michelle", "Nguyen"));
		collectionPeople.add(Sally);
		assertEquals(false, mySortedSet.containsAll(collectionPeople));
	}

	/**
	 * Tests that the isEmpty method returns true if the set is empty, meaning
	 * it contains no elements.
	 */
	@Test
	public void testIsEmpty1 ()
	{
		assertEquals(true, emptySet.isEmpty());
	}

	/**
	 * Tests that the isEmpty method returns false if the set is not empty,
	 * meaning it contains at least one element.
	 */
	@Test
	public void testIsEmpty2 ()
	{
		// Tests the natural ordered set
		assertEquals(false, mySortedSetNatural.isEmpty());

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(false, mySortedSet.isEmpty());
	}

	/**
	 * Tests that the remove method returns true and removes the specified
	 * element from the set if it is present in the set.
	 */
	@Test
	public void testRemove1 ()
	{
		// Tests the natural ordered set
		assertEquals(true, mySortedSetNatural.remove(1));

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(true, mySortedSet.remove(Amy));
	}

	/**
	 * Tests that the remove method returns false if the specified element is
	 * not present in the set.
	 */
	@Test
	public void testRemove2 ()
	{
		// Tests the natural ordered set
		assertEquals(false, mySortedSetNatural.remove(4));

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(false, mySortedSet.remove(Bill));
	}

	/**
	 * Tests that the removeAll method returns true and removes from this set
	 * all of its elements that are contained in the specified collection if
	 * there are any.
	 */
	@Test
	public void testRemoveAll1 ()
	{
		// Tests the natural ordered set
		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(2);
		collection.add(3);
		collection.add(4);

		assertEquals(true, mySortedSetNatural.removeAll(collection));
		assertEquals(2, mySortedSetNatural.size());

		// Tests the non-natural ordered class type that takes a comparator
		ArrayList<Person> collectionPeople = new ArrayList<Person>();
		collectionPeople.add(Amy);
		collectionPeople.add(Sally);
		collectionPeople.add(Bill);
		assertEquals(true, mySortedSet.removeAll(collectionPeople));
		assertEquals(2, mySortedSet.size());
	}

	/**
	 * Tests that the removeAll method returns false if there are no elements
	 * contained in the specified collection that occur in the set.
	 */
	@Test
	public void testRemoveAll2 ()
	{
		// Tests the natural ordered set
		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(4);
		collection.add(6);
		collection.add(7);

		assertEquals(false, mySortedSetNatural.removeAll(collection));
		assertEquals(5, mySortedSetNatural.size());

		// Tests the non-natural ordered class type that takes a comparator
		ArrayList<Person> collectionPeople = new ArrayList<Person>();
		collectionPeople.add(new Person("John", "Smith"));
		collectionPeople.add(new Person("Felicia", "Ho"));
		collectionPeople.add(new Person("Michelle", "Nguyen"));
		assertEquals(false, mySortedSet.removeAll(collectionPeople));
		assertEquals(4, mySortedSet.size());
	}

	/**
	 * Tests that the size method returns the number of elements in the set.
	 */
	@Test
	public void testSize ()
	{
		// Tests the natural ordering set
		assertEquals(5, mySortedSetNatural.size());

		// Tests the non-natural ordered class type that takes a comparator
		assertEquals(4, mySortedSet.size());
	}

	/**
	 * Tests that the toArray method returns an array containing all the
	 * elements in the set in ascending order.
	 */
	@Test
	public void testToArray ()
	{
		// Tests the natural ordering set
		for (int i = 0; i < mySortedSetNatural.size(); i++)
		{
			assertEquals(expectedArray[i], mySortedSetNatural.toArray()[i]);
		}

		// Tests the non-natural ordered class type that takes a comparator
		for (int j = 0; j < mySortedSet.size(); j++)
		{
			assertEquals(expectedArrayPerson[j], mySortedSet.toArray()[j]);
		}
	}

	/**
	 * Tests that the toArray method returns an array containing all the
	 * elements in the set in ascending order.
	 */
	@Test
	public void testIterator ()
	{
		// Tests the natural ordering set
		Iterator<Integer> myIterator = mySortedSetNatural.iterator();
		assertEquals(true, myIterator.hasNext());
		assertEquals(1, myIterator.next().intValue());

		// Tests the non-natural ordered class type that takes a comparator
		Iterator<Person> myIterator2 = mySortedSet.iterator();
		assertEquals(true, myIterator2.hasNext());
		assertEquals(Amy, myIterator2.next());

	}

	/**
	 * Creates a new class, called Person. Each Person is assigned a first and
	 * last name.
	 */
	public class Person implements Comparable<Object>
	{

		private String firstName;
		private String lastName;

		/**
		 * Constructor that creates an instance of a Person.
		 * 
		 * @param firstName
		 *            -- first name of the person
		 * @param lastName
		 *            -- last name of the person
		 */
		public Person (String firstName, String lastName)
		{
			this.firstName = firstName;
			this.lastName = lastName;
		}

		/**
		 * Getter method for the Person's first name.
		 * 
		 * @return first name of the specific Person
		 */
		public String getFirstName ()
		{
			return firstName;
		}

		/**
		 * Getter method for the Person's last name.
		 * 
		 * @return last name of the specific Person
		 */
		public String getLastName ()
		{
			return lastName;
		}

		/**
		 * Equals method for person class
		 * 
		 * @return last name of the specific Person
		 */
		public boolean equals (Person p1)
		{
			if (this.getFirstName().equals(p1.getFirstName())
					&& this.getLastName().equals(p1.getLastName()))
			{
				return true;
			}
			return false;
		}

		@Override
		public int compareTo (Object o)
		{
			if (o != null)
			{
				return (int) (this.getFirstName().compareTo(((Person) o)
						.getFirstName()));
			} else
				throw new NullPointerException();
		}
	}

	/**
	 * Manual comparator that compares two elements of the same class
	 */
	public Comparator<Person> personComparator = new Comparator<Person>()
	{
		/**
		 * Compares two objects in relation to their first name fields.
		 * 
		 * @param -- o1 and o2 for comparison
		 * @return a negative integer if o1 lexicographically precedes o2, a
		 *         positive integer if o2 lexicographically precedes o1, or a 0
		 *         if o1 and o2 are lexicographically equal to each other.
		 */
		public int compare (Person p1, Person p2)
		{
			if (p2 != null)
			{
				return (int) ((p1).getFirstName()
						.compareTo((p2).getFirstName()));
			} else
				return -1;
		};
	};
}
