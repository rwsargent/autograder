package assignment3;

/**
 * Timing mechanisms for contains method from MySortedSet class.
 * 
 * @author Kenny Ho & Michelle Nguyen
 */
public class ContainsTiming
{

	public static void main (String[] args)
	{
		long startTime, stopTime;

		long timesToLoop = 200000;

		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		for (int i = 0; i < 1700000; i++)
		{
			mySet.add(i);
		}

		startTime = System.nanoTime();

		for (int i=0; i< 1700000; i++)
		mySet.contains(i);

		stopTime = System.nanoTime();

		double averageTime = (stopTime - startTime) / timesToLoop;

		System.out
				.println("It takes exactly "
						+ averageTime
						+ " nanoseconds to compute the running times for the contain method.");

	}
}