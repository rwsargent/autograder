package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This class, through the implementation of a SortedSet<E> interface, handles
 * lists of strings, integers, library books, and anything else that can be
 * thought of. It allows for the usual operations of a list, such as the ability
 * to add items, remove items, search for items, and get items (in sorted
 * order).
 * 
 * @author Michelle Nguyen and Kenny Ho
 *
 * @param <E>
 *            -- the type of elements maintained by this set
 */

public class MySortedSet<E> implements SortedSet<E>
{

	private E[] mySet;
	private Comparator<? super E> mComparator;
	private int size;

	/**
	 * Constructor of a set that contains items from classes which have a
	 * natural ordering
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet ()
	{
		mySet = (E[]) new Object[10];
		mComparator = null;
		size = 0;
	}

	/**
	 * Constructor of a set that contains items from a certain class which does
	 * not have a natural ordering therefore we must pass through a comparator
	 * to create an ordering scheme
	 * 
	 * @param comparator
	 *            -- comparator to be used in comparing two items of the same
	 *            class
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet (Comparator<? super E> comparator)
	{
		mySet = (E[]) new Object[10];
		mComparator = comparator;
		size = 0;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator ()
	{
		return mComparator;
	}

	/**
	 * Returns the first element currently contained in the sorted set. In an
	 * empty set, NoSuchElementException will be thrown.
	 * 
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first () throws NoSuchElementException
	{
		if (size == 0)
		{
			throw new NoSuchElementException();
		}
		return mySet[0];
	}

	/**
	 * Returns the last element currently contained in the sorted set. In an
	 * empty set, NoSuchElementException will be thrown.
	 * 
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last () throws NoSuchElementException
	{
		if (size == 0)
		{
			throw new NoSuchElementException();
		}
		return mySet[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add (E o)
	{
		if (!contains(o) && o != null)
		{
			// double size of array if elements size
			// exceed mySet size
			if (size + 1 > mySet.length)
			{
				E[] myNewSet = (E[]) new Object[mySet.length * 2];
				for (int i = 0; i < mySet.length; i++)
				{
					myNewSet[i] = mySet[i];
				}
				mySet = myNewSet;
			}

			// adds the element in the array
			if (size == 0)
			{
				mySet[0] = (E) o;
				size++;
				return true;
			} else if (size == 1)
			{
				if (mComparator == null)
				{
					Comparable<E> objectComp = (Comparable<E>) o;
					if (objectComp.compareTo(mySet[0]) > 0)
					{
						mySet[1] = (E) o;
					} else
					{
						E temp = mySet[0];
						mySet[0] = (E) o;
						mySet[1] = temp;
					}
				} else
				{
					if (mComparator.compare(o, mySet[0]) > 0)
					{
						mySet[1] = (E) o;
					} else
					{
						E temp = mySet[0];
						mySet[0] = (E) o;
						mySet[1] = temp;
					}
				}
				size++;
			} else if (size >= 2)
			{
				// Finding the correct index to add the object
				int correctIndex = binarySearch(o);

				// Shifting values over to the right
				for (int i = size - 1; i >= correctIndex; i--)
				{
					mySet[i + 1] = mySet[i];
				}

				// Adding the new value to the array
				mySet[correctIndex] = o;
				size++; // increments size

			}
			return true;
		}
		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll (Collection<? extends E> c)
	{
		boolean myBoolean = false;
		Iterator<? extends E> myIterator = c.iterator();
		while (myIterator.hasNext())
		{
			myBoolean = (add(myIterator.next()) || myBoolean);
		}
		return myBoolean;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void clear ()
	{
		mySet = (E[]) new Object[10];
		size = 0;
	}

	/**
	 * Checks a set for containment of an object, o, within it.
	 * 
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings(
	{ "unchecked" })
	@Override
	public boolean contains (Object o)
	{
		if (o != null)
		{
			int first = 0;
			int mid = 0;
			int last = size - 1;
			if (mComparator == null)
			{
				Comparable<E> oComp = (Comparable<E>) o;
				while (first <= last)
				{
					mid = (first + last) / 2;
					if (oComp.compareTo(mySet[mid]) > 0)
					{
						first = mid + 1;
					} else if (oComp.compareTo(mySet[mid]) < 0)
					{
						last = mid - 1;
					} else
						return true;
				}
			} else
			{
				while (first <= last)
				{
					mid = (first + last) / 2;
					if (mComparator.compare((E) o, mySet[mid]) > 0)
					{
						first = mid + 1;
					} else if (mComparator.compare((E) o, mySet[mid]) < 0)
					{
						last = mid - 1;
					} else
						return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks a set for containment of all the elements of an entire collection,
	 * c, within it.
	 * 
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll (Collection<?> c)
	{
		Iterator<?> myIterator = c.iterator();
		while (myIterator.hasNext())
			if (!contains(myIterator.next()))
				return false;
		return true;
	}

	/**
	 * Checks to see if a set is empty, meaning it contains no elements.
	 * 
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty ()
	{
		return (size == 0);
	}

	/**
	 * Creates an iterator for the sorted set.
	 * 
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator ()
	{
		return new iterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove (Object o)
	{
		if (contains(o))
		{
			for (int j = binarySearch((E) o); j < mySet.length - 1; j++)
			{
				mySet[j] = mySet[j + 1];
			}
			size--;
			return true;
		}
		return false;
	}

	/**
	 * Remove from the set all of the elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean removeAll (Collection<?> c)
	{
		Iterator<?> myIterator = c.iterator();
		int i = 0;
		while (myIterator.hasNext())
		{
			E currentElement = (E) myIterator.next();
			if (this.remove(currentElement))
			{
				i++;
			}
		}
		if (i != 0)
		{
			return true;

		}
		return false;
	}

	/**
	 * Counts the number of elements in the set.
	 * 
	 * @return the number of elements in this set
	 */
	@Override
	public int size ()
	{
		return size;
	}

	/**
	 * Converts all the elements in the set to an array in ascending order.
	 * 
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray ()
	{
		return Arrays.copyOf(mySet, size);
	}

	/**
	 * Uses the technique of binary searching through a list of sorted items to
	 * find the index in the array of elements at which the specified element
	 * which has been passed through occurs.
	 * 
	 * @param findMe
	 *            -- the element that we want to find
	 * @return the index at which the element occurs in the set or a -1 if it
	 *         does not occur.
	 */
	@SuppressWarnings("unchecked")
	private int binarySearch (E findMe)
	{
		if (findMe != null)
		{
			int first = 0;
			int mid = 0;
			int last = size - 1;
			if (mComparator == null)
			{
				Comparable<E> findMeComp = (Comparable<E>) findMe;
				while (first <= last)
				{
					mid = (first + last) / 2;
					if (findMeComp.compareTo(mySet[mid]) > 0)
					{
						first = mid + 1;
					} else if (findMeComp.compareTo(mySet[mid]) < 0)
					{
						last = mid - 1;
					} else
						return mid;
				}
				if (findMeComp.compareTo(mySet[mid]) > 0)
				{
					return mid + 1;
				} else
				{
					return mid;
				}
			} else
			{
				while (first <= last)
				{
					mid = (first + last) / 2;
					if (mComparator.compare(findMe, mySet[mid]) > 0)
					{
						first = mid + 1;
					} else if (mComparator.compare(findMe, mySet[mid]) < 0)
					{
						last = mid - 1;
					} else
						return mid;
				}
				if (mComparator.compare(findMe, mySet[mid]) > 0)
				{
					return mid + 1;
				} else
				{
					return mid;
				}
			}
		} else
			throw new NullPointerException();
	}

	/**
	 * Returns an iterator over the elements in this queue.
	 */
	private final class iterator implements Iterator<E>
	{
		boolean isValid = false;
		int index = -1;

		/**
		 * Checks to see if the iterator can move forward in the set.
		 * 
		 * @return true if the iteration has more elements
		 */
		@Override
		public boolean hasNext ()
		{
			return (index < (size - 1));
		}

		/**
		 * Moves the iterator to the next available position in the set.
		 * 
		 * @return the next element in the iteration
		 */
		@Override
		public E next ()
		{
			isValid = true;
			if (index >= mySet.length)
			{
				throw new IndexOutOfBoundsException();
			}
			index++;
			return mySet[index];
		}

		/**
		 * Removes the last element returned by the iterator.
		 */
		@Override
		public void remove ()
		{
			if (isValid)
			{
				MySortedSet.this.remove(mySet[index]);
				isValid = false;
				index--;
			}
		}
	}
}