package assignment3;

/**
 * Timing mechanisms for add and binarySearch method from MySortedSet class.
 * 
 * @author Kenny Ho & Michelle Nguyen
 */
public class AddTiming
{

	public static void main (String[] args)
	{
		long startTime, stopTime;

		long timesToLoop = 1000;

		MySortedSet<Integer> mySet = new MySortedSet<Integer>();
		mySet.add(1);
		mySet.add(2);
		mySet.add(3);
		mySet.add(4);
		mySet.add(5);
		mySet.add(6);
		mySet.add(7);
		mySet.add(8);
		mySet.add(9);
		mySet.add(10);

		for (int i = 0; i < 5; i++)
		{
			startTime = System.nanoTime();
			mySet.add(100);
			stopTime = System.nanoTime();
			double averageTime = (stopTime - startTime) / timesToLoop;
			System.out
					.println("It takes exactly "
							+ averageTime
							+ " nanoseconds to compute the running times for the contain method.");
			mySet.remove(100);
		}
	}
}
