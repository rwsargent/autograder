package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SortedSetTest {

	private MySortedSet set1, set2, set3;
	private ArrayList<Integer> temp1, temp2, temp3;
	
	@Before
	public void setUp() throws Exception {
		set1 = new MySortedSet();
		set2 = new MySortedSet();
		set3 = new MySortedSet();
		ArrayList<Integer> temp1 = new ArrayList<Integer>(Arrays.asList(1, 2));
		ArrayList<Integer> temp2 = new ArrayList<Integer>(Arrays.asList(3, -3));
		ArrayList<Integer> temp3 = new ArrayList<Integer>(Arrays.asList(2, 4, 11, -6, 8, 3, -30, 34, 35, 36, 9, 0, 1));
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFirst() {
		try{
			
		set1.first();
		fail("expected NoSuchElementException");
		}
		
		catch(NoSuchElementException e){
			// do nothing
		}
	}
	
	@Test
	public void testLast(){
		try{
			
			set1.last();
			fail("expected NoSuchElementException");
		}
		
		catch(NoSuchElementException e) {
			//empty
		}
	}
	
	@Test		//Checks the add function for 1 integer
	public void testAdd(){
		assertTrue(set2.add(4));
	}
	@Test		//Checks the add function for two integers
	public void testAdd2(){
		assertTrue(set2.add(7));
		assertTrue(set2.add(8));
	}
	@Test		//Checks the add function for 5 integers
	public void testAdd3(){
		set2.add(4);
		set2.add(-5);
		set2.add(6);		//These numbers can be changed in different orders or different values
		set2.add(12);
		set2.add(0);
		assertEquals(-5, (set2.toArray()[0]));	//This can be changed to test various orders of additions and their placement
		
	}
	@Test		//Verifies the lists' ability to grow
	public void testAdd4(){
		set2.add(0);
		set2.add(1);
		set2.add(2);
		set2.add(3);
		set2.add(4);
		set2.add(5);
		set2.add(6);
		set2.add(7);
		set2.add(8);
		set2.add(9);
		set2.add(10);
		assertEquals(10, (set2.toArray()[10]));
	}
	@Test // test the addAll method
	public void testAddAll1(){
		set1.addAll(temp1); // add an ArrayList
		assertEquals(3, set1.toArray()[2]);
	}
	@Test // test to make sure addAll will return false when list doesn't change
	public void testAddAll2(){
		set1.addAll(temp1); // add an ArrayList
		assertFalse(set1.addAll(temp1)); 
	}
	@Test 	//test the remove method
	public void testRemove1(){
		set2.add(1); //add some numbers
		set2.add(2);
		set2.add(9);
		assertTrue(set2.remove(2)); // check to see if remove returns true
	}
	@Test	 //tests removeAll method
	public void testRemoveAll(){
		set2.add(3);
		set2.add(2);
		set2.add(-3);
		assertTrue(set2.removeAll(temp2));
	}
	@Test	//tests clear and addAll methods
	public void testClear(){
		set3.addAll(temp3);
		set3.clear();
		assertNull(set3.toArray()[0]);
	}
	@Test	//Tests contains method for both a number in the set and a number not in the set
	public void testContains(){
		set3.addAll(temp3);
		assertTrue(set3.contains(3));
		assertFalse(set3.contains(50));
	}
	@Test	//Test containsAll method for both an all encompassing list and one that is not
	public void testContainsAll(){
		set3.addAll(temp3);
		assertTrue(set3.containsAll(temp3));
		assertFalse(set3.containsAll(temp2));
	}
	@Test	//Tests isEmpty function on both an populated array and an empty one
	public void testIsEmpty(){
		set3.add(3);
		set3.add(0);
		assertFalse(set3.isEmpty());
		assertTrue(set2.isEmpty());
	}
	@Test	//Tests iterator
	public void testIterator(){
		// ????????
	}
	
	
}


