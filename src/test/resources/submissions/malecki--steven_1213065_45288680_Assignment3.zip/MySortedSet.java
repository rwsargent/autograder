/**
 * This program does XXXXX
 * 
 * By Steven Malecki and Naoki Tominaga
 */
package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> {

	// variables to keep track of size and number of elements
	private int size, element;
	// the array that represents the sorted set
	private E[] mainArray;
	// comparator
	private Comparator<? super E> c;
	// boolean to keep track of whether the sorted sets implements comparable
	private boolean isComparable;
	
	/**
	 * The MySortedSet constructor
	 */
	public MySortedSet(){
		// set size equal to ten and number of elements to zero
		size = 10;
		element = 0;
		//create the main array
		mainArray = (E[])new Object[size];
		// if you are using this constructor set isComparable to true
		isComparable = true;
	}
	
	public MySortedSet(Comparator<? super E> compare){
		// same things as above but using a comparator instead
		size = 10;
		element = 0;
		mainArray = (E[])new Object[size];
		c = compare;
		isComparable = false;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator()
	{
		// if we are using comparable return null
		if(isComparable == true)
			return null;
	}
	/**
	 * Gives us the first element
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException{
		// throw exception if there are no elements in our set
		if (element == 0)
			throw new NoSuchElementException();
		// return the first element
		return mainArray[0];
	}
	/**
	 * Gives us the last element
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		// throw exception because if are no elements in our set
		if (element == 0)
			throw new NoSuchElementException();
		// return the last element in the array
		return mainArray[element - 1];
		
	}
	
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) {
		 int max = element;
		 int min = 0;			//Sets variables necessary for binary search
		 int pos = (max/2);
		 boolean notInList = true;		//Used to break out of while loop and check if element is already present
		 // we are using comparator
		 if(isComparable == false){
			 // if there is nothing in the sorted set place the object at the start
			 if(element == 0)
			 {
				 mainArray[pos] = o;
				 element++;
				 return true;
			 }
			 
			 while(true)
			 {
				 if(min == max)	//Breaks loop during the first few additions so there isn't an infinite loop
					 break;
				 // if the object is at the first position that we look at it was in the list
				 // so we should break out of this loop
				 else if(mainArray[pos] == o)
				 {
					 notInList = false;
					 break;
				 }
				 else if(c.compare(mainArray[pos], o) < 0)
				 {
					 // set min to pos and pos to ((max-min)/2) + min
					 min = pos;
					 pos = ((max-min)/2) + min;
				 }
				 else if(c.compare(mainArray[pos], o) > 0)
				 {
					 // set max to pos and pos to ((max-min)/2) + min
					 max = pos;
					 pos = ((max-min)/2) + min;
				 }
				 else
			 	{
					 // if none of the other if statements pass we know 
					 // the item is not in the list and we can get out of the loop
					 notInList = true;
					 break;
			 	}
			 }
		 }
		 // if we are using comparable rather than comparator
		 if(isComparable == true)
		 {
			 // if the object is at the first position that we look at it was in the list
			 // so we should break out of this loop
			 if(element == 0)
			 {
				 mainArray[pos] = o;
				 element++;
				 return true;
			 }
			 while(true)
			 {
				 if(min == max)	//Breaks loop during the first few additions so there isn't an infinite loop
					 break;
				 
				 else if(mainArray[pos] == o)	//Binary search checks if the input matches what is at the middle of the list
				 {
					 notInList = false;	// if the object is at the first position that we look at it was in the list
					 break;				// so we should break out of this loop
				 }
				 else if((((Comparable<E>)mainArray[pos]).compareTo(o)) < 0)	//If the input is greater than what's in the middle of the array...
				 {
					 min = pos;					//The middle of the array becomes the new minimum
					 pos = ((max-min)/2) + min;	//Formula calculates position of new middle point
				 }
				 else if(((Comparable<E>)mainArray[pos]).compareTo(o) > 0)	//If input is less than what's in the middle...
				 {
					 max = pos;						//The middle of the array becomes the new maximum
					 pos = ((max-min)/2) + min;		//Formula calculates position of new middle point
				 }
				 else
			 	{
					 notInList = true;		//If comparison is not '<' or '>', the new object is not in the list 
					 break;				//Breaks loop. Ready to add it to list
			 	}
			 }
		 }
		 if(size == element)	//Because we are adding an element, this would overfill the list
		 {
			size = size * 2;	//Double size to fit more elements
			E[] tempArray = (E[])new Object[size];	//make a new array
			for(int i = 0; i < element; i++)
				tempArray[i] = mainArray[i];		//For loop inputs the old array's values into the temp array
			mainArray = tempArray;					//Finished; sets the mainArray to match the temp one
		 }
		 
		 for(int i = element; i < pos; i--)					//For loop shifts data over one by one until all data is moved
			mainArray[i + 1] = mainArray[i];	//Shifts last element 1 over to the right
		 mainArray[pos] = o;								//Places the input into the proper place in the list
		 element++;											//Increments element for future addition
		 return notInList;									//Returns true
	}
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c)
	{
		int change = 0;								// A variable that keeps track if the list is changing
		for(int i = 0; i < c.size(); i++)			//For loop runs through all the items in c
		{
			boolean inArray = add((E)c.toArray()[i]);		//create boolean to see if a duplicate exists
			if(inArray == true)	// If the list changes increment change by positive 1
				change++;
		}
	if(change > 0)		// if the list change return true
		return true;
	else 				// Otherwise return false
		return false;
	}
	
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear()
	{
		// loop thru every element
		for(int i = 0; i < element; i++)
		{
			// set every element equal to null
			mainArray[i] = null;
		}
	}
	
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o)
	{
		 E temp = (E)o;				
		 int max = element - 1;
		 int min = 0;			//Sets variables necessary for binary search
		 int pos = max/2;
		 boolean InList;		//Used to break out of while loop and check if element is present
		 Comparator<E> c = null;//Sets up comparator
		 while(true)
		 {
			 
			 if(mainArray[pos] == temp) // if the object is in the position we are looking at it is in the list
			 {
				 InList = true;
				 break;
			 }
			 else if(c.compare(mainArray[pos], temp) < 0) //If the input is greater than what's in the middle of the array...
			 {
				 min = pos;								// set the middle equal to the min
				 pos = ((max-min)/2) + min;				// calculate new middle point
			 }
			 else if(c.compare(mainArray[pos], temp) > 0) // If the input is less than what's in the middle of the array...
			 {
				 max = pos;								// set the middle equal to the max
				 pos = ((max-min)/2) + min;				// calculate the new middle point
			 }
			 else										// if the object is not in the list break out
			 {
				 InList = false;
				 break;
			 }
		 }
		 return InList;									// return true or false based on if it's in the list or not
	}
	
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c)
	{
		for(int i = 0; i < c.size(); i++) // go thru every element of c
		{
			if(contains((E)c.toArray()[i]) == false) // check if c is contained within the list
				return false;
	}
		return true; // return true if you get to this point
	}
	
	/**
	 * This method checks if there are no elements 
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty()
	{
		// check if there are no elements
		if(element == 0)
			return true;
		// otherwise return false
		else
			return false;
	}
	
	/**
	 * This method gives us the number of elements in the array
	 * @return the number of elements in this set
	 */
	public int size()
	{
		// return the number of elements
		return element;
	}
	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator()
	{
		Iterator<E> placeholder;
		
		return placeholder;
	}
	/**
	private mainIterator<E> implements Iterator<E> {
		
		private int location;
		
		public iteratorLocation() {
			this.location = mainArray.this.start;
		}
		
		public boolean hasNext() {
			return ;
		}
		
		public E next() {
			return null;
		}
		
		public void remove() {
			
		}
	}
	**/
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o)
	{
		 E temp = (E)o;
		 int max = element - 1;
		 int min = 0;
		 int pos = max/2;			// creates variables necessary for binary search
		 boolean notInList;			// variable that tells us if o is not in the list
		 Comparator<E> c = null;	// declares the comparator
		 while(true)
		 {
			 
			 if(mainArray[pos] == temp) // if the object is at the position we are looking at break out of loop
			 {
				 notInList = false;
				 break;
			 }
			 else if(c.compare(mainArray[pos], temp) < 0) // object at position is less than object being compared to
			 {
				 min = pos;
				 pos = ((max-min)/2) + min;
			 }
			 else if(c.compare(mainArray[pos], temp) > 0) // object at position is more than object being compared to
			 {
				 max = pos;
				 pos = ((max-min)/2) + min;
			 }
			 else // if none of if statements are true object is not in list
			 {
				 notInList = true;
				 break;
			 }
		 }
		 mainArray[pos] = null; // object at specified position is null
		 for(int i = pos; i < element; i++)// move everything
		 {
			 mainArray[pos] = mainArray[pos + 1];
		 }
		 element--; // one less element
		 return notInList; // return true or false
	}
	
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c)
	{
		E[] newArray = (E[])new Object[c.size()]; 
		for(int i = 0; i < c.size(); i++)
		{
			boolean inArray = remove(newArray[i]);
			if(inArray == false)
				return false;
		}
		return true;
	}
	
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray()
	{
		// return the array we're using 
		return mainArray;
	}
	
}