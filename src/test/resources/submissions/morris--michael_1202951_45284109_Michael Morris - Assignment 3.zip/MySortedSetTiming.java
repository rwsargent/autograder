package assignment3;

/**
 * Simple timing test for measuring MySortedSet's performance.
 * Design of timing tests comes from Lab 1.
 * 
 * @author Michael Morris and Paulmartin Gentile
 *
 */
public class MySortedSetTiming {
	
	// Timing constants
	private static final long THREAD_STABILIZATION_TIME = 1000000000; // Nanoseconds, time for thread to stabilize
	private static final long TIMES_TO_LOOP = 100000; // Sample size of target method executions

	public static void main(String[] args) {
		// Timing positions
		long startTime, midTime, stopTime;
		
		// METHOD TO TEST SETUP GOES HERE
		
		// Allow thread to stabilize
		startTime = System.nanoTime();
		while ((System.nanoTime() - startTime) < THREAD_STABILIZATION_TIME) {
			// Do nothing
		}
		
		// Begin testing
		
		startTime = System.nanoTime();
		
		// METHOD TO TEST GOES HERE
		// Execute target method multiple times
		for (long i = 0; i < TIMES_TO_LOOP; i++) {
			
		}
		
		midTime = System.nanoTime();
		
		// ANY METHOD OVERHEAD GOES HERE
		// Run empty loop for control
		for (long i = 0; i < TIMES_TO_LOOP; i++) {
			
		}
		
		stopTime = System.nanoTime();
		
		// Compute running time and average of sample size
		double averageTime = ((midTime - startTime) - (stopTime - midTime)) / TIMES_TO_LOOP;
		
		// Display results
		System.out.println("Method executed in " + averageTime + " nanoseconds");
		System.out.println("Method executed in " + (averageTime / 1000000) + " milliseconds");
		System.out.println("Method executed in " + (averageTime / 1000000000) + " seconds");
		System.out.println("Sample size was " + TIMES_TO_LOOP);
		System.out.println("Total running time was " + ((stopTime - startTime) / 1000000000) + " seconds");
	}
}
