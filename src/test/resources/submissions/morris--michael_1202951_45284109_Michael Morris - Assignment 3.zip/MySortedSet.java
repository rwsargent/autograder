package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * An always-sorted list that does not contain duplicates. Provides all
 * of the usual operations, including the ability to add items, remove
 * items, search for items, and get items (in sorted order). Cannot
 * contain null elements.
 *   
 * @author Michael Morris and Paulmartin Gentile.
 *
 * @param <E> - The type of object the list holds.
 */
public class MySortedSet<E> implements SortedSet<E> {
	
	// Representation Invariant:
	// elements in data are of type E
	// elements in data cannot be null
	// comparator is null if using natural ordering of elements
	
	private Object[] data; // Array backing set
	private int size; // How many elements are contained in array
	private Comparator<? super E> comparator; // If provided, compares array elements
	
	private static final int INITIAL_SIZE = 10; // The size of initial array
	private static final double EXPANSION_FACTOR = 2.0; // The rate the array grows when full or shrinks when empty
	
	/**
	 * Creates an empty sorted set in which its elements will be ordered
	 * using their natural ordering.
	 * It is necessary that E implements Comparable<? super E>.
	 */
	public MySortedSet() {
		data = new Object[INITIAL_SIZE];
		size = 0;
		comparator = null;
	}
	
	/**
	 * Creates an empty sorted set in which its elements will be ordered
	 * using the provided comparator.
	 * 
	 * @param comparator - The comparator that will order the elements of the set
	 */
	public MySortedSet(Comparator<? super E> comparator) {
		data = new Object[INITIAL_SIZE];
		size = 0;
		this.comparator = comparator; 
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
    public Comparator<? super E> comparator() {
	    return comparator;
    }

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@SuppressWarnings("unchecked")
    @Override
    public E first() throws NoSuchElementException {
	    if (size == 0) {
	    	throw new NoSuchElementException("Set is empty");
	    }
	    return (E) data[0];
    }

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@SuppressWarnings("unchecked")
    @Override
    public E last() throws NoSuchElementException {
	    if (size == 0) {
	    	throw new NoSuchElementException("Set is empty");
	    }
	    return (E) data[size - 1];
    }

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
    @Override
    public boolean add(E o) {
		// Ensure o is not null
		if (o == null) {
			return false;
		}
		
		// Find where the element belongs in the array
		int targetIndex = search(o, true);
		// If element is already in array, do nothing
		if (targetIndex == -1) {
			return false;
		}
		
		// Make space for new element and add it appropriately
		shiftRight(targetIndex);
		if (data[targetIndex] == null) {
			data[targetIndex] = o;
		} else if ((comparator != null ? comparator.compare(o, (E) data[targetIndex]) : ((Comparable<E>) o).compareTo((E) data[targetIndex])) < 0) {
			data[targetIndex] = o;
		} else {
			data[targetIndex + 1] = o;
		}
		return true;
    }

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
    public boolean addAll(Collection<? extends E> c) {
		// Ensure Collection is not null
		if (c == null) {
			return false;
		}		
		
		boolean setChanged = false;
		for (E e : c) {
			if (add(e)) {
				setChanged = true;
			}
		}
		return setChanged;
    }

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
    public void clear() {
		data = new Object[INITIAL_SIZE];
		size = 0;
    }

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings("unchecked")
    @Override
    public boolean contains(Object o) {
	    try {
	    	return (search((E) o, false) != -1);
	    } 
	    // o is not of type E or is null
	    catch (ClassCastException | NullPointerException e) {
	    	return false;
	    }
    }

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
    public boolean containsAll(Collection<?> c) {
		// Ensure Collection is not null
		if (c == null) {
			return false;
		}		
		
	    for (Object o : c) {
	    	if (!contains(o)) {
	    		return false;
	    	}
	    }
	    return true;
    }

	/**
	 * @return true if this set contains no elements
	 */
	@Override
    public boolean isEmpty() {
	    return (size == 0);
    }

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
    public Iterator<E> iterator() {
	    return new MySortedSetIterator();
    }

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@SuppressWarnings("unchecked")
    @Override
    public boolean remove(Object o) {
		// Attempt to remove object, doing nothing if not present
		try {
			int targetIndex = search((E) o, false);
			data[targetIndex] = null;
			size--;
			clean(targetIndex);
			return true;
		} catch (ClassCastException | IndexOutOfBoundsException e) {
			return false;
		}
    }

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
    public boolean removeAll(Collection<?> c) {
		// Ensure Collection is not null
		if (c == null) {
			return false;
		}
		// Note: cleaning must occur after every removal to ensure non-null comparisons
		// during searching
		boolean setChanged = false;
		for (Object o : c) {
			if (remove(o)) {
				setChanged = true;
			}
		}
		return setChanged;
    }

	/**
	 * @return the number of elements in this set
	 */
	@Override
    public int size() {
	    return size;
    }

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
    public Object[] toArray() {
	    return Arrays.copyOf(data, size);
    }
	
	/**
	 * Iterates over the elements in MySortedSet in low to high order.
	 * 
	 * @author Michael Morris and Paulmartin Gentile.
	 *
	 * @param <E> - The type of object the list holds. 
	 */
	private class MySortedSetIterator implements Iterator<E> {
		
		private int nextIndex; // The next location for the iterator in the MySortedSet array
		private Object[] dataCopy;
		private int sizeCopy;
		
		/**
		 * Constructs a new iterator at the lowest element in MySortedSet.
		 */
		public MySortedSetIterator() {
			nextIndex = 0;
			sizeCopy = size;
			dataCopy = Arrays.copyOf(data, size);
		}

		/**
		 * Returns true if there is another element in the iteration.
		 */
		@Override
        public boolean hasNext() {
	        return (nextIndex < sizeCopy);
        }

		/**
		 * Returns the next element in the iteration.
		 */
		@SuppressWarnings("unchecked")
        @Override
        public E next() {
			// Return what the iterator is looking at next and then advance that index
	        return (E) dataCopy[nextIndex++];
        }
		
	}
	
	/**
	 * Searches through array backing MySortedSet for the provided element. If the element is present,
	 * returns its array index. Otherwise, returns -1. If insertMode is true, the
	 * search looks for the index of where the element belongs. If the element is
	 * already present in this mode, returns -1. 
	 * @param element - The element to be looked for in array.
	 * @param insertMode - Whether the search should look for the element or where the element belongs.
	 * @return - The array index of the target element, or -1 if it is absent (or is already present in insertMode).
	 */
    @SuppressWarnings("unchecked")
    private int search(E element, boolean insertMode) {
		// Current implementation uses binary search
		int startI = 0;
		int midI = size / 2;
		int endI = size - 1;
		int compValue;
		
		// Do search loop and return match if found
		while (startI <= endI) {
			compValue = (comparator != null ? comparator.compare(element, (E) data[midI]) : ((Comparable<E>) element).compareTo( (E) data[midI]));
			if (compValue < 0) {
				endI = midI - 1;
				if (startI <= endI) {
					midI = endI / 2;
				}
			} else if (compValue > 0) {
				startI = midI + 1;
				if (startI <= endI) {
					midI = ((endI - startI) / 2) + startI;
				}
			} else {
				return (insertMode ? -1 : midI); // The element was found in the array
			}
		}
		
		return (insertMode ? midI : -1); // No match was found, but where it belongs was found
	}
    
    /**
     * Moves all the elements in the array backing MySortedSet one index to the right, resizing
     * the array if necessary. The move starts at the index parameter. The element at the shift
     * index is duplicated, so that the elements at data[index] and data[index + 1] are the same.
     * @param index - Index in array where the shift should occur.
     */
    private void shiftRight(int index) {
    	// Determine if array needs to be enlarged or can be shrunk
    	resize();
    	
    	// Move elements, moving backward from end of array
    	for (int i = size; i > index ; i--) {
    		data[i] = data[i - 1];
    	}
    	
    	size++; // Update size
    }
    
    /**
     * If the array backing MySortedSet is full, enlarges it by a constant factor.
     * If the array is mostly empty, shrinks it by the same factor.
     */
    private void resize() {
    	// Enlarge array if full
    	if (size == data.length) {
    		data = Arrays.copyOf(data, (int) (data.length * EXPANSION_FACTOR));
    	}
    	// Shrink array if mostly empty
    	else if (size <= (int) (data.length / (2 * EXPANSION_FACTOR)) && size > INITIAL_SIZE) {
    		data = Arrays.copyOf(data, (int) (data.length / EXPANSION_FACTOR));
    	}
    }
    
    /**
     * Removes all null elements in the data-containing section of the array backing
     * MySortedSet. The cleaning sweep begins at the given index and moves right. It is
     * necessary that there be no null elements preceding the specified index in the array and that the
     * number of elements in the array (size) be accurate before this method call.
     * @param index - The array index position where cleaning starts, inclusive. 
     */
    private void clean(int index) {
    	// Move elements and trim out nulls
    	int count = size - index; // Number of elements to be moved
    	int dirtyIndex = index; // Array position for finding non-nulls
    	int cleanIndex = index; // Array position of non-null elements
    	while (count > 0) {
    		if (data[dirtyIndex] != null) {
    			data[cleanIndex] = data[dirtyIndex];
    			cleanIndex++;
    			count--;
    		}
    		dirtyIndex++;
    	}
    	
    	resize(); // Adjust array size if necessary
    }

}
