package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

import org.junit.Test;

/**
 * Ensures MySortedSet performs as specified.
 * 
 * @author Michael Morris and Paulmartin Gentile.
 *
 */
public class MySortedSetTest {
	
	private MySortedSet<String> testSet1;
	private MySortedSet<String> testSet2;
	private MySortedSet<Integer> testSet3;

	@Test
	public void testComparator() {
		testSet1 = new MySortedSet<String>();
		testSet1.add("A");
		testSet1.add("B");
		assertTrue(testSet1.comparator() == null);
		
		testSet2 = new MySortedSet<String>(String.CASE_INSENSITIVE_ORDER);
		testSet2.add("A");
		testSet2.add("B");
		assertEquals(testSet2.comparator(), String.CASE_INSENSITIVE_ORDER);
		assertFalse(testSet2.add("A"));
		assertFalse(testSet2.add("a"));
	}

	@Test
	public void testFirst() {
		// Empty Set
		testSet1 = new MySortedSet<String>();
		try {
			testSet1.first();
			fail();
		} catch (NoSuchElementException e) {
		}
		
		// Non-empty Set
		testSet2 = new MySortedSet<String>();
		testSet2.add("Z");
		testSet2.add("H");
		testSet2.add("Y");
		testSet2.add("B");
		testSet2.add("D");
		assertEquals("B", testSet2.first());
	}

	@Test
	public void testLast() {
		// Empty Set
		testSet1 = new MySortedSet<String>();
		try {
			testSet1.last();
			fail();
		} catch (NoSuchElementException e) {
		}
		
		// Non-empty Set
		testSet2 = new MySortedSet<String>();
		testSet2.add("H");
		testSet2.add("Z");
		testSet2.add("Y");
		testSet2.add("B");
		testSet2.add("D");
		assertEquals("Z", testSet2.last());
	}

	@Test
	public void testAdd() {
		testSet1 = new MySortedSet<String>();
		assertFalse(testSet1.add(null)); // Try adding null
		assertTrue(testSet1.add("A"));
		assertFalse(testSet1.add("A")); // Try adding duplicate
		assertEquals(1, testSet1.size());
		assertTrue(testSet1.add("B"));
		assertFalse(testSet1.add("B")); // Try adding duplicate
		assertEquals(2, testSet1.size());
		
		// Add a large amount of elements to a MySortedSet
		// Tests resizing methods
		Random random = new Random();
		testSet3 = new MySortedSet<Integer>();
		int count = 0;
		while (count < 10000) {
			if (testSet3.add(new Integer(random.nextInt()))) {
				count++;
			}
		}
		// Ensure MySortedSet is properly sorted and contains no nulls
		Iterator<Integer> iterator = testSet3.iterator();
		Integer previousElement = iterator.next();
		Integer currentElement = iterator.next();
		while (iterator.hasNext()) {
			if (previousElement == null || currentElement == null || previousElement.compareTo(currentElement) >= 0) {
				fail();
			}
			previousElement = currentElement;
			currentElement = iterator.next();
		}
	}

	@Test
	public void testAddAll() {
		testSet1 = new MySortedSet<String>();
		// Create new Collection
		ArrayList<String> list = new ArrayList<String>();
		list.add("A");
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("C");
		list.add("Z");
		list.add("D");
		list.add(null);
		// Add Collection to MySortedSet
		assertTrue(testSet1.addAll(list));
		assertEquals(5, testSet1.size());
		assertFalse(testSet1.addAll(list));
		
		testSet2 = new MySortedSet<String>();
		// Create new Collection
		list = new ArrayList<String>();
		list.add(null);
		list.add(null);
		list.add(null);
		// Add Collection to MySortedSet
		assertFalse(testSet2.addAll(list));
		assertEquals(0, testSet2.size());
		
		assertFalse(testSet2.addAll(null));
	}

	@Test
	public void testClear() {
		testSet1 = new MySortedSet<String>();
		testSet1.add("A");
		testSet1.add("B");
		testSet1.add("C");
		testSet1.add("D");
		assertEquals(4, testSet1.size());
		// Clear MySortedSet and ensure elements are gone
		testSet1.clear();
		assertEquals(0, testSet1.size());
		for (Iterator<String> i = testSet1.iterator(); i.hasNext();) {
			fail();
		}
		
		testSet2 = new MySortedSet<String>();
		testSet2.clear();
		assertEquals(0, testSet2.size());
		for (Iterator<String> i = testSet2.iterator(); i.hasNext();) {
			fail();
		}
	}

	@Test
	public void testContains() {
		testSet1 = new MySortedSet<String>();
		testSet1.add("A");
		testSet1.add("B");
		testSet1.add("C");
		testSet1.add("D");
		testSet1.add("E");
		testSet1.add("F");
		testSet1.add(null);
		// Look for objects not in set
		assertFalse(testSet1.contains(null));
		assertFalse(testSet1.contains(new ArrayList<String>()));
		assertFalse(testSet1.contains(new Object()));
		assertFalse(testSet1.contains("Z"));
		assertFalse(testSet1.contains("a"));
		// Look for objects in set
		assertTrue(testSet1.contains("A"));
		assertTrue(testSet1.contains("D"));
	}

	@Test
	public void testContainsAll() {
		testSet1 = new MySortedSet<String>();
		// Create Collection
		ArrayList<String> list = new ArrayList<String>();
		list.add("A");
		list.add("B");
		list.add("C");
		assertFalse(testSet1.containsAll(list));
		testSet1.add("B");
		testSet1.add("C");
		testSet1.add("A");
		assertTrue(testSet1.containsAll(list));
		list.add(null);
		assertFalse(testSet1.containsAll(list));
		
		testSet2 = new MySortedSet<String>();
		ArrayList<Object> list2 = new ArrayList<Object>();
		list2.add(new Scanner("TEST SCANNER"));
		list2.add(null);
		list2.add(new MySortedSet<String>());
		assertFalse(testSet2.containsAll(list2));
		
		assertFalse(testSet2.containsAll(null));
	}

	@Test
	public void testIsEmpty() {
		testSet1 = new MySortedSet<String>();
		assertTrue(testSet1.isEmpty());
		for (Iterator<String> i = testSet1.iterator(); i.hasNext();) {
			fail();
		}
		testSet1.add("A");
		assertFalse(testSet1.isEmpty());
		testSet1.add("B");
		testSet1.add("C");
		testSet1.add("D");
		assertFalse(testSet1.isEmpty());
		testSet1.clear();
		assertTrue(testSet1.isEmpty());
		for (Iterator<String> i = testSet1.iterator(); i.hasNext();) {
			fail();
		}
		
		testSet2 = new MySortedSet<String>();
		assertTrue(testSet2.isEmpty());
		testSet2.add(null);
		testSet2.add(null);
		assertTrue(testSet2.isEmpty());
		for (Iterator<String> i = testSet1.iterator(); i.hasNext();) {
			fail();
		}
	}

	@Test
	public void testIterator() {
		testSet1 = new MySortedSet<String>();
		testSet1.add("C");
		testSet1.add("B");
		testSet1.add("A");
		testSet1.add("E");
		testSet1.add("D");
		testSet1.add("G");
		testSet1.add("F");
		// Iterate over and concatenate elements
		String combinedElements = "";
		for (Iterator<String> i = testSet1.iterator(); i.hasNext();) {
			combinedElements += i.next();
		}
		assertEquals("ABCDEFG", combinedElements);
	}

	@Test
	public void testRemove() {
		testSet1 = new MySortedSet<String>();
		assertFalse(testSet1.remove(null));
		testSet1.add("A");
		testSet1.add("B");
		testSet1.add("C");
		assertEquals(3, testSet1.size());
		assertFalse(testSet1.remove("a"));
		assertTrue(testSet1.remove("B"));
		assertEquals(2, testSet1.size());
		assertFalse(testSet1.remove("B"));
	}

	@Test
	public void testRemoveAll() {
		testSet1 = new MySortedSet<String>();
		// Create new Collection
		ArrayList<String> list = new ArrayList<String>();
		list.add("A");
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("C");
		list.add("Z");
		list.add("D");
		list.add(null);
		// Try to remove Collection from MySortedSet
		assertFalse(testSet1.removeAll(list));
		// Add and then remove Collection
		assertTrue(testSet1.addAll(list));
		assertTrue(testSet1.removeAll(list));
		assertFalse(testSet1.removeAll(list));
		
		testSet2 = new MySortedSet<String>();
		// Create new Collection
		list = new ArrayList<String>();
		list.add(null);
		list.add(null);
		list.add(null);
		// Try to remove Collection from MySortedSet
		assertFalse(testSet2.removeAll(list));
		
		assertFalse(testSet2.removeAll(null));
	}

	@Test
	public void testSize() {
		testSet1 = new MySortedSet<String>();
		assertEquals(0, testSet1.size());
		testSet1.add(null);
		assertEquals(0, testSet1.size());
		testSet1.add("A");
		assertEquals(1, testSet1.size());
		testSet1.add("A");
		assertEquals(1, testSet1.size());
	}

	@Test
	public void testToArray() {
		testSet1 = new MySortedSet<String>();
		assertEquals(0, testSet1.toArray().length);
		testSet1.add("B");
		testSet1.add("C");
		testSet1.add("A");
		testSet1.add("E");
		testSet1.add("D");
		testSet1.add("G");
		testSet1.add("F");
		Object[] array1 = testSet1.toArray();
		assertEquals(7, array1.length);
		assertEquals("A", (String) array1[0]);
		assertEquals("B", (String) array1[1]);
		assertEquals("C", (String) array1[2]);
		assertEquals("D", (String) array1[3]);
		assertEquals("E", (String) array1[4]);
		assertEquals("F", (String) array1[5]);
		assertEquals("G", (String) array1[6]);
	}

}
