package assignment3;

import java.util.Random;

/**
 * 
 * this is a time test for add method
 * 
 * @author bo zhu and andy ford
 *
 */
public class TimeTest2 {

	

	public static void main(String[] args) {
	    
		MySortedSet<Double> set1 = new MySortedSet<Double>();
		Random rmd = new Random();
		
			
		long startTime, midpointTime, stopTime;
        for(int i = 100000; i <= 2000000; i += 100000){
        	for(int j = 0; j < 100000; j++)
        		set1.add((double)(i + j - 100000));
        	// First, spin computing stuff until one second has gone by.
            // This allows this thread to stabilize.

    		startTime = System.nanoTime();
        
    		while (System.nanoTime() - startTime < 1000000000) { // empty block
        
    		}

        // Now, run the test.

        
    		long timesToLoop = 100000;

            
    		startTime = System.nanoTime();

        
    		for (long j = 0; j < timesToLoop; j++){
    			double ran = rmd.nextInt(i) + 0.5;
                set1.add(ran);
                set1.remove(ran);
    		}

        
    		midpointTime = System.nanoTime();

        // Run an empty loop to capture the cost of running the loop.

       
    		for (long k = 0; k < timesToLoop; k++) { // empty block
    			int ran = rmd.nextInt(i);
    			set1.remove(1.0);
    		}

    		stopTime = System.nanoTime();

        // Compute the time, subtract the cost of running the loop
        // from the cost of running the loop and computing square roots.
        // Average it over the number of runs.

        
    		double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
            
    				/ timesToLoop;

        	
        	System.out.println(  i + "\t" + averageTime);
        	
        }
        
        
   
  }
}
