package assignment3;

import java.util.Comparator;

public class MySortedSetComparator<E> implements Comparator {
    

	@Override
	/**
	 * this is a comparator of inverse natural ordering
	 */
	public int compare(Object o1, Object o2) {

		if(((String)o1).compareTo((String)o2) > 0)
		    return -1;
		else if(((String)o1).compareTo((String)o2) < 0)
			return 1;
		else 
			return 0;
		
	}
}

