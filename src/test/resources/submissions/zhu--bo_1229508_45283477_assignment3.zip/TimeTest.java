package assignment3;

import java.util.Random;

/**
 * this is a time test for contains method
 * 
 * @author bo zhu and andy ford
 *
 */
public class TimeTest {

	

	public static void main(String[] args) {
	    
		MySortedSet<Integer> set1 = new MySortedSet<Integer>();
		Random rmd = new Random();
		
			
		long startTime, midpointTime, stopTime;
        for(int i = 100000; i <= 2000000; i += 100000){
        	for(int j = 0; j < 100000; j++)
        		set1.add(j+i-100000);
        	
        	// First, spin computing stuff until one second has gone by.
            // This allows this thread to stabilize.

    		startTime = System.nanoTime();
        
    		while (System.nanoTime() - startTime < 1000000000) { // empty block
        
    		}

        // Now, run the test.

        
    		long timesToLoop = 1000000;

            
    		startTime = System.nanoTime();

        
    		for (long j = 0; j < timesToLoop; j++)
                set1.contains(rmd.nextInt(i));

        
    		midpointTime = System.nanoTime();

        // Run an empty loop to capture the cost of running the loop.

       
    		for (long k = 0; k < timesToLoop; k++) { // empty block
        
    		}

    		stopTime = System.nanoTime();

        // Compute the time, subtract the cost of running the loop
        // from the cost of running the loop and computing square roots.
        // Average it over the number of runs.

        
    		double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
            
    				/ timesToLoop;

        	
        	System.out.println(  i + "\t" + averageTime);
        	
        }
        
        
   
  }
}
