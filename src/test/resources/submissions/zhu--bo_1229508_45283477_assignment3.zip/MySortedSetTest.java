package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * This is the test class for MySortedSet
 * @author bo zhu and andy ford
 *
 */
public class MySortedSetTest {
	private MySortedSet<String> set1, set2, set3, set4;

	@Before
	public void setUp() throws Exception {
		set1 = new MySortedSet<String>();
		
		set2 = new MySortedSet<String>();
		set2.add("test string 1");
		set2.add("test string 2");
		set2.add("test string 3");
		set2.add("test string 4");
		set2.add("test string 5");
		set2.add("test string 6");
		set2.add("test string 7");
		
		set3 = new MySortedSet<String>();
		set3.add("abc");
		set3.add("bcd");
		set3.add("hij");
		set3.add("cde");
		set3.add("def");
		set3.add("efg");
		set3.add("fgh");
		set3.add("ghi");
		
		MySortedSetComparator<String> comparator = new MySortedSetComparator<String>(); 
		set4 = new MySortedSet<>(comparator);
		set4.add("01");
		set4.add("02");
		set4.add("03");
		set4.add("04");
		set4.add("05");
		set4.add("06");
		set4.add("07");
		set4.add("08");
		set4.add("09");
		set4.add("10");
		set4.add("11");
		set4.add("12");
		set4.add("13");
		set4.add("14");
		set4.add("15");
		
	}

	@After
	public void tearDown() throws Exception {
		set1 = null;
		set2 = null;
		set3 = null;
		set4 = null;
	}
	
	// Test add method:
	@Test
	public void addTest1() {
		assertTrue(set1.add("abc"));
	}
	
	@Test
	public void addTest2() {
		assertFalse(set2.add("test string 1"));
	}
	
	@Test
	public void addTest3() {
		assertFalse(set3.add("abc"));
	}
	
	@Test
	public void addTest4() {
		assertTrue(set3.add("xyz"));
	}
	
	@Test
	public void addTest5() {
		assertFalse(set1.add(null));
	}
	
	// Test size method:
	@Test
	public void sizeTest1() {
		assertEquals(0, set1.size());
	}
	
	@Test
	public void sizeTest2() {
		assertEquals(7, set2.size());
	}
	
	@Test
	public void sizeTest3() {
		assertEquals(15, set4.size());
	}
	
	@Test
	public void sizeTest4() {
		set3.add("xyz");
		assertEquals(9, set3.size());
	}
	
	// Test contains method:
	@Test
	public void containsTest1() {
		assertFalse(set1.contains("def"));
	}
	
	@Test
	public void containsTest2() {
		assertTrue(set2.contains("test string 1"));
	}
	
	@Test
	public void containsTest3() {
		assertTrue(set3.contains("hij"));
	}
	
	@Test 
	public void containsAll() {
		List<String> list = new ArrayList<String>();
		list.add(0, "06");
		list.add(1, "05");
		list.add(2, "04");
		list.add(3, "03");
		list.add(4, "02");
		list.add(5, "01");

		assertTrue(set4.containsAll(list));
	}
			
	// Test isEmpty method:
	@Test
	public void isEmptyTest1() {
		assertTrue(set1.isEmpty());
	}
	
	@Test
	public void isEmptyTest2() {
		assertFalse(set3.isEmpty());
	}
	
	// Test remove method:
	@Test
	public void removeTest1() {
		assertTrue(set3.remove("abc"));
	}
	
	@Test
	public void removeTest2() {
		assertFalse(set3.remove("blah"));
	}
	
	//Test first method:
	@Test
	public void firstTest1(){
		assertEquals("15", set4.first());
	}
	
	//Test if no element in the set for first method
	@Test
	public void firstTest2NoSuchElementException(){
		 try {
		        set1.first();
		        assert false;
		    } catch (NoSuchElementException e) {
		        assert true;
		    }
	}
	
	//Test last method:
	@Test
	public void lastTest1() {
		assertEquals("test string 7", set2.last());
	}
	
	//Test if no element in the set for last mehtod
	@Test
	public void lastTest2NoSuchElementException() {
		try {
	        set1.last();
	        assert false;
	    } catch (NoSuchElementException e) {
	        assert true;
	    }
	}
	
	//Test addall method
	@Test
	public void addallTest1(){
		List<String> list = new ArrayList<String>();
		list.add(0, "07");
		list.add(1, "06");
		list.add(2, "05");
		list.add(3, "04");
		list.add(4, "03");
		list.add(5, "02");
		list.add(6, "01");
		
		assertFalse(set4.addAll(list));
	}
	
	@Test
	public void addallTest2(){
		List<String> list = new ArrayList<String>();
		list.add(0, "21");
		assertTrue(set4.addAll(list));
	}
	
	//Test removeAll method
	@Test 
	public void removeAllTest1() {
		List<String> list = new ArrayList<String>();
		list.add(0, "01");
		list.add(1, "02");
		list.add(2, "03");
		list.add(3, "04");
		list.add(4, "05");
		list.add(5, "06");
		assertTrue(set4.removeAll(list));
	}
	
	@Test
	public void removeAllTest2() {
		List<String> list = new ArrayList<String>();
		list.add(0, "21");
		list.add(1, "22");
		list.add(2, "23");
		list.add(3, "24");
		list.add(4, "25");
		list.add(5, "26");
		assertFalse(set4.removeAll(list));
	}
	
	//Test toArray method
	@Test
	public void toArrayTest(){
		Object[] arr = set4.toArray();
		assertEquals(16,arr.length);
	}
	
	@Test
	public void toArrayTest1() {
		Object[] arr = set1.toArray();
		assertEquals(0,arr.length);
	}
	//Test clear method
	@Test
	public void clearTest() {
		set2.clear();
	    assertEquals(0, set2.size());
	}
	
}
