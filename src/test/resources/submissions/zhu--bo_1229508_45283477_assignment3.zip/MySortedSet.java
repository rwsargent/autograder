package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
/**
 * this is the class of my sorted set implements the sorted set.
 * 
 * @author bo zhu and andy ford
 *
 * @param <E>  the generic type of object
 */
public class MySortedSet<E> implements SortedSet<E> {

	// this is the array of E type elements to store the elements 
	private E[] arr;
	
	//size is the number of the elements in the set
	private int size = 0; 
	
	//This is the comparator use the ordering designed by my own
	private MySortedSetComparator comparator;
	
	//this boolean var will return true this set is using natural ordering
	//false means this set will use a artificial ordering.
	private boolean isComparable = true;
	
	//this int var is to record the index of the object tested contained in the set
    private int Index = 0;
    /**
     * This is the first constructor of this class 
     * and it will use natural ordering
     * 
     */
	public MySortedSet(){
		Object[] arr1 = new Object[8];
		arr = (E[])arr1;
	}
	
	/**
     * This is the second constructor of this class 
     * but it will use the ordering designed by mine own.
     * 
     */
	public MySortedSet(Comparator<? super E> c) {
		Object[] arr1 = new Object[8];
		arr = (E[])arr1;
		comparator = (MySortedSetComparator) c;
		isComparable = false;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException {
		if(size == 0)
			throw new NoSuchElementException();
		return arr[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if(size == 0)
			throw new NoSuchElementException();
		return arr[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) {
		if(o == null)
			return false;
		
		int maxIndex = 0;
        int minIndex = 0;
    	if(isComparable && !this.isEmpty()){
    		maxIndex = size - 1;
            minIndex = 0;
            
            if(((Comparable<E>)o).compareTo(first()) < 0)
            	maxIndex = 0;
            else if(((Comparable<E>)o).compareTo(first()) == 0)
            	return false;
            else if(((Comparable<E>)o).compareTo(last()) == 0)
            	return false;
            else if (((Comparable<E>)o).compareTo(last()) > 0)
        	    maxIndex = size;
            
            //Here we using a binary search to get the index to insert the element 
        	while(minIndex != maxIndex - 1 && minIndex != maxIndex){
            	if (((Comparable<E>)o).compareTo(arr[(maxIndex + minIndex)/2]) < 0)
            		maxIndex = (maxIndex + minIndex)/2;
            	else if(((Comparable<E>)o).compareTo(arr[(maxIndex + minIndex)/2]) == 0)
            		return false;
            	else
            		minIndex = (maxIndex + minIndex)/2;
            }
    	}
    	//here we using a comparator to find the index to insert
    	else if(!isComparable && !this.isEmpty()){
    		maxIndex = size - 1;
            minIndex = 0;
            
            if(comparator.compare(o, first()) < 0)
            	maxIndex = 0;
            else if(comparator.compare(o, first()) == 0)
            	return false;
            else if(comparator.compare(o, last()) == 0)
            	return false;
            else if (comparator.compare(o, last()) < 0)
        	    maxIndex = size;
        		
        	while(minIndex != maxIndex - 1 && minIndex != maxIndex){
            	if (comparator.compare(o, arr[(maxIndex + minIndex)/2]) < 0)
            		maxIndex = (maxIndex + minIndex)/2;
            	else if(comparator.compare(o, arr[(maxIndex + minIndex)/2]) == 0)
            		return false;
            	else
            		minIndex = (maxIndex + minIndex)/2;
            }
    	}
    	Object[] temp;
	    if(size == arr.length){
		    temp = new Object[size*2];
		    for(int i = 0;i < size; i ++)
		        temp[i] = arr[i];
		    arr = (E[])temp;
	    }
    	size ++;
    	
    	for(int i = size - 2; i >= maxIndex; i --){
    		arr[i+1] = arr[i];
    	}
    	arr[maxIndex] = o;
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
        boolean added = false;
		for(E e : c){
			boolean a = add(e);
			if(a)
				added = true;
		}
		return added;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) {
        if(isEmpty())
        	return false;
		if(o == null)
			return false;
        int currentIndex = size/2;
        int maxIndex = size - 1;
        int minIndex = 0;
        if(isComparable){
        	
        	//here we using a binary search to check if this set contains that object
        	if(((Comparable<E>)o).compareTo(first()) == 0){
        		Index = currentIndex;
    		    return true;
        	}
        	if(((Comparable<E>)o).compareTo(last()) == 0){
        		Index = currentIndex;
    		    return true;
        	}
        	while(minIndex != maxIndex && minIndex != maxIndex - 1){
            	if(((Comparable<E>)o).compareTo(arr[currentIndex]) == 0){
            		Index = currentIndex;
            		return true;
            	}
            	if (((Comparable<E>)o).compareTo(arr[currentIndex]) < 0){
            		maxIndex = currentIndex;
            	    currentIndex = (maxIndex + minIndex)/2;
            	}
            	else {
            		minIndex = currentIndex;
            	    currentIndex = (maxIndex + minIndex)/2;
            	}
        	}
        }
        //this is for when we using a comparator to search if the object is in the set
        else{
        	if(comparator.compare(o, first()) == 0){
        		Index = currentIndex;
    		    return true;
        	}
        	if(comparator.compare(o, last()) == 0){
        		Index = currentIndex;
    		    return true;
        	}
        	while( minIndex != maxIndex && minIndex != maxIndex - 1 ){
            	if(comparator.compare(o, arr[currentIndex]) == 0){
            	    Index = currentIndex;
            		return true;
            	}
            	if (comparator.compare(o, arr[currentIndex]) < 0){
            		maxIndex = currentIndex;
        	        currentIndex = (maxIndex + minIndex)/2;
            	}
            	else{
            		minIndex = currentIndex;
            	    currentIndex = (maxIndex + minIndex)/2;
            	}
        	}
        }

		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c) {
		for(Object o : c){
			if(!contains(o))
				return false;
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		MySortedSetIterator<E> itr = new MySortedSetIterator(this); 
		return itr;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
	    if(this.contains(o)){
	        for(int i = Index; i < size - 1; i++){
	        	arr[i] = arr[i + 1];
	        }
	    	size --;
	    	return true;
	    }
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		boolean removed = false;
		for(Object o : c)
			if(remove(o))
				removed = true;
		return removed;
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		if(size == 0)
			return new Object[0];
		return arr;
	}



}
