package assignment3;

import java.util.Iterator;
/**
 * this is a iterator for a MySortedSet
 * 
 * @author bo zhu and andy ford
 *
 * @param <E>
 */
public class MySortedSetIterator<E> implements Iterator<E> {
	private int currentIndex = 0;
	private MySortedSet<E> set;
	
	/**
	 * this is the constructor of a MySortedSetIterator 
	 * @param _set
	 */
	public MySortedSetIterator(MySortedSet<E> _set){
		set = _set;
	}

    /**
     * @return true if the set has next, false otherwise
     */
    public boolean hasNext() {
        return currentIndex < set.size() && set.toArray()[currentIndex] != null;
    }

    /**
     * @return the element at next index
     */
    public E next() {
        return (E)set.toArray()[currentIndex++];
    }

    /**
     * remove the element where the iterator is
     */
    public void remove() {
        for(int i = currentIndex; i < set.size(); i ++)
        	set.toArray()[i] = set.toArray()[i+1];
    }
}

