package assignment3;

import java.util.Comparator;

/**
 * Builds an example comparator for testing MySortedSet
 * 
 * @author Kayden Thomson
 * @author Leonardo Roese
 *
 */
public class MyComparator implements Comparator<String> {

	/**
	 * Compares the length of 2 strings
	 * @return -1 if o1 length is less than o2 length
	 * @return 1 if o1 length is greater than o2 length
	 * @return 0 if o1 length is equal to o2 length
	 */
	@Override
	public int compare(String o1, String o2) {
		if (o1.length() < o2.length()) //compares length of object 1 and object 2
			return -1;  //o1 length less than o2
		else if (o1.length() > o2.length())
			return 1; //o1 length greater than o2
		else
			return 0; //same length
	}

}
