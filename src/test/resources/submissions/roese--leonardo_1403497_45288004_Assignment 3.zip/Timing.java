package assignment3;

import java.util.Random;

/**
 * Timer used for analysis document, we used it to time the add and remove
 * method in MySortedSet
 * 
 * @author Kayden Thomson
 * @author Leonardo Roese
 *
 */
public class Timing {
	public static void main(String[] args) {
		long stabalize;

		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		stabalize = System.nanoTime();
		while (System.nanoTime() - stabalize < 1000000000) { // empty block
		}
		MySortedSet<Integer> time = new MySortedSet<>();
		for (int i = 0; i < 1000000; i++) {
			time.add(i);
		}

		time.remove(200000);

		long startTime = System.nanoTime();

		time.add(200000);

		long stopTime = System.nanoTime();

		System.out.println((stopTime - startTime));
	}

}