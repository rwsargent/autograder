package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;

import org.junit.Before;
import org.junit.Test;

/**
 * Tests for MySortedSet Class
 * 
 * @author Kayden Thomson
 * @author Leonardo Roese
 *
 */
public class MySortedSetTest {

	private MySortedSet<String> list1; //string test list
	private MySortedSet<Integer> list2; //integer test list
	private ArrayList<String> arrayList1; //collection string test 
	private ArrayList<Integer> arrayList2; //collection integer test

	/**
	 * Sets up 2 MySortedSet lists and 1 arrayList
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		list1 = new MySortedSet<>(); //creates test SortedSet

		list1.add("this "); //adds known strings to list1
		list1.add("is ");
		list1.add("a ");
		list1.add("test ");

		list2 = new MySortedSet<>(); //creates 2nd test sorted set

		list2.add(5); //adds known integers to list 2
		list2.add(3);
		list2.add(6);
		list2.add(4);
		list2.remove(4); //removes known integer from list 2

		arrayList1 = new ArrayList<>(); //creates test collection of strings
		arrayList1.add("this ");//adds known strings to test collection
		arrayList1.add("is ");
		arrayList1.add("another ");
		arrayList1.add("example ");

		arrayList2 = new ArrayList<>(); //creates 2nd test collection of integers
		arrayList2.add(3); //adds integers to collection
		arrayList2.add(6);
	}

	/**
	 * Tests add, first, last, contains, remove, isEmpty methods and the
	 * iterator
	 */
	@Test
	public void testMySortedSet1() {
		Iterator<String> iter = list1.iterator(); //creates string iterator for 1st test sortedset
		String combined = ""; //instantiates empty string
		for (int n = 0; n < list1.size(); n++)
			combined += (iter.next()); //iterates through test list and adds to combined string, also tests iterator functions

		assertEquals("a is test this ", combined); //compares expected string to 
		assertEquals("a ", list1.first()); //tests first function
		assertEquals("this ", list1.last());//tests last function
		assertEquals(4, list1.size());//tests size function
		assertEquals(false, list1.contains("john")); //tests contains of item not in list
		assertEquals(true, list1.contains("is ")); //tests contains of item in list
		assertEquals(false, list1.isEmpty()); //tests isEmpty()
		assertEquals(false, list1.remove("apple")); //tests remove of item not in list
		assertEquals(true, list1.remove("test ")); //tests remove of item in list

	}

	/**
	 * Tests add, remove, binarySearch, clear methods as well as the iterator
	 */
	@Test
	public void testMySortedSet2() {
		Iterator<Integer> iter = list2.iterator(); //creates iterator for 2nd sorted set
		String combined = ""; 
		for (int n = 0; n < list2.size(); n++) //tests iteratror
			combined += (iter.next().toString());

		assertEquals(new Integer(3), list2.first()); 
		assertEquals("356", combined);
		assertEquals(1, list2.binarySearch(5));

		list2.clear();

		Iterator<Integer> iter2 = list2.iterator();
		combined = "";
		for (int n = 0; n < list2.size(); n++)
			combined += (iter.next().toString());
		assertEquals("", combined);
	}

	/**
	 * Tests addAll, containsAll, removeAll, as well as the iterator
	 */
	@Test
	public void testMySortedSet3() {
		list1.addAll(arrayList1); //tests add all method
		Iterator<String> iter = list1.iterator();
		String combined = "";
		for (int n = 0; n < list1.size(); n++)
			combined += (iter.next().toString());
		assertEquals("a another example is test this ", combined); //sees if adding correctly

		assertEquals(true, list2.containsAll(arrayList2)); //tests contains all

		arrayList2.add(7); //adds value to arraylist2
		assertEquals(false, list2.containsAll(arrayList2)); //test contains all after adding new valu
		assertEquals(true, list2.removeAll(arrayList2)); //test removeall
		assertEquals(1, list2.size()); //tests size after remove all
	}

	/**
	 * Tests the comparator method
	 */
	@Test
	public void testComparator() {
		MyComparator comparator1 = new MyComparator(); //creates comparator
		list1 = new MySortedSet(comparator1); //test for constructor with comparator
		assertEquals(comparator1, list1.comparator()); //sees if comparator is being set correctly
	}
}
