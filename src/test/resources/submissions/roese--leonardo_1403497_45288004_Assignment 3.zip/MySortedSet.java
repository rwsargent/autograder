package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 * @author Kayden Thomson
 * @author Leonardo Roese
 * 
 * 
 *         * A set that provides a total ordering on its elements. The elements
 *         are ordered using their natural ordering, or by a Comparator provided
 *         at sorted set creation time. Thus, all elements inserted into a
 *         sorted set must implement the Comparable interface or be accepted by
 *         the specified Comparator. The set's iterator will traverse the set in
 *         ascending element order.
 *
 * @param <E>
 *            -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] sortedList; //stores basic array
	private int elems; //keeps track of number of elements in array
	private Comparator comparator; //stores comparator

	/**
	 * Constructs an empty list with a length of 30. Initializes elements of the
	 * list to 0.
	 */
	public MySortedSet() {
		// Ordered using natural ordering
		sortedList = (E[]) new Object[30];// Initialize array of type Object with 0 elements inside
		elems = 0;// initializes elems to 0
	}

	/**
	 * Sets the private member variable to the parameter
	 * 
	 * @param comparator
	 *            -- the comparator to be used
	 */
	public MySortedSet(Comparator<? super E> comparator) {
		// Ordered using the provided Comparator
		this(); //constructs sorted set
		this.comparator = comparator; //sets comparator to parameter
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		return comparator; //returns comparator
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException {
		return sortedList[0]; // returns 1st element in array(smallest)
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if (this.isEmpty()) //if array is empty
			return null; //returns null

		return sortedList[elems - 1]; // returns last element in array(largest)
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) {
		// Check is o is already in sortedList
		if (this.contains(o))
			return false; //if contains object in array returns false

		// If there is no more space in sortedList, doubles the size
		if (sortedList.length - 1 == elems) {
			// Makes a temp array of double the size
			E[] temp = (E[]) new Object[this.size() * 2];
			// Adds each item to temp
			for (int i = 0; i < sortedList.length; i++)
				temp[i] = sortedList[i];
			// Sets sortedList to temp
			sortedList = temp;
		}

		// Finds where o belongs
		int place = binarySearch(o);

		// Moves everything after o's place 1 to the right
		for (int i = elems - 1; i >= place; i--) {
			sortedList[i + 1] = sortedList[i];
		}
		// Adds o to the sortedList
		sortedList[place] = o;
		// Increments elems
		elems++;

		return true; 

	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {

		int initialElems = elems; //initial elements in array

		// Copies colletion to an array
		E[] temp = (E[]) c.toArray();

		// Adds items that don't exist in sortedList from the collection
		for (int i = 0; i < c.size(); i++)
			add(temp[i]);

		// Checks if any items were added
		if (elems > initialElems)
			return true; //items added
		else
			return false;//not added
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		// sets each item in array to null
		for (int i = elems; i >= 0; i--)
			sortedList[i] = null;
		elems = 0; //resets elems to 0
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) {
		// Searches where o would belong, if it's already there returns true
		if (sortedList[binarySearch(o)] == (o))
			return true;
		else
			return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c) {
		// Copies colletion to an array
		E[] temp = (E[]) c.toArray();

		// Runs through each item in the list, if any of them are not in
		// sortedList returns false
		for (int i = 0; i < c.size(); i++)
			if (contains(temp[i]) == false)//checks to see if contains
				return false;

		return true; 
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		if (elems == 0)
			return true;
		else
			return false; //if not empty
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		//creates iterator
		MySortedIterator iterator = new MySortedIterator();
		return iterator;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		//checks to see if object is in array
		if (this.contains(o)) {
			// Finds where o is in the sortedList
			int place = binarySearch(o);
			// Shifts everything that was right of o to the left
			for (int i = place; i <= this.elems; i++)
				sortedList[i] = sortedList[i + 1];
			elems--; //decrements amount of elements
			return true;
		} else
			return false; //if set did not contain object

	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		int initialElems = elems; //intial amount of elems in array

		// Copies colletion to an array
		E[] temp = (E[]) c.toArray();
		for (int i = 0; i < c.size(); i++) 
			remove(temp[i]);

		// Checks if any items were removed from sortedList
		if (elems < initialElems)
			return true;
		else
			return false; //nothing was removed
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size() {
		return elems; 
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		E[] array = (E[]) new Object[elems];
		Iterator<E> itr = this.iterator();
		for (int i = 0; i < this.size(); i++)
			array[i] = itr.next();

		return array;

	}

	/**
	 * Performs a binary search of the sorted list for where o should be placed
	 * 
	 * @param o
	 *            -- placement to be found for o
	 * @returns the place where should be
	 */
	public int binarySearch(Object o) {
		int start = 0, mid = 0;
		int end = elems;

		// If there aren't any elements, returns 0
		if (elems == 0)
			return 0;

		while (start < end) {
			// Sets the mid
			mid = (start + end) / 2;
			// Finds the middle of the list
			E value = sortedList[mid];
			// Compares o to the middle value
			if (((Comparable<E>) o).compareTo(value) > 0)
				start = mid + 1;
			else
				end = mid;
		}
		return start;

	}

	/**
	 * Sets up an iterator over a collection.
	 * 
	 * @author Kayden Thomson
	 * @author Leonardo Roese
	 *
	 */
	private class MySortedIterator implements Iterator<E> {

		private int location; //stores location of where in the array
		private E lastreturn; //stores last returned object

		/**
		 * Constructs the iterator
		 */
		public MySortedIterator() {
			location = -1; //sets location to -1
			lastreturn = null; //last return set to null
		}

		/**
		 * @returns true if the iteration has more elements.
		 */
		@Override
		public boolean hasNext() {
			//if at the end of the array
			if (location == size() - 1)
				return false;
			else
				return true;

		}

		/**
		 * @returns the next element in the iteration.
		 */
		@Override
		public E next() {
			//checks to see that array has a next
			if (this.hasNext()) {
				return lastreturn = sortedList[++location]; //increments location
			} else
				throw new NoSuchElementException(); //no next value
		}

		/**
		 * Removes from the underlying collection the last element returned by
		 * this iterator.
		 */
		@Override
		public void remove() {
			//checks to see if returned value is not null
			if (lastreturn != null) {
				MySortedSet.this.remove(lastreturn);//removes last returned value from array
				location--;//decrements the location
				lastreturn = null;//sets to null so cant call remove twice in a row
			} else
				throw new IllegalStateException();//if last return is null
		}

	}
}
