package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Class Representation of a Sorted Set
 * 
 * @author Gage Glenn
 * @author Cody Woolsey
 */
@SuppressWarnings("unchecked")
public class MySortedSet<E> implements SortedSet<E>
{
	// The array containing the data of the set.
	private E[] data;
	// The actual size of the set.
	private int size;
	// The Comparator object provided by the user, used to sort the data.
	private Comparator<? super E> cmp;
	
	/**
	 * Instantiates a MySortedSet object of type E. Type E must inherit the Comparable Interface.
	 */
	public MySortedSet()
	{
		data = (E[]) new Object[10];
		size = 0;
		cmp = null;
	}
	
	/**
	 * Instantiates a MySortedSet object of type E. Uses the provided Comparator to sort the set.
	 * @param cmp the Comparator to be used for sorting
	 */
	public MySortedSet(Comparator<? super E> cmp)
	{
		this();
		this.cmp = cmp;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator()
	{
		return cmp;
	}
	
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException
	{
		if (this.isEmpty())
			throw new NoSuchElementException();
		return data[0];
	}
	
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException
	{
		if (this.isEmpty())
			throw new NoSuchElementException();
		return data[size - 1];
	}
	
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o)
	{
		if (o == null)
			return false;
		// If it's the first value being added to the set, add it to data[0].
		else if (size == 0)
		{
			size++;
			data[0] = o;
			return true;
		}
		// Ensure the Set doesn't already contain the object.
		else if (contains(o))
			return false;
		else
		{
			// Expand our array if we've hit max capacity
			if (size == data.length)
				expand();
			for (int index = 0; index < size + 1; index++)
			{
				// hit end and add value
				if(data[index] == null)
				{
					data[index] = o;
					size++;
					return true;
				}
				else if (compareElements(o, data[index]) > 0)
				{
					continue;
				} 
				// Insert behind greater value
				else
				{
					for (int shift = size; shift > index; shift--)
					{
						data[shift] = data[shift - 1];
					}
					data[index] = o;
					size++;
					return true;
				}
			}
		}
		return false;
	}
	
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c)
	{
		boolean addFlag = false;
		boolean tempFlag = false;
		
		if(c == null)
		{
			return false;
		}
		
		for (Object element : c)
		{
			tempFlag = add((E) element);
			if (tempFlag)
			{
				addFlag = tempFlag;
			}
				
		}
		return addFlag;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear()
	{
		size = 0;
		data = (E[]) new Object[10];
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o)
	{
		return (binarySearch(o) > -1);
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c)
	{
		for (Object element : c)
		{
			if (!contains(element))
				return false;
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty()
	{
		return (size <= 0);
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator()
	{
		return new Iterator<E>()
				{
					// The next index in the iteration
					private int next = 0;
					// Keeps track of whether or not the next method has been called since the last remove.
					private boolean nextCalled = false;
			
					/**
					 * @return true if the iteration has more elements
					 */
					@Override
					public boolean hasNext()
					{
						return (next < size);
					}

					/**
					 * @return the next element in the iteration
					 * @throws NoSuchElementException - if the iteration has no more elements
					 */
					@Override
					public E next() throws NoSuchElementException
					{
						if (!hasNext())
							throw new NoSuchElementException();
						nextCalled = true;
						next++;
						return data[next - 1];
					}					
					
					/**
					 * Removes from the underlying collection the last element returned by this iterator (optional operation). 
					 * This method can be called only once per call to next(). The behavior of an iterator is unspecified if the 
					 * underlying collection is modified while the iteration is in progress in any way other than by calling this method.
					 * @throws IllegalStateException - if the next method has not yet been called, or the remove method has already been called after the last call to the next method
					 */
					@Override
					public void remove() throws IllegalStateException
					{
						if (!nextCalled)
							throw new IllegalStateException();
						MySortedSet.this.remove(data[next - 1]);
						nextCalled = false;
					}
				};
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o)
	{
		if (size == 0)
			return false;

		int indexOfOccurence = binarySearch(o);
		if (indexOfOccurence == -1)
			return false;
		else
		{
			E[] newData = (E[]) new Object[data.length];
			for (int i = 0; i < indexOfOccurence; i++)
			{
				newData[i] = data[i];
			}
			for (int i = indexOfOccurence + 1; i < size; i++)
			{
				newData[i - 1] = data[i];
			}
			size--;
			data = newData;
			return true;
		}
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c)
	{
		boolean addFlag = false;
		boolean tempFlag = false;
		
		if (c == null)
			return false;
		
		for (Object element : c)
		{
			tempFlag = remove((E) element);
			if (tempFlag)
			{
				addFlag = tempFlag;
			}
				
		}
		return addFlag;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size()
	{
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray()
	{
		Object[] temp = new Object[size];
		
		for (int i = 0; i < size; i++)
		{
			temp[i] = data[i];
		}
		return temp;
	}

	/**
	 * Doubles the size of the internal array and copies the data to the new array.
	 */
	private void expand()
	{
		E[] newData = (E[]) new Object[data.length * 2];

		// Copy the data
		for (int index = 0; index < size; index++)
		{
			newData[index] = data[index];
		}

		data = newData;
	}
	
	/**
	 * Returns the index at which the object occurs in the set, or -1 if the object does not exist in the set.
	 * @param o the Object to be searched for
	 * @return the index at which o occurs
	 */
	private int binarySearch(Object o)
	{
		int mid = this.size / 2;
		int min = 0;
		int max = this.size;
		E obj = (E) o;

		for (int index = 0; index < (size / 2) + 1; index++)
		{
			// If the object at mid is equal to our target, return the index.
			if (data[mid].equals(obj))
				return mid;
			// Move the indexes to the right or left depending on 
			else if (compareElements(data[mid], obj) > 0)
			{
				max = mid;
				mid = (max + min) / 2;
			} 
			else
			{
				min = mid;
				mid = (max + min) / 2;
			}
		}
		return -1;
	}
	
	/**
	 * Compares the given elements using either a Comparator or the Comparable interface,
	 * depending on which class constructor was used.
	 * @return The comparison value between e1 and e2.
	 */
	private int compareElements(E e1, E e2)
	{
		if (cmp == null && e1 instanceof Comparable && e2 instanceof Comparable)
			return ((Comparable<E>) e1).compareTo(e2);
		else
			return cmp.compare(e1, e2);
	}
}
