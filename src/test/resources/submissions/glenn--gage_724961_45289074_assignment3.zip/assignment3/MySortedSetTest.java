package assignment3;

/**
 * Testing Code for the MySortedSet
 * 
 * @author Gage Glenn
 * @author Cody Woolsey
 */


import static org.junit.Assert.*;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.TreeSet;

import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest
{
	private MySortedSet<Integer> set;

	@Before
	public void setUp() throws Exception
	{
		set = new MySortedSet<Integer>();
	}
	
	/**
	 * A JUnit method which tests the add method in MySortedSet
	 * 
	 * */
	
	@Test
	public void testAdd()
	{
		
		// tests add and ensures the array is as predicted
		assertTrue(set.add(1));
		assertEquals((Integer) 1, set.first());
		assertEquals((Integer) 1, set.last());

		assertTrue(set.add(2));
		assertEquals((Integer) 1, set.first());
		assertEquals((Integer) 2, set.last());

		assertTrue(set.add(5));
		assertEquals((Integer) 1, set.first());
		assertEquals((Integer) 5, set.last());

		// tests add and ensures the array expands when it reaches the backing limit
		
		assertTrue(set.add(4));
		assertFalse(set.add(1));
		assertTrue(set.add(8));
		assertTrue(set.add(7));
		assertTrue(set.add(94));
		assertTrue(set.add(14));
		assertTrue(set.add(64));
		assertTrue(set.add(411));

		// First Expansion (Value added at end)
		assertTrue(set.add(-411));
		assertEquals((Integer) (-411), set.first());
		assertEquals((Integer) 411, set.last());

		assertTrue(set.add(1337));
		assertTrue(set.add(1336));

		// Second Expansion (value in the middle of data)
		for (int i = 421; i < 440; i++)
		{
			assertTrue(set.add(i));
		}

		set.clear();
		assertTrue(set.size() == 0);

	}
	
	/**
	 * A JUnit method which tests the addAll method in MySortedSet
	 * 
	 * */
	

	@Test
	public void testAddAll()
	{
		MySortedSet<Integer> set1 = new MySortedSet<Integer>();
		TreeSet<Integer> set2 = new TreeSet<Integer>();

		for (int i = 0; i < 40; i++)
		{
			assertTrue(set2.add(i));
		}

		// addAll to set 1

		assertTrue(set1.addAll(set2));
		assertFalse(set1.addAll(set2));

		assertTrue(set1.size() == 40);

		// test addAll when a partial amount is added

		assertTrue(set2.add(90));

		assertTrue(set1.addAll(set2));
		assertFalse(set1.addAll(set2));

		assertTrue(set1.size() == 41);

		// clear and test addAll

		set1.clear();

		assertTrue(set1.size() == 0);

		assertTrue(set1.isEmpty());

		assertTrue(set1.addAll(set2));

		assertTrue(set1.size() == 41);

		// Test with a null set.

		assertFalse(set1.addAll(null));

		MySortedSet<String> stringSet1 = new MySortedSet<String>();
		TreeSet<String> stringSet2 = new TreeSet<String>();

		// Test with strings

		stringSet2.add("dont");
		stringSet2.add("dont");
		stringSet2.add("you");
		stringSet2.add("want");
		stringSet2.add("me");
		stringSet2.add("you");
		stringSet2.add("know");
		stringSet2.add("I");
		stringSet2.add("dont");
		stringSet2.add("believe");
		stringSet2.add("you");
		stringSet2.add("when");
		stringSet2.add("you");
		stringSet2.add("say");
		stringSet2.add("that");
		stringSet2.add("you");
		stringSet2.add("wont");
		stringSet1.add("see");
		stringSet1.add("me");

		// addAll

		assertTrue(stringSet1.addAll(stringSet2));
		assertFalse(stringSet1.addAll(stringSet2));

		stringSet2.add("dont");
		stringSet2.add("you");
		stringSet2.add("want");
		stringSet2.add("me");
		stringSet2.add("OooooooooHhhhhhh");

		assertTrue(stringSet2.size() == 12);

		assertTrue(stringSet1.addAll(stringSet2));
		assertFalse(stringSet1.addAll(stringSet2));

		stringSet2.clear();
		assertTrue(stringSet2.size() == 0);

	}
	
	/**
	 * A JUnit method which tests the remove method in MySortedSet
	 * 
	 * */
	

	@Test
	public void testRemove()
	{
		// Test on empty set
		assertFalse(set.remove(0));

		// Add some items to the set
		for (int i = 1; i < 50; i++)
		{
			assertTrue(set.add(i));
		}

		assertEquals(new Integer(1), set.first());
		assertEquals(new Integer(49), set.last());
		// Test shifting of the array.
		assertTrue(set.remove(1));
		assertFalse(set.remove(0));
		assertTrue(set.remove(49));
		assertFalse(set.remove(49));
		assertTrue(set.remove(36));
		assertFalse(set.remove(36));
		assertEquals(new Integer(2), set.first());
		assertEquals(new Integer(48), set.last());

		assertEquals(46, set.size());
		// Test the clear method.
		set.clear();
		assertEquals(0, set.size());
		assertTrue(set.isEmpty());
	}
	
	/**
	 * A JUnit method which tests the removeAll method in MySortedSet
	 * 
	 * */
	

	@Test
	public void testRemoveAll()
	{
		MySortedSet<String> newSet = new MySortedSet<String>();
		TreeSet<String> set1 = new TreeSet<String>();
		// Test with a null set.
		assertFalse(set.removeAll(null));
		// Test with an empty set.
		assertFalse(set.removeAll(set1));

		// Test on a set of 1 element
		assertTrue(newSet.add(""));
		set1.add("");
		assertTrue(newSet.removeAll(set1));
		assertTrue(newSet.isEmpty());
		assertEquals(0, newSet.size());

		String toAdd = "";
		// Add some values to the set
		for (int i = 1; i < 50; i++)
		{
			toAdd += 'a';
			assertTrue(newSet.add(toAdd));
		}

		toAdd = "aa";
		for (int i = 3; i < 49; i++)
		{
			toAdd += 'a';
			set1.add(toAdd);
		}

		assertTrue(newSet.removeAll(set1));
		assertEquals("a", newSet.first());

		String result = "";
		for (int i = 1; i < 50; i++)
		{
			result += 'a';
		}

		assertEquals(result, newSet.last());
	}
	
	/**
	 * A JUnit method which tests the testToArray method in MySortedSet
	 * 
	 * */
	

	@Test
	public void testToArray()
	{
		MySortedSet<String> set1 = new MySortedSet<String>();

		Object[] checkArr = { "The", "awakens", "sleeper" };

		set1.add("The");
		set1.add("sleeper");
		set1.add("awakens");

		// Check initial toArray

		Object[] arr = (Object[]) set1.toArray();

		for (int i = 0; i < 3; i++)
		{
			assertEquals(checkArr[i], arr[i]);
		}

		set1.add("Muad'Dib");

		// Check changed toArray

		Object[] checkArr2 = { "Muad'Dib", "The", "awakens", "sleeper" };
		arr = (Object[]) set1.toArray();

		for (int i = 0; i < 4; i++)
		{
			assertEquals(checkArr2[i], arr[i]);
		}
	}

	/**
	 * A JUnit method which tests MySortedSet with a comparator instead of the default comparable
	 * 
	 * */
	
	
	@Test
	public void testComparator()
	{
		IntComparator comparator = new IntComparator();
		MySortedSet<Integer> set1 = new MySortedSet<Integer>(comparator);

		// Test adding values in sorted order
		assertEquals(comparator, set1.comparator());
		assertTrue(set1.add(0));
		assertFalse(set1.add(0));
		assertTrue(set1.add(4));
		assertFalse(set1.add(4));
		assertTrue(set1.add(3));
		assertFalse(set1.add(3));
		assertEquals(3, set1.size());
		// Make sure the set is sorted properly
		assertEquals(new Integer(0), set1.first());
		assertEquals(new Integer(4), set1.last());
		set1.clear();
		assertEquals(0, set1.size());

		// Test the first and last methods on an empty set.
		try
		{
			set1.first();
			fail("No exception thrown.");
		} catch (NoSuchElementException e)
		{
		}

		try
		{
			set1.last();
			fail("No exception thrown.");
		} catch (NoSuchElementException e)
		{
		}

		// Test removing items from the set
		assertTrue(set1.add(3));
		assertTrue(set1.add(1));
		assertTrue(set1.remove(3));
		assertTrue(set1.remove(1));

		// Test with Longs

		LongComparator comparatorLong = new LongComparator();
		MySortedSet<Long> set2 = new MySortedSet<Long>(comparatorLong);

		// Test adding values in sorted order
		assertEquals(comparator, set1.comparator());
		assertTrue(set2.add(01L));
		assertFalse(set2.add(01L));
		assertTrue(set2.add(40000L));
		assertFalse(set2.add(40000L));
		assertTrue(set2.add(30000L));
		assertFalse(set2.add(30000L));
		assertEquals(3, set2.size());

		// Make sure the set is sorted properly
		assertEquals(new Long(01L), set2.first());
		assertEquals(new Long(40000L), set2.last());
		set2.clear();
		assertEquals(0, set2.size());

	}
	
	/**
	 * A JUnit method which tests the iterator
	 * 
	 * */
	
	
	@Test
	public void testIterator()
	{
		for (int i = 0; i < 20; i++)
		{
			assertTrue(set.add(i));
		}	
		
		Iterator<Integer> iTest = set.iterator();
		
		assertTrue(iTest.hasNext());
		
		for (int i = 0; i < 20; i++)
		{
			if(i < 19){
				assertTrue(iTest.hasNext());
			}			
			assertTrue(iTest.next() != null);
		}	
		
		iTest = set.iterator();
		// Verify correct values
		for (int i = 0; i < 20; i++)
		{
		assertTrue(iTest.next() == i);
		}
		
		iTest = set.iterator();
		
		// Check Remove correctness
		iTest.next();
		iTest.remove();
		for (int i = 0; i < 18; i++)
		{
		assertTrue(iTest.next() == (i + 2));
		}
		
	}
	
	/**
	 * An integer comparator for testing
	 * 
	 * */
	

	protected class IntComparator implements Comparator<Integer>
	{
		@Override
		public int compare(Integer o1, Integer o2)
		{
			return o1 - o2;
		}
	}
	
	/**
	 * A long comparator for testing
	 * 
	 * */
	

	protected class LongComparator implements Comparator<Long>
	{
		@Override
		public int compare(Long o1, Long o2)
		{
			return (int) (o1 - o2);
		}
	}
}
