/**
 * Timing Code for the MySortedSet Contains Method
 * 
 * @author Gage Glenn
 * @author Cody Woolsey
 */



package assignment3;

public class MySortedSetTimerContains
{

	public static void main(String[] args)
	{
		for (int i = 0; i < 124; i++)
		{
			System.out.println(100000 + (10000 * i));
		}

		long startTime, midpointTime, stopTime;
		startTime = System.nanoTime();

		MySortedSet<Integer> testSet = new MySortedSet<Integer>();
		
		// prep contains for timing
		
		for (int i = 0; i < 100000; i++)
		{
			testSet.add((Integer) i);
		}


		for (int growLoop = 100000; growLoop <= 20000000; growLoop = growLoop + 10000)
		{			
			startTime = System.nanoTime();
			
			// Run Contains X number of times

			for (int i = 0; i < growLoop; i++)
			{
				testSet.contains((Integer) i);
			}

			midpointTime = System.nanoTime();
			for (int i = 0; i < growLoop; i++)
			{
			}
			stopTime = System.nanoTime();
			
			// calculate the average time to loop.

			double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))/ growLoop;

			System.out.println(averageTime);
			for (int i = growLoop; i < growLoop + 10000; i++)
			{
				testSet.add((Integer) i);
			}

		}
	}
}
