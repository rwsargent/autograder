package assignment3;

/**
 * Timing Code for the MySortedSet Add Method
 * 
 * @author Gage Glenn
 * @author Cody Woolsey
 */

public class MySortedSetTimerAdd
{
	public static void main(String[] args)
	{
		long startTime, midpointTime, stopTime;
		startTime = System.nanoTime();

		MySortedSet<Integer> testSet = new MySortedSet<Integer>();
		
		

		for (int growLoop = 100; growLoop <= 20000000; growLoop = growLoop + 100)
		{
			for (int i = 0; i < growLoop; i = i + 2)
			{
				testSet.add((Integer) i);
			}

			// Timing Start
			
			startTime = System.nanoTime();

			for (int i = growLoop; i > 0; i--)
			{
				testSet.add((Integer) i);
			}

			stopTime = System.nanoTime();

			// Average time of each add
			
			double averageTime = (stopTime - startTime) / growLoop;

			System.out.println(averageTime);

			testSet.clear();

		}

	}

}
