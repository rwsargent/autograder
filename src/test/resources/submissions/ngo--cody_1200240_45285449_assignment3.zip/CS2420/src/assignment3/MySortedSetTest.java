package assignment3;
/**
 * @author Cody Ngo, Tianyu Wang
 */

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest {
	ArrayList<Integer> arr2,arr6;
	ArrayList<String> arr4;
	private MySortedSet<Integer> arr1, arr3, arr5,arr0;
//	private MySortedSet<String> arr4;
	
	@Before
	public void setUp() throws Exception {
		arr1= new MySortedSet<Integer>();
		arr2= new  ArrayList<Integer>();
		arr6= new  ArrayList<Integer>();
		arr3= new  MySortedSet<Integer> ();
		arr5= new  MySortedSet<Integer> ();
		arr0= new  MySortedSet<Integer> ();
		
		arr0.add(1);
		arr0.add(2);
		arr0.add(3);
		arr0.add(4);
		arr0.add(5);
		arr0.add(6);
		arr0.add(7);
		arr0.add(8);
		arr0.add(9);
		
		arr2.add(1);
		arr2.add(3);
		arr2.add(7);
		arr2.add(9);
	

		

		
	}

	@After
	public void tearDown() throws Exception {
	}

	
	
	
	@Test
	public void testbase() {
		assertTrue(arr0.size()==9);
		assertTrue(arr2.size()==4);
	}
	
	
	
	@Test
	public void testAdd() {
		assertTrue(arr1.add(3));
		assertTrue(arr1.add(2));
		assertTrue(arr1.add(5));
		assertTrue(arr1.add(7));
		assertTrue(!arr1.add(5));
		assertTrue(arr1.add(6));
		assertTrue(arr1.add(1));
		assertTrue(arr1.add(4));
		//arr1={1 2 3 4 5 6 7}
	}
	
	@Test
	public void testAddfull() {
		arr1=arr0;
		assertTrue(arr1.add(15));
		assertTrue(arr1.add(16));
		assertTrue(arr1.add(11));
		assertTrue(arr1.size()==12);
	}
	@Test
	public void testremove() {
		arr1=arr0;
		assertTrue(arr1.remove(1));
		assertTrue(arr1.remove(7));
		assertTrue(arr1.remove(4));
		assertFalse(arr1.remove(7));
		// arr1={2 3 5 6 8 9}
		assertTrue(arr1.size()==6);
	}
	
	@Test
	public void testaddall() {		
		assertTrue(arr1.size()==0);
		arr1.addAll(arr2);
		assertTrue(arr1.size()==4);
		
		//arr0={1 2 3 4 5 6 7 8 9}
		//arr2={1 3 7 9}
		assertTrue(arr2.size()==4);
		assertTrue(arr0.size()==9);
		
		assertFalse(arr0.add(1));
		assertFalse(arr0.add(3));
		assertFalse(arr0.add(7));
		assertFalse(arr0.add(9));
		assertFalse(arr0.addAll(arr2));
		arr0.addAll(arr2);
		assertTrue(arr0.size()==9);
	}
	
	@Test
	public void testremoveall() {
		arr3=arr0;
		assertTrue(arr3.size()==9);
		arr3.remove(5);
		assertTrue(arr3.size()==8);
		assertTrue(arr2.size()==4);
		// arr3={1 2 3 4 6 7 8 9}
		// arr2={1 3 7 9}
		assertTrue(arr3.removeAll(arr2));
		// arr5={2 4 6 8}
		assertTrue(arr3.size()==4);
		arr3.toArray();
	}
	
	@Test
	public void testcontains() {	

		assertTrue(arr0.contains(5));
		assertFalse(arr0.contains(10));
		
	}
	
	@Test
	public void testcontainsall() {
		//arr0={1 2 3 4 5 6 7 9}
		// arr2 = {1 3 7 9}
		assertTrue(arr0.containsAll(arr2));
		arr2.add(10);
		assertFalse(arr0.containsAll(arr2));
	}
	
	@Test
	public void testisEmpty() {
		assertFalse(arr0.isEmpty());
	}
	
	@Test
	public void testclear() {
		arr5=arr0;
		arr5.clear();
		assertTrue(arr5.size()==0);
	}

	@Test
	public void iteratorTest(){
		assertTrue(arr0.iterator().hasNext());
		assertFalse(arr1.iterator().hasNext());
		arr0.add(10);
		arr0.iterator().next();//2 position 1
		arr0.iterator().next();//3 2
		arr0.iterator().next();//4 3
		arr0.iterator().next();// 5 4
		arr0.iterator().next();//6 5
		arr0.iterator().next();//7 6
		arr0.iterator().next();//8 7
		arr0.iterator().next();//9 8
		arr0.iterator().next();//10 9
		assertFalse(arr0.iterator().hasNext());
		arr0.iterator().remove();
		arr0.iterator().remove();
		arr0.add(11000);
		System.out.println(arr0.iterator().next());
		
	}
}
