package assignment3;
/**
 * @author Cody Ngo, Tianyu Wang
 */

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> {
	// Initializes array that will contain elements;
	private E[] arr;

	// comparator that is being used in constructor
	private Comparator<? super E> comparator;

	// Keeps track of the position in the array when adding/removing
	private int position = 0;
	
	//Keeps track of the position when using the iterator
	private int itPosition = 0;

	// Keeps track of items in array;
	private int arrayItems;
	


	/**
	 * Creates a sorted set assuming the elements are in natural ordering
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet() {
		arr = (E[]) new Object[10];
		arrayItems = 0;
	}

	/**
	 * Creates a sorted set assuming the elements are using the comparator
	 */
	public MySortedSet(Comparator<? super E> comparator) {
		this();
		// save passed in comparator
		arrayItems = 0;
		this.comparator = comparator;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return this.comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (arr[0] == null) {
			throw new NoSuchElementException();
		}
		return arr[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (arr[arr.length - 1] == null) {
			throw new NoSuchElementException();
		}
		return arr[arrayItems - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		if (arrayItems == 0) {
			arr[0] = o;
			arrayItems++;
			return true;
		}
		// Returns false if binarySearch found o in the array
		else if (binarySearch(o) == false) {
			return false;
		} 
			// Case if array still has room
			else {

				// Moves every elements after object to be inserted one space
				// over
				for (int i = arrayItems - 1; i >= position; i--) {
					arr[i + 1] = arr[i];

				}
				arr[position] = o;
				arrayItems++;
				// Case if array is already full
				if (arrayItems == arr.length) {
					// Doubles the size of array
					arr = Arrays.copyOf(arr, arr.length * 2);
				}
				return true;
			}

		}


	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		//Initially assumes that nothing has changed.
		boolean answer=false;
		
		//Adds each element from c that can b added and sets the result to true
		for (E o : c) {
			if(this.add(o))
			{
				answer=true;
			}
			else continue;   
		}
		return answer;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {

		// Goes through array and sets each space to null
		for (int i = 0; i < arr.length; i++) {
			arr[i] = null;
		}
		arrayItems = 0;
		itPosition=0;

	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		// If binarySearch found the object, return true
		if (binaryCheckSearch((E) o) == false)
			return true;

		// binarySearch did not find the object
		else {
			return false;
		}
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		//Initially assumes that all items are from collection c
		boolean answer = true;
		
		//Searches array to make sure all elements are from c, if not all sets answer to false
		for (Object o : c) {
			if(this.contains(o)==false)
				answer = false;;
		}
		return answer;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (arrayItems == 0)
			return true;
		else {
			return false;
		}
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		Iterator<E> it = new Iterator<E>(){

			@Override
			public boolean hasNext() {
				//Checks to make sure that there are elements ahead of position
				if(arr[itPosition+1]!= null)
					return true;
				else
					return false;
			}

			@Override
			public E next() {
				//Checks to make sure there is an element ahead of position
				if(arr[itPosition+1]== null)
					throw new NoSuchElementException();
				else
				{
					itPosition++;
					return arr[itPosition];
				}
			}
			@Override
			public void remove(){
				if(itPosition == 0 || arr[itPosition]== null)
					throw new IllegalStateException();
				else
					//Removes item at position and moves back position
					removePos(itPosition);
					itPosition--;
			}
			
		};
		return it;
	}
	
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- position of object to be removed from this set
	 */
	private void removePos(int o) {
			// Shifts every elements ahead of of the object to be removed to the
			// left,
			// and therefore taking the place of o.
			for (int i = o; i < arrayItems; i++) {
				arr[i] = arr[i + 1];
			}
			arrayItems--;
		}
	

	
	
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object o) {
		// binarySearch did not find the object, returns false
		if (binaryCheckSearch((E)o))
			return false;

		// binarySearch found the object
		else {
			// Shifts every elements ahead of of the object to be removed to the
			// left,
			// and therefore taking the place of o.
			for (int i = position; i < arrayItems; i++) {
				arr[i] = arr[i + 1];
			}
			arrayItems--;
			return true;
		}
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		//Initially assumes that nothing has changed
		boolean answer=false;
		
		//Searches array for each object from c and reports if they exist and can be removed and sets result to true
		for (Object o : c) {
			if(this.remove(o))
			{
				answer=true;
			}
			else continue;   
		}
		return answer;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {

		return arrayItems;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {

		return arr;
	}

	/**
	 * Searches through through the array using binary search also sets the
	 * position for where object o should be
	 * 
	 * @param o
	 * @return True if element o is not in the array being searched or false if
	 *         o is in the array
	 */
	@SuppressWarnings("unchecked")
	private boolean binarySearch(E o) {
		// Sets the initial limits for the search
		int mid = arrayItems / 2;
		int low = 0;
		int high = arrayItems;
		while (low < high) {
			// If o is less than the mid point, set the upper limit to the mid - 1
			if (((Comparable<E>) arr[mid]).compareTo(o) > 0) {
				high = mid - 1;
			}
			// If o is greater than mid point, set lower limit to the mid + 1
			if (((Comparable<E>) arr[mid]).compareTo(o) < 0) {
				low = mid + 1;
			}
			// If o is the object at the mid point, return false
			if (((Comparable<E>) arr[mid]).compareTo(o) == 0) {
				return false;
			}
			mid = (high + low) / 2;
		}
		// Position for which o will be inserted in add or removed in remove
		// methods
		
		if(arr[mid]!=null&& ((Comparable<E>) arr[mid]).compareTo(o) == 0 &&arr[mid] !=null)
			{
				return false;
			}
		else if (mid == arrayItems)
			position = mid;
		else if (((Comparable<E>) arr[mid]).compareTo(o) > 0) {
			position = mid;
		} else {
			position = mid + 1;
		}

		return true;

	}

	@SuppressWarnings("unchecked")
	private boolean binaryCheckSearch(E o) {
		// Sets the initial limits for the search
		int mid = arrayItems / 2;
		int low = 0;
		int high = arrayItems;
		while (low <= high) {
			if(arr[mid] == null ){
				return true;
			}
			// If o is less than the mid point, set the upper limit to the mid -
			// 1
			if (((Comparable<E>) arr[mid]).compareTo(o) > 0) {
				high = mid - 1;
			}
			// If o is greater than mid point, set lower limit to the mid + 1
			if (((Comparable<E>) arr[mid]).compareTo(o) < 0) {
				low = mid + 1;
			}
			// If o is the object at the mid point, return false
			if (((Comparable<E>) arr[mid]).compareTo(o) == 0) {
				position = mid;
				return false;
			}
			mid = (high + low) / 2;
		}
		
		return true;

	}

}
