package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
/**
 * 
 * @author Tanner Barlow
 * @author Elijah Grubb
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E>, Iterator<E>{
	
	private Object [] eArray;
	private int size;
	private int index;
	private final int INITIAL_SIZE = 10;
	private Comparator<? super E> comparator;
	
	/**
	 * Creates a new MySortedSet that will be sorted using a Comparable
	 */
	public MySortedSet()
	{
		comparator = null;
		eArray = new Object[INITIAL_SIZE];
		size = 0;
	}
	
	/**
	 * Creates a new MySortedSet that will be sorted using a Comparator
	 * @param c Comparator to be used while sorting
	 */
	public MySortedSet(Comparator<? super E> c)
	{
		comparator = c;
		eArray = new Object[INITIAL_SIZE];
		size = 0;
	}
	
	/**
	 * Returns the comparator to be used in sorting MySortedSet
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * Returns the first element of the set
	 * If empty, throws NoSuchElementException
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (eArray.length == 0)
			throw new NoSuchElementException("Empty Array");
		return (E) eArray[0];
	}

	/**
	 * Returns the last element of the set
	 * If empty, throws NoSuchElementException
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (eArray.length == 0)
			throw new NoSuchElementException("Empty Array");
		return (E)eArray[eArray.length-1];
	}

	/**
	 * Adds the object of type E into the set
	 * If the object is null or is already in the set, returns false
	 * Otherwise, inserts the object into the set and returns true
	 */
	@Override
	public boolean add(E o) {
		if (o == null)
			return false;
		if (this.contains(o))
			return false;
		
		// if there's no room left grow the array
		// otherwise we know there's at least one open space
		// which is all we need to finish add()
		if (size == eArray.length) {
			Object[] temp = new Object[eArray.length * 2];
			for (int i = 0; i < eArray.length; i ++)
				temp[i] = eArray[i];
			eArray = temp;
		}
		
		if (size == 0 && index == 0)
		{
			eArray[0] = o;
			size++;
			return true;
		}
		int insertionPoint;
		int comparison = comparison(o, (E[]) eArray, index);
		if(comparison < 0)
			insertionPoint = index - 1;
		else
			insertionPoint = index + 1;
		
		if (insertionPoint < 0)
			insertionPoint = 0;
		
		// If the new element belongs at the very end of the array
		// then we don't want to waste time or space making and a whole new
		// unneeded array when it's just easier to add it to the end
		// and be done with it
		if (size == insertionPoint) {
			eArray[insertionPoint] = o;
			size++;
			return true;
		} else {
			Object[] shiftedObjects = new Object[eArray.length - insertionPoint];
			for (int j = insertionPoint; j < size; j++)
					shiftedObjects[j - insertionPoint] = eArray[j];
			eArray[insertionPoint] = o;
			for (int j = insertionPoint + 1; j < eArray.length; j++)
				eArray[j] = shiftedObjects[j - insertionPoint - 1];
			size++;
			return true;
		}
	}

	/**
	 * Adds all of the elements from a
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean successAdd = false;
		if (c == null)
			return false;
		if(c.size() == 0)
			return false;
		for(E o : c)
			if(add(o))
				successAdd = true;
		return successAdd;
	}

	@Override
	public void clear() {
		eArray = new Object[INITIAL_SIZE];
		size = 0;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		
		if (size == 0)
			return false;
		
		E temp;
		E[] tempArray;
		
		try {
			temp = (E) o;
			tempArray = (E[]) eArray;
		} catch (ClassCastException e) {
			return false;
		}
		
		int high, low, mid;
		high = size - 1;
		low = 0;
		mid = (high + low)/2;
		
		//If temp is less than the lowest thing or
		//higher than the highest thing, we don't need
		//to bother doing a binary search
		//Set index to the highest or lowest item in
		//the list so that the add method will know
		//where to put the new item.
		
		if (comparison(temp, tempArray, high) > 0) {
			index = high;
			return false;
		}
		if (comparison(temp, tempArray, low) < 0) {
			index = low;
			return false;
		}

		while (low <= high) {
			int comparison = comparison(temp, tempArray, mid);
			if(comparison < 0)
			{
				high = mid -1;
			}
			else if (comparison > 0)
			{
				low = mid + 1;
			}
			else {
				index = mid;
				return true;
			}
			mid = (high + low) / 2;
		}
		index = mid; //Element not found, setting index to know where to insert new element		
		return false;
		
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		if (c.size() == 0)
			return false;
		
		for (Object o : c)
			if (!(this.contains(o)))
				return false;
		return true;
	}
	
	public int comparison (E o, E[] a, int point) {
		int comparison;
		if (comparator != null && point < size)
			comparison = comparator.compare(o, a[point]);
		else
			comparison = (((Comparable<? super E>) o).compareTo(a[point]));
		return comparison;
	}

	@Override
	public boolean isEmpty() {
		if (size == 0)
			return true;
		else
			return false;
	}

	@Override
	public Iterator<E> iterator() {
		return (Iterator<E>) this;
	}

	@Override
	public boolean remove(Object o) {
		// TODO FINISH
		if(!(this.contains(o)))
			return false;
		Object [] shiftedObjects = new Object[size];
		for(int i = index + 1; i < size; i++)
			shiftedObjects[i-index-1] = eArray[i];
		for(int i = index; i < size; i++)
			eArray[i] = shiftedObjects[i-index];
		size--;
		return true;
		
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		boolean successRemove = false;
		if (c == null)
			return false;
		if(c.size() == 0)
			return false;
		for(Object o : c)
			if(remove(o))
				successRemove = true;
		
		return successRemove;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public Object[] toArray() {
		return eArray;
	}

	/**
	 * Returns true if the iteration has more elements. (In other words, 
	 * returns true if next() would return an element rather than throwing an exception.)
	 */
	@Override
	public boolean hasNext() {
		if (size > 0)
			return true;
		else
			return false;
	}

	/**
	 * Returns the next element in the iteration.
	 * @throws NoSuchElementException if there are no more elements to return
	 */
	@Override
	public E next() {
		if (size == 0)
			throw new NoSuchElementException();
		
		E next = (E) eArray[0];
		remove(next);
		return next;
	}
	
	
//	 Removes from the underlying collection the last element returned 
//	 by this iterator (optional operation). This method can be called 
//	 only once per call to next(). The behavior of an iterator is 
//	 unspecified if the underlying collection is modified while the 
//	 iteration is in progress in any way other than by calling this 
//	 method.
	
	/** 
	 * The remove operation is not supported in this implementation of
	 * Iterator
	 */
	@Override
	public void remove() {
		throw new UnsupportedOperationException();
	}

}
