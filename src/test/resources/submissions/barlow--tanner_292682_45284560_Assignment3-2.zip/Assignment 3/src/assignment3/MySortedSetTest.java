package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Scanner;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * 
 * @author Tanner Barlow
 * @author Elijah Grubb
 */
public class MySortedSetTest {
	
	public MySortedSet<Integer> set1, set2, set3, emptySet;
	public ArrayList<Integer> a1, nullList, set1arrayList;
	public MySortedSet<String> stringSet1, stringSet2, stringSet3, emptyStringSet;
	public ArrayList<String> s1, nullStringList, stringSet1arrayList;
	public MySortedSet<PhoneNumber> phoneNumberSet;
	

	@Before
	public void setUp() throws Exception {
		OrderByInt comparator = new OrderByInt();
		set1 = new MySortedSet<Integer>(comparator);
		set1.add(1);
		set1.add(2);
		set1.add(3);
		set1.add(15);
		set1.add(55);
		
		set2 = new MySortedSet<Integer>();
		set2.add(1);
		set2.add(2);
		set2.add(3);
		set2.add(15);
		set2.add(55);
		
		set3 = new MySortedSet<Integer>();
		set3.add(1);
		set3.add(2);
		set3.add(3);
		set3.add(15);
		set3.add(55);
		
		emptySet = new MySortedSet<Integer>();
		
		a1 = new ArrayList<Integer>();
		nullList = new ArrayList<Integer>();
		set1arrayList = new ArrayList<Integer>();
		
		a1.add(5);
		a1.add(81);
		a1.add(242);
		a1.add(76);
		a1.add(2);
		a1.add(-6);
		a1.add(-80);

		set1arrayList.add(1);
		set1arrayList.add(2);
		set1arrayList.add(3);
		set1arrayList.add(15);
		set1arrayList.add(55);
		
		stringSet1 = new MySortedSet<String>();
		stringSet1.add("a");
		stringSet1.add("b");
		stringSet1.add("c");
		stringSet1.add("m");
		stringSet1.add("v");
		
		stringSet2 = new MySortedSet<String>();
		stringSet2.add("a");
		stringSet2.add("b");
		stringSet2.add("c");
		stringSet2.add("m");
		stringSet2.add("v");
		
		stringSet3 = new MySortedSet<String>();
		stringSet3.add("a");
		stringSet3.add("b");
		stringSet3.add("c");
		stringSet3.add("m");
		stringSet3.add("v");
		
		emptyStringSet = new MySortedSet<String>();
		
		s1 = new ArrayList<String>();
		nullStringList = new ArrayList<String>();
		stringSet1arrayList = new ArrayList<String>();
		
		s1.add("e");
		s1.add("Ab");
		s1.add("zzzoinks");
		s1.add("76");
		s1.add("b");
		s1.add("AAA");
		s1.add("aaaa");

		stringSet1arrayList.add("a");
		stringSet1arrayList.add("b");
		stringSet1arrayList.add("c");
		stringSet1arrayList.add("m");
		stringSet1arrayList.add("v");
		
		phoneNumberSet = new MySortedSet<PhoneNumber>(new OrderByPhoneNumber());
		phoneNumberSet.add(new PhoneNumber("8014755421"));
		phoneNumberSet.add(new PhoneNumber("8015555555"));
		phoneNumberSet.add(new PhoneNumber("8016555315"));
		phoneNumberSet.add(new PhoneNumber("3855555555"));
		phoneNumberSet.add(new PhoneNumber("8012555555"));
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * tests the clear method to make sure everything is removed
	 */
	@Test
	public void testClear1() {
		set1.clear();
		assertEquals(0, set1.size());
	}
	
	/**
	 * tests the isEmpty method to make sure it really knows the truth
	 */
	@Test
	public void testIsEmpty1() {
		assertEquals(true,emptySet.isEmpty());
	}
	
	/**
	 * tests the isEmpty method to make sure it really knows the truth
	 */
	@Test
	public void testIsEmpty2() {
		assertEquals(false,set1.isEmpty());
	}
	
	/**
	 * Tests to make sure the binary search in contains works when using comparator
	 */
	@Test
	public void testContains1() {
		assertEquals(true, set1.contains(new Integer(3)));
		assertEquals(false, set1.contains(new Integer(4)));
	}
	
	/**
	 * Tests to make sure the binary search in contains works when using comparable
	 */
	@Test
	public void testContains2() {
		assertEquals(true, set2.contains(new Integer(3)));
		assertEquals(false, set2.contains(new Integer(4)));
	}
	
	/**
	 * tests to make sure that contains works when iterated over a list through
	 * contains all
	 */
	@Test
	public void testContainsAll1() {
		assertEquals(true, set1.containsAll(set1arrayList));
	}
	
	/**
	 * tests to make sure that contains works when iterated over a list through
	 * contains all
	 */
	@Test
	public void testContainsAll2() {
		assertEquals(false, set1.containsAll(nullList));
	}
	
	/**
	 * tests to make sure that contains works when iterated over a list through
	 * contains all
	 */
	@Test
	public void testContainsAll3() {
		assertEquals(false, set1.containsAll(a1));
	}
	
	/**
	 * makes sure that everything is added alright
	 */
	@Test
	public void testAdd1() {
		assertEquals(true, set1.add(4));
		assertEquals(true,set1.add(-1));
		assertEquals(true,set1.add(50000));
	}
	
	/**
	 * shouldn't add it since it's already in this list
	 */
	@Test
	public void testAdd2() {
		assertEquals(false, set1.add(1));
	}
	
	/**
	 * tests to make sure that add works when iterated over a list through
	 * add all
	 */
	@Test
	public void testAddAll1() {
		assertEquals(true,set2.addAll(a1));
		assertEquals(false,set2.addAll(nullList));
	}

	/**
	 * makes sure that objects are really removed from MySortedSet
	 */
	@Test
	public void testRemove1() {
		assertEquals(true,set1.remove(3));
		assertEquals(false,set1.contains(3));
	}
	
	/**
	 * makes sure that objects are really removed from MySortedSet
	 */
	@Test
	public void testRemove2() {
		assertEquals(false,set1.remove(70));
	}
	
	/**
	 * tests to make sure that remove works when iterated over a list through
	 * remove all
	 */
	@Test
	public void testRemoveAll1() {
		assertEquals(true,set1.removeAll(set1arrayList));
		assertEquals(0,set1.size());
	}
	
	/**
	 * tests to make sure that remove works when iterated over a list through
	 * remove all
	 */
	@Test
	public void testRemoveAll2() {
		assertEquals(false,set1.removeAll(nullList));
	}
	
	/**
	 * makes sure a proper iterator and working functions are returned when calling
	 * the iterator method
	 */
	@Test
	public void testIterator1() {
		assertEquals(true, set2.iterator().hasNext());
	}
	
	/**
	 * makes sure a proper iterator and working functions are returned when calling
	 * the iterator method
	 */
	@Test
	public void testIterator2() {
		try {
			set2.iterator().remove();
			fail("Should have thrown an UnsupportedOperationException");
		} catch (UnsupportedOperationException e) {
		}
	}
	
	/**
	 * makes sure a proper iterator and working functions are returned when calling
	 * the iterator method
	 */
	@Test
	public void testIterator3() {
		Iterator<Integer> iterator = set3.iterator();
		assertEquals((Integer) 1, iterator.next());
		assertEquals((Integer) 2, iterator.next());
		assertEquals((Integer) 3, iterator.next());
		assertEquals(true, iterator.hasNext());
		assertEquals((Integer) 15, iterator.next());
		assertEquals((Integer) 55, iterator.next());
		assertEquals(false, iterator.hasNext());
		try {
			iterator.next();
			fail("Should have thrown a NoSuchElementException");
		} catch (NoSuchElementException e) {
		}
	}
	
	/**
	 * Make sure some of the basic functions work with objects besides Integers
	 * so we used Prof Meyer's PhoneNumbers class from Assignment 2
	 */
	@Test
	public void testWithPhoneNumbers1() {
		assertEquals(false, phoneNumberSet.add(new PhoneNumber("8014755421")));
		assertEquals(true, phoneNumberSet.add(new PhoneNumber("3854555555")));
		assertEquals(true, phoneNumberSet.contains(new PhoneNumber("3855555555")));
		assertEquals(false, phoneNumberSet.contains(new PhoneNumber("3855557555")));
	}
	
	// ALL OF THIS BELOW IS THE EXACT SAME TESTING WE DID WITH INTEGERS ABOVE BUT 
	// NOW WE'RE USING STRINGS INSTEAD TO MAKE SURE IT STILL WORKS
	
	/**
	 * tests the clear method to make sure everything is removed
	 */
	@Test
	public void testStringClear1() {
		stringSet1.clear();
		assertEquals(0, stringSet1.size());
	}
	
	/**
	 * tests the isEmpty method to make sure it really knows the truth
	 */
	@Test
	public void testStringIsEmpty1() {
		assertEquals(true,emptyStringSet.isEmpty());
	}
	
	/**
	 * tests the isEmpty method to make sure it really knows the truth
	 */
	@Test
	public void testStringIsEmpty2() {
		assertEquals(false,stringSet1.isEmpty());
	}
	
	/**
	 * Tests to make sure the binary search in contains works when using comparator
	 */
	@Test
	public void testStringContains1() {
		assertEquals(true, stringSet1.contains("c"));
		assertEquals(false, stringSet1.contains("d"));
	}
	
	/**
	 * Tests to make sure the binary search in contains works when using comparable
	 */
	@Test
	public void testStringContains2() {
		assertEquals(true, stringSet2.contains("c"));
		assertEquals(false, stringSet2.contains("d"));
	}
	
	/**
	 * tests to make sure that contains works when iterated over a list through
	 * contains all
	 */
	@Test
	public void testStringContainsAll1() {
		stringSet1.addAll(stringSet1arrayList);
		assertEquals(true, stringSet1.containsAll(stringSet1arrayList));
	}
	
	/**
	 * tests to make sure that contains works when iterated over a list through
	 * contains all
	 */
	@Test
	public void testStringContainsAll2() {
		assertEquals(false, stringSet1.containsAll(nullStringList));
	}
	
	/**
	 * tests to make sure that contains works when iterated over a list through
	 * contains all
	 */
	@Test
	public void testStringContainsAll3() {
		assertEquals(false, stringSet1.containsAll(s1));
	}
	
	/**
	 * makes sure that everything is added alright
	 */
	@Test
	public void testStringAdd1() {
		assertEquals(true, stringSet1.add("d"));
	}
	
	/**
	 * shouldn't add it since it's already in this list
	 */
	@Test
	public void testStringAdd2() {
		assertEquals(false, stringSet1.add("a"));
	}
	
	/**
	 * tests to make sure that add works when iterated over a list through
	 * add all
	 */
	@Test
	public void testStringAddAll1() {
		assertEquals(true,stringSet2.addAll(s1));
		assertEquals(false,stringSet2.addAll(nullStringList));
	}

	/**
	 * makes sure that objects are really removed from MySortedSet
	 */
	@Test
	public void testStringRemove1() {
		assertEquals(true,stringSet1.remove("c"));
		assertEquals(false,stringSet1.contains("c"));
	}
	
	/**
	 * makes sure that objects are really removed from MySortedSet
	 */
	@Test
	public void testStringRemove2() {
		assertEquals(false,stringSet1.remove("howdy"));
	}
	
	/**
	 * tests to make sure that remove works when iterated over a list through
	 * remove all
	 */
	@Test
	public void testStringRemoveAll1() {
		assertEquals(true,stringSet1.removeAll(stringSet1arrayList));
		assertEquals(0,stringSet1.size());
	}
	
	/**
	 * tests to make sure that remove works when iterated over a list through
	 * remove all
	 */
	@Test
	public void testStringRemoveAll2() {
		assertEquals(false,stringSet1.removeAll(nullStringList));
	}
	
	/**
	 * makes sure a proper iterator and working functions are returned when calling
	 * the iterator method
	 */
	@Test
	public void testStringIterator1() {
		assertEquals(true, stringSet2.iterator().hasNext());
	}
	
	/**
	 * makes sure a proper iterator and working functions are returned when calling
	 * the iterator method
	 */
	@Test
	public void testStringIterator2() {
		try {
			stringSet2.iterator().remove();
			fail("Should have thrown an UnsupportedOperationException");
		} catch (UnsupportedOperationException e) {
		}
	}
	
	/**
	 * makes sure a proper iterator and working functions are returned when calling
	 * the iterator method
	 */
	@Test
	public void testStringIterator3() {
		Iterator<String> iterator = stringSet3.iterator();
		assertEquals((String) "a", iterator.next());
		assertEquals((String) "b", iterator.next());
		assertEquals((String) "c", iterator.next());
		assertEquals(true, iterator.hasNext());
		assertEquals((String) "m", iterator.next());
		assertEquals((String) "v", iterator.next());
		assertEquals(false, iterator.hasNext());
		try {
			iterator.next();
			fail("Should have thrown a NoSuchElementException");
		} catch (NoSuchElementException e) {
		}
	}
}
	
/**
 * Comparator built to make sure that side of MySortedSet is working
 */
class OrderByInt implements Comparator<Integer> {

	@Override
	public int compare(Integer o1, Integer o2) {
		return o1 - o2;
	}
	
}

/**
 * Comparator for the PhoneNumber built to make sure that side of MySortedSet is working
 * and to enable us to actually sort PhoneNumber
 * 
 * (Not sure how well this comparator actually works.. I'm not a regex expert)
 *
 */
class OrderByPhoneNumber implements Comparator<PhoneNumber> {

	@Override
	public int compare(PhoneNumber p1, PhoneNumber p2) {
		String leftPhoneNum = p1.toString().replaceAll("-|\\s|\\.|\\(|\\)", "");
		String rightPhoneNum = p2.toString().replaceAll("-|\\s|\\.|\\(|\\)", "");
		
		long lhs = Long.parseLong(leftPhoneNum);
		long rhs = Long.parseLong(rightPhoneNum);
		
		return (int) (lhs - rhs);
	}
	
}
