package assignment3;

public class TimingExperiment08 {

  public static void main(String[] args) {
	  
	MySortedSet<Integer> testSet = new MySortedSet<Integer>();
	final int SET_SIZE = 2000000;
	
	for(int i = 1; i <= SET_SIZE; i++)
	{
		testSet.add(i);
	}
    long startTime, midpointTime, stopTime;

    // First, spin computing stuff until one second has gone by.
    // This allows this thread to stabilize.

    startTime = System.nanoTime();
    while (System.nanoTime() - startTime < 1000000000) { // empty block
    }

    // Now, run the test.

    long timesToLoop = 100000;

    startTime = System.nanoTime();

    for (long i = 0; i < timesToLoop; i++)
    	testSet.contains(-1);

    midpointTime = System.nanoTime();

    // Run an empty loop to capture the cost of running the loop.

    for (long i = 0; i < timesToLoop; i++) { // empty block
    }

    stopTime = System.nanoTime();

    // Compute the time, subtract the cost of running the loop
    // from the cost of running the loop and computing square roots.
    // Average it over the number of runs.

    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
        / timesToLoop;

    System.out.println("It takes exactly " + averageTime
        + " nanoseconds to run the \ncontains method on"
        + " a set the size of " + SET_SIZE);
  }
}