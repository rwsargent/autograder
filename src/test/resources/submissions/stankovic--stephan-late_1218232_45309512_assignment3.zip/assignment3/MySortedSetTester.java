package assignment3;

import static org.junit.Assert.*;

import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTester<E> {

	private MySortedSet set1, set2;
	
	@Before
	public void setUp() throws Exception {
		set1 = new MySortedSet();
		set2 = new MySortedSet();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddAndBinarySearchAndFirst() {
		set1.add(3);
		set1.add(7);
		set1.add(1);
		set1.add(0);
		assertEquals(0, set1.first());
	}
	
	@Test
	public void testLast(){
		set1.add(3);
		set1.add(7);
		set1.add(1);
		set1.add(100);
		set1.add(10000);
		assertEquals(10000, set1.last());
	}

	@Test
	public void testContains(){
		set1.add("String");
		set1.add("Happy Birthday");
		set1.add("Love");
		set1.add("UofU");
		assertEquals(false, set1.contains("Freak"));
	}

	@Test
	public void testIsFirst() {
		set1.add(3);
		set1.add(7);
		set1.add(1);
		assertEquals(1, set1.first());
	}
	
	@Test
	public void testIsLast(){
		set1.add(4);
		set1.add(9);
		set1.add(45);
		set1.add(89);
		set1.add(1);
		set1.add(10000);
		assertEquals(10000, set1.last());
	}

	@Test
	public void testIsRemove(){
		set1.add(4);
		set1.add(9);
		set1.add(45);
		set1.add(89);
		set1.add(1);
		assertEquals(false, set1.remove(6));
	}
	
	@Test
	public void testIsEmpty(){
		assertEquals(true, set2.isEmpty());
		
	}
	
	@Test
	public void testIsEmpty2(){
		set1.add("ello");
		set1.add("xyz");
		set1.add("tree");
		set1.add("fish");
		assertEquals(false, set1.isEmpty());
		
	}
	
	@Test
	public void testSize(){
		set1.add(4);
		set1.add(9);
		set1.add(45);
		set1.add(89);
		set1.add(1);
		set1.add(10000);
		set1.clear();
		assertEquals(0, set1.size());
	}
	
	@Test
	public void testIsFirst2(){
		set1.add("ello");
		set1.add("xyz");
		set1.add("tree");
		set1.add("fish");
		set1.clear();
		assertEquals(null, set1.first());
		
	}
	
	@Test
	public void testIsEmpty3(){
		set1.add(4);
		set1.add(9);
		set1.add(45);
		set1.add(89);
		set1.add(1);
		set1.add(0);
		set1.add(10000);
		set1.clear();
		assertEquals(true, set1.isEmpty());
	}
	
	@Test
	public void testBinarySearch(){
		set1.add(4);
		set1.add(9);
		set1.add(45);
		set1.add(89);
		set1.add(1);
		set1.add(0);
		set1.add(10000);
		assertEquals(true, set1.binarySearch(45));
		
	}
	
	@Test
	public void testBinarySearch2(){
		set1.add(4);
		set1.add(9);
		set1.add(45);
		set1.add(89);
		set1.add(1);
		set1.add(0);
		set1.add(10000);
		assertEquals(false, set1.binarySearch(13));
		
	}
}
