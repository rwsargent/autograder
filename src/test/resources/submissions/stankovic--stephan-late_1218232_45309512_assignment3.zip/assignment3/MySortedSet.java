package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This is a class that will contain any type of object and place it in a sorted set
 * which adds everything in order already. 
 * 
 * @author Stephan Stankovic
 * @author Austin Chen
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E mySet[];
	private int count;
	private Comparator<? super E> myComparator;
	private boolean isUsingComp;

	/**
	 * The constructor
	 */
	public MySortedSet(){
		mySet = (E[]) new Object[10];
		count = 0;
		isUsingComp = false;
		//a.compareTo(b)
	}

	/**
	 * Second constructor that will take in a comparator
	 * 
	 * @param c - our comparator
	 */
	public MySortedSet(Comparator<? super E> c){
		mySet = (E[]) new Object[10];
		count = 0;
		// c.compare(a, b)
		myComparator = c;
		isUsingComp = true;
	}

	/**
	 * Returns the comparator that was passed in with the constructor
	 */
	public Comparator<? super E> comparator() {
		return myComparator;
	}

	/**
	 * This method will simply return what is in the first position of the 
	 * SortedSet. 
	 * 
	 * @return The first element in the array
	 * 
	 * @throws NoSuchElementExcetion if element doesn't exist
	 */
	public E first() throws NoSuchElementException {
		if(mySet.length == 0)
			throw new NoSuchElementException();
		return mySet[0];
	}

	/**
	 * This method will return the last element in our SortedSet. And throw an 
	 * exception if there is no such element. 
	 * 
	 * @return The last element in the array
	 * 
	 * @throws NoSuchelementException if element doesn't exist
	 */
	public E last() throws NoSuchElementException {
		if(mySet.length == 0)
			throw new NoSuchElementException();
		return mySet[count - 1];
	}

	/**
	 * Adds an element into the array in sorted order using binarySearch and 
	 * binaryIndex
	 * 
	 * @return - false if array already contains the element or true if it adds 
	 * 		     an element into the array
	 */
	public boolean add(E o){
		//Doubles the array if current array is full.
		if(count == mySet.length){
			E[] newSet = (E[]) new Object[mySet.length * 2];
			newSet = mySet;
		}
		if (binarySearch(o) == false){
			int mid = binaryIndex(o);
			
			//Shifts everything in the array to the right.
			for (int i = count; i >= mid; i--){
				mySet[i + 1] = mySet[i];
			}
			mySet[mid] = o;
			count++;
			return true;
		}
		return false;
	}

	/**
	 * This method will add everything in a collection into our SortedSet.
	 * 
	 * @return - Returns true if our Set changed and false if it didn't
	 */
	public boolean addAll(Collection<? extends E> c) {
		boolean changed = false;
		while(c.iterator().hasNext()){
			this.add(c.iterator().next());
			changed = true;
		}
		return changed;
	}

	/**
	 * Clears our Set and sets count to 0
	 */
	public void clear() {
		E emptySet[] = (E[]) new Object[10];
		mySet = emptySet;
		count = 0;
	}

	/**
	 * Searches the array for the specific element
	 * 
	 * @return - true if the array contains the element or false if not
	 */
	public boolean contains(Object o){
		return this.binarySearch((E) o);
	}

	/**
	 * This method will check if the entire collection sits in our SortedSet
	 * 
	 * @return - Returns true if the entire collection is in our SortedSet, and False if not.
	 */
	public boolean containsAll(Collection<?> c) {
		boolean contained = false;
		while(c.iterator().hasNext())
			if(!this.contains(c.iterator().next()))
				return contained;
			else
				contained = true;
		return contained;
	}

	/**
	 * This method checks if our SortedSet is empty
	 * 
	 * @return True if the array contains no elements or False if it does contain some elements
	 */
	public boolean isEmpty() {
		if(count > 0)
			return false;
		return true;
	}

	/**
	 * This method simply makes our iterator usable with this keyword.
	 * 
	 * @return - returns the iterator class
	 */
	public Iterator<E> iterator() {
		return new SortedSetIterator();
	}

	/**
	 * This method will remove an element from our SortedSet and shift it so that it is again sorted. Also
	 * updates our count. 
	 * 
	 * @return - Returns true if our SortedSet contained the object we are looking to remove
	 */
	public boolean remove(Object o){
		//Shifts everything in the array to the left.
		boolean contained = false;
		if(this.binarySearch((E)o) == true){
			mySet[binaryIndex((E) o)] = mySet[binaryIndex((E) o) + 1];
			contained = true;
		}
		count--;
		return contained;

	}

	/**
	 * This method will remove an entire collection from our SortedSet, only if the Set contains
	 * all the items in collection
	 * 
	 * @return - This returns true if our array was changed or false if not
	 */
	public boolean removeAll(Collection<?> c){
		boolean changed = false;
		while(c.iterator().hasNext()){
			this.remove(c.iterator().next());
			changed = true;
		}
		return changed;
	}

	/**
	 * Returns the number of elements in our set
	 * 
	 * @return the number of elements
	 */
	public int size(){
		return count;
	}

	/**
	 * Converts our SortedSet into an Array. 
	 * 
	 * @return - Returns an object array.
	 */
	public Object[] toArray(){
		return mySet;
	}

	/**
	 * This method will return the index after running a binarySearch on our Set with the said
	 * element. 
	 *  
	 * @param o - this is the item we are searching a place for
	 * @return - this will return the mid point or the point where the item should be added into the 
	 * 			 Sorted Set. 
	 */
	public int binaryIndex(E o){
		int min = 0;
		int max = count - 1;
		int mid = 0;
		int result = 0;
		while (min <= max)	{
			mid = (min + max)/2;

			if(isUsingComp == true){
				result = myComparator.compare(o, mySet[mid]);
			}
			else if(isUsingComp == false){
				result = ((Comparable<E>) o).compareTo(mySet[mid]);
			}

			if(result > 0){
				min = mid + 1;
			}
			else if(result < 0){
				max = mid - 1;
			}
			else{
				return mid;
			}
		}
		if(min > mid)
			return mid + 1;
		else
			return mid;
	}

	/**
	 * This method will search through our set, looking for the passed in object,
	 * and it will also return true or false if the item was located in our set
	 * 
	 * @param o - This is the object that we are searching for in the set
	 * 
	 * @return - returns true if the item is in the set, or false if it wasn't
	 */
	public boolean binarySearch(E o){
		int min = 0;
		int max = count - 1;
		int mid = 0;
		int result = 0;
		while (min <= max)	{
			mid = (min + max)/2;

			if(isUsingComp == true){
				result = myComparator.compare(o, mySet[mid]);
			}	
			else if(isUsingComp == false){
				result = ((Comparable<E>) o).compareTo(mySet[mid]);
			}

			if(result > 0){
				min = mid + 1;
			}
			else if(result < 0){
				max = mid - 1;
			}
			else if(result == 0) {
				return true;
			}
		}
		return false;	
	}

	/**
	 * This is the iterator class for iterating through our sorted set. 
	 * 
	 * @author Stephan Stankovic
	 * @author Austin Chen
	 *
	 */
	private class SortedSetIterator implements Iterator<E>{
		int index = 0;
		boolean gotNext = false;

		/**
		 * This method tells us if there is another item in the next spot of our set.
		 * 
		 * @return - Returns a boolean telling us if our sorted set has something in the next
		 * 			 position. 
		 */
		@Override
		public boolean hasNext(){
			return index < mySet.length - 1;
		}

		/**
		 * This method will return the next object/item in our sorted set.
		 * 
		 * @return - Returns object E
		 */
		@Override
		public E next(){
			if(index >= count - 1){
				throw new NoSuchElementException();
			}
			index ++;
			gotNext = true;
			return mySet[index];
		}

		/**
		 * There is no return, and it removes the item in the last index that we iterated through
		 */
		@Override
		public void remove(){
			if(gotNext)
			{
				MySortedSet.this.remove(mySet[index]);
				gotNext = false;
				index --;
			}
			else{
				throw new UnsupportedOperationException();
			}
		}
	}
}
