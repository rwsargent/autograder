package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Jacob Bullard
 * @author Alfred Neufeld
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */

public class MySortedSet <E> implements SortedSet<E>

{
	private E[] data;									// array that stores our set
	private int size; 									// the number of elements in the set
	private Comparator<? super E> comparator;			// comparator to be used if given to constructor
	private int globalIndex;							// keeps track of a global current index in our set
	private int direction;								// keeps track of the direction to be added/removed from
	private MySortedSetIterator<E> iterator;	

	/**
	 * This constructor assumes that the objects in the set implement the Comparable Interface
	 */
	public MySortedSet ()
	{
		/* initialize variables */

		this.data = (E[]) new Object[10];
		this.size = 0;
		this.globalIndex = -1;
		this.iterator = new MySortedSetIterator<E>(this);

	}

	/**
	 * This constructor takes a comparator as a paramater which determines the ordering of the items in the
	 * set. 
	 * @param c - the comparator of the items 
	 */
	public MySortedSet(Comparator<? super E> c)
	{
		/* initialize variables */

		this.comparator = c;
		this.data = (E[]) new Object[10];
		this.size = 0;
		this.globalIndex = -1;
		this.iterator = new MySortedSetIterator<E>(this);
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() 
	{
		return this.comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException 
	{
		if(isEmpty())//if empty then no first element
			throw new NoSuchElementException();

		return this.data[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException 
	{
		if(isEmpty())//if empty no last element
			throw new NoSuchElementException();

		return this.data[this.size - 1];

	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) 
	{

		if(o.equals(null) || contains(o))		// if we are trying to add a null item or this set already contains the item trying to add, return false
			return false;

		// after calling contains, the global index should be pointing to where the element needs to be added

		if(this.globalIndex == -1)		// if the global index is -1 the set is empty, add the item and return
		{
			this.data[0] = o;
			this.size++;
			this.iterator.resetSet(this);
			return true;
		}

		if(this.size == this.data.length)	// if the size of the set has reached its capacity, grow before trying to add the item
			grow();

		E tempElementPointer1 = o;	// create a dummy variable to point to the item adding
		boolean itChecker = this.iterator.checkForShift(this.globalIndex);	//check to see if iterator is pointing at a moving object

		if(this.direction < 0)	// this means that the element adding goes to the right of the element at global index
		{
			if(this.globalIndex == this.size - 1)
			{
				this.data[this.globalIndex + 1] = tempElementPointer1;
				this.size++;
				this.iterator.resetSet(this);
				return true;
			}

			while(this.data[this.globalIndex + 1] != null)	// while there is an element to the right of the position we are seeking to add to
			{
				E tempElementPointer2 = (E) this.data[this.globalIndex];	// store the item in the current index in a temporary variable
				this.data[this.globalIndex] = tempElementPointer1;	// place the item adding into the array at the current index
				tempElementPointer1 = tempElementPointer2;	// make the next item to be added, the item that was just in the current index
				this.globalIndex++;	// increment the index

			}


			E tempElementPointer3 = (E) this.data[this.globalIndex];	// store the item in the current index in a temporary variable
			this.data[this.globalIndex] = tempElementPointer1;	// place the item adding into the array at the current index
			tempElementPointer1 = tempElementPointer3;	// make the next item to be added, the item that was just in the current index
			this.globalIndex++;	// increment the index
			if(itChecker)
			{this.iterator.shiftIndex(true);}


			this.data[this.globalIndex] = tempElementPointer1;	// if we reach here, we need to place the item we are currently holding into the array at the current position

			this.size++;	//increment the size
		}
		else	// this means that the element adding goes to the left of the element at global index
		{
			while(this.data[this.globalIndex + 1] != null)	// while there is an element to the right of the position we are seeking to add to
			{
				E tempElementPointer2 = (E) this.data[this.globalIndex];	// store the item in the current index in a temporary variable
				this.data[this.globalIndex] = tempElementPointer1;	// place the item adding into the array at the current index
				tempElementPointer1 = tempElementPointer2;	// make the next item to be added, the item that was just in the current index
				this.globalIndex++;	// increment the index

			}


			E tempElementPointer3 = (E) this.data[this.globalIndex];	// store the item in the current index in a temporary variable
			this.data[this.globalIndex] = tempElementPointer1;	// place the item adding into the array at the current index
			tempElementPointer1 = tempElementPointer3;	// make the next item to be added, the item that was just in the current index
			this.globalIndex++;	// increment the index
			if(itChecker)
			{this.iterator.shiftIndex(true);}


			this.data[this.globalIndex] = tempElementPointer1;							// if we reach here, we need to place the item we are currently holding into the array at the current position

			this.size++;	//increment the size
		}


		this.iterator.resetSet(this);
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) 
	{
		boolean changed = false;

		for(E ob : c)//loop through call add function
			if(add(ob))
				changed = true;

		this.iterator.resetSet(this);
		return changed;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() 
	{
		/*null the array to prevent issues*/
		for(int i=0; i<this.size();i++)
		{this.data[i]=null;}
			
		/*reset iterator set and this size*/
		this.size = 0;
		this.iterator.resetSet(this);
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) 
	{
		if(isEmpty())//if empty doesn not contain element
			return false;

		return binarySearchElementPos(o);
	}

	/**
	 * This method is used for testing purposes
	 * @param i - index of item seeking
	 * @return - the data of type E at the requested index
	 */
	public E get(int i)
	{
		return (E) this.data[i];
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) 
	{

		for(Object ob : c)//loop through collection and verify
			if(!contains(ob))
				return false;

		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() 
	{
		return this.size == 0;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() 
	{
		//this.iterator = new MySortedSetIterator<E>(this);
		return this.iterator;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object o) 
	{
		if(o == null || isEmpty() || !contains(o))			// if the set is empty, return false immediately
			return false;

		// if we are removing the only item in the set, do so and return
		if(this.size == 1)	
		{
			this.data[0] = null;
			this.size--;
			this.iterator.resetSet(this);
			return true;
		}

		
		boolean itChecker = this.iterator.checkForShift(this.globalIndex);//check to see if we need to shift iterator index
		/*Boundary Case Removing from end of list*/
		if(this.globalIndex >= this.size-1)
		{
			this.data[this.globalIndex]=null;

			if(itChecker)//if shift needed shift backwards
			{this.iterator.shiftIndex(false);}

			this.size--;//decrement size
			this.iterator.resetSet(this);
			return true;

		}

		/*General Case */
		while(this.globalIndex<this.size-1)
		{
			/*Shift all elemants to right of removal element back one space*/
			swap(this.globalIndex, this.globalIndex + 1);
			this.globalIndex++;
		}
		if(itChecker)//if shift needed shift backwards
		{this.iterator.shiftIndex(false);}

		this.data[this.globalIndex] = null;//null out last item
		this.size--;//decrement size
		this.iterator.resetSet(this);
		return true;

	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) 
	{
		boolean changed = false;

		for(Object ob : c)//loop and remove objects
			if(remove(ob))
				changed = true;

		this.iterator.resetSet(this);
		return changed;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() 
	{
		return this.size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() 
	{
		return this.data;
	}


	/**
	 * This method grows the array once it has reached its maximum capacity. 
	 * 
	 */
	private void grow()
	{
		E[] temp = (E[]) new Object[this.data.length*2];		// create a new array double the size of the last one

		for(int i = 0; i < this.size; i++)
			temp[i] = this.data[i];								// copy the data from the old array into the new one

		this.data = (E[]) temp;									// make sure that this sets data array points to the new one of double size
	}

	/**
	 * This method sets a private field variable, 'globalCurrentIndex', to either the position of an item in this set OR to the position
	 * where an item would need to be added. This method returns true if there is an item in our set. 
	 * 
	 * 
	 * @param goal - item searching for 
	 * @return true if the set contains the element
	 */
	private boolean binarySearchElementPos(Object goal)
	{
		int startIndex = 0;	// starting index
		int endIndex = this.size - 1;	// index of item in the last position in our array
		int mid = startIndex + ((endIndex - startIndex)/2);	// our middle index

		while(startIndex <= endIndex)					
		{

			mid = startIndex + ((endIndex - startIndex)/2);	// our middle index

			if(this.comparator != null)	// if we are using a comparator to order our items
			{

				int direction = this.comparator.compare( (this.data[mid]), (E) goal); // this determines the order relation
				this.direction = direction;

				switch (direction)
				{
				case (-1) :		// this is if the data at the midpoint is less than the goal data
				{
					startIndex = mid + 1;
					break;
				}
				case (1) :		// this is if the data at the midpoint is greater than the goal data
				{
					endIndex = mid - 1;
					break;
				}
				case (0) :		// this is if the data at the midpoint is equal to the goal data
				{
					this.globalIndex = mid;
					return true;
				}
				}

			}
			else
			{

				int direction = ((Comparable<E>) (this.data[mid])).compareTo((E) goal);	// this determines the order relation
				this.direction = direction;

				switch (direction)
				{
				case (-1) :	// this is if the data at the midpoint is less than the goal data
				{
					startIndex = mid + 1;
					break;
				}
				case (1) :	// this is if the data at the midpoint is greater than the goal data
				{
					endIndex = mid - 1;
					break;
				}
				case (0) :	// this is if the data at the midpoint is equal to the goal data
				{
					this.globalIndex = mid;
					return true;
				}
				}

			}
		}

		this.globalIndex = mid;	// if we have reached here, then the element is not in our set but this mid index is where it need to be added to
		return false;
	}

	/**
	 * This method swaps two elements of an array
	 * 
	 * @param l - the left element
	 * @param r - the right element
	 */
	private void swap(int l, int r)
	{
		E temp = (E) this.data[l];

		this.data[l] = this.data[r];

		this.data[r] = temp;

	}

	/**
	 * This class represents an iterator for the MySortedSet<E> class
	 * 
	 * @author Jacob Bullard
	 * @author Alfred Neufeld
	 * 
	 * @param <E>
	 */
	private class MySortedSetIterator<E> implements Iterator<E> {
		MySortedSet<E> set;// the iterator get the set object inside of it so it
							// can access fields and methods on the set in the
							// set
		int index = 0;// the index for the iterator
		E last;// the last element ouptut by the iterator

		/**
		 * --Constructor--
		 * 
		 * @param s
		 */
		protected MySortedSetIterator(MySortedSet<E> s) {
			this.set = s;// initialize the set variable
		}

		/**
		 * 
		 */
		public void resetSet(MySortedSet<E> s)
		{this.set=s;}
		
		/**
		 * This Method will check to see if the element being added is being
		 * added or removed before or after the element the iterator is current
		 * looking at.
		 * 
		 * @param index
		 *            -- index of the item being added or removed
		 */
		public boolean checkForShift(int index) {
			if (index <= this.index)// if the param index is less than the
									// iterator index then a shift will be
									// required
				return true;
			else
				// otherwise
				return false;

		}

		/**
		 * This method increments the index of the iterator based on the param
		 * boolean
		 * 
		 * @param dir
		 *            -- Boolean representing incrementation or decrementation
		 */
		public void shiftIndex(boolean dir) {
			if (dir)
				this.index++;
			else
				this.index--;

		}

		/**
		 * This Method will look and see if there is another item in the set
		 * 
		 * @return Boolean telling if there is or is not another element in the
		 *         list
		 */
		@Override
		public boolean hasNext() {

			if (this.set.data[index] != null)// if the data we are looking at is
												// not null
				return true;// return true

			else// we are at end of list
			{
				/*
				 * NOTE: We chose to reset the index as gesture of good faith to
				 * programmers who check objects before they try to use them.
				 * This way so long as the person is calling the hasNext
				 * function before the next function the program will not blow
				 * up because the index will be reset to 0 at end of the list
				 */
				this.index = 0;// reset the index
				return false;// return false
			}

		}

		/**
		 * This method will return the item the index is currently on and the
		 * point the index at the next element
		 * 
		 * @return E the data element the index is currently pointing to
		 */
		@Override
		public E next() {
			if (!this.hasNext()) {
				throw new NoSuchElementException();
			}// if calling next at the end of the list blow up

			/* Otherwise */
			int temp = index;// save the current index
			this.index++;// increment the index
			this.last = this.set.data[temp];// save the object as the last
											// object output
			return this.set.data[temp];// return the current object
		}

		/**
		 * This Method will remove the last data element output by the next
		 * function
		 * 
		 */
		@Override
		public void remove() {

			if (this.last == null || set.data[this.index] == null) {
				throw new IllegalStateException();
			}// if last has not been set meaning the next function has not yet
				// been called
			// or we are calling remove on the end of the list

			/* Otherwise */
			else {
				this.set.remove(last);
			}// remove the last object ouput by the iterator

		}

	}
}

