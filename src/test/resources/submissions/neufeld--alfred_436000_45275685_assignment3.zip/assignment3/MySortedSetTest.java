package assignment3;
/*--MySortedSetTest--
 * This is a set of testing for the MySortedSet class
 * 
 * @author Jacob Bullard
 * @author Alfred Neufeld
 * 
 */
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.NoSuchElementException;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest 
{

	/*fields for holding various Sets and collections*/
	MySortedSet<Integer> ints;
	MySortedSet<Object> obs;
	Collection<Integer> intColl;
	Collection<Integer> intColl2;
	Collection<Integer> intColl3;
	Collection<Integer> intCollEmpty;
	
	
	@Before
	public void setUp() throws Exception 
	{
		/*Initialize fields*/
		ints = new MySortedSet<Integer>();
		obs = new MySortedSet<Object>();
		
		intColl = new ArrayList<Integer>();
		intColl2 = new ArrayList<Integer>();
		intColl3 = new ArrayList<Integer>();
		intCollEmpty = new ArrayList<Integer>();
		
		intColl.add(6);
		
		intColl2.add(5);
		intColl2.add(4);
		
		intColl3.add(3);
		intColl3.add(2);
		intColl3.add(1);
		
		
		
	}

	@After
	public void tearDown() throws Exception 
	{
	}

	@Test
	public void testEmpty() 
	{
		assertEquals(true, ints.isEmpty());//testing isEmpty function
	}
	
	@Test
	public void testAddInt() 
	{
		assertEquals(true, ints.add(5));//test add
		assertEquals(false, ints.isEmpty());//test that the list is not empty
		assertEquals(1,ints.size());//test that the size is 1
	}
	
	@Test
	public void testAddDupeInt() 
	{
		/*Try adding two ints that are = and verify that the second one does not get added*/
		assertEquals(true, ints.add(5));
		assertEquals(false, ints.add(5));
		assertEquals(false, ints.isEmpty());
		assertEquals(1,ints.size());
	}
	
	@Test
	public void testAddTwoIntsAsc() 
	{
		/*Add two ints verify size and order*/
		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(6));
		assertEquals(2,ints.size());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddTwoIntsDesc() 
	{
		/*Add two ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(4));
		assertEquals(2,ints.size());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddThreeIntsAsc() 
	{
		/*Add three ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(6));
		assertEquals(true, ints.add(7));
		assertEquals(3,ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddThreeIntsDesc() 
	{
		/*Add three ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(4));
		assertEquals(true, ints.add(3));
		assertEquals(3,ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddThreeIntsAltAsc() 
	{
		/*Add three ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(6));
		assertEquals(true, ints.add(4));
		assertEquals(3,ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddThreeIntsAltDesc() 
	{
		/*Add three ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(4));
		assertEquals(true, ints.add(6));
		assertEquals(3,ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddFourIntsAsc() 
	{
		/*Add four ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(6));
		assertEquals(true, ints.add(7));
		assertEquals(true, ints.add(8));
		assertEquals(4, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddFourIntsDesc() 
	{
		/*Add four ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(4));
		assertEquals(true, ints.add(3));
		assertEquals(true, ints.add(2));
		assertEquals(4, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddFourIntsAltAsc() 
	{
		/*Add four ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(6));
		assertEquals(true, ints.add(4));
		assertEquals(true, ints.add(3));
		assertEquals(4, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddFourIntsAltDesc() 
	{
		/*Add four ints verify size and order*/

		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(4));
		assertEquals(true, ints.add(6));
		assertEquals(true, ints.add(7));
		assertEquals(4, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testGrow() 
	{
		/*Add enough ints to make the array grow its self
		 * verify size and order*/
		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(6));
		assertEquals(true, ints.add(4));
		assertEquals(true, ints.add(7));
		assertEquals(true, ints.add(3));
		assertEquals(true, ints.add(8));
		assertEquals(true, ints.add(2));
		assertEquals(true, ints.add(9));
		assertEquals(true, ints.add(1));
		assertEquals(true, ints.add(10));
		assertEquals(true, ints.add(0));
		assertEquals(true, ints.add(11));
		assertEquals(true, ints.add(-1));
		assertEquals(true, ints.add(12));
		
		assertEquals(14, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testFirstEmpty() 
	{
		/*Make sure the exception is thrown*/
		try
		{
			assertEquals(new NoSuchElementException(), ints.first());
		}
		catch(NoSuchElementException nse)
		{
			
		}
	}
	
	@Test
	public void testFirst() 
	{
	
		/*Add one item to Set verify it is the first item*/
		ints.add(7);
		assertEquals((Integer)7, ints.first());
	}
	
	@Test
	public void testLastEmpty() 
	{
		/*Make sure the exception is thrown*/
		
		try
		{
			assertEquals(new NoSuchElementException(), ints.last());
		}
		catch(NoSuchElementException nse)
		{
			
		}
	}
	
	@Test
	public void testLast() 
	{
		
		/*verify that the last number is the biggest and that the last function is working*/
		ints.add(7);
		ints.add(6);
		ints.add(420);
		assertEquals((Integer)420, ints.last());
	}
	
	@Test
	public void testAddAllEmptyToEmpty() 
	{
		/*verify that adding empty collection returns false*/
		assertEquals(false, ints.addAll(intCollEmpty));
	}
	
	@Test
	public void testAddAllEmptyToOne() 
	{
		/*add a collection of one and verify size and order*/
		assertEquals(true, ints.addAll(intColl));
		assertEquals(1, ints.size());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddAllEmptyToOneDupe() 
	{
		/*Make sure not addind duplicates in addAll verify size and order*/
		ints.add(6);
		assertEquals(false, ints.addAll(intColl));
		assertEquals(1, ints.size());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddAllEmptyToTwo() 
	{
		/*Test addAll verify size and order*/
		assertEquals(true, ints.addAll(intColl2));
		assertEquals(2, ints.size());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddAllEmptyToTwoBothDupes() 
	{
		/*test that addAll is not addidng duplicates verify size and order */
		ints.add(5);
		ints.add(4);
		assertEquals(false, ints.addAll(intColl2));
		assertEquals(2, ints.size());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testAddAllEmptyToTwoOneDupe() 
	{
		/*test that addAll will still add elements that do no exist verify size and order*/
		ints.add(5);
		assertEquals(true, ints.addAll(intColl2));
		assertEquals(2, ints.size());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testClearEmpty() 
	{
		/*Verify results for clearing empty list*/
		ints.clear();
		assertEquals(0, ints.size());
		
	}
	
	@Test
	public void testClearFull() 
	{
		/*Add a bunch of elements to the list*/
		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(6));
		assertEquals(true, ints.add(4));
		assertEquals(true, ints.add(7));
		assertEquals(true, ints.add(3));
		assertEquals(true, ints.add(8));
		assertEquals(true, ints.add(2));
		assertEquals(true, ints.add(9));
		assertEquals(true, ints.add(1));
		assertEquals(true, ints.add(10));
		assertEquals(true, ints.add(0));
		assertEquals(true, ints.add(11));
		assertEquals(true, ints.add(-1));
		assertEquals(true, ints.add(12));
		
		/*Verify size and not Empty*/
		assertEquals(14, ints.size());
		assertEquals(false, ints.isEmpty());
		/*Test Clear*/
		ints.clear();
		assertEquals(true, ints.isEmpty());
		assertEquals(0, ints.size());
		
		
	}
	
	@Test
	public void testContains() 
	{
		/*add numbers and verify that the set contains them*/
		
		assertEquals(false, ints.contains(null));
		
		ints.add(1);
		assertEquals(true,ints.contains(1));
		
		ints.add(0);
		assertEquals(true,ints.contains(1));
		assertEquals(true,ints.contains(0));
		
		ints.add(-5);
		assertEquals(true,ints.contains(1));
		assertEquals(true,ints.contains(0));
		assertEquals(true,ints.contains(-5));
		
		ints.add(-7);
		assertEquals(true,ints.contains(1));
		assertEquals(true,ints.contains(0));
		assertEquals(true,ints.contains(-5));
		assertEquals(true,ints.contains(-7));
		
		
	}
	
	@Test
	public void testContainsAllEmpty() 
	{
		
		/*test containsAll on an empty list*/
		assertEquals(true,ints.containsAll(intCollEmpty));
		
	}
	
	@Test
	public void testContainsAllOne() 
	{
		
		/*test containsAll on list of one collection of one*/
		ints.add(6);
		assertEquals(true,ints.containsAll(intColl));
		
	}
	
	@Test
	public void testContainsAllTwo() 
	{
		/*test containsAll on collection of two*/
		ints.add(5);
		assertEquals(false,ints.containsAll(intColl2));
		
		ints.add(4);
		assertEquals(true,ints.containsAll(intColl2));
		
	}
	
	@Test
	public void testRemoveEmpty() 
	{
		/*Test Remove on an empty list*/
		assertEquals(false, ints.remove(5));
		
	}
	
	@Test
	public void testRemoveOne() 
	{
		/*Test Removing One Item*/
		ints.add(5);
		assertEquals(true, ints.remove(5));
		assertEquals(0, ints.size());
		assertEquals(true, ints.isEmpty());
		
	}
	
	@Test
	public void testRemoveFirst() 
	{
		/*test Remove on Set with more than one Item verify size and order*/
		ints.add(5);
		ints.add(6);
		ints.add(7);
		assertEquals(true, ints.remove(5));
		assertEquals(2, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
		
	}
	
	@Test
	public void testRemoveLast() 
	{
		/*test Remove on Set with more than one Item verify size and order*/
		ints.add(5);
		ints.add(6);
		ints.add(7);
		assertEquals(true, ints.remove(7));
		assertEquals(2, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testRemoveMiddle() 
	{
		/*test Remove on Set with more than one Item verify size and order*/
		ints.add(5);
		ints.add(6);
		ints.add(7);
		assertEquals(true, ints.remove(6));
		assertEquals(2, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
	}
	
	@Test
	public void testRemoveAllEmptyToEmpty() 
	{
		assertEquals(false, ints.removeAll(intCollEmpty));
	}
	
	@Test
	public void testRemoveAllOne() 
	{
		ints.add(6);
		assertEquals(true, ints.removeAll(intColl));
		assertEquals(0, ints.size());
		assertEquals(true, ints.isEmpty());
	}
	
	@Test
	public void testRemoveAllTwo() 
	{
		ints.add(5);
		ints.add(4);
		assertEquals(true, ints.removeAll(intColl2));
		assertEquals(0, ints.size());
		assertEquals(true, ints.isEmpty());
		
		ints.add(5);
		assertEquals(true, ints.removeAll(intColl2));
		assertEquals(0, ints.size());
		assertEquals(true, ints.isEmpty());
		
		
		ints.add(6);
		ints.add(5);
		ints.add(4);
		assertEquals(true, ints.removeAll(intColl2));
		assertEquals(1, ints.size());
		assertEquals(false, ints.isEmpty());
		
		for(int i = 0; i < ints.size() - 1; i++)
		{
			assertEquals(-1,ints.get(i).compareTo(ints.get(i+1)));
		}
		
	}
	
	@Test
	public void testToArray()
	{
		assertEquals(true, ints.add(5));
		assertEquals(true, ints.add(6));
		assertEquals(true, ints.add(4));
		assertEquals(true, ints.add(7));
		assertEquals(true, ints.add(3));
		assertEquals(true, ints.add(8));
		assertEquals(true, ints.add(2));
		assertEquals(true, ints.add(9));
		assertEquals(true, ints.add(1));
		assertEquals(true, ints.add(10));
		assertEquals(true, ints.add(0));
		assertEquals(true, ints.add(11));
		assertEquals(true, ints.add(-1));
		assertEquals(true, ints.add(12));
		
		Object[] copy = ints.toArray();
		
		//System.out.println(Arrays.toString(copy));
		
	}
	
	@Test
	public void testIterator()
	{
		int checker = 1;//ints used for verifying iterator output
		
		assertEquals(false, ints.iterator().hasNext());	// empty list base case
		
		assertEquals(true, ints.add(1));//add one element
		
		assertEquals(true, ints.iterator().hasNext());//verify there is one element
		
		
		/*Test that exception is thrown if attempting to remove before calling next*/
		boolean b = true;
		
		try
		{ints.iterator().remove();}
		catch(IllegalStateException e)
		{b=false;}
		
		assertEquals(false,b);
		
		
		/*Add elements 2-59 to the set*/
		for(int i = 2; i < 60; i++)
			ints.add(i);
		
		//verify the iterator is outputing the correct numbers
		while(ints.iterator().hasNext())
		{
			assertEquals((Integer)checker,(Integer) ints.iterator().next());
			checker++;
		}
		
		/*Verify iterator resets itself*/
		assertEquals((Integer)ints.iterator().next(),(Integer)1);
		
		
		/*Verifying indexing being shifted appropriately
		 *Start by moving several places into the list */
		ints.iterator().next();
		ints.iterator().next();
		ints.iterator().next();
		/*Remove Something behind the iterators position*/
		ints.remove(2);
		
		/*verify that the iterator stayed with the correct data element*/
		assertEquals((Integer)ints.iterator().next(),(Integer)5);
		
		/*Add some stuff before the iterators current position*/
		ints.add(-3);
		ints.add(-5);
		
		/*verify that the iterator stayed with the correct data element*/
		assertEquals((Integer) ints.iterator().next(), (Integer) 6);
		
		/*Remove the element the iterator is pointing to currently*/
		ints.remove(7);
		
		/*verify indexing and removal*/
		assertEquals((Integer) ints.iterator().next(), (Integer) 6);
		assertEquals((Integer) ints.iterator().next(), (Integer) 8);
		
		/*Double check remove is working properly*/
		ints.iterator().remove();
		assertEquals(ints.contains(8),false);

	
		
	}
	

	

}
