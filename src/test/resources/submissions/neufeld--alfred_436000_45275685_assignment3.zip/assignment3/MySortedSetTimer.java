package assignment3;
/*
 * MySortedSetTimer is a class that times the add and contains method for the MySortedSet Class
 * 
 * @author Jacob Bullard
 * @author Alfred Neufeld
 * 
 */


import java.util.ArrayList;

public class MySortedSetTimer {
	public static ArrayList<Long> containsDP;
	public static ArrayList<Long> addDP;
	public static MySortedSet<Integer> ints;

	/**
	 * Main Method Runs the timing and data computation for contains and add methods
	 * @param args
	 */
	public static void main(String[] args) {
		containsDP = new ArrayList<Long>();// Data Points for Contains Timing
		addDP = new ArrayList<Long>();// Data Points for add Timing

		/* Loop through different size lists */
		for (int k = 100000; k <= 2000000; k += 100000) {
			containsDP.add(timeContains(k));
		}
		
		/* Loop through different size lists */
		for (int i = 100000; i <= 2000000; i += 100000) {
			addDP.add(timeAddNewElement(i));
		}

		/* Output Data Points in order */
		System.out.println("Data Points for Timing Contains:\n");
		for (int i = 0; i < containsDP.size(); i++) {
			System.out.println(containsDP.get(i));
		}

	

		/* Output the data points in order */
		System.out.println("Data Points for Timing Add:\n");
		for (int i = 0; i < addDP.size(); i++) {
			System.out.println(addDP.get(i));
		}
	}

	/**
	 * This method times the contains method 10000 times and returns an average
	 * value
	 * 
	 * @param listS
	 *            -- size of the list to be searched
	 * @return Average of 10000 timed contains function calls
	 */
	public static long timeContains(int listS) {
		System.out.println("Current List Size: " + listS);// checkpoint

		ints = makeNewList(listS);// get the list of integer values
		ArrayList<Long> times = new ArrayList<Long>();// list for storing all
														// the trials

		/* time Variables */
		long startContainsTime;
		long endContainsTime;

		/* Loop 10000 times */
		for (int i = 0; i < 10000; i++) {
			int find = (int) ((Math.random()) * listS);// get a random number
														// inside the list

			startContainsTime = System.nanoTime();// start the timer
			ints.contains(find);// function call
			endContainsTime = System.nanoTime();// end the timer
			times.add((endContainsTime - startContainsTime));// add the number
																// to the list
		}
		return avgList(times);// return the average of the list
	}

	/**
	 * This Method times adding one element to the list 10000 times and then
	 * returns the average
	 * 
	 * @param listS
	 *            -- Size of the list to be tested
	 * @return the average of 10000 times calling the add function
	 */
	public static long timeAddNewElement(int listS) {

		System.out.println("Current List Size: " + listS);// checkpoint output

		ArrayList<Long> addTimes = new ArrayList<Long>();// arraylist to hold
															// the times
		/* Timing Variables */
		long startAddOneTime;
		long endAddOneTime;

		ints = makeNewList(listS);// get the list
		/* Loop 10000 times */
		for (int i = 0; i < 10000; i++) {
			/* Find a random number in the list and Remove it */
			int add = (int) (Math.random() * listS);
			ints.remove(add);

			startAddOneTime = System.nanoTime();// start timer
			ints.add(add);// function call
			endAddOneTime = System.nanoTime();// end timer
			addTimes.add(endAddOneTime - startAddOneTime);// add time to the
															// list

		}

		return avgList(addTimes);// return the average

	}

	/**
	 * This method creates a MySortedSet object with the numbers 0 - (listS-1)
	 * 
	 * @param listS
	 *            -- Size of the list to be created
	 * @return retSet -- the MySortedSet object
	 */
	private static MySortedSet<Integer> makeNewList(int listS) {
		MySortedSet<Integer> retSet = new MySortedSet<Integer>();// create the
																	// MySortedSet
																	// Object
		/* Loop from 0 to listS-1 */
		for (int i = 0; i < listS; i++) {
			retSet.add(i);// add each number
		}
		return retSet;// return the MySortedSet Object
	}

	/**
	 * This Method Averages the List of Longs and return the average as long
	 * 
	 * @param times
	 *            -- ArrayList<Long> to be averaged
	 * @return The average of the param list
	 */
	private static long avgList(ArrayList<Long> times) {
		long sum = 0;// variable to hold the sum

		/* Loop through param List */
		for (int i = 0; i < times.size(); i++) {
			sum += times.get(i);// sum the list
		}

		return (sum / times.size());// divide by number of elements in the list
									// and return
	}

}
