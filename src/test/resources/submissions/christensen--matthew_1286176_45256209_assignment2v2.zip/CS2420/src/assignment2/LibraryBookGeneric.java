package assignment2;

import java.util.GregorianCalendar;
/**
 * A library book which can have a holder of any Type 
 * Authors: Patrick McHugh (u0883718) & Matthew Christensen (u0899251)
 *
 * @param <Type>
 */
public class LibraryBookGeneric<Type> extends Book{
	
	//Fields for representing the due date,a string
	//representation of the current holder, and whether or not the book is checked in.
	private GregorianCalendar dueDate;
	private Type holder;
	private boolean checkedIn;
	
	/**
	 * The constructor for the class.
	 * @param _isbn
	 * 		--Sets the ISBN of the book to the given long
	 * @param _author
	 * 		--Sets the author to the given String
	 * @param _title
	 * 		--Sets the title to the given String
	 */
	public LibraryBookGeneric(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		checkedIn = true;

	}
	/**
	 * Returns the holder of this LibraryBook
	 */
	public Type getHolder(){
		return holder;
	}
	/**
	 * Returns the due date of this LibraryBook
	 */
	public GregorianCalendar getDueDate(){
		return dueDate;
	}
	/**
	 * Checks-in the book and sets dueDate and holder to null
	 */
	public void checkIn (){
		checkedIn = true;
		dueDate = null;
		holder = null;
	}
	/**
	 * Checks out the book and sets its holder and due date to the values passed in.
	 */
	public void checkOut (Type holder, GregorianCalendar dueDate){
		this.holder = holder;
		this.dueDate = dueDate;
		checkedIn = false;
	}
	/**
	 *Returns true if the book is checked in.
	 */
	public boolean isCheckedIn(){
		return this.checkedIn;
	}
}
