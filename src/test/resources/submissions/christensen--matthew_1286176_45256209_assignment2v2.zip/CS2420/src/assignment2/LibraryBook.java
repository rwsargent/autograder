package assignment2;

import java.util.GregorianCalendar;
/**
 * A class representation of a library book. Can be checked in or out of a collection.
 * Authors: Patrick McHugh (u0883718) & Matthew Christensen (u0899251)
 *
 */
public class LibraryBook extends Book{
	
	//Fields for representing the due date,a string
	//representation of the current holder, and whether or not the book is checked in.
	private GregorianCalendar dueDate;
	private String holder;
	private boolean checkedIn;
	
	/**
	 * The constructor for the LibraryBookClass
	 */
	public LibraryBook(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		checkedIn = true;
	}
	/**
	 * Returns the holder of this LibraryBook
	 */
	public String getHolder(){
		return holder;
	}
	/**
	 * Returns the due date of this LibraryBook
	 */
	public GregorianCalendar getDueDate(){
		return dueDate;
	}
	/**
	 * Checks-in the book and sets dueDate and holder to null
	 */
	public void checkIn (){
		checkedIn = true;
		dueDate = null;
		holder = null;
	}
	/**
	 * A method for checking out the library book
	 * @param holder
	 * 		--Sets the holder of the book to the String specified
	 * @param dueDate
	 * 		--Sets the dueDate to the GregorianCalendar passed in
	 */
	public void checkOut (String holder, GregorianCalendar dueDate){
		this.holder = holder;
		this.dueDate = dueDate;
		checkedIn = false;
	}
	/**
	 * 
	 * @return
	 * 		--Returns true if the book is checked in, false if it is not.
	 */
	public boolean isCheckedIn(){
		return this.checkedIn;
	}
}
