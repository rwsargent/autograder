package assignment2;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.Scanner;


/**
 * Class representation of a library (a collection of library books). Can have a
 * holder of any Type. Authors: Patrick McHugh (u0883718) & Matthew Christensen
 * (u0899251)
 * 
 */
public class LibraryGeneric<Type> {

	private ArrayList<LibraryBookGeneric<Type>> library;

	public LibraryGeneric() {
		library = new ArrayList<LibraryBookGeneric<Type>>();
	}

	/**
	 * Add the specified book to the library, assume no duplicates.
	 * 
	 * @param isbn
	 *            -- ISBN of the book to be added
	 * @param author
	 *            -- author of the book to be added
	 * @param title
	 *            -- title of the book to be added
	 */
	public void add(long isbn, String author, String title) {
		library.add(new LibraryBookGeneric<Type>(isbn, author, title));
	}

	/**
	 * Add the list of library books to the library, assume no duplicates.
	 * 
	 * @param list
	 *            -- list of library books to be added
	 */
	public void addAll(ArrayList<LibraryBookGeneric<Type>> list) {
		library.addAll(list);
	}

	/**
	 * Add books specified by the input file. One book per line with ISBN,
	 * author, and title separated by tabs.
	 * 
	 * If file does not exist or format is violated, do nothing.
	 * 
	 * @param filename
	 */
	public void addAll(String filename) {
		ArrayList<LibraryBookGeneric<Type>> toBeAdded = new ArrayList<LibraryBookGeneric<Type>>();

		try {
			Scanner fileIn = new Scanner(new File(filename));
			int lineNum = 1;

			while (fileIn.hasNextLine()) {
				String line = fileIn.nextLine();

				Scanner lineIn = new Scanner(line);
				lineIn.useDelimiter("\\t");

				if (!lineIn.hasNextLong())
					throw new ParseException("ISBN", lineNum);
				long isbn = lineIn.nextLong();

				if (!lineIn.hasNext())
					throw new ParseException("Author", lineNum);
				String author = lineIn.next();

				if (!lineIn.hasNext())
					throw new ParseException("Title", lineNum);
				String title = lineIn.next();

				toBeAdded
						.add(new LibraryBookGeneric<Type>(isbn, author, title));

				lineNum++;
			}
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage()
					+ " Nothing added to the library.");
			return;
		} catch (ParseException e) {
			System.err.println(e.getLocalizedMessage()
					+ " formatted incorrectly at line " + e.getErrorOffset()
					+ ". Nothing added to the library.");
			return;
		}

		library.addAll(toBeAdded);
	}

	/**
	 * Returns the holder of the library book with the specified ISBN.
	 * 
	 * If no book with the specified ISBN is in the library, returns null.
	 * 
	 * @param isbn
	 *            -- ISBN of the book to be looked up
	 */
	public Type lookup(long isbn) {
		for (LibraryBookGeneric<Type> book : library) {
			if (book.getIsbn() == isbn)
				return book.getHolder();
		}
		return null;
	}

	/**
	 * Returns the list of library books checked out to the specified holder.
	 * 
	 * If the specified holder has no books checked out, returns an empty list.
	 * 
	 * @param holder
	 *            -- holder whose checked out books are returned
	 */
	public ArrayList<LibraryBookGeneric<Type>> lookup(Type holder) {
		ArrayList<LibraryBookGeneric<Type>> books = new ArrayList<LibraryBookGeneric<Type>>();
		for (LibraryBookGeneric<Type> book : library) {
			if (!book.isCheckedIn()) {
				if (book.getHolder().equals(holder))
					books.add(book);
			}
		}
		return books;
	}

	/**
	 * Sets the holder and due date of the library book with the specified ISBN.
	 * 
	 * If no book with the specified ISBN is in the library, returns false.
	 * 
	 * If the book with the specified ISBN is already checked out, returns
	 * false.
	 * 
	 * Otherwise, returns true.
	 * 
	 * @param isbn
	 *            -- ISBN of the library book to be checked out
	 * @param holder
	 *            -- new holder of the library book
	 * @param month
	 *            -- month of the new due date of the library book
	 * @param day
	 *            -- day of the new due date of the library book
	 * @param year
	 *            -- year of the new due date of the library book
	 * 
	 */
	public boolean checkout(long isbn, Type holder, int month, int day, int year) {
		LibraryBookGeneric<Type> toBeCheckedOut = null;
		//A loop that goes through all the books in the library and finds the book with
		//the matching ISBN
		for (LibraryBookGeneric<Type> book : library) {
			if (book.getIsbn() == isbn) {
				toBeCheckedOut = book;
			}
		}
		//If no book was found, returns false
		if (toBeCheckedOut == null)
			return false;
		//Calls the book's checkout() method if it is checked in
		if (toBeCheckedOut.isCheckedIn()) {
			toBeCheckedOut.checkOut(holder, new GregorianCalendar(year, month,
					day));
			return true;
		}
		//Otherwise, returns false
		return false;
	}

	/**
	 * Unsets the holder and due date of the library book.
	 * 
	 * If no book with the specified ISBN is in the library, returns false.
	 * 
	 * If the book with the specified ISBN is already checked in, returns false.
	 * 
	 * Otherwise, returns true.
	 * 
	 * @param isbn
	 *            -- ISBN of the library book to be checked in
	 */
	public boolean checkin(long isbn) {
		LibraryBookGeneric<Type> toBeCheckedIn = null;
		//Goes through every book in the library and gets the book
		//with the ISBN that was passed in
		for (LibraryBookGeneric<Type> book : library) {
			if (book.getIsbn() == isbn) {
				toBeCheckedIn = book;
			}
		}
		//If no such book exists, returns false
		if (toBeCheckedIn == null)
			return false;
		//If the book is checked out, calls the book's checkIn() method
		if (!toBeCheckedIn.isCheckedIn()) {
			toBeCheckedIn.checkIn();
			return true;
		}
		//Returns false if the book exists, but is checked in already
		return false;
	}

	/**
	 * Unsets the holder and due date for all library books checked out be the
	 * specified holder.
	 * 
	 * If no books with the specified holder are in the library, returns false;
	 * 
	 * Otherwise, returns true.
	 * 
	 * @param holder
	 *            -- holder of the library books to be checked in
	 */
	public boolean checkin(Type holder) {
		ArrayList<LibraryBookGeneric<Type>> toBeCheckedIn = new ArrayList<LibraryBookGeneric<Type>>();
		//Adds all of the books that are checked out to that holder to toBeCheckedIn
		toBeCheckedIn.addAll(this.lookup(holder));
		//If toBeCheckedIn does not contain any books, returns false
		if (toBeCheckedIn.size() <= 0)
			return false;
		//Goes through every book in toBeCheckedIn and checks them in.
		for (LibraryBookGeneric<Type> book : toBeCheckedIn) {
			book.checkIn();
		}
		//At this point, all the books have been checked in and the method returns true
		return true;
	}

	/**
	 * Returns the list of library books, sorted by ISBN (smallest ISBN first).
	 */
	public ArrayList<LibraryBookGeneric<Type>> getInventoryList() {
		ArrayList<LibraryBookGeneric<Type>> libraryCopy = new ArrayList<LibraryBookGeneric<Type>>();
		libraryCopy.addAll(library);

		OrderByIsbn comparator = new OrderByIsbn();

		sort(libraryCopy, comparator);

		return libraryCopy;
	}

	/**
	 * Returns the list of library books, sorted by author
	 */
	public ArrayList<LibraryBookGeneric<Type>> getOrderedByAuthor() {
		ArrayList<LibraryBookGeneric<Type>> authorOrderedList = new ArrayList<LibraryBookGeneric<Type>>();
		//Creates a new OrderByAuthor that can compare the lexicographic positions of the authors
		//relative to each other
		OrderByAuthor comparator = new OrderByAuthor();
		//Adds all the books in the library to authorOrderedList
		authorOrderedList.addAll(library);
		//Sorts the authorOrderedList with the given comparator and returns the sorted list.
		sort(authorOrderedList, comparator);
		return authorOrderedList;
	}

	/**
	 * Returns the list of library books whose due date is older than the input
	 * date. The list is sorted by date (oldest first).
	 * 
	 * If no library books are overdue, returns an empty list.
	 */
	public ArrayList<LibraryBookGeneric<Type>> getOverdueList(int month,
			int day, int year) {
		ArrayList<LibraryBookGeneric<Type>> overdueList = new ArrayList<LibraryBookGeneric<Type>>();
		//Goes through every book in the library, checks that the current book is checked out.
		//If it is checked out and it's due date is before the due date specified by the
		//day, month, and year passed in, then adds the book to the overdueList
		for (LibraryBookGeneric<Type> book : library) {
			if (!book.isCheckedIn()) {
				if (book.getDueDate().compareTo(new GregorianCalendar(year, month, day)) < 0) {
					overdueList.add(book);
				}
			}

		}
		OrderByDueDate comparator = new OrderByDueDate();
		//Sorts the list of overdue books by their due date (oldest first) with the given comparator
		//and then returns the sorted list.
		sort(overdueList, comparator);
		return overdueList;
	}

	/**
	 * Performs a SELECTION SORT on the input ArrayList. 1. Find the smallest
	 * item in the list. 2. Swap the smallest item with the first item in the
	 * list. 3. Now let the list be the remaining unsorted portion (second item
	 * to Nth item) and repeat steps 1, 2, and 3.
	 */
	private static <ListType> void sort(ArrayList<ListType> list,
			Comparator<ListType> c) {
		for (int i = 0; i < list.size() - 1; i++) {
			int j, minIndex;
			for (j = i + 1, minIndex = i; j < list.size(); j++)
				if (c.compare(list.get(j), list.get(minIndex)) < 0)
					minIndex = j;
			ListType temp = list.get(i);
			list.set(i, list.get(minIndex));
			list.set(minIndex, temp);
		}
	}

	/**
	 * Comparator that defines an ordering among library books using the ISBN.
	 */
	protected class OrderByIsbn implements Comparator<LibraryBookGeneric<Type>> {

		/**
		 * Returns a negative value if lhs is smaller than rhs. Returns a
		 * positive value if lhs is larger than rhs. Returns 0 if lhs and rhs
		 * are equal.
		 */
		public int compare(LibraryBookGeneric<Type> lhs,
				LibraryBookGeneric<Type> rhs) {
			return (int) (lhs.getIsbn() - rhs.getIsbn());
		}
	}

	/**
	 * Comparator that defines an ordering among library books using the author's name (sorted by first name),
	 * and book title as a tie-breaker, where the book title that is alphabetically lower comes before the other.
	 * 
	 * Returns -1 if book0, in sorted order, is less than book1
	 * Returns 0 if book0 and book1 have the same author and book title
	 * Returns 1 if book0, in sorted order, is greater than book1
	 */
	public class OrderByAuthor implements
			Comparator<LibraryBookGeneric<Type>> {

		@Override
		public int compare(LibraryBookGeneric<Type> book0,
				LibraryBookGeneric<Type> book1) {
			// The case when book0's author precedes book1's
			if (book0.getAuthor().compareTo(book1.getAuthor()) < 0) {
				return -1;
			}
			// The case when book0's author comes after book1's
			// lexicographically
			else if (book0.getAuthor().compareTo(book1.getAuthor()) > 0) {
				return 1;
			}
			// If book0 and book1's authors are the same, compares book titles
			// The case when book0's book title precedes book1's
			if (book0.getTitle().compareTo(book1.getTitle()) < 0) {
				return -1;
			}
			// The case when book0's book title is the same as book1
			else if (book0.getTitle().compareTo(book1.getTitle()) == 0) {
				return 0;
			}
			// The case when book0's book title comes after book1's
			// lexicographically
			else {
				return 1;
			}
		}
	}

	/**
	 * Comparator that defines an ordering among library books using the due
	 * date. Dates are sorted in ascending order.
	 * 
	 * Returns -1 if book0 is due before book1
	 * Returns 0 if book0 and book1 are due at the same time.
	 * Returns 1 if book0 is due after book1.
	 */
	protected class OrderByDueDate implements
			Comparator<LibraryBookGeneric<Type>>  {

		@Override
		public int compare(LibraryBookGeneric<Type> book0,
				LibraryBookGeneric<Type> book1) {

			if (book0.getDueDate().compareTo(book1.getDueDate()) < 0) {
				return -1;
			} else if (book0.getDueDate().compareTo(book1.getDueDate()) > 0) {
				return 1;
			}

			else {
				return 0;
			}
		}
	}
}
