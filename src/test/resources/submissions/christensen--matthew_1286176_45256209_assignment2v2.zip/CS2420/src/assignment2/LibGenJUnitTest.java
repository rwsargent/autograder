package assignment2;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

/**
 * A collection of tests which test the getOverdueList and getOrderedByAuthor.
 * 
 * Authors: Patrick McHugh (u0883718) & Matthew Christensen (u0899251)
 *
 */
public class LibGenJUnitTest {
	
	/**
	 * Tests the getOverdueList() method.  Makes sure that the sorted order of the list is correct and 
	 * that all of the books which are overdue are added to overdue list.
	 */
	@Test
	public void testGetOverdueList() {
		LibraryGeneric<String> lib = new LibraryGeneric<String>();
	    lib.addAll("Mushroom_Publishing.txt");
	    //Check out 5 books, 3 overdue, 2 underdue.
	    lib.checkout(9781843190400L, "Matt", 12, 25, 2012);
	    lib.checkout(9781843190516L, "Matt", 12, 1, 2012);
	    lib.checkout(9781843192022L, "Matt", 12, 12, 2012);
	    lib.checkout(9781843190998L, "Matt", 12, 12, 2016);
	    lib.checkout(9781843191230L, "Matt", 12, 12, 2016);
	    //calls the method
	    ArrayList<LibraryBookGeneric<String>> overdueList = lib.getOverdueList(1, 28, 2015);
	    assertEquals(3,overdueList.size());
	    assertEquals(9781843190516L, overdueList.get(0).getIsbn());
	    assertEquals(9781843192022L, overdueList.get(1).getIsbn());
	    assertEquals(9781843190400L, overdueList.get(2).getIsbn());
	}
	
	/**
	 * Tests the getOrderedByAuthor() method.  Makes sure that the sorted order of the returned
	 * list is correct and that all of the books in the library are in the list that 
	 * has been sorted.
	 */
	@Test
	public void testGetOrderedByAuthor() {
		LibraryGeneric<String> lib = new LibraryGeneric<String>();
	    lib.addAll("Mushroom_Publishing.txt");
	    //Calls the method
	    ArrayList<LibraryBookGeneric<String>> sortedList = lib.getOrderedByAuthor(); 
	    assertEquals (lib.getInventoryList().size(), sortedList.size());
	    assertEquals (9781843193319L, sortedList.get(0).getIsbn());
	    assertEquals (9781843192039L, sortedList.get(sortedList.size() - 1).getIsbn());
	    assertEquals (9781843190479L, sortedList.get(1).getIsbn());
	}
}
