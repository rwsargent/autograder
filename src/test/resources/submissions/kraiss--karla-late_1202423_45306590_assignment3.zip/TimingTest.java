package assignment3;

import java.util.ArrayList;

/**
 * @author Karla Kraiss
 * @author Michael Swisher
 *
 */
public class TimingTest
{
	public static void main(String[] args)
	{
		MySortedSet<Long> test = new MySortedSet<Long>();
		long startTime, stopTime;

		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000)
		{ // empty block
		}

		// Now, run the test.
		long timesToLoop = 10000000;
		
		// step size
		int stepSize = 100000;
		double total;
		
		// step sizes of 10,000
		for(int n = 100000; n <= 2000000; n += stepSize)
		{
			total = 0;
			// fills the array
			for (long i = 0; i < n; i++)
			{
				test.add(i);
			}
			for(long j = 0; j < timesToLoop; j++)
			{
				startTime = System.nanoTime();
				test.add((long) test.size());
				stopTime = System.nanoTime();
				total += (stopTime - startTime);
				test.remove((long)test.size() - 1);
			}
			double avg = total / timesToLoop;
			System.out.println(avg + " " + n);
		}
	}
}
