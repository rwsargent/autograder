/**
 * @author Karla Kraiss
 * @author Michael Swisher
 *
 */
package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Constructs a sorted list from any object or primitive. Contains the methods add, add
 * all, remove, clear, isEmpty, first, last, and size.
 * 
 * @author Karla Kraiss
 * @author Michael Swisher
 *
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet
{
	// the generic array
	private E[] array;

	// the comparator being used by the client
	private Comparator comparator;

	// the amount of indexes holding an object/primitive
	private int size;

	// the total amount of memory allotted to the array
	private int arrayCap;

	// holds the index that binary search finds
	private int tracker;
	private MyIterator myIterator;// = new Iterator<E>();

	/**
	 * Determines whether two objects use comparable or use comparator
	 * @param item1
	 * @param item2
	 * @return 
	 */
	private int compare(E item1, E item2)
	{
		if (comparator == null)
		{
			return ((Comparable<? super E>) item1).compareTo(item2);
		}
		else
		{
			return comparator.compare(item1, item2);
		}
	}

	private class MyIterator<E> implements Iterator<E>
	{
		private int index;
		private boolean gotNext;

		private MyIterator()
		{
			index = -1;
			gotNext = false;
		}

		/**
		 * Returns true if the iteration has more elements. (In other words, returns true
		 * if next() would return an element rather than throwing an exception.)
		 * 
		 * @return - true if the iteration has more elements
		 */
		@Override
		public boolean hasNext()
		{
			return (index < (size - 1));
		}

		/**
		 * Returns the next element in the iteration.
		 * 
		 * @return - the next element in the iteration
		 */
		@Override
		public E next()
		{
			if (index >= (size - 1))
			{
				index++;
				gotNext = true;
				return ((E) array[index]);
			}
			throw new NoSuchElementException();
		}

		/**
		 * Removes from the underlying collection the last element returned by this
		 * iterator (optional operation). This method can be called only once per call to
		 * next(). The behavior of an iterator is unspecified if the underlying collection
		 * is modified while the iteration is in progress in any way other than by calling
		 * this method.
		 * 
		 * @throws IllegalStateException
		 *             - if the next method has not yet been called, or the remove method
		 *             has already been called after the last call to the next method
		 */
		@Override
		public void remove()
		{
			if (gotNext)
			{
				gotNext = false;
				MySortedSet.this.remove(array[index]);
			}
			else
			{
				throw new IllegalStateException();
			}
		}
	}

	/**
	 * Creates a sorted set using an object's natural ordering.
	 */
	public MySortedSet()
	{
		arrayCap = 10;
		array = (E[]) new Object[arrayCap];
		comparator = null;
		size = 0;
	}

	/**
	 * Creates a sorted set using the specified comparator
	 * 
	 * @param _comparator
	 *            -- specefied comparator to use for sorting
	 */
	public MySortedSet(Comparator<? super E> _comparator)
	{
		this();
		comparator = _comparator;
	}

	@Override
	public Comparator comparator()
	{
		return comparator;
	}

	@Override
	public Object first() throws NoSuchElementException
	{
		Object o = array[0];
		return o;
	}

	@Override
	public Object last() throws NoSuchElementException
	{
		Object o = array[size - 1];
		return o;
	}

	@Override
	public boolean add(Object o)
	{
		// checks if the array is full
		if (size >= arrayCap)
		{
			grow();
		}

		// runs comparable
		if (this.comparator == null)
		{
			// runs binary search to look for the specified object
			if (binarySearchComparable((E) o))
			{
				return false;
			}
			else
			{
				// moves each element over one space in the array
				for (int i = (size - 1); i > tracker - 1; i--)
				{
					E temp = array[i];
					array[i + 1] = temp;
				}
				array[tracker] = (E) o;
				size++;
				return true;
			}
		}
		// runs comparator
		else
		{
			// runs binary search to look for the specified object in the specified
			// sorting order
			if (binarySearchComparator((E) o))
			{
				return false;
			}
			else
			{
				// moves each element over one space in the array
				for (int i = (size - 1); i > tracker - 1; i--)
				{
					E temp = array[i];
					array[i + 1] = temp;
				}
				array[tracker] = (E) o;
				size++;
				return true;
			}
		}
	}

	@Override
	public boolean addAll(Collection c)
	{
		// makes sure there are elements in the collection
		if (c.isEmpty())
		{
			return false;
		}

		int originalSize = size;

		// iterates through the collection and adds the objects to list
		for (Object o : c)
		{
			add((E) o);
		}

		// checks to see if any additions were made
		if (originalSize == size)
		{
			return false;
		}
		return true;
	}

	@Override
	public void clear()
	{
		for (int i = 0; size > 0; i++)
		{
			array[i] = null;
			size--;
		}
	}

	@Override
	public boolean contains(Object o)
	{
		if (this.comparator == null)
		{
			return binarySearchComparable((E) o);
		}
		else
		{
			return binarySearchComparator((E) o);
		}
	}

	@Override
	public boolean containsAll(Collection c)
	{
		for (Object o : c)
		{
			if (!(contains((E) o)))
			{
				return false;
			}
		}
		return true;
	}

	@Override
	public boolean isEmpty()
	{
		if (size <= 0)
		{
			return true;
		}
		return false;
	}

	@Override
	public Iterator<E> iterator()
	{
		return new MyIterator<>();
	}

	@Override
	public boolean remove(Object o)
	{
		// checks if there is a comparator and decides which binary search to use
		if (this.comparator == null)
		{
			// if the element is not in the set, returns false.
			if (!(binarySearchComparable((E) o)))
			{
				return false;
			}
		}
		else
		{
			// if the element is not in the set, returns false.
			if (!(binarySearchComparator((E) o)))
			{
				return false;
			}
		}

		// iterates through array and moves everything left to replace the removed element
		for (int i = tracker; i < (size - tracker); i++)
		{
			E temp = array[i + 1];
			array[i] = temp;
		}
		// sets the last element to null.
		array[size - 1] = null;
		size--;
		return true;

	}

	@Override
	public boolean removeAll(Collection c)
	{
		// makes sure there are elements in the collection
		if (c.isEmpty())
		{
			return false;
		}

		int originalSize = size;

		// iterates through the collection and removes the objects from list
		for (Object o : c)
		{
			remove((E) o);
		}

		// checks to see if temp changed
		if (originalSize == size)
		{
			return false;
		}
		return true;
	}

	@Override
	public int size()
	{
		return size;
	}

	@Override
	public Object[] toArray()
	{
		return array;
	}

	/**
	 * Searches through the array by halving it until it finds the specified object.
	 * 
	 * @param o
	 *            -- Object you are searching for
	 * @return -- true if the object is within the list, false if the object is not in the
	 *         list
	 */
	private boolean binarySearchComparable(E o)
	{
		int low = 0;
		int mid = 0;
		int high = size - 1;
		if (size == 0)
		{
			return false;
		}
		else
		{
			while (low <= high)
			{
				mid = (low + high) / 2;
				Comparable<? super E> e = (Comparable<? super E>) o;

				// discards the lower half
				if (e.compareTo(array[mid]) > 0)
				{
					low = mid + 1;
				}
				// if we have found the object
				else if (e.compareTo(array[mid]) == 0)
				{
					// sets tracker to the space the object is held
					tracker = mid;
					return true;
				}
				// discards the upper half
				else
				{
					high = mid - 1;
				}
			}
		}
		// ensures tracker does not throw an index out of bounds exception
		if (low == -1)
		{
			low = 0;
		}
		tracker = low;
		return false;
	}

	/**
	 * Searches through the array by halving it until it finds the specified object.
	 * 
	 * @param o
	 *            -- Object you are searching for
	 * @return -- true if the object is within the list, false if the object is not in the
	 *         list
	 */
	private boolean binarySearchComparator(E o)
	{
		int low = 0;
		int mid = 0;
		int high = size - 1;
		if (size == 0)
		{
			return false;
		}
		else
		{
			while (low <= high)
			{
				mid = (low + high) / 2;
				// discards the lower half
				if (comparator.compare(o, array[mid]) > 0)
				{
					low = mid + 1;
				}
				// if we have found the object
				else if (comparator.compare(o, array[mid]) == 0)
				{
					// sets tracker to the space the object is held
					tracker = mid;
					return true;
				}
				// discards the upper half
				else
				{
					high = mid - 1;
				}
			}
		}
		// ensures tracker does not throw an exception
		if (low == -1)
		{
			low = 0;
		}
		// set tracker to the space where the item would be held
		tracker = low;
		return false;
	}

	/**
	 * doubles the array size
	 */
	private void grow()
	{
		// doubles the allotted array size
		arrayCap = arrayCap * 2;

		// creates a temporary array with the doubled size
		E[] temp = (E[]) new Object[arrayCap];

		// iterates through list and adds each element to temp
		for (int i = 0; i < (size); i++)
		{
			temp[i] = array[i];
		}
		array = temp;
	}

	/**
	 * returns the index where the element is stored
	 */
	public E get(int x)
	{
		return array[x];
	}
}