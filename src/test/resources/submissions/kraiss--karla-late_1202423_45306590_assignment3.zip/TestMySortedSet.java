package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import assignment2.LibraryBookGeneric;

/**
 * tests the methods implemented in MySortedSet
 * @author Karla Kraiss
 * @author Michael Swisher
 *
 */
public class TestMySortedSet
{
	/**
	 * sorts in descending order
	 */
	class MyComparator implements Comparator<Integer>
	{
		@Override
		public int compare(Integer lhs, Integer rhs)
		{
			return (int) (rhs - lhs);
		}
	}
	
	MyComparator cmp = new MyComparator();
	
	
	// comparable
	MySortedSet test = new MySortedSet();
	MySortedSet emptyTest = new MySortedSet();
	MySortedSet unorderedTest1 = new MySortedSet();
	MySortedSet unorderedTest2 = new MySortedSet();
	MySortedSet unorderedTest3 = new MySortedSet();
	MySortedSet growTest = new MySortedSet();
	ArrayList<Integer> collection1 = new ArrayList<Integer>();
	ArrayList<Integer> collection2 = new ArrayList<Integer>();
	ArrayList<Integer> collection3 = new ArrayList<Integer>();
	
	
	// comparator
	MySortedSet testC = new MySortedSet(cmp);
	MySortedSet emptyTestC = new MySortedSet(cmp);
	MySortedSet unorderedTest1C = new MySortedSet(cmp);
	MySortedSet unorderedTest2C = new MySortedSet(cmp);
	MySortedSet unorderedTest3C = new MySortedSet(cmp);
	
	@Before
	public void setUp() throws Exception{
		test.add(0);
		test.add(10);
		test.add(20);
		test.add(30);
		test.add(40);
		
		unorderedTest1.add(30);
		unorderedTest1.add(40);
		unorderedTest1.add(0);
		unorderedTest1.add(10);
		unorderedTest1.add(20);
		
		unorderedTest2.add(10);
		unorderedTest2.add(20);
		unorderedTest2.add(30);
		unorderedTest2.add(40);
		unorderedTest2.add(0);
		
		unorderedTest3.add(0);
		unorderedTest3.add(67);
		unorderedTest3.add(70);
		
		growTest.add(0);
		growTest.add(10);
		growTest.add(20);
		growTest.add(30);
		growTest.add(40);
		growTest.add(50);
		growTest.add(60);
		growTest.add(70);
		growTest.add(80);
		growTest.add(90);
		
		collection1.add(10);
		collection1.add(20);
		
		collection2.add(35);
		collection2.add(99);
		
		collection3.add(32);
		collection3.add(40);
		
		testC.add(0);
		testC.add(10);
		testC.add(20);
		testC.add(30);
		testC.add(40);
		
		unorderedTest1C.add(30);
		unorderedTest1C.add(40);
		unorderedTest1C.add(0);
		unorderedTest1C.add(10);
		unorderedTest1C.add(20);
		
		unorderedTest2C.add(10);
		unorderedTest2C.add(20);
		unorderedTest2C.add(30);
		unorderedTest2C.add(40);
		unorderedTest2C.add(0);
		
		unorderedTest3C.add(0);
		unorderedTest3C.add(67);
		unorderedTest3C.add(70);
	}
	
	@Test
	public void testContains1()
	{	
		assertTrue(test.contains(20));
	}

	@Test
	public void testContains2()
	{		
		assertFalse(test.contains(50));
	}
	
	@Test
	public void testContains3()
	{
		assertTrue(test.contains(0));
	}
	
	@Test
	public void testContains4()
	{
		assertFalse(test.contains(02));
	}
	
	@Test
	public void testContains5()
	{
		unorderedTest3.addAll(collection2);
		assertEquals(35, unorderedTest3.get(1));
	}
	
	@Test
	public void testContainsComparator1()
	{
		assertFalse(testC.contains(02));
	}
	
	@Test
	public void testContainsComparator2()
	{
		unorderedTest3C.addAll(collection2);
		assertEquals(70, unorderedTest3C.get(1));
	}
	
	@Test
	public void testContainsComparator3()
	{
		unorderedTest3C.addAll(collection2);
		assertEquals(99, unorderedTest3C.get(0));
	}
	
	@Test
	public void testAdd1()
	{		
		assertEquals(0, unorderedTest1.get(0));
	}
	
	@Test
	public void testAdd2()
	{
		assertEquals(10, unorderedTest1.get(1));
	}
	
	@Test
	public void testAdd3()
	{		
		assertEquals(20, unorderedTest1.get(2));
	}
	
	@Test
	public void testAdd4()
	{		
		assertEquals(30, unorderedTest1.get(3));
	}
	
	@Test
	public void testAdd5()
	{		
		assertEquals(40, unorderedTest1.get(4));
	}
	
	@Test
	public void testAdd6()
	{
		assertEquals(0, unorderedTest2.get(0));
	}
	
	@Test
	public void testAdd7()
	{
		assertEquals(10, unorderedTest2.get(1));
	}
	
	@Test
	public void testAdd8()
	{
		assertEquals(20, unorderedTest2.get(2));
	}
	
	@Test
	public void testAdd9()
	{
		assertEquals(30, unorderedTest2.get(3));
	}
	
	@Test
	public void testAdd10()
	{
		assertEquals(40, unorderedTest2.get(4));
	}
	
	@Test
	public void testAddComparator1()
	{
		assertEquals(40, unorderedTest2.get(4));
	}

	@Test
	public void testAddAll1()
	{
		assertFalse(unorderedTest2.addAll(collection1));	
	}
	
	@Test
	public void testAddAll2()
	{
		assertTrue(unorderedTest3.addAll(collection2));
	}
	
	@Test
	public void testAddAll3()
	{
		assertTrue(unorderedTest2.addAll(collection3));
	}
	
	@Test
	public void testAddAllComparator1()
	{
		assertTrue(unorderedTest2C.addAll(collection3));
	}
	
	@Test
	public void testRemove1()
	{		
		assertTrue(unorderedTest1.remove(0));
	}
	
	@Test
	public void testRemove2()
	{		
		assertTrue(unorderedTest3.remove(70));
	}
	
	@Test
	public void testRemove3()
	{		
		assertFalse(unorderedTest1.remove(57));
	}
	
	@Test
	public void testRemoveComparator1()
	{		
		assertFalse(unorderedTest1C.remove(57));
	}
	
	@Test
	public void testRemoveAll1()
	{
		assertTrue(unorderedTest1.removeAll(collection1));
	}
	
	@Test
	public void testRemoveAll2()
	{
		unorderedTest1.removeAll(collection1);
		assertEquals(30, unorderedTest1.get(1));
	}
	
	@Test
	public void testRemoveAll3()
	{
		assertFalse(unorderedTest1.removeAll(collection2));
	}
	
	@Test
	public void testRemoveAll4()
	{
		unorderedTest1.removeAll(collection2);
		assertEquals(0, unorderedTest1.get(0));
	}
	
	@Test
	public void testRemoveAllComparator1()
	{
		unorderedTest1C.removeAll(collection2);
		assertEquals(40, unorderedTest1C.get(0));
	}
	
	@Test
	public void testFirst()
	{
		assertEquals(0, unorderedTest1.first());
	}
	
	@Test
	public void testFirstComparator()
	{
		assertEquals(40, unorderedTest1C.first());
	}
	
	@Test
	public void testLast()
	{
		assertEquals(70, unorderedTest3.last());
	}
	
	@Test
	public void testLastComparator()
	{
		assertEquals(0, unorderedTest3C.last());
	}
	
	@Test
	public void testClear()
	{
		unorderedTest1.clear();
		assertNull(unorderedTest1.get(1));
	}
	
	@Test
	public void testClearComparator()
	{
		unorderedTest1C.clear();
		assertNull(unorderedTest1C.get(1));
	}
	
	@Test
	public void testContainsAll1()
	{
		assertEquals(true, unorderedTest1.containsAll(collection1));
	}
	
	@Test
	public void testContainsAll2()
	{
		assertFalse(unorderedTest1.containsAll(collection2));
	}
	
	@Test
	public void testContainsAllComparator1()
	{
		assertEquals(true, unorderedTest1C.containsAll(collection1));
	}
	
	@Test
	public void testIsEmpty1()
	{
		unorderedTest1.clear();
		assertTrue(unorderedTest1.isEmpty());
	}
	
	@Test
	public void testIsEmpty2()
	{
		assertTrue(emptyTest.isEmpty());
	}
	
	@Test
	public void testIsEmpty3()
	{
		assertFalse(test.isEmpty());
	}
	
	@Test
	public void testSize1()
	{
		assertEquals(3, unorderedTest3.size());
	}
	
	@Test
	public void testSize2()
	{
		assertEquals(5, unorderedTest1.size());
	}
	
	@Test
	public void testSize3()
	{
		assertEquals(0, emptyTest.size());
	}
	
	@Test
	public void testSizeComparator1()
	{
		assertEquals(5, unorderedTest1C.size());
	}
	
	@Test
	public void testSizeComparator2()
	{
		unorderedTest1C.addAll(collection2);
		assertEquals(7, unorderedTest1C.size());
	}
	
	@Test
	public void testToArray1()
	{		
		Object[] temp = test.toArray();
		for(int i = 0; i < test.size() - 1; i++)
		{
			assertEquals(temp[i], test.get(i));
		}
	}
	
	@Test
	public void testGrow1()
	{
		growTest.add(100);
		assertEquals(100, growTest.get(10));
	}
}
