package assignment3;

import static org.junit.Assert.*;

import  org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;
/**
 * 
 * @author Lucas Fivas, Maxwell Wright
 * Our implementation of the SortedSet<E> iterface provided.
 *
 * Unit test for MySortedSet.java
 */
public class TestMySortedSet {

	Comparator<Integer> comparator;

	MySortedSet<Integer> emptySet;
	MySortedSet<Integer> oneItemSet;
	
	MySortedSet<Integer> comparatorEmptySet;
	MySortedSet<Integer> comparatorOneItemSet;
	MySortedSet<Integer> comparatorTestSet1;
	MySortedSet<Integer> comparatorTestSet2;

	MySortedSet<Integer> testSet1;
	MySortedSet<Integer> testSet2;

	int[] testArray1 = new int[] {1,2,3,5,8,13,21};
	ArrayList<Integer> testList1;

	int[] testArray2 = new int[] {1,2,4,8,16,32};
	ArrayList<Integer> testList2;

	int[] addAllReferenceArray = new int[] {1,2,3,4,5,8,13,16,21,32};
	
	boolean[] hasNextReferenceArray1 = new boolean[] { true, true, true, true, true, true, true, false };
	boolean[] hasNextReferenceArray2 = new boolean[] { true, true, true, true, true, true, false };

	/**
	 * Prepares the various lists and sets we use for each test
	 */
	@Before
	public void setUp()
	{
		testList1 = new ArrayList<Integer>();
		testList2 = new ArrayList<Integer>();
		
		for(int integer : testArray1)
			testList1.add(new Integer(integer));

		for(int integer : testArray2)
			testList2.add(new Integer(integer));

		emptySet = new MySortedSet<Integer>();

		oneItemSet = new MySortedSet<Integer>();
		oneItemSet.add(1);

		comparator = new MySortedSetDefaultComparator<Integer>();
		comparatorEmptySet = new MySortedSet<Integer>(comparator);
		comparatorOneItemSet = new MySortedSet<Integer>(comparator);
		comparatorOneItemSet.add(1);
		comparatorTestSet1 = new MySortedSet<Integer>(comparator);
		comparatorTestSet1.addAll(testList1);
		comparatorTestSet2 = new MySortedSet<Integer>(comparator);
		comparatorTestSet2.addAll(testList2);

		testSet1 = new MySortedSet<Integer>();
		testSet1.addAll(testList1);

		testSet2 = new MySortedSet<Integer>();
		testSet2.addAll(testList2);

	}

	/**
	 * comparator() should return null if there is no comparator assigned.
	 */
	@Test
	public void comparatorTestNoComparator()
	{
		assertEquals(null, emptySet.comparator());
	}

	/**
	 * comparator() should return the same comparator that was assigned if one is assigned.
	 */
	@Test
	public void comparatorTestWithComparator()
	{
		assertEquals(comparator, comparatorEmptySet.comparator());
	}

	/**
	 * An empty set should throw a NoSuchElementException when first() is called.
	 */
	@Test(expected = NoSuchElementException.class)
	public void firstTestEmptySet()
	{
		emptySet.first();
	}

	/**
	 * Test the behavior of first() on a set of one item
	 */
	@Test
	public void firstTestSingleItemSet()
	{
		assertEquals(1, (int)oneItemSet.first());
	}

	/**
	 * Test the behavior of first on a larger set.
	 */
	@Test
	public void firstTestLargeSet()
	{
		assertEquals(1, (int)testSet1.first());
	}

	/**
	 * An empty set should throw a NoSuchElementException when last() is called.
	 */
	@Test(expected = NoSuchElementException.class)
	public  void lastTestEmptySet()
	{
		emptySet.last();
	}

	/**
	 * Test the behavior of last() on a single item set.
	 */
	@Test
	public void lastTestSingleItemSet()
	{
		assertEquals(1, (int)oneItemSet.last());
	}

	/**
	 * Test the behavior of last() on a larger set. 
	 */
	@Test
	public void lastTestLargeSet()
	{
		assertEquals(21, (int)testSet1.last());
	}

	/**
	 * Test adding an item to an empty set.  The item should be added at index 0.
	 */
	@Test
	public void addTestEmptySet()
	{
		assertTrue(emptySet.add(1));
		
		assertEquals(1, emptySet.toArray()[0]);
	}

	/**
	 * Test adding an item to a set with one item.  The item should be added at index 1. 
	 */
	@Test
	public void addTestOneItemSet()
	{
		assertTrue(oneItemSet.add(2));

		assertEquals(2, oneItemSet.toArray()[1] );
	}

	/**
	 * Test adding an item to a larger set.  The item should be put in the correct place.
	 */
	@Test
	public void addTestLargeSet1()
	{
		assertTrue(testSet1.add(4));
		assertEquals(4, testSet1.toArray()[3]);
	}
	/**
	 * Test adding an item to another larger set.  The item should be put in the correct place.
	 */
	@Test
	public void addTestLargeSet2()
	{
		assertTrue(testSet1.add(4));
		assertEquals(4, testSet1.toArray()[3]);
	}
	
	/**
	 * Test adding an item to an empty set using a comparator.  The item should be added at index 0.
	 */
	@Test
	public void addTestEmptySetComparator()
	{
		assertTrue(comparatorEmptySet.add(1));
		
		assertEquals(1, comparatorEmptySet.toArray()[0]);
	}
	
	/**
	 * Test adding an item to a set with one item using a comparator.  The item should be added at index 1. 
	 */
	@Test
	public void addTestOneItemSetComparator()
	{
		assertTrue(comparatorOneItemSet.add(2));

		assertEquals(2,comparatorOneItemSet.toArray()[1] );
	}

	/**
	 * Test adding an item to a larger set using a comparator.  The item should be put in the correct place.
	 */
	@Test
	public void addTestLargeSet1Comparator()
	{
		assertTrue(comparatorTestSet1.add(4));
		assertEquals(4, comparatorTestSet1.toArray()[3]);
	}
	
	/**
	 * Test adding an item to another larger set using a comparator.  The item should be put in the correct place.
	 */
	@Test
	public void addTestLargeSet2Comparator()
	{
		assertTrue(comparatorTestSet2.add(3));
		assertEquals(3, comparatorTestSet1.toArray()[2]);
	}

	/**
	 * Test the behavior of addAll() when adding to an empty set.  All of the items from the source collection should be added in order.
	 */
	@Test
	public void addAllTestEmptySet()
	{
		assertTrue(emptySet.addAll(testList1));
		
		Object[] emptySetArray = emptySet.toArray();
				
		for(int i = 0; i < testArray1.length; i++)
			assertEquals(testArray1[i], (int)emptySetArray[i]);	
	}
	
	/**
	 * Test the behavior of addAll() when adding to a filled set.  Duplicate items should be ignored; non-duplicates should be added in order.
	 */
	@Test
	public void addAllTestFilledSet()
	{
		assertTrue(testSet1.addAll(testList2));
		
		for(Integer i : testList2)
			assertTrue(testSet1.contains(i));
	}

	/**
	 * Test clear() on an empty set.  The set should still be empty.  Can you imagine if it weren't?
	 */
	@Test
	public void clearTestEmptySet()
	{
		emptySet.clear();
		assertEquals(0,emptySet.toArray().length);
	}
	
	/**
	 * Test clear() on a filled set.  It shoudl properly clear the set.
	 */
	@Test
	public void clearTestFilledSet()
	{
		testSet1.clear();
		assertEquals(0,testSet1.toArray().length);
	}
	
	/**
	 * Test contains() on an empty set.  It should always return false.
	 */
	@Test
	public void containsTestEmptySet()
	{
		assertFalse(emptySet.contains(1));
	}
	
	/**
	 * Test contains() where it should return true.
	 */
	@Test
	public void containsTestTrue()
	{
		assertTrue(testSet1.contains(5));
	}
	
	/**
	 * Test contains() where it should return false.
	 */
	@Test
	public void containsTestFalse()
	{
		assertFalse(testSet2.contains(3));
	}
	
	/**
	 * Test containsAll() on an empty set.  Should always return false.
	 */
	@Test
	public void containsAllEmptySet()
	{
		assertFalse(emptySet.containsAll(testList1));
	}
	
	/**
	 * Test containsAll() when it should return true.
	 */
	@Test
	public void containsAllTrue()
	{
		assertTrue(testSet1.containsAll(testList1));
	}
	
	/** 
	 * Test containsAll() when it should return false.
	 */
	@Test
	public void containsAllFalse() 
	{
		assertFalse(testSet1.containsAll(testList2));
	}
	
	/**
	 * Test isEmpty() when it should return true.
	 */
	@Test
	public void isEmptyTestTrue()
	{
		assertTrue(emptySet.isEmpty());
	}
	
	/**
	 * Test isEmpty() when it should return false.
	 */
	@Test
	public void isEmptyTestFalse()
	{
		assertFalse(testSet1.isEmpty());
	}
	
	/**
	 * Test remove() on an empty set.  It should always return false.
	 */
	@Test
	public void removeTestEmptySet()
	{
		assertFalse(emptySet.remove(1));
	}
	
	/**
	 * Test remove() when it should return true.  Make sure that the item is actually removed.
	 */
	@Test
	public void removeTestTrue()
	{
		assertTrue(testSet1.remove(1));
		assertFalse(testSet1.contains(1));
	}
	
	/**
	 * Test remove() when it should return false.
	 */
	@Test
	public void removeTestFalse()
	{
		assertFalse(testSet2.remove(3));
	}
	
	/**
	 * Test remove() on a single-element array where it should return true. Make sure the item is removed.
	 */
	@Test
	public void removeTestOneElementTrue()
	{
		assertTrue(oneItemSet.remove(1));
		assertFalse(oneItemSet.contains(1));
	}
	
	/**
	 * Test remove() on a single-element array where it should return false.
	 */
	@Test
	public void removeTestOneElementFalse()
	{
		assertFalse(oneItemSet.remove(2));
	}
	
	/**
	 * Test removeAll() on an empty set.  It should return false.
	 */
	@Test
	public void removeAllTestEmptySet()
	{
		assertFalse(emptySet.removeAll(testList1));
	}
	
	/**
	 * Test removeAll() where it should return true.
	 */
	@Test
	public void removeAllTestFilledSet()
	{
		assertTrue(testSet1.removeAll(testList1));
		for(Integer i : testList1)
			assertFalse(testSet1.contains(i));
	}
	
	/**
	 * Test size() on a filled set.
	 */
	@Test
	public void sizeTestFilledSet()
	{
		
		assertEquals(7,testSet1.size());
		assertEquals(6,testSet2.size());
	}
	
	/**
	 * Test size() on an empty set.
	 */
	@Test
	public void sizeTestEmptySet()
	{
		
		assertEquals(0,emptySet.size());
	}
	
	/**
	 * Test toArray() on an empty set.  Should return an array of size 0.
	 */
	@Test
	public void toArrayTestEmptySet()
	{
		
		assertEquals(0, emptySet.toArray().length);
	}
	
	/**
	 * Test toArray() on a filled set.  Should return an array matching the reference array.
	 */
	@Test
	public void toArrayTestFilledSet()
	{
		Object[] testToArray1 = testSet1.toArray();
		assertEquals(testToArray1.length, testArray1.length);
		
		for (int i = 0; i < testArray1.length; i++)
			assertEquals(testToArray1[i], testArray1[i]);
			
		Object[] testToArray2 = testSet2.toArray();
		assertEquals(testToArray2.length, testArray2.length);
		
		for (int i = 0; i < testArray2.length; i++)
			assertEquals(testToArray2[i], testArray2[i]);
	}
	
	/**
	 * Test search() on an empty set.  Should return -1.
	 */
	@Test
	public void searchTestEmptySet()
	{
		assertEquals(-1, emptySet.search(1));
	}
	
	/**
	 * Test search() for the item at the left boundary.
	 */
	@Test
	public void searchTestItemInSetLeftBoundary()
	{
		assertEquals(0, testSet1.search(1));
		assertEquals(0, testSet2.search(1));
	}
	
	/**
	 * Test search() for the item at the right boundary.
	 */
	@Test
	public void searchTestItemInSetRightBoundary()
	{
		assertEquals(6, testSet1.search(21));
		assertEquals(5, testSet2.search(32));
	}
	
	/**
	 * Test search() for an item at the middle of the set.
	 */
	@Test
	public void searchTestItemInSetMiddle()
	{
		assertEquals(3, testSet1.search(5));
		assertEquals(3, testSet2.search(8));
	}
	
	/**
	 * Test search() for an item not in the set that would be added at the left boundary.
	 */
	@Test
	public void searchTestItemNotInSetLeftBoundary()
	{
		assertEquals(0, testSet1.search(0));
		assertEquals(0, testSet2.search(0));
	}
	
	/**
	 * Test search() for an item not in the set that would be added at the right boundary.
	 */
	@Test
	public void searchTestItemNotInSetRightBoundary()
	{
		assertEquals(7, testSet1.search(34));
		assertEquals(6, testSet2.search(64));
	}
	
	/**
	 * Test search() for an item not in the set that would be added in the middle of the set.
	 */
	@Test
	public void searchTestItemNotInSetMiddleOfSet()
	{
		assertEquals(3, testSet1.search(4));
		assertEquals(3, testSet2.search(7));
	}
	
	/**
	 * Test haseNext() on an empty set.  Should always return false.
	 */
	@Test
	public void hasNextTestEmptySet()
	{
		Iterator<Integer> emptySetIterator = emptySet.iterator();
		assertFalse(emptySetIterator.hasNext());
	}
	
	/** 
	 * Test hasNext() on a filled set.  It should behave as the Iterator interface defines.
	 */
	@Test
	public void hasNextTestFilledSet()
	{
		Iterator<Integer> testSet1Iterator = testSet1.iterator();
		
		for (int i = 0; i < hasNextReferenceArray1.length - 1; i++)
		{
			assertEquals(hasNextReferenceArray1[i], testSet1Iterator.hasNext());
			testSet1Iterator.next();
		}
		
		
		Iterator<Integer> testSet2Iterator = testSet2.iterator();
		
		for (int i = 0; i < hasNextReferenceArray2.length - 1; i++)
		{
			assertEquals(hasNextReferenceArray2[i], testSet2Iterator.hasNext());
			testSet2Iterator.next();
		}
		
	}
	
	/*
	 * Test next() on an empty set.  It should throw a NoSuchElementException.
	 */
	@Test(expected = NoSuchElementException.class)
	public void nextEmptySet()
	{
		Iterator<Integer> emptySetIterator = emptySet.iterator();
		emptySetIterator.next();
	}
	
	/**
	 * Test next() at the left boundary.  Should return the first item.
	 */
	@Test
	public void nextFilledSetLeftBoundary()
	{
		Iterator<Integer> testSet1Iterator = testSet1.iterator();
		assertEquals(1, (int)testSet1Iterator.next());
	}
	
	/**
	 * Test next() at the right boundary.  Should throw a NoSuchElementException.
	 */
	@Test(expected = NoSuchElementException.class)
	public void nextFilledSetRightBoundary()
	{
		Iterator<Integer> testSet1Iterator = testSet1.iterator();
		for (int i = 0; i <= testSet1.size(); i++)
			testSet1Iterator.next();
		
	}
	
	/**
	 * Test next(0n in the middle of the array.  Should return the correct item.
	 */
	@Test
	public void nextFilledSetMiddle()
	{
		Iterator<Integer> testSet2Iterator = testSet2.iterator();
		testSet2Iterator.next();
		assertEquals(2, (int)testSet2Iterator.next());
	}
	
	/**
	 * Test the iterator's remove() method.  Should throw a UnsupportedOperationException.
	 */
	@Test(expected = UnsupportedOperationException.class)
	public void iteratorRemoveTest()
	{
		Iterator<Integer> testSet1Iterator = testSet1.iterator();
		testSet1Iterator.remove();
	}

}


