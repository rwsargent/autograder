package assignment3;

import java.util.*;

/**
 * 
 * @author Lucas Fivas, Maxwell Wright
 * Our implementation of the SortedSet<E> iterface provided.
 *
 * @param <E>
 * -The type of elements contained within the set
 */
public class MySortedSet<E extends Comparable> implements SortedSet<E>{

	private Comparator<? super E> comparator;
	private	Object[] items;
	private int capacity;
	private int count;

	/**
	 * Creates a new MySortedSet with a default size of 10 using the items' natural ordering.
	 */
	public MySortedSet()
	{
		items = new Object[10];
		capacity = 10;
		count = 0;
	}

	/**
	 * Creates a new MySortedSet with a default size of 10 using the supplied comparator for the items' ordering.
	 * @param comparator
	 * The comparator to use when ordering and searching the items.
	 */
	public MySortedSet(Comparator<? super E> comparator)
	{
		items = new Object[10];
		capacity = 10;
		count = 0;
		this.comparator = comparator;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		//check if a first item even exists
		if (count == 0)
			throw new NoSuchElementException();
		return (E) items[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		//check if a last item even exists
		if (count == 0)
			throw new NoSuchElementException();
		return (E) items[count -1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		//if the list is empty, don't bother searching for where to insert the item; just put it in index 0.
		if (o != null && items[0] == null)
		{
			items[0] = o;
			count++;
			return true;
		}

		//Don't try to add null to the set.  That's pointless.
		if (o != null)
		{
			//Search for the item in the array.  Remembr that search() returns either the index where an item is at, OR the index for it to be inserted to. 
			int index = search(o);

			//If the list is about to overflow, make it bigger.
			if (count == capacity - 1)
			{
				//copy the current elements into a new array, and replace the old with the new.
				Object[] newArray = new Object[capacity *= 2];
				for(int i = 0; i < count; i++)
					newArray[i] = items[i];
				items = newArray;
			}

			//If the index corresponds to either a null value or a different value from what we're trying to add, go ahead and add it.
			if (items[index] == null || !((E)items[index]).equals(o)) {
				//Shift all the greater values to the left
				for(int i = count -1; i >= index; i-- ){
					items[i+1] = items[i];
				}
				//add the item, increase our count, and return true
				items[index] = o;
				count++;
				return true;
			}

		}

		//If we weren't able to add the item, return false.
		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		//Keep track of whether we've modified the set
		boolean hasAdded = false;

		//Loop through the collection we were given, trying to add all of its entries to the set
		for(E item : c) {
			if (add(item))
				hasAdded = true;
		}

		//Return whether we've changed anything or not
		return hasAdded;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		//Replace the array with a new array of size 10, reset our count to 0, and reset our capacity to 10
		Object[] newItems = new Object[10];
		count = 0;
		capacity = 10;
		items = newItems;

	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		//If there's nothing in the set, it doesn't contain anything.
		if (count == 0)
			return false;
		//If the item isn't an E, we don't have it.
		if (!(o instanceof Comparable<?>))
			return false;

		//Cast the object to the type of item in the set.
		E item = (E) o;

		//Search for the item in the array.  Remembr that search() returns either the index where an item is at, OR the index for it to be inserted to.  
		int index = search(item);

		//If the index isn't higher than our current count and the item at the given index is equal to o, we have it.  Otherwise, we don't.
		return index < count && ((E)items[index]).equals(item);

	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		//Call contains on all of the items in the collection.  If we find one we don't have, stop looking and just return false.
		for(int i = 0; i < c.size(); i++)
			if (!this.contains(c.toArray()[i]))
				return false;
		//If we've made it through the array without running into an item we don't have, return true.
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		//We're not empty if count > 0.
		if(count != 0){
			return false;
		}
		return true;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MySortedSetIterator<E>(items, count);
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {

		//If we don't have anything, we can't remove anything.
		if (count == 0)
			return false;

		//If the item isn't an E, we don't have it, so we can't remove it.
		if (o instanceof Comparable<?> ){
			//Cast the item to an e.
			E item = (E) o;

			//Search for the item in the array.  Remembr that search() returns either the index where an item is at, OR the index for it to be inserted to.
			int index = search(item);

			//Search returns -1 if the array is empty, so we use this as a sanity check.  If the index is higher than our count, we don't have the item.
			if (index == -1 || index >= count)
				return false;

			//Check whether the item at the index matches the item we're looking for.
			if (items[index].equals(item))
			{
				//If it does, shift the elements greater than it to the right, lower our count, and return true.
				for(int i = index; i < count - 1; i++ ){
					items[i] = items[i+1];}
				count--;
				return true;
			}
		}
		//If we weren't able to return anything, return false.
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		//Keep track of whether we've removed anything.
		boolean hasRemoved = false;

		//Dump the collection into an array.  
		Object[] array = c.toArray(); 

		//For every item in the collection, attempt to remove it.
		for(int i = 0; i < c.size(); i++){
			if (this.contains(array[i])){
				if (remove(array[i]))
					hasRemoved = true;
			}
		}

		//Return whether we've removed anything or not.
		return hasRemoved;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return count;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		//create a new array the size of our current count, since we don't want to return an array with empty slots
		Object[] returnArray = new Object[count];
		//fill the array and return it
		for (int i = 0; i < count; i++)
			returnArray[i] = items[i];
		return returnArray;
	}

	/**
	 * Searches for the item in the set
	 * @param item The item to be searched for
	 * @return The index of the item if it is in the set; the index it would be inserted at if it were to be added; -1 if the set is empty
	 */
	@SuppressWarnings("unchecked")
	public int search(E item)
	{
		//If we don't have any items, return -1
		if (count == 0)
			return -1;

		int upperBound = count;
		int lowerBound = 0;
		int index = ((upperBound - lowerBound) / 2);

		//If count = 1, we manually correct for the rounding error
		if (count == 1)
		{
			//If we don't have a comparator, use compareTo
			if (comparator == null)
			{
				if (((E)items[0]).compareTo(item) >= 0)
					index = 1;
				index = 0;
			}
			//otherwise, use the comparator
			else
			{
				if (comparator.compare(((E)items[0]),item) >= 0)
					index = 1;
				index = 0;
			}

		}

		
		int comparison;
		boolean finished = false;

		while(!finished)
		{

			//If we don't have a comparator, get our comparison from compareTo 
			if (comparator == null)
				comparison = ((E)items[index]).compareTo((item));
			//Otherwise use the comparator
			else
				comparison = comparator.compare((E)items[index], item);
			
			//If the item at the index matches, return the index
			if (comparison == 0) {
				return index;
			}

			//If our bounds have ran past each other, we've finished.
			if (upperBound - lowerBound <= 1)
				finished = true;

			//If the item at the index is greater than the item we're looking for, move on to check the upper half of the unsearched portion of the set
			if (comparison > 0) 
			{
				upperBound = index;
				index = lowerBound + (upperBound - lowerBound) / 2;
				continue;
			}

			//If the item at the index is lesser than the item we're looking for, move on to check the lower half of the unsearched portion of the set
			if(comparison < 0)
			{
				lowerBound = index;
				index = lowerBound + (upperBound - lowerBound) / 2;
				continue;
			}

		}
		//If we finished, return upperBound.  This will be the index to insert a new element at.
		return upperBound;
	}

	/**
	 * 
	 * @author Lucas Fivas, Maxwell Wright
	 *
	 * @param <E>
	 * -the type of items in the set
	 */
	public class MySortedSetIterator<E> implements Iterator<E>
	{
		private int index;
		private int count;
		private Object[] items;

		protected MySortedSetIterator(Object[] items, int count)
		{
			index = 0;
			this.items = items;
			this.count = count;
		}

		/**
		 * Checks if there is a next element in the set.
		 * @return true if there is a next element; false if there is not
		 */
		@Override
		public boolean hasNext() {
			return (index < count);
		}

		/**
		 * Gets the next element in the set.
		 * @return The next element in the set.
		 */
		@Override
		public E next() {
			if (hasNext())
				return (E)items[index++];
			throw new NoSuchElementException();
		}

		/**
		 * Not supported.
		 * @throws UnsupportedOperationException
		 */
		@Override
		public void remove() {
			throw new UnsupportedOperationException();
		}
	}


}

