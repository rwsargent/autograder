package assignment3;

import java.util.Comparator;

/**
 *  * @author Lucas Fivas, Maxwell Wright
 * A default comparator for the MySortedSet
 */
public class MySortedSetDefaultComparator<E extends Comparable> implements Comparator<E>
{

	/**
	 * Compares using the natural ordering.
	 * @return The result from arg0.compareTo(arg1)
	 */
	@Override
	public int compare(E arg0, E arg1) {
		return arg0.compareTo(arg1);
		//return arg1.compareTo(arg0);
	}
	
}