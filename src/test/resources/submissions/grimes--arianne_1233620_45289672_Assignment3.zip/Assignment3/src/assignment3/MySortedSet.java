package assignment3;

import java.util.Arrays;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Arianne Grimes
 * Giorgi Kvernadze
 * 
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @param <E>
 *            -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] list; // backbone array for MySortedSet
	private int elements; // the number of elements in the MySortedSet
	private Comparator comparator; // given comparator
	private int middle; // index for inserting an element in the list
	private E[] tempArray; // for given Collections
	private int index;
	private boolean canRemove; // boolean that keeps track of whether or not

	/**
	 * constructor if the elements are ordered according to their natural
	 * ordering
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet() {

		list = (E[]) new Object[10];
		comparator = null;
	}

	/**
	 * constructor if the elements are ordered according to the given comparator
	 */
	public MySortedSet(Comparator<? super E> _comparator) {

		list = (E[]) new Object[10];
		comparator = _comparator;

	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {

		return comparator();
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (elements == 0) {
			throw new NoSuchElementException();
		}
		return list[0];

	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {

		if (list[0] != null) {
			return list[elements - 1];
		}
		throw new NoSuchElementException();
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {

		if (elements >= list.length) {
			E[] listCopy = (E[]) new Object[list.length * 2];
			for (int i = 0; i < list.length; i++) {
				listCopy[i] = list[i];
			}

			list = listCopy;

		}

		if (elements == 0) {
			list[0] = o;
			elements++;
			return true;
		}

		else {

			int n = binarySearch((E) o);

			if (n != -1) {

				for (int i = elements - 1; i >= n; i--) {
					list[i + 1] = list[i];
				}

				list[n] = (E) o;
				elements++;

				return true;
			}
		}

		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {

		tempArray = (E[]) c.toArray();
		boolean changed = false;

		for (int i = 0; i < tempArray.length; i++) {
			if (add(tempArray[i])) {
				changed = true;
			}
		}

		return changed;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		list = (E[]) new Object[10];
		elements = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {

		if (binarySearch((E) o) == -1) {
			return true;
		}

		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {

		tempArray = (E[]) c.toArray();
		for (int i = 0; i < tempArray.length; i++) {

			if (!contains(tempArray[i])) {

				return false;
			}
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (elements == 0) {
			return true;
		}
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MyIterator();

	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int n = binarySearch((E) o);
		if (n == -1) {
			list[middle] = null;

			for (int i = middle; i <= elements - 1; i++) {
				list[i] = list[i + 1];
			}

			elements--;
			return true;
		}

		return false;

	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {

		tempArray = (E[]) c.toArray();

		boolean changed = false;

		for (int i = 0; i < tempArray.length; i++) {
			if (remove(tempArray[i])) {
				changed = true;
			}
		}

		return changed;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return elements;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {

		return list;
	}

	/**
	 * binary search through list, can handle elements that either implement
	 * Comparator or Comparable
	 * 
	 * @param o
	 * @return -1 if o is already in the list, otherwise, returns the index in
	 *         the list where o should go
	 */
	private int binarySearch(E o) {

		if (isComparable(o)) {

			int low = 0;
			int high = elements - 1;

			while (high >= low) {
				middle = (low + high) / 2;
				if ((((Comparable) o)).compareTo(list[middle]) == 0) {
					return -1;

				}

				if ((((Comparable) o)).compareTo(list[middle]) < 0) {

					high = middle - 1;
				}

				else if ((((Comparable) o)).compareTo(list[middle]) > 0) {
					low = middle + 1;
				}

			}

			if ((((Comparable) o)).compareTo(list[middle]) < 0) {
				return middle;
			}

			else {
				return middle + 1;
			}
		}

		else {

			int low = 0;
			int high = elements - 1;
			while (high >= low) {
				middle = (low + high) / 2;
				if (comparator.compare(o, list[middle]) == 0) {
					return -1;
				}

				if (comparator.compare(o, list[middle]) < 0) {
					high = middle - 1;
				}

				else if (comparator.compare(o, list[middle]) > 0) {
					low = middle + 1;
				}
			}
			if (comparator.compare(o, list[middle]) < 0) {
				return middle;
			}

			else {
				return middle + 1;
			}
		}

	}

	/**
	 * determines whether the parameter o implements Comparator or Comparable
	 * 
	 * @param o
	 * @return true if o implements Comparable, false if o implements Comparator
	 */
	private boolean isComparable(E o) {
		if (o instanceof Comparable<?>) {
			return true;
		}

		return false;
	}

	/**
	 * iterator class that defines next(), hasNext(), and remove() methods for
	 * iterating through a MySortedList
	 *
	 */
	private class MyIterator implements Iterator<E> {
		private int index;
		private boolean canRemove; // boolean that keeps track of whether or not remove can be called				

		/**
		 * returns true if there is another element on which next() can be
		 * called
		 */
		@Override
		public boolean hasNext() {

			return (index < elements);
		}

		/**
		 * calls the next element in the list, throws a NoSuchElementException
		 * if such an elements does not exist
		 */
		@Override
		public E next() {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			canRemove = true;
			return list[index++];
		}

		/**
		 * removes the last element seen by the iterator, throws an
		 * IllegalStateException if there has not yet been an element called
		 * (i.e next() has not yet been called)
		 */
		public void remove() {
			if (canRemove) {
				MySortedSet.this.remove(list[index]);
				index--;
				canRemove = false;
			} else {
				throw new IllegalStateException();

			}
		}

	}
}
