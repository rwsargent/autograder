package assignment3;

import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * Arianne Grimes
 * Giorgi Kvernadze
 * 
 *
 */
public class MySortedSetTest {

	private MySortedSet setInts;
	private MySortedSet setStrings;
	private MySortedSet set2;
	private MySortedSet set2String;
	private int[] set2Expected;
	private String[] set2ExpectedString;
	private MySortedSet setEmpty;
	private Collection<Integer> testInts;


	private Person stu = new Person();
	Person student[] = new Person[3];

	private MySortedSet setGeneric;

	@Before
	public void setUp() throws Exception {
		
		setEmpty = new MySortedSet();
		
		setInts = new MySortedSet();
		setInts.add(1);
		setInts.add(34);
		setInts.add(3);
		setInts.add(90);
		setInts.add(4);
		setInts.add(-1);
		setInts.add(0);
		setInts.add(4);
		setInts.add(90);

		setStrings = new MySortedSet();
		setStrings.add("Hello");
		setStrings.add("test");
		setStrings.add("apple");
		setStrings.add("Banana");
		setStrings.add("Paper");
		setStrings.add("Cat");
		setStrings.add("Apple");
		setStrings.add("testing");
		
		
		set2 = new MySortedSet();	
		set2.add(35);
		set2.add(-4);
		set2.add(1);
		set2.add(44444);
		set2.add(10);
		set2Expected = new int[]{-4, 1, 10, 35,44444}; 
				
		set2String = new MySortedSet();	
		set2String.add("Apple");
		set2String.add("Element");
		set2String.add("Bee");
		set2String.add("Cat");
		set2String.add("Door");
		set2ExpectedString = new String[]{"Apple", "Bee", "Cat", "Door", "Element"};

	}

	@Test
	public void firstTestInts() {

		assertEquals(-1, setInts.first());
	}
	
	@Test
	public void firstTestStrings() {

		assertEquals("Apple", setStrings.first());
	}

	@Test(expected = NoSuchElementException.class)
	public void firstTestException() {

		setEmpty.first();

	}

	@Test
	public void lastTestInts() {

		assertEquals(90, setInts.last());
	}
	
	@Test
	public void lastTestStrings() {

		assertEquals("testing", setStrings.last());
	}

	@Test(expected = NoSuchElementException.class)
	public void lastTestException() {
		setEmpty.last();
	}

	@Test
	public void addTest() {
		
		setInts.add(10);
		setInts.add(334);
		setInts.add(-299);
		setInts.add(11);
		setInts.add(4);
		setInts.add(-1);
		
		
		assertEquals(false, setInts.add(1));
		assertEquals(true, setInts.add(666));
		assertEquals(12,setInts.size());
		assertEquals(-299,setInts.first());
		assertEquals(666,setInts.last());		
	}
	
	@Test
	public void testOrderingInts() {
		
		int compare[] = new int[set2.size()];
		int i = 0;
		Iterator<Integer> iter = set2.iterator();
		
		while(iter.hasNext())
		{
			compare[i] = (int) iter.next();
			i++;
		}
		
		assertArrayEquals(set2Expected, compare);
	}
	
	@Test
	public void testOrderingStrings() {
		
		String compare[] = new String[set2String.size()];
		int i = 0;
		Iterator<String> iter = set2String.iterator();
		
		while(iter.hasNext())
		{
			compare[i] = "" + iter.next();
			i++;
		}
		

		assertArrayEquals(set2ExpectedString, compare);
	}

	@Test
	public void addAllTest() {
		
		testInts = new ArrayList<Integer>();
		testInts.add(1);
		testInts.add(4);
		testInts.add(6);
		testInts.add(11);
		assertEquals(true, setEmpty.addAll(testInts));
	}

	

	@Test
	public void containsTest() {
		
		assertEquals(true, setInts.contains(1));
		assertEquals(true, setStrings.contains("Apple"));
		assertEquals(false, setInts.contains(100000));
		assertEquals(false, setStrings.contains("Google"));
	}

	@Test
	public void containsAllTest() {
		testInts = new ArrayList<Integer>();
		testInts.add(1);
		testInts.add(6);
		testInts.add(9);
		testInts.add(100);
		setEmpty.addAll(testInts);
		assertEquals(true, setEmpty.containsAll(testInts));
	}

	@Test
	public void isEmptyTest() {
		
		assertEquals(false,setInts.isEmpty());
		assertEquals(true,setEmpty.isEmpty());
	}

	@Test
	public void iteratorTest() {

	}

	@Test
	public void removeTest() {
		
		setInts = new MySortedSet();
		setInts.add(1);
		setInts.add(34);
		setInts.add(3);
		
		setInts.remove(34);		
		assertEquals(2, setInts.size());
		
		setInts.remove(1);	
		setInts.remove(3);	
		assertEquals(true, setInts.isEmpty());


	}

	@Test
	public void removeAllTest() {
		
		testInts = new ArrayList<Integer>();
		testInts.add(1);
		testInts.add(6);
		testInts.add(10);
		testInts.add(111);
		
		setEmpty.addAll(testInts);
		assertEquals(true, setEmpty.containsAll(testInts));
		
		setEmpty.removeAll(testInts);
		assertEquals(true, setEmpty.isEmpty());

	}

	@Test
	public void sizeTest() {
		
		setInts = new MySortedSet();
		setInts.add(1);
		setInts.add(34);
		setInts.add(3);
		setInts.add(1);
		setInts.add(10);
		setInts.add(5);
		
		assertEquals(5, setInts.size());

	}

	@Test
	public void toArrayTest() {
		
		setInts = new MySortedSet();
		setInts.add(1);
		setInts.add(34);
		setInts.add(3);
		setInts.add(1);
		setInts.add(10);
		setInts.add(5);
		
		System.out.println(Arrays.toString(setInts.toArray()));
		
		
		Object compare[] = new Object[]{1, 3, 5, 10, 34, null, null, null, null, null};
		
		assertArrayEquals(compare, setInts.toArray());


	}

	@After
	public void tearDown() throws Exception {
	}

	
	@Test(expected = NoSuchElementException.class)
	public void clearTest() {
		 setInts.clear();
		 setInts.first();

	}

	

	public class AgeComparator implements Comparator<Person> {

		@Override
		public int compare(Person o1, Person o2) {

			return o1.getAge() - o2.getAge();

		}

	}

}
