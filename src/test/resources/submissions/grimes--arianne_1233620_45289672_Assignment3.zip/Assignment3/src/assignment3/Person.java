package assignment3;

import java.util.Comparator;

/**
 * Arianne Grimes 
 * Giorgi Kvernadze
 * 
 * class that uses Comparator, for testing purposes
 */
public class Person {
	private String name; // name
	private int age; // age

	/**
	 * constructor
	 */
	public Person() {
	}

	/**
	 * constructor
	 * 
	 * @param name
	 * @param age
	 */
	public Person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * sets name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return age
	 */
	public int getAge() {
		return age;
	}

	/**
	 * sets age
	 * @param age
	 */
	public void setAge(int age) {
		this.age = age;
	}

	/**
	 * converts object to string
	 * 
	 * @return
	 */
	@Override
	public String toString() {
		return "[name=" + this.name + ", age=" + this.age + "]";
	}

	/**
	 * comparator
	 */
	public class AgeComparator implements Comparator<Person> {

		@Override
		public int compare(Person o1, Person o2) {

			return o1.getAge() - o2.getAge();

		}

	}

}
