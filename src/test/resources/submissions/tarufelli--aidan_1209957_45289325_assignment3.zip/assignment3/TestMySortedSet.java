package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * This is a junit tester that test the methods that were written
 * by the authors.  Though it is not as extensive as we would like it,
 * this test code should cover most if not all the instances that we could
 * face when taking in information.
 * 
 * @author Aidan Tarufelli & Ellen Brigance
 *
 * @param <E>
 */

public class TestMySortedSet<E> {
	
	private MySortedSet<String> set;
	private MySortedSet<Integer> set1;
	ArrayList<Integer> nums = new ArrayList<Integer> ();
	ArrayList<Integer> nums1 = new ArrayList<Integer> ();
	ArrayList<Integer> nums2 = new ArrayList<Integer> ();
	Object[] arr1 = new Object [] {0,1,2,3,4,5,6,7,8,9,10};
	
	
	//private My

	@Before
	public void setUp() throws Exception {
		set = new MySortedSet<String> ();
		set1 = new MySortedSet<Integer> ();
		nums.add(1);
		nums.add(2);
		nums.add(3);
		nums.add(4);
		nums.add(5);
		nums.add(6);
		nums.add(7);
		nums.add(8);
		nums.add(9);
		nums.add(0);
		nums.add(10);
		nums1.add(1);
		nums2.add(1);
		nums2.add(3);
		nums2.add(5);
		nums2.add(7);
		nums2.add(9);

		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testFirst1() {
		set.add("e");
		set.add("C");
		set.add("A");
		set.add("D");
		set.add("a");
		set.add("B");
		set.add("l");
		set.add("g");
		set.add("r");
		set.add("G");
		set.add("P");
		
		assertEquals("A", set.first());
	}
	@Test(expected = NoSuchElementException.class)
	public void testFirst2() {
		set.first();
	}

	@Test
	public void testLast1() {
		set.add("e");
		set.add("C");
		set.add("A");
		set.add("D");
		set.add("a");
		set.add("B");
		set.add("l");
		set.add("g");
		set.add("r");
		set.add("G");
		set.add("P");
		
		assertEquals("r", set.last());
	}
	
	@Test(expected = NoSuchElementException.class)
	public void testLast2() {
		set.last();
	}

	@Test
	public void testAdd() {
		set.add("e");
		set.add("C");
		set.add("A");
		set.add("D");
		set.add("a");
		set.add("B");
		set.add("l");
		set.add("g");
		set.add("r");
		set.add("G");
		set.add("P");

		assertEquals(true, set.add("H"));
		assertEquals(false, set.add("e"));
	}

	@Test
	public void testAddAll() {
		set1.add(1);
		assertEquals(true, set1.addAll(nums));
		assertEquals(false, set1.addAll(nums1));
	}

	@Test
	public void testClear() {
		set.add("e");
		set.add("C");
		set.add("A");
		set.add("D");
		set.add("a");
		set.add("B");
		set.add("l");
		set.add("g");
		set.add("r");
		set.add("G");
		set.add("P");
		set.clear();
		assertEquals(null, set.first());
	}

	@Test
	public void testContains() {
		set.add("e");
		set.add("C");
		set.add("A");
		set.add("D");
		set.add("a");
		set.add("B");
		set.add("l");
		set.add("g");
		set.add("r");
		set.add("G");
		set.add("P");
		assertEquals(true, set.contains("G"));
		assertEquals(false, set.contains("b"));
	}

	@Test
	public void testContainsAll() {
		set1.addAll(nums);
		assertEquals(true, set1.containsAll(nums2));
	}

	@Test
	public void testIsEmpty() {
		assertEquals(true, set.isEmpty());
		
		set.add("b");
		assertEquals(false, set.isEmpty());
	}

	@Test
	public void testRemove() {
		
		set.add("a");
		set.add("c");
		assertEquals(true, set.remove("a"));
		assertEquals(false, set.remove("b"));
	}

	@Test
	public void testRemoveAll() {
		set1.addAll(nums);
		assertEquals(true, set1.removeAll(nums2));
	}

	@Test
	public void testSize1() {
		assertEquals(0, set.size());
	}
	
	@Test
	public void testSize2() {
		set1.addAll(nums);
		assertEquals(11, set1.size());
	}

	@Test
	public void testToArray() {
		set1.addAll(nums);
		assertArrayEquals(arr1, set1.toArray());
	}

}
