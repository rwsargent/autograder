package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This class contains methods that were written in order to perform certain
 * sorting actions that include adding and objects to a sorted set, removing
 * objects from the sorted set, checking to see if certain items are contained
 * within the sorted set, and more. This class implements SortedSet <E>.
 * 
 * @author Aidan Tarufelli & Ellen Brigance
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E> {

	private Comparator<? super E> p_comparator;
	private int arraySize = 10;
	private E[] array;
	private int numElements;


	/**
	 *Constructor that creates an empty array that will 
	 *hold E objects.
	 *
	 */
	public MySortedSet() {
		// initialized using the natural ordering
		array = (E[]) new Object[arraySize];

	}

	/**
	 *Constructor that sets up an array that will hold
	 *E objects but will be governed by the user's
	 *comparator.
	 *
	 */
	public MySortedSet(Comparator<? super E> p_comparator) {
		//allows user to use their own comparator
		this();
		this.p_comparator = p_comparator;
	}

	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return p_comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (this.numElements == 0)
			throw new NoSuchElementException("This is an empty list.");
		return array[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (this.numElements == 0)
			throw new NoSuchElementException("This is an empty list.");
		return array[numElements - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o -- element to be added to this set
	 * 
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		// Binary Search - if the element is not already in the array, insert it.
		if(numElements == 0){
			array[0] = o;
			numElements++;
			return true;
		}
		int middle = binaryHelper(o);
		if (compare(o, array[middle]) == 0)
			return false;
		else {
			if (array.length == numElements) { //grow the array if necessary
				arraySize = arraySize * 2;
				E[] temp = (E[]) new Object[arraySize];

				for(int i = 0; i < numElements; i++) //copy the array into the larger array
					temp[i] = array[i];
				array = temp;
			}
			/*if (compare(array[binaryHelper(o)], o) < 0)
				middle = binaryHelper(o);
			else if (compare(array[binaryHelper(o)], o) > 0)
				middle = binaryHelper(o) + 1;*/
				
				
			if(compare(array[middle], o) < 0)
				middle++;		
				
			for (int i = numElements; i >= middle && i > 0; i--)
				array[i] = array[i-1];
			
			
			array[middle] = o; //insert the element
			numElements ++;
			return true;
		}
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		int originalSize = numElements;
		for (E a : c)
			add(a);
		return (originalSize != numElements);
	}

	/**Collection<? extends E> c)
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		for (int i = 0; i < numElements; i++)
			array[i] = null;
			numElements--;
	}

	/**
	 * @param o -- element whose presence in this set is to be tested
	 * 
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		if (compare((E) o, array[binaryHelper((E) o)]) == 0)
			return true;
		return false;

	}

	/**
	 * @param c -- collection to be checked for containment in this set
	 * 
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for (Object a: c){
			if (contains(a)){
			}
			else
				return false;
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (numElements == 0)
			return true;
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MyIterator();
	}


	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o -- object to be removed from this set, if present
	 * 
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		if (numElements == 0)
			return false;
		int middle = binaryHelper((E) o);
		if (compare((E) o, array[middle]) == 0) { //if the object we're trying to remove is found in the array
			for (int i = middle; i < numElements - 1 ; i++){
				array[i] = array[i+1];		//removes desired element
			}
			array[numElements - 1]= null; // removes duplicate at end of array.
			numElements --;
			return true;
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c -- collection containing elements to be removed from this set
	 * 
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		int originalSize = numElements;
		for (Object e : c) //"for every Object e in c"
			remove (e);
		return (originalSize != numElements);
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return numElements;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		E[] newArray = (E[]) new Object [numElements]; //initializing new array
		for (int i = 0; i < numElements; i++)
			newArray [i] = array[i]; //copies objects to new object array
		return newArray;
	}
	
	/**This method conducts a binary search.
	 * 
	 * @param array -- the array that we're searching
	 * @param o -- the item that we're searching for
	 * @return midPos -- position of item we're searching for in the array
	 */
	private int binaryHelper (E o) {
		int startPos = 0;
		int endPos = numElements -1;
		int middle = 0;
		while (startPos <= endPos) {
			middle = (startPos + endPos)/2;
			//if the second object is greater than what's in the middle, search the second half of the array
			if (compare(array[middle], o) > 0)
				endPos = middle - 1;
			//if the second object is less than than what's in the middle, search the first half of the array
			else if (compare(array[middle], o) < 0)
				startPos = middle + 1;
			else if (compare(array[middle], o) == 0)
				return middle;
			if (startPos == middle) //this is to prevent the code from getting jammed up
				return middle;		//as the search area shrinks.
		}
		return middle;
	}
	
	/**
	 * This is a class that allows for the implementation of 
	 * methods contained in Iterator. They are overridden in
	 * order to complete the tasks that we need them to.
	 * 
	 */
	private class MyIterator implements Iterator <E> {
		//need a starting position for our iterator
		int arrayPos = 0;

		@Override
		public boolean hasNext() {
			if(arrayPos < numElements -1)
				return true;
			return false;
		}

		@Override
		public E next() {
			if (this.hasNext()){
				arrayPos ++;
				return array[arrayPos];
			}
			else
				throw new NoSuchElementException("There are no more elements to iterate.");
		}

		@Override
		public void remove() {
			MySortedSet.this.remove(array[arrayPos]);
		}
	}
	
	/**
	 * This method compares two items, using Comparator or Comparable when appropriate.
	 * 
	 * @param item1 -- the first object to be compared
	 * @param item2 -- the second object to be compared
	 * @return -- negative integer if (item1 < item2) 
	 * 			  zero if (item1 = item2)
	 * 			  a positive integer if (item1 > item2) 
	 */

	private int compare(E item1, E item2) {
		//Check to see if the objects can use Comparator
		if (this.comparator() == null) {
			//if it can't, change it to use Comparable to compare the two items, instead.
			Comparable<E> comparableItem;
			if(item1 instanceof Comparable) {
				comparableItem = (Comparable<E>) item1; //creates an item that can be compared.
				return comparableItem.compareTo(item2); //uses compare to to make comparison
			}
		}
		return this.comparator().compare(item1, item2);	
	}
}