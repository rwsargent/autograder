package assignment3;

import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * CS 2420 - Assignment 3
 * @author Nicholas Moore - 
 * @author Nicholas Lloyd - u0949261
 *
 * A generic implementation of an ordered Set which uses either a given Comparator or
 * a types given Comparable method to order the objects.  Utilizes binary searching,
 * adding, and removing.
 * 
 * NOTE: This set CANNOT accept types that aren't comparable unless a Comparator is
 * given via parameter.
 *
 * @param <E> - The type of object to be stored
 */
public class MySortedSet<E> implements SortedSet<E>, Iterator<E>, Iterable<E> {

	// Declare the member variables
	private E[] theArray;
	private int size;
	private Comparator<? super E> theComparator;
	private int pointer;
	
	/**
	 * Plain constructor, no Comparator given.
	 */
	public MySortedSet() {
		
		// Set initial size of structure to 50
		theArray = (E[]) new Object[50];
		
		// Size starts at 0
		size = 0;
		
		// Pointer always starts at -1
		pointer = -1;
		
		// No comparator given
		theComparator = null;
	}
	
	/**
	 * Constructor for when Comparator is specified.
	 * 
	 * @param comp - The Comparator to be used for sorting this MySortedSet
	 */
	public MySortedSet(Comparator<? super E> comp) {
		
		// Call the plain constructor to initialize member variables
		this();
		
		// Set the member variable Comparator to the one specified by the caller
		theComparator = comp;
	}
	
	/**
	 * Returns the Comparator for this MySortedSet, returns null if it has none.
	 * 
	 * @return - Comparator if this MySortedSet has one, null otherwise
	 */
	@Override
	public Comparator<? super E> comparator() {
		return (theComparator == null) ? theComparator : null;
	}

	/**
	 * Returns the first Object in this MySortedSet. Returns null if it is empty.
	 * 
	 * @return - First Object in this MySortedSet, returns null if it is empty
	 * @exception - NoSuchElementException() if this MySortedSet is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		
		// if it's empty, throw exception
		if (size == 0) throw new NoSuchElementException();
		
		// If it's not empty, return the first Object
		else return theArray[0];
	}

	/**
	 * Returns the last Object in this MySortedSet. Returns null if it is empty.
	 * 
	 * @return - First Object in this MySortedSet, returns null if it is empty
	 * @exception - NoSuchElementException() if this MySortedSet is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		
		// If it's empty, throw exception
		if (size == 0) throw new NoSuchElementException();
		
		// If it's not empty, return the last Object
		return theArray[size - 1];
	}

	/**
	 * If a Comparator was given at construction, or the type of this MySortedSet is
	 * comparable, adds the parameter Object to this MySortedSet and returns true.
	 * Returns false if no Comparator, type isn't comparable, or the Object is already
	 * in this MySortedSet. Utilizes Binary Search to either find a duplicate, or 
	 * determine the spot the parameter object needs to be put.
	 * 
	 * @param o - Object to add to this MySortedSet
	 * @return - true if o is added to this MySortedSet, false if it is not
	 */
	@Override
	public boolean add(E o) {
		
		// If we can't compare this type, or o is null, return false
		if ((theComparator == null && !(o instanceof Comparable)) || o == null) return false;

		// Make the array bigger if necessary
		if (size == theArray.length) {
			E[] temp = (E[]) new Object[size*2];
			for (int j = 0; j < size; j++) temp[j] = theArray[j];
			theArray = temp;
		}

		// If there's nothing added yet, just add it
		if (size == 0) {
			theArray[0] = o;
			size++;
			return true;
		}
		
		// For comparison results
		int comp;
		
		// If it's size one, figure out where it goes and add it
		if (size == 1) {
			
			// Compare the objects
			if (theComparator != null) comp = theComparator.compare((E) o, theArray[0]);
			else comp = ((Comparable) o).compareTo(theArray[0]);
			
			// If they're the same, return false
			if ( theArray[0].equals(o) ) return false;
			
			// If o is before the element, move the element over and place o first
			if ( comp < 0 ) {
				theArray[1] = theArray[0];
				theArray[0] = o;
				size++;
				return true;
			}
			
			// Otherwise, just add o to the end
			else {
				theArray[1] = o;
				size++;
				return true;
			}
		}
		
		// Set the initial boundaries and mid point
		int lowerBound = 0;
		int upperBound = size-1;
		int mid = upperBound/2;

		// Make sure o doesn't equal either of the boundaries
		if (first().equals(o)) return false;
		if (last().equals(o)) return false;

		// If o is on either side of the boundaries, add it before or after all entries
		comp = (theComparator != null) ? theComparator.compare((E) o, theArray[upperBound]) :
			((Comparable) o).compareTo(theArray[upperBound]);
		if (comp > 0) {
			theArray[upperBound + 1] = o;
			size++;
			return true;
		}
		
		comp = (theComparator != null) ? theComparator.compare((E) o, theArray[lowerBound]) :
			((Comparable) o).compareTo(theArray[lowerBound]);
		if (comp < 0) {
			shift(0, true);
			theArray[lowerBound] = o;
			size++;
			return true;
		}

		// Binary search algorithm
		while (upperBound - lowerBound != 1) {

			// If the midpoint equals o, it's there
			if (theArray[mid].equals(o)) return false;

			// Only compare once
			comp = (theComparator != null) ? theComparator.compare((E) o, theArray[mid]) :
				((Comparable) o).compareTo(theArray[mid]);

			// If it's before the midpoint, make mid the upperBound and recalculate mid
			if (comp < 0) {
				upperBound = mid;
				mid = (upperBound + lowerBound) / 2;
			}

			// If it's after the midpoint, make mid the lowerBound and recalculate mid
			else {
				lowerBound = mid;
				mid = (upperBound + lowerBound) / 2;
			}
		}
				
		// If the loop ends without returning false, shift the array and add o
		shift(upperBound, true);
		theArray[upperBound] = o;

		// Increase the size
		size++;

		// Return true
		return true;
	}

	
	/**
	 * Shift the array to allow for adding or removing elements
	 * 
	 * @param start - The point to start at
	 * @param right - If true, it's shifting right. If false, shifting left.
	 */
	private void shift(int start, boolean right) {
		if (right) {
			for (int i = size; i > start; i--) theArray[i] = theArray[i-1];
		}
		else {
			for (int i = start; i < size - 1; i++) theArray[i] = theArray[i+1];
			theArray[size - 1] = null;
		}
	}

	/**
	 * Add the values of a collection to the set
	 * 
	 * @param c - Collection of same type as MySortedSet
	 * @return - true if values were added, false if values were not added
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		
		// Default return
		boolean collectionChanged = false;
		
		// If any elements are added, make collectionChanged true
		for (E iteratableObject: c) collectionChanged = (this.add(iteratableObject)) ? true : collectionChanged;
		
		// Return true if any elements were added, false otherwise
		return collectionChanged;
	}

	/**
	 * Clear the structure by setting it to a new, empty one
	 */
	@Override
	public void clear() {
		
		// Set the array to a new, empty one
		theArray = (E[]) new Object[50];
		
		// Set size to zero as the structure is now empty
		size = 0;
	}
	
	/**
	 * Returns true if any object in MySortedList has the same value as the parameter object.
	 * 
	 * @param o - The object to be searched for
	 * @return - True if o is in this MySortedList, false if o is not in this MySortedList
	 */
	@Override
	public boolean contains(Object o) {
		
		// If we can't compare this type, return false
		if (theComparator == null && !(o instanceof Comparable)) return false;
				
		// if o is null or there's nothing in the set, return false
		if (o == null || size == 0) return false;
		
		// If the size is one, just check it
		if (size == 1) {
			if (o.equals(theArray[0])) return true;
			else return false;
		}
		
		// Set the bounds & compare ints
		int lowerBound = 0;
		int upperBound = size - 1;
		int mid = upperBound / 2;
		int comp;
		
		// If o is equal to either bound, return true
		if (theArray[lowerBound] == o || theArray[upperBound] == o) return true;

		// If o is before the lowerBound, or o isn't comparable, return false
		comp = (theComparator != null) ? theComparator.compare((E) o, theArray[lowerBound]) :
			((Comparable) o).compareTo(theArray[lowerBound]);
		if (comp < 0) return false;

		// If o is higher than the upperBound, return false
		comp = (theComparator != null) ? theComparator.compare((E) o, theArray[upperBound]) :
			((Comparable) o).compareTo(theArray[upperBound]);
		if (comp > 0) return false;

		// Meat and Potatoes loop
		while (upperBound - lowerBound != 1) {
			
			// Return true is o equals the mid
			if (o.equals(theArray[mid])) return true;
			
			comp = (theComparator != null) ? theComparator.compare((E) o, theArray[mid]) :
				((Comparable) o).compareTo(theArray[mid]);
			
			// if o is lower than mid, make upperBound mid and recalculate mid
			if (comp < 0) {
				upperBound = mid;
				mid = (upperBound + lowerBound) / 2;
			}
			
			// if o is higher than mid, make lowerBound mid and recalculate mid
			else {
				lowerBound = mid;
				mid = (upperBound + lowerBound) / 2;
			}
		}
		return false;
	}
	
	/**
	 * Compares all values of parameter collection objects to those in this MySortedSet. If
	 * any of the parameter collection values are not in this MySortedSet, return false; 
	 * otherwise return true;
	 * 
	 * @param c - A collection of objects
	 * @return - false if any parameter collection values are not in this MySortedSet, true
	 * otherwise
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		
		// If Collection C is empty, return false
		if (c.size() == 0) return false;
		
		// If any c object is not in this MySortedSet, return false
		for (Object iterableObject: c) if (this.contains(iterableObject) == false) return false;
		
		// If all c objects were in this MySortedSet, return true
		return true;
	}

	/**
	 * Determines if this MySortedSet is empty.
	 * 
	 * @return - true if this MySortedSet is empty, false if this MySortedSet is not empty
	 */
	@Override
	public boolean isEmpty() {
		return (size == 0) ? true : false;
	}

	/**
	 * Returns the iterator for this MySortedSet.
	 * 
	 * @return - Iterator for this MySortedSet
	 */
	@Override
	public Iterator<E> iterator() {
		
		// When a new iterator is called, reset the pointer
		pointer = -1;
		
		// Return this class, as it implements Iterator
		return this;
	}

	/**
	 * Removes the parameter Object if it is contained in this MySortedSet, and returns true.
	 * If the parameter Object is not contained in this MySortedSet, returns false;
	 * 
	 * @param o - Object to remove from this MySortedSet
	 * @return - true if the Object is removed from this MySortedSet, false otherwise
	 */
	@Override
	public boolean remove(Object o) {
		
		// If we can't compare this type, return false
		if (theComparator == null && !(o instanceof Comparable)) return false;
				
		// Make sure o isn't null and this object isn't empty
		if (o == null || size == 0) return false;
		
		// Set up initial bounds
		int lowerBound = 0;
		int upperBound = size - 1;
		int mid = upperBound / 2;
		int comp;
		
		// if o equals one of the bounds, remove it.
		if (o.equals(theArray[lowerBound])) {
			shift(0, false);
			theArray[upperBound] = null;
			size--;
			return true;
		}
		else if (o.equals(theArray[size - 1])) {
			theArray[size - 1] = null;
			size--;
			return true;
		}
		
		// If o comes before the lowerBound, return false
		comp = (theComparator != null) ? theComparator.compare((E) o, theArray[lowerBound]) :
			((Comparable) o).compareTo(theArray[lowerBound]);
		if (comp < 0) return false;
		
		// If o comes after the upperBound, return false
		comp = (theComparator != null) ? theComparator.compare((E) o, theArray[upperBound]) :
			((Comparable) o).compareTo(theArray[upperBound]);
		if (comp > 0) return false;
		
		// Binary Search
		while (upperBound - lowerBound != 1) {
			
			// of mid equals o, remove it
			if (o.equals(theArray[mid])) {
				shift(mid, false);
				theArray[size - 1] = null;
				size--;
				return true;
			}
			
			comp = (theComparator != null) ? theComparator.compare((E) o, theArray[mid]) :
				((Comparable) o).compareTo(theArray[mid]);
			
			// if o is lower than mid, make upperBound mid and recalculate mid
			if (comp < 0) {
				upperBound = mid;
				mid = (upperBound + lowerBound) / 2;
			}
			
			// if o is higher than mid, make lowerBound mid and recalculate mid
			else {
				lowerBound = mid;
				mid = (upperBound + lowerBound) / 2;
			}
		}
		return false;
	}

	/**
	 * Removes all Objects in parameter collection from this MySortedSet.
	 * 
	 * @param c - Collection of Objects to remove from this MySortedSet
	 * @return - true if any Objects are removed from this MySortedSet, false if not
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		
		// set the default return
		boolean collectionChanged = false;
		
		// If any Object from c is removed from this MySortedSet, change return value to true
		for (Object iteratorObject : c) collectionChanged = (this.remove(iteratorObject)) ? true : collectionChanged;
		
		// Return the value
		return collectionChanged;
	}

	/**
	 * Returns the number of Objects contained in this MySortedSet
	 * 
	 * @return - int value representing number of Objects in this MySortedSet
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Returns all Objects in this MySortedSet in the form of an array.
	 * 
	 * @return - An array of all Objects in this MySortedSet
	 */
	@Override
	public Object[] toArray() {
		
		// Create an array to house the Objects
		E[] tempArray = (E[]) new Object [size];
		
		// Copy Objects into array
		for (int i = 0; i < size; i = i + 1) tempArray[i] = theArray[i];
		
		// Return the array
		return tempArray;
	}

	/**
	 * MySortedSet implements Iterator(), this method is a required overwrite. Returns
	 * true if there is another Object in this MySortedSet after the current location of
	 * the iterator. Returns false if there is no such Object.
	 * 
	 * @return - boolean: true if another Object follows the current iterator, false if not
	 */
	@Override
	public boolean hasNext() {
		
		// If the pointer is at the end, there are no more Objects, otherwise there are
		return (pointer == size - 1) ? false : true;
	}

	/**
	 * MySortedSet implements Iterator(), this method is a required overwrite. If there is
	 * a next Object, returns the Object which follows the current location of the iterator.
	 * Returns null otherwise.
	 * 
	 * @return - The next Object in the iterator, or null if there isn't one
	 */
	@Override
	public E next() {
		return (hasNext()) ? theArray[++pointer] : null;
	}

}
