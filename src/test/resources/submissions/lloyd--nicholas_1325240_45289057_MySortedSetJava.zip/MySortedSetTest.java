package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * CS 2420 - Assignment 3
 * @author Nicholas Moore - 
 * @author Nicholas Lloyd - u0949261
 * 
 * Most of the tests in this JUnit will be using toArray from the MySortedSet class to test the methods.
 */
public class MySortedSetTest 
{
	MySortedSet <Integer> ss1;
	MySortedSet <String> ss2;
	MySortedSet <Boolean> ss3;
	MySortedSet <Integer> ss4;
	MySortedSet <Double> ss5;
	MySortedSet <String> ss6;
	
	/**
	 * Initializes all of the MySortedSets.
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception 
	{
		ss1 = new MySortedSet <Integer> ();
		ss2 = new MySortedSet <String> ();
		ss3 = new MySortedSet <Boolean> ();
		ss4 = new MySortedSet <Integer> ();
		ss5 = new MySortedSet <Double> ();
		ss6 = new MySortedSet <String> ();
	}

	@After
	public void tearDown() throws Exception 
	{
		
	}
	
	/**
	 * This checks the toArray() method, although this method will be checked throughout the whole JUnit.
	 */
	@Test
	public void testToArray()
	{
		ss1.add(1);
		ss1.add(2);
		ss1.add(3);
		assertTrue(Arrays.equals(ss1.toArray(), new Integer[] {1, 2, 3}));
		ss1.add(4);
		assertTrue(Arrays.equals(ss1.toArray(), new Integer[] {1, 2, 3, 4}));
		ss2.add("a");
		ss2.add("b");
		ss2.add("c");
		assertTrue(Arrays.equals(ss2.toArray(), new String[] {"a", "b", "c"}));
		ss2.add("d");
		ss2.add("e");
		assertTrue(Arrays.equals(ss2.toArray(), new String[] {"a", "b", "c", "d", "e"}));
		ss3.add(true);
		ss3.add(false);
		assertTrue(Arrays.equals(ss3.toArray(), new Boolean[] {false, true}));
		ss3.add(true);
		assertTrue(Arrays.equals(ss3.toArray(), new Boolean[] {false, true}));
	}

	@Test
	public void testComparator() 
	{
		// Create a test comparator that uses any comparable type to reverse the order of the natural comparison
		class Reverse implements Comparator {

			@Override
			public int compare(Object arg0, Object arg1) {
				if (((Comparable) arg0).compareTo(arg1) < 0) return 1;
				else if (((Comparable) arg0).compareTo(arg1) > 0) return -1;
				else return 0;
			}
			
		}
		
		Reverse reverseOrder = new Reverse();
		MySortedSet<Integer> toReverse = new MySortedSet<Integer>(reverseOrder);
		toReverse.add(1);
		toReverse.add(2);
		toReverse.add(3);
		toReverse.add(4);
		toReverse.add(5);
		toReverse.add(10);
		toReverse.add(7);
		toReverse.add(21);
		toReverse.add(11);
		toReverse.add(-1);
		assertTrue(Arrays.equals(toReverse.toArray(), new Integer[] {21, 11, 10, 7, 5, 4, 3, 2, 1, -1}));
		assertTrue(toReverse.remove(7));
		assertFalse(toReverse.remove(50));
		assertTrue(toReverse.contains(3));
		assertFalse(toReverse.contains(9));
		
	
		MySortedSet<String> reverseStrings = new MySortedSet<String>(reverseOrder);
		reverseStrings.add("happy");
		reverseStrings.add("Happy");
		reverseStrings.add("stupid");
		reverseStrings.add("lion eats gazelle,");
		reverseStrings.add("Bob");
		reverseStrings.add("xylophone");
		assertFalse(reverseStrings.add("Bob"));
		assertFalse(reverseStrings.add("happy"));
		assertFalse(reverseStrings.add("lion eats gazelle,"));
		assertFalse(reverseStrings.add("xylophone"));
		assertTrue(Arrays.equals(reverseStrings.toArray(), new String[] { "xylophone", "stupid", "lion eats gazelle,", "happy", "Happy", "Bob"}));
		
		
		Comparator testing = toReverse.comparator();
		assertEquals(testing, toReverse.comparator());
	}
	
	/**
	 * Checks to see if the first element method is working correctly.
	 */
	@Test
	public void testFirst()
	{
		ss1.add(1);
		ss1.add(2);
		ss1.add(3);
		ss1.add(4);
		ss2.add("a");
		ss2.add("b");
		ss2.add("c");
		ss2.add("d");
		ss2.add("e");
		ss3.add(true);
		ss3.add(false);
		ss3.add(true);
		assertTrue(ss1.first().equals(1));
		assertTrue(ss2.first().equals("a"));
		assertTrue(ss3.first().equals(false));
		// Checks to see if the method is throwing exceptions correctly.
		try
		{
			ss4.first();
			fail("No exception was thrown.");
		}
		catch (NoSuchElementException e)
		{
			
		}
	}
	
	/**
	 * Tests to see if the last method of the MySortedSet class is working properly.
	 */
	@Test
	public void testLast()
	{
		ss1.add(1);
		ss1.add(2);
		ss1.add(3);
		ss1.add(4);
		ss2.add("a");
		ss2.add("b");
		ss2.add("c");
		ss2.add("d");
		ss2.add("e");
		ss3.add(true);
		ss3.add(false);
		ss3.add(true);
		assertTrue(ss1.last().equals(4));
		assertTrue(ss2.last().equals("e"));
		assertTrue(ss3.last().equals(true));
		// Checks to see if the method throws and exception when the set is empty.
		try
		{
			ss4.last();
			fail("No exception was thrown.");
		}
		catch (NoSuchElementException e)
		{
			
		}
	}
	
	/**
	 * Tests the add method for the MySortedSet class.
	 */
	@Test
	public void testAdd()
	{
		ss1.add(1);
		ss1.add(2);
		ss1.add(3);
		ss1.add(4);
		ss2.add("a");
		ss2.add("b");
		ss2.add("c");
		ss2.add("d");
		ss2.add("e");
		ss3.add(true);
		ss3.add(false);
		ss3.add(true);
		ss1.add(5);
		assertTrue(Arrays.equals(ss1.toArray(), new Integer [] {1, 2, 3, 4, 5}));
		ss2.add("f");
		ss2.add("a");
		ss2.add("h");
		ss2.add("g");
		assertTrue(Arrays.equals(ss2.toArray(), new String [] {"a", "b", "c", "d", "e", "f", "g", "h"}));
		ss2.add(null);
		assertTrue(Arrays.equals(ss2.toArray(), new String [] {"a", "b", "c", "d", "e", "f", "g", "h"}));
		ss3.add(true);
		ss3.add(false);
		assertTrue(Arrays.equals(ss3.toArray(), new Boolean [] {false, true}));
	}
	
	/**
	 * Tests the addAll method from the MySortedSet class.
	 */
	@Test
	public void testAddAll()
	{
		// The ArrayLists are what we will be using for our collection parameters.
		ArrayList <Integer> list1 = new ArrayList <Integer> ();
		ArrayList <Double> list2 = new ArrayList <Double> ();
		ArrayList <String> list3 = new ArrayList <String> ();
		list1.add(24);
		list1.add(34);
		list1.add(29);
		ss4.addAll(list1);
		assertTrue(Arrays.equals(ss4.toArray(), new Integer [] {24, 29, 34}));
		list1.add(2);
		ss4.addAll(list1);
		// Tests to make sure it won't add the same elements twice.
		assertTrue(Arrays.equals(ss4.toArray(), new Integer [] {2, 24, 29, 34}));
		list2.add(3.0);
		list2.add(3.1);
		list2.add(3.05);
		list2.add(2.01);
		list2.add(1.04);
		ss5.addAll(list2);
		assertTrue(Arrays.equals(ss5.toArray(), new Double [] {1.04, 2.01, 3.0, 3.05, 3.1}));
		list3.add("this");
		list3.add("has");
		list3.add("TO");
		list3.add("be");
		list3.add("ordered");
		list3.add("but");
		list3.add("not");
		list3.add("IN");
		list3.add("way");
		ss6.addAll(list3);
		assertTrue(Arrays.equals(ss6.toArray(), new String [] {"IN", "TO", "be", "but", "has", "not", "ordered", "this", "way"}));
	}
	
	/**
	 * Tests the clear method for the MySortedSet class.
	 */
	@Test
	public void testClear()
	{
		ss1.clear();
		try
		{
			ss1.first(); // Uses the first method to make sure it is clear.
			fail("No exception was thrown");
		}
		catch (NoSuchElementException e)
		{
			
		}
		assertEquals(0, ss1.size()); // Makes sure the size of the sorted set is zero.
		ss2.clear();
		try
		{
			ss2.first();
			fail("No exception was thrown");
		}
		catch (NoSuchElementException e)
		{
			
		}
		assertEquals(0, ss2.size());
		ss3.clear();
		try
		{
			ss3.first();
			fail("No exception was thrown");
		}
		catch (NoSuchElementException e)
		{
			
		}
		assertEquals(0, ss3.size());
	}
	
	/**
	 * Tests the contains method for the MySortedSet class.
	 */
	@Test
	public void testContains()
	{
		ss1.add(23);
		ss1.add(2);
		ss1.add(45);
		ss1.add(3);
		assertTrue(ss1.contains(23));
		assertFalse(ss1.contains(1)); // Makes sure that if the sorted set does not contain the element that false is returned.
		assertFalse(ss2.contains("False"));
		ss2.add("Hello");
		ss2.add("There");
		ss2.add("Contains");
		ss2.add("Computer");
		ss2.add("Java");
		assertTrue(ss2.contains("Java"));
		assertTrue(ss2.contains("There"));
		assertFalse(ss2.contains("java"));
		assertFalse(ss2.contains("hi"));
		ss3.add(false);
		assertTrue(ss3.contains(false));
		assertFalse(ss3.contains(true));
		ss3.add(true);
		assertTrue(ss3.contains(true));
		assertFalse(ss1.contains(null));
		assertFalse(ss2.contains(null));
	}
	
	/**
	 * Tests the containsAll method for the MySortedSet class.
	 */
	@Test
	public void testContainsAll()
	{
		ss1.add(23);
		ss1.add(2);
		ss1.add(45);
		ss1.add(3);
		ss2.add("Hello");
		ss2.add("There");
		ss2.add("Contains");
		ss2.add("Computer");
		ss2.add("Java");
		ss3.add(false);
		ss3.add(true);
		// These ArrayLists are what will be used as the collection parameters for the method.
		ArrayList <Integer> list1 = new ArrayList <Integer> ();
		ArrayList <String> list2 = new ArrayList <String> ();
		ArrayList <Boolean> list3 = new ArrayList <Boolean> ();
		ArrayList <String> list4 = new ArrayList <String> ();
		list1.add(23);
		list1.add(45);
		assertTrue(ss1.containsAll(list1));
		list1.add(63);
		assertFalse(ss1.containsAll(list1));
		list2.add("Java");
		list2.add("There");
		list2.add("Hello");
		assertTrue(ss2.containsAll(list2));
		list3.add(true);
		assertTrue(ss3.containsAll(list3));
		list3.add(false);
		assertTrue(ss3.containsAll(list3));
		assertFalse(ss3.containsAll(list4)); // Makes sure that the method will return false if the collection is null.
	}
	
	/**
	 * Tests the isEmpty method for the MySortedSet class.
	 */
	@Test
	public void testIsEmpty()
	{
		assertTrue(ss1.isEmpty());
		ss1.add(23);
		ss1.add(2);
		ss1.add(45);
		ss1.add(3);
		ss2.add("Hello");
		ss2.add("There");
		ss2.add("Contains");
		ss2.add("Computer");
		ss2.add("Java");
		ss3.add(false);
		ss3.add(true);
		// Checks if the method will notice if the arrays are empty and if they're not.
		ss1.clear();
		assertTrue(ss1.isEmpty());
		assertFalse(ss2.isEmpty());
		assertFalse(ss3.isEmpty());
		ss2.clear();
		ss3.clear();
		assertTrue(ss2.isEmpty());
		assertTrue(ss3.isEmpty());
		ss1.add(1);
		assertFalse(ss1.isEmpty());
	}
	
	/**
	 * Tests the iterator class for the MySortedSet class.
	 */
	@Test
	public void testIterator()
	{
		ss1.add(3);
		ss1.add(6);
		ss1.add(10);
		ss1.add(7);
		Iterator<Integer> test = ss1.iterator();
		int count = 0;
		while (test.hasNext()) {
			test.next();
			count++;
		}
		assertTrue(count == 4);
		ss1.add(8);
		ss1.add(1);
		count = 0;
		while (test.hasNext()) {
			test.next();
			count++;
		}
		assertTrue(count == 2);
		count = 0;
		test = ss1.iterator();
		while (test.hasNext()) {
			test.next();
			count++;
		}
		assertEquals(count, 6);
		test = ss1.iterator();
		count = 0;
		Integer[] toTest = new Integer[6];
		while (test.hasNext()) {
			toTest[count] = test.next();
			count++;
		}
		assertTrue(Arrays.equals(toTest, ss1.toArray()));
	}
	
	/**
	 * Tests the remove method for the MySortedSet class.
	 */
	@Test
	public void testRemove()
	{
		assertTrue(ss1.isEmpty());
		ss1.add(143);
		ss1.add(24);
		ss1.add(-4);
		ss1.add(8);
		ss1.add(456);
		assertTrue(ss1.remove(143));
		assertFalse(ss1.remove(10));
		assertTrue(Arrays.equals(ss1.toArray(), new Integer [] {-4, 8, 24, 456}));
		ss2.add("Hello");
		ss2.add("food");
		ss2.add("Food");
		ss2.add("yellow");
		ss2.add("toad");
		ss2.add("PHONE");
		assertTrue(ss2.remove("Hello"));
		assertFalse(ss2.remove("Yellow"));
		assertFalse(ss2.remove("it"));
		assertTrue(Arrays.equals(ss2.toArray(), new String [] {"Food", "PHONE", "food", "toad", "yellow"}));
		ss3.add(true);
		ss3.add(false);
		assertTrue(ss3.remove(true));
		assertTrue(ss3.remove(false));
		assertFalse(ss3.remove(true));
		assertFalse(ss3.remove(true));
	}
	
	/**
	 * Tests the removeAll method for the MySortedSet class.
	 */
	@Test
	public void testRemoveAll()
	{
		ss1.add(143);
		ss1.add(24);
		ss1.add(-4);
		ss1.add(8);
		ss1.add(456);
		ss1.remove(143);
		ss1.remove(10);
		ss2.add("Hello");
		ss2.add("food");
		ss2.add("Food");
		ss2.add("yellow");
		ss2.add("toad");
		ss2.add("PHONE");
		ss2.remove("Hello");
		ss2.remove("Yellow");
		ss2.remove("it");
		ss3.add(true);
		ss3.add(false);
		ss3.remove(true);
		ss3.remove(false);
		ss3.remove(true);
		ss3.remove(true);
		ArrayList <Integer> list1 = new ArrayList <Integer> ();
		ArrayList <String> list2 = new ArrayList <String> ();
		ArrayList <Boolean> list3 = new ArrayList <Boolean> ();
		ss1.add(23);
		ss1.add(45);
		ss1.add(201);
		list1.add(23);
		list1.add(456);
		list1.add(-4);
		assertTrue(ss1.removeAll(list1));
		assertTrue(Arrays.equals(ss1.toArray(), ((new Integer [] {8, 24, 45, 201}))));
		ss2.add("boat");
		ss2.add("dog");
		ss2.add("coat");
		list2.add("boat");
		list2.add("coat");
		list2.add("food");
		assertTrue(ss2.removeAll(list2));
		assertTrue(Arrays.equals(ss2.toArray(), new String [] {"Food", "PHONE", "dog", "toad", "yellow"}));
		ss3.add(true);
		ss3.add(false);
		list3.add(true);
		list3.add(false);
		assertTrue(ss3.removeAll(list3));
		assertTrue(ss3.isEmpty()); // Makes sure that after all of the elements were removed, that its empty.
 	}
	
	/** 
	 * Tests the size method for the MySortedSet class.
	 */
	@Test
	public void testSize()
	{
		ss1.add(1);
		ss1.add(5);
		ss1.add(23);
		ss1.add(45);
		ss1.add(132);
		assertEquals(5, ss1.size());
		ss2.add("Hello");
		ss2.add("There");
		ss2.add("is");
		ss2.add("dog");
		ss2.add("cat");
		ss2.add("goat");
		ss2.add("elephant");
		assertEquals(7, ss2.size());
		ss3.add(true);
		ss3.add(true);
		assertEquals(1, ss3.size());
	}
}
