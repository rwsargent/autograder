package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 * @author Brandon Mercado & Morgan Mercado
 * @date	2/4/15
 *
 * @param <E> -- the type of elements maintained by this set.
 */
public class MySortedSet<E> implements SortedSet<E> {

	private Comparator<? super E> cmp;
	private E[] list;
	private int size;
	private boolean isComparable;


	@SuppressWarnings("unchecked")
	public MySortedSet(){
		cmp = null;
		list = (E[]) new Object[13];
		size = 0;
		isComparable = false;

	} 

	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> cmp){
		this.cmp = cmp;
		list = (E[]) new Object[13];
		size = 0;
		isComparable = false;
	}
	
	/**
	 * @return cmp - the comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {

		return cmp;
	}
	
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		// Check if the list is empty
		if(list[0].equals(null))
			throw new NoSuchElementException();

		return (E)list[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		// Check if the list is empty
		if(list[0].equals(null))
			throw new NoSuchElementException();

		return list[size-1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {
		// Check to see if the object is null
		if(o == null)
			return false;
		
		if(o instanceof Comparable){
			isComparable = true;
		}
		
		// Check to see if the object is already in the array
		for(int i = 0; i <= size-1; i++){
			// Check to see if the items are comparable
			if(isComparable){
				if(list[i].equals(o))
					return false;
			}else{
				if(cmp == null){
					return false;
				}
				if(cmp.compare(o, list[i]) == 0){
					return false;
				}
			}
		}
		// Check to see if the object will fit into the array
		if(size+1 > list.length){
			E[] tmp_Arr = (E[])new Object[list.length*2];
			for(int i = 0; i < size; i++){
				tmp_Arr[i] = list[i];
			}
			list = tmp_Arr;
		}

		// Find the right spot for the object, and add the object into the array, using a binary search.
		if(size == 0){
			list[0] = o;
			size++;
			return true;
		}
		
		if(size == 1){
			if(((Comparable<E>)o).compareTo(list[0]) < 0){
				list[1] = list[0];
				list[0] = o;
				size++;
				return true;
			}
			
			list[1] = o;
			size++;
			return true;
		}
		// Check to see if it's will be the lowest item in the list
		if(((Comparable<E>)o).compareTo(list[0]) < 0){
			int j = size;
			while(j > 0){
				list[j] = list[j-1];
				j--;
			}
			list[0] = o;
			size++;
			return true;
		}
		// Binary Search method
		int lowIndex = 0;
		int highIndex = size-1;

		while(highIndex >= lowIndex){
			int midIndex = (lowIndex + highIndex) / 2;
			// Check if comparable
			if(isComparable){
				// Check to see if the item should be added between the midIndex and midIndex - 1
				if(((Comparable<E>)o).compareTo(list[midIndex]) < 0 && ((Comparable<E>)o).compareTo(list[midIndex - 1]) > 0){
					int j = size;
					while(j > midIndex){
						list[j] = list[j-1];
						j--;
					}
					list[midIndex] = o;
					size++;
					return true;
				}
				if(((Comparable<E>)o).compareTo(list[midIndex]) < 0){
					highIndex = midIndex - 1;
				}
				if(((Comparable<E>)o).compareTo(list[midIndex]) > 0){
					lowIndex = midIndex + 1;
				}
				// if we've reached the end of the list
				if(highIndex == lowIndex){
					list[size] = o;
					size++;
					return true;
				}
			}else{
				if(cmp == null){
					return false;
				}
				if(cmp.compare(o, list[midIndex]) == 0){
					int j = size;
					while(j > midIndex){
						list[j] = list[j-1];
						j--;
					}
					list[midIndex] = o;
					size++;
					return true;
				}
				if(cmp.compare(o, list[midIndex]) < 0){
					highIndex = midIndex - 1;
				}
				if(cmp.compare(o, list[midIndex]) > 0){
					lowIndex = midIndex + 1;
				}
				if(highIndex == lowIndex){
					list[size] = o;
					size++;
					return true;
				}
			}
		}

		size++;

		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {

		boolean hasChanged = false;
		// Go through the collection given and try to add each item
		for(E item : c){
			if(add(item)){
				hasChanged = true;
			}
		}

		return hasChanged;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		// Create a new list and set the size to 0
		list = (E[])new Object[13];
		size = 0;
	}
	
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		// Go through the list

		int lowIndex = 0;
		int highIndex = size-1;

		while(highIndex >= lowIndex){
			int midIndex = (lowIndex + highIndex) / 2;
			if(isComparable){
				if(((Comparable<E>)o).compareTo(list[midIndex]) == 0){
					return true;
				}
				if(((Comparable<E>)o).compareTo(list[midIndex]) < 0){
					highIndex = midIndex - 1;
				}
				if(((Comparable<E>)o).compareTo(list[midIndex]) > 0){
					lowIndex = midIndex + 1;
				}
			}else{
				if(cmp == null){
					return false;
				}
				if(cmp.compare((E)o, list[midIndex]) == 0){
					return true;
				}
				if(cmp.compare((E)o, list[midIndex]) < 0){
					highIndex = midIndex - 1;
				}
				if(cmp.compare((E)o, list[midIndex]) > 0){
					lowIndex = midIndex + 1;
				}
			}
		}

		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return containsAll Elem- a flag that starts true if this set contains all of the elements of the specified
	 *         collection, false if proven otherwise.
	 */
	@Override
	public boolean containsAll(Collection<?> c) {

		boolean containsAllElem = true;
		// Go through the given collection and see if the items are all contained in our list
		for(Object item: c){
			if(!contains(item)){
				containsAllElem = false;
			}
		}

		return containsAllElem;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {

		return size == 0;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {

		MySortedSetIterator<E> itr =  new MySortedSetIterator<E>();
		return itr;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean remove(Object o) {
		// Go through the list
		for(int i = 0; i < size; i++){
			// Check if comparable
			if(isComparable){
				// Check the equality
				if(((Comparable<E>)o).compareTo(list[i]) == 0){
					// Adjust list
					int j = i;
					while(j < size){
						list[j] = list[j+1];
						j++;
					}
					size--;
					return true;
				}
			}else{
				// Check equality
				if(cmp.compare((E)o, list[i]) == 0){
					// Adjust list
					int j = i;
					while(j < size){
						list[j] = list[j+1];
						j++;
					}
					size--;
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {

		boolean hasChanged = false;
		// Go through the collection given and try to remove each item
		for(Object item: c){
			if(remove(item)){
				hasChanged = true;
			}
		}

		return hasChanged;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {

		return list;
	}

	private class MySortedSetIterator<E> implements Iterator<E>{

		private int index = 0;

		@Override
		public boolean hasNext() {

			if(index < size-1){
				return true;
			}

			return false;
		}

		@Override
		public E next() {

			return (E)list[index++];
		}

		@Override
		public void remove() {
			// TODO Auto-generated method stub

		}


	}

}
