package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTests {

	MySortedSet<Integer> emptySet;
	MySortedSet<Integer> intSet;
	MySortedSet<String> stringSet;
	ArrayList<Integer> intSet2;
	Comparator<Integer> myIntComparator;
	
	@Before
	public void setUp() throws Exception {
		 emptySet = new MySortedSet<Integer>();
		 intSet = new MySortedSet<Integer>();
		 stringSet = new MySortedSet<String>();
		 intSet2 = new ArrayList<Integer>();
		 intSet2.add(1);
		 intSet2.add(33);
		 intSet2.add(53);
		 intSet2.add(-3);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testEmptySet() {
		assertEquals(true, emptySet.isEmpty());
		assertEquals(false, emptySet.contains(2));
		assertEquals(false, emptySet.remove(0));
	}
	
	@Test
	public void testIntSet(){
		assertEquals(true, intSet.add(4));
		assertEquals(false, intSet.add(4));
		intSet.add(5);
		intSet.add(3);
		intSet.add(6);
		intSet.add(2);
		assertEquals(5, intSet.size());
		assertEquals(true, intSet.first().equals(2));
		assertEquals(false, intSet.first().equals(3));
		assertEquals(true, intSet.last().equals(6));
		assertEquals(false, intSet.last().equals(5));
		assertEquals(true, intSet.addAll(intSet2));
		assertEquals(true, intSet.contains(2));
		assertEquals(true, intSet.contains(6));
		assertEquals(false, intSet.contains(0));
		assertEquals(true, intSet.containsAll(intSet2));
		assertEquals(true, intSet.remove(2));
		assertEquals(true, intSet.remove(4));
		assertEquals(true, intSet.remove(6));
		assertEquals(false, intSet.remove(2));
		intSet2.remove(0);
		assertEquals(true, intSet.removeAll(intSet2));
		assertEquals(false, intSet.containsAll(intSet2));
		assertEquals(false, intSet.removeAll(intSet2));
		
	}
	
	@Test
	public void testIntSet1(){
		for(int i = 0; i < 36; i++){
			intSet.add(i);
		}
		assertEquals(36, intSet.size());
		intSet.clear();
		assertEquals(0, intSet.size());
	}
	
	@Test
	public void testStringSet(){
		assertEquals(true, stringSet.add("Hi"));
		assertEquals(false, stringSet.add("Hi"));
		stringSet.add("World");
		assertEquals(true, stringSet.add("hi"));
		assertEquals("hi", stringSet.last());
		assertEquals("Hi", stringSet.first());
		stringSet.add("hia");
		assertEquals("hia", stringSet.last());
		assertEquals(true, stringSet.contains("Hi"));
		assertEquals(false, stringSet.contains("The martian"));
		assertEquals(true, stringSet.contains("hia"));
		assertEquals(true, stringSet.remove("Hi"));
		assertEquals(false, stringSet.remove("jump"));
		assertEquals(true, stringSet.remove("hia"));
	}
	
	

}
