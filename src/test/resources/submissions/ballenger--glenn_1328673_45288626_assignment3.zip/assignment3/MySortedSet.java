package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> {

	E[] set;
	Comparator comparator;
	private int size = 0;

	public MySortedSet() {
		set = (E[]) new Object[10];
	}

	/**
	 * 
	 * @param compare
	 */
	public MySortedSet(Comparator<? super E> compare) {
		comparator = compare;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (set[0] != null)
			return set[0];
		throw new NoSuchElementException();
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (set[set.length] != null)
			return set[set.length];
		throw new NoSuchElementException();
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		int start;
		int mid;
		int end;

		if (size == 0) {
			set[0] = o;
			size++;
			return true;
		}

		if (comparator() == null) {
			start = 0;
			end = size - 1;
			mid = (start + size) / 2;

			while (set[mid] != o) {
				if (((Comparable<E>) o).compareTo(set[mid]) < 0) {
					mid = (mid + size) / 2;
					end = mid + 1;
				}

				if (((Comparable<E>) o).compareTo(set[mid]) > 0) {
					mid = (start + mid) / 2;
					start = mid - 1;
				}

				if (((Comparable<E>) o).compareTo(set[mid]) == 0) {
					return false;
				}

				if (start < end) {
					set[mid] = o;
					size++;
					return true;
				}

				if (comparator() != null) {
					start = 0;
					end = size - 1;
					mid = (start + size) / 2;

					while (set[mid] != o) {
						if (comparator.compare(o, set[mid]) < 0) {
							mid = (mid + size) / 2;
							end = mid + 1;
						}

						if (comparator.compare(o, set[mid]) > 0) {
							mid = (start + mid) / 2;
							start = mid - 1;
						}

						if (comparator.compare(o, set[mid]) == 0) {
							return false;
						}

						if (start < end) {
							set[mid] = o;
							size++;
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		for (Object item : c) {
			add((E) c);
		}
		return false;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		E[] temp;
		temp = (E[]) new Object[size];
		set = temp;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		for (int pos = 0; pos < size; pos++) {
			if (set[pos] == o) {
				return true;
			}
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for (Object item : c) {
			contains((E) c);
		}
		return false;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		for (int pos = 0; pos < size; pos++) {
			if (set[pos] != null)
				return false;
		}
		return true;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {	   
		return iterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		E[] temp;
		temp = (E[]) new Object[size];
		for (int pos = 0; pos < size; pos++) {
			if (set[pos] == o) {
				set[pos] = temp[pos];
				size--;
				return true;
			}
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		for (Object item : c) {
			remove((E) c);
		}
		return false;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {

		E[] temp;
		temp = (E[]) new Object[size];
		for (int pos = 0; pos < size; pos++) {
			temp[pos] = set[pos];
		}
		return temp;
	}

	class MyIterator implements Iterator<E> {

		int index = -1;
		E next = null;

		@Override
		public boolean hasNext() {
			if (index > size - 1)
				return true;
			else
				return false;
		}

		@Override
		public E next() {
			if(!hasNext())
				throw new NoSuchElementException();
			index++;
			return next = MySortedSet.this.set[index];
		}

		@Override
		public void remove() {
			if (next != null)
				throw new IllegalStateException();	
			else
				MySortedSet.this.remove(next);
		}

	}

}
