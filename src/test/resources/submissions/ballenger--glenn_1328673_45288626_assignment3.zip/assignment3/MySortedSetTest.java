package assignment3;

import static org.junit.Assert.*;
import lab2.DiffUtil;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest<E> {

	@Before
	public void setUp() throws Exception {
		new MySortedSet<E>();
		int o1 = 10;	
	}
	
	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAdd() {
		int o1 = 2;
		assertEquals(true, MySortedSet.add(o1));
	}
	
/**	
	@Test
	public void testAddAll() {
		assertEquals(-1, MySortedSet.addAll(arr1));
	}
	
	@Test
	public void testClear() {
		assertEquals(-1, MySortedSet.clear(arr1));
	}
	
	@Test
	public void testContains() {
		assertEquals(-1, MySortedSet.contains(arr1));
	}
	
	@Test
	public void testContainsAll() {
		assertEquals(-1, MySortedSet.containsAll(arr1));
	}
	
	@Test
	public void testIsEmpty() {
		assertEquals(-1, MySortedSet.isEmpty(arr1));
	}
	
	@Test
	public void testIterator() {
		assertEquals(-1, MySortedSet.Iterator(arr1));
	}
	
	@Test
	public void testRemove() {
		assertEquals(-1, MySortedSet.remove(arr1));
	}
	
	@Test
	public void testRemoveAll() {
		assertEquals(-1, MySortedSet.removeAll(arr1));
	}
	
	@Test
	public void testToArray() {
		assertEquals(-1, MySortedSet.toArray(arr1));
	}
*/
}
