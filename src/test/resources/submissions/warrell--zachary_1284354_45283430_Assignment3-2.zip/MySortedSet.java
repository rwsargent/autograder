package assignment3;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This class provides a sorted set for and object of type E.
 * The set is ordered by either a provided Comparator or the object's natural ordering (a Comparable interface)
 * Note: The object of type E MUST implement Comparable or provide a Comparator in order for this class to behave correctly.
 * @author Zach Warrell and Cashe Rumsey
 *
 * @param <E> - The type of object stored in the MySortedSet
 */
public class MySortedSet<E> implements SortedSet<E> {

	// Representation
	private E set[]; // The set that contains the objects in sorted order
	private Comparator<? super E> comparator; // A reference to a comparator telling how to sort the given type E
	private int size; // Keeps track of the index of the last element in the set
	private boolean usesComparator; // Used to indicate whether or not a comparator has been used

// Constructors  //////////////////////////////////////////////////////////////////////
	
	/**
	 * Constructs a MySortedSet<E> object of type E using comparable
	 */
	public MySortedSet()
	{
		this.set = (E[]) new Object[10];
		this.comparator = new NaturalOrdering<E>();
		this.size = 0;
		this.usesComparator = false;
	}
	
	/**
	 * Constructs a MySortedSet<E> object of type E using a specified comparator for the type E
	 */
	public MySortedSet(Comparator<? super E> comparator)
	{
		this.set = (E[]) new Object[10];
		this.comparator = comparator;
		this.size = 0;
		this.usesComparator = true;
	}
	
// Methods //////////////////////////////////////////////////////////////////////////	
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		if (this.usesComparator)
		{
			return this.comparator;		
		}
		else
		{
			return null;
		}
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (this.set[0] == null)
		{
			throw new NoSuchElementException();
		}
		
		return this.set[0];
	}
	
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (this.set[0] == null)
		{
			throw new NoSuchElementException();
		}		
		
		return this.set[this.size-1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		// If E o is null, do not add
		if (o == null)
		{
			return false;
		}
		
		// Get position to place new object in sorted order
		int position = binarySearch(o);
		
		// In the list, so return false
		if(position >= 0){
			return false;
		}
		
		// Shift elements to make space for new element
		shiftElements(-(position + 1), true);
		
		//set new element
		this.set[-(position + 1)] = o;
		this.size++;
		
		return true;
	}
	
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		// Loop through collection and keep track of if something was added
		boolean wasChanged = false;
		for(E obj: c){
			if(add(obj)){
				wasChanged = true;
			}
		}
		return wasChanged;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		E clearSet[] = (E[]) new Object[10];
		set = clearSet;
		this.size = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		// Try to cast to type E. If they aren't the same types, they can't be in the set 
		try{			
			// If found, return true. If not found, return false
			if(binarySearch((E)o) >= 0){
				return true;
			}
			return false;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		// Loop through to check each element in the collection is in MySortedSet
		Iterator<E> iterator = (Iterator<E>) c.iterator();
		while(iterator.hasNext())
		{
			if(!(contains(iterator.next())))
			{
					return false;
			}
		}
		return true;
	}

	/**
	 * @return true if the set is empty.  false otherwise
	 */
	@Override
	public boolean isEmpty() {
		if(this.size == 0){
			return true;
		}
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MySortedSetIterator<E>(this);
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		// Surround in try to catch potental ClassCastException
		try {
			// Find element, shift list, then decrement size
			int pos = binarySearch((E)o);
			
			// If not found in the list return false
			if(pos < 0){
				return false;
			}
			
			shiftElements(pos, false);
			this.size--;
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		
		boolean wasChanged = false;
		for (Object obj : c){
			if(remove(obj)){
				wasChanged = true;
			}
		}
		return wasChanged;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return this.size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		return Arrays.copyOf(this.set, this.size);
	}

	
// Helper Methods //////////////////////////////////////////////
	
	/**
	 * 
	 * @param o - the object to search for
	 * @return - the index of that object if the object is not found returns -(i +1)
	 * where i is the index where the o should be inserted
	 */
	private int binarySearch(E o){
		int high = this.size;
		int mid = 0;
		int low = 0;
		
		while (low < high)
		{
			mid = (low + high) / 2;
			if(this.comparator.compare(o, this.set[mid]) == 0){
				return mid;
			}
			else if (this.comparator.compare(o, this.set[mid]) > 0)
			{
				low = mid + 1;
			}
			else 
			{
				high = mid;
			}
		}		
		if( low == this.size || this.comparator.compare(o, this.set[low]) != 0 ){
			return -(low + 1);
		}
		return mid;
	}
	
	/**
	 * An array utility that helps with the insertion and removing items into an array by shifting elements
	 * @param shiftPos - the start position of where to begin shifting
	 * @param direction - false is left, true is right
	 */
	private void shiftElements(int shiftPos, boolean direction){
		/// Make sure we have room for the new element; if not, expand the array
		if (this.size + 1 >= this.set.length){
			this.set = Arrays.copyOf(this.set, this.size*2);
		}
		
		// Shift Right
		if (direction)
		{
		// move elements over one
		         //Make this size
		for(int i=this.size; i > shiftPos; i--){
			this.set[i] = this.set[i-1];
		}
		}
		// Shift Left
		else
		{
			// move elements over one
	         //Make this size
			for(int i=shiftPos; i < this.size-1; i++){
				this.set[i] = this.set[i+1];
			}
		}
	}	
	
/**
 * Provides a comparator based off of the objects Comparable interface
 * @author Zach Warrell and Cashe Rumsey
 *
 * @param <E>
 */
private class NaturalOrdering<E> implements Comparator<E> {

	@Override
	public int compare(E arg0, E arg1) {
		// Make sure it is off the type comparable
		if(arg0 instanceof Comparable){
			// Use the comparable "natural ordering" to sort
			return ((Comparable<E>) arg0).compareTo(arg1);
		}
		// Doesn't implement Comparable or a Comparator so error out!
		System.err.println("Object does not implement Comparator or Comparable!");
		return -1;
	}
	
}
	

/**
 * Provides an iterator object for a MySortedSet<E>
 * @author Zach Warrell and Cashe Rumsey
 *
 * @param <E>
 */
private class MySortedSetIterator<E> implements Iterator<E>{
	
	// Representation
	private int current; // holds the position of the iterator in the collection
	private MySortedSet<E> mySet; // a reference to the set
	private boolean deleted; // checks whether the last item was deleted to prevent multiple deletions
	private E lastItem; // holds last item iterated over
	
	public MySortedSetIterator(MySortedSet<E> set){
		current = 0;
		mySet = set;
		lastItem = null;
	}

	@Override
	public boolean hasNext() {
		return current < mySet.size;
	}

	@Override
	public E next() {
		deleted = false;
		lastItem = mySet.set[current++];
		return lastItem;
	}
	
	@Override
	public void remove(){
		if(deleted || lastItem == null){
			throw new IllegalStateException();
		}
		mySet.remove(lastItem);
	}
	
}
}