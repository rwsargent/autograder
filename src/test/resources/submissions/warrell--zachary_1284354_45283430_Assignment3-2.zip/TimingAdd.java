package assignment3;

/**
 * Timing for the add() method
 * @author Zach Warrell and Cashe Rumsey
 *
 */
public class TimingAdd {

	//build a my sorted set of Integers
    private static MySortedSet<Integer> test;
    
	
  public static void main(String[] args) {
	  test = new MySortedSet<Integer>();
	  
	  int number = 0;
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  for(int i = 0; i < 50000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timeAdd();
	 
	  
	  
  }
	  
  public static void timeAdd(){
		  long  startTime, startAdd, endAdd;
		    long total = 0;
		    
		    
		 // First, spin computing stuff until one second has gone by.
		    // This allows this thread to stabilize.

		    startTime = System.nanoTime();
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }
		    

		    // Now, run the test.

		    long timesToLoop = 10000;
		    
		    for (long i = 0; i < timesToLoop; i++){
		    	startAdd = System.nanoTime();
		    	test.add(-1);
		    	endAdd = System.nanoTime();
		    	
		    	total += endAdd - startAdd;
		    	
		    	test.remove(-1);
		    	
		    }
		    
		    double averageTime = (total) / timesToLoop;

		    System.out.println(averageTime);
  }
	
	  
	 
}