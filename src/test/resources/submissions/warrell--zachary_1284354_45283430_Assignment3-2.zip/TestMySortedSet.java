package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * A class used for testing MySortedSet<E>
 * @author Zach Warrell and Cashe Rumsey
 *
 */
public class TestMySortedSet {

	private MySortedSet<Integer> s1, s2;
	private MySortedSet<String> s3, s4;
	private IntCompare test1;
	private StringCompare test2;
	
	/**
	 * Creates MySortedSet Objects for testing
	 */
	@Before
	public void setUp() throws Exception {
		// Constructors are tested here
		
		// Natural ordered sets
		s1 = new MySortedSet<Integer>();
		s3 = new MySortedSet<String>();
		
		// Comparator ordered sets
		test1 = new IntCompare();
		s2 = new MySortedSet<Integer>(test1);
		test2 = new StringCompare();
		s4 = new MySortedSet<String>(test2);
		
	}

	@After
	public void tearDown() throws Exception {
	}
	
	/**
	 * Method for testing comparator()
	 */
	@Test
	public void testComparator()
	{
		// Comparator ordered sets tests
		assertEquals(test1, s2.comparator());
		assertEquals(test2, s4.comparator());
		
		// Natural ordered sets tests
		assertEquals(null, s1.comparator());
		assertEquals(null, s3.comparator());
	}
	
	/**
	 * Method for testing first()
	 */
	@Test
	public void testFirst()
	{
		// Tests with Integer
		s1.add(3);
		s1.add(1);
		s1.add(4);
		s1.add(2);
		assertEquals(new Integer(1), s1.first());
		
		// Tests with Strings
		s4.add("Hello");
		s4.add("World");
		s4.add("Don't take my test cases");
		s4.add("Please");
		assertEquals(new String("World"), s4.first());
	}
	
	/**
	 * Method for testing first() for exceptions 
	 */
	@Test(expected = NoSuchElementException.class)
	public void testFirstForException()
	{
		s1.first();		
	}

	/**
	 * Method for testing last()
	 */
	@Test
	public void testLast()
	{
		// Tests with Integer
		s1.add(3);
		s1.add(1);
		s1.add(4);
		s1.add(2);
		assertEquals(new Integer(4), s1.last());
		
		// Tests with Strings
		s4.add("hello");
		s4.add("planet");
		s4.add("sorted");
		s4.add("set");
		assertEquals("hello", s4.last());
		
	}
	
	/**
	 * Method for testing last() for exceptions
	 */
	@Test(expected = NoSuchElementException.class)
	public void testLastForException()
	{
		s1.last();
	}
	
	
	/**
	 * Tests the add() method
	 * NOTE: this test also tests the private methods for the class: binarySearch(), shiftElements()
	 */
	@Test
	public void testAddAndRemove() {
// Test the removal of items in the set
		
	// Integers
		// add() Method 11 items total
		// Testing with 11 calls to make sure that shiftElements() expands the array to make room for them
		s1.add(2);
		s1.add(5);
		s1.add(-1);
		
		//duplicate doesn't get added
		s1.add(2);
		s1.add(3);
		s1.add(4);
		s1.add(10);
		s1.add(6);
		s1.add(7);
		s1.add(8);
		s1.add(9);
		// array must expand
		s1.add(56);
		// check return values
		assertFalse(s1.add(10));
		assertTrue(s1.add(11));
		
		// toArray() Method
		Object[] test = s1.toArray();
		
		// Checks elements are correct also uses to array 
		assertEquals(12, test.length);
		assertEquals(-1, test[0]);
		assertEquals(2, test[1]);
		assertEquals(3, test[2]);
		assertEquals(4, test[3]);
		assertEquals(5, test[4]);
		assertFalse(s1.add(null));
		
		
// Test the removal of items in the set
		 
		// Add items into the array
		s1.remove(2);
		s1.remove(5);
		s1.remove(-1);
		
		// Test to see the new size, the first and last elements, trying to remove items not in the array--of the same type and of different types
		assertEquals(9, s1.size());
		assertEquals(new Integer(3), s1.first());
		assertEquals(new Integer(56), s1.last());
		assertFalse(s1.remove(99866));
		assertFalse(s1.remove("as"));
		
	// String
		// add() Method 11 items total
		// Testing with 11 calls to make sure that shiftElements() expands the array to make room for them
		s4.add("a");
		s4.add("b");
		s4.add("c");
		
		//duplicate doesn't get added
		s4.add("b");
		s4.add("c");
		s4.add("d");
		s4.add("e");
		s4.add("f");
		s4.add("g");
		s4.add("h");
		s4.add("i");
		// array must expand
		s4.add("j");
		// check return values
		assertFalse(s4.add("f"));
		assertTrue(s4.add("z"));
		
		// toArray() Method
		Object[] test2 = s4.toArray();
		
		// Checks elements are correct also uses to array 
		assertEquals(11, test2.length);
		assertEquals("z", test2[0]);
		assertEquals("j", test2[1]);
		assertEquals("i", test2[2]);
		assertEquals("h", test2[3]);
		assertEquals("g", test2[4]);
		assertTrue(!(s4.add(null)));
	}
	
	/**
	 * Method for testing addAll()
	 */
	@Test
	public void testAddAllRemoveAll()
	{
	// Add All Tests
		// Build a Collection of Integers
		ArrayList<Integer> test1 = new ArrayList<Integer>();
		test1.add(1);
		test1.add(2);
		test1.add(56);
		test1.add(9081);
		
		// Build comparison arrays
		Integer[] compArray1 = {1,2,56,9081};
		Integer[] compArray2 = {9081,56,2,1};
		
		// Add Collection to set
		s1.addAll(test1);
		s2.addAll(test1);
		
		// Check Contents
		assertArrayEquals( compArray1,  s1.toArray());
		assertArrayEquals( compArray2,  s2.toArray());
		
		// Build a Collection of Strings
		ArrayList<String> test3 = new ArrayList<String>();
		test3.add("abc");
		test3.add("def");
		test3.add("ghi");
		test3.add("zach");
		
		// Build comparison arrays
		String[] compArray3 = {"abc","def","ghi","zach"};
		String[] compArray4 = {"zach","ghi","def","abc"};
		
		// Add Collection to set
		s3.addAll(test3);
		s4.addAll(test3);
		
		// Check Contents
		assertArrayEquals( compArray3,  s3.toArray());
		assertArrayEquals( compArray4,  s4.toArray());
		
		
	// Remove All Tests
		// Remove elements from sets (Integers)
		s1.removeAll(test1);
		s2.removeAll(test1);
		
		// Build comparison arrays
		Integer[] compArray5 = new Integer[0];
		Integer[] compArray6 = new Integer[0];
		
		// Check contents
		assertArrayEquals( compArray5,  s1.toArray());
		assertArrayEquals( compArray6,  s2.toArray());
		
		// Remove Elements from set (Strings)
		s3.removeAll(test3);
		s4.removeAll(test3);
		
		// Build comparison arrays
		String[] compArray7 = new String[0];
		String[] compArray8 = new String[0];
		
		// Check Contents
		assertArrayEquals( compArray7,  s3.toArray());
		assertArrayEquals( compArray8,  s4.toArray());
		
	}
	

	/**
	 * Method for testing clear() with integers
	 */
	@Test(expected = NoSuchElementException.class)
	public void testClearIntegers()
	{
		// Test with integers
		s1.add(3);
		s1.add(4);
		s1.add(6);
		s1.add(1);
		s1.toArray();
		s1.clear();
		s1.first();
	}
	
	/**
	 * Method for testing clear() with strings
	 */
	@Test(expected = NoSuchElementException.class)
	public void testClearStrings()
	{	
		// Test with Strings
		s4.add("a");
		s4.add("b");
		s4.add("c");
		s4.add("d");
		s4.toArray();
		s4.clear();
		s4.first();
	}

	/**
	 * Method for testing contains()
	 */
	@Test
	public void testContains()
	{
		s1.add(5);
		s1.add(7);
		s1.add(9);
		s1.add(11);
		// Tests two things that are either already at position[0], or should be inserted at position[0]
		assertEquals(true, s1.contains(new Integer(5)));
		assertEquals(false, s1.contains(new Integer(1)));
	}
	
	/**
	 * Method for testing containsAll()
	 */
	@Test
	public void testContainsAll()
	{
		ArrayList<Integer> test = new ArrayList<Integer>();
		test.add(5);
		test.add(4);
		s1.add(5);
		s1.add(4);
		s1.containsAll(test);
		assertTrue(s1.containsAll(test));
	}
	
	/**
	 * Method for testing isEmpty()
	 */
	@Test
	public void testIsEmpty()
	{
		// Empty tests
		assertTrue(s1.isEmpty());
		assertTrue(s2.isEmpty());
		assertTrue(s3.isEmpty());
		assertTrue(s4.isEmpty());
		
		// Add Elements to sets
		s1.add(1);
		s2.add(3);
		s3.add("hello");
		s4.add("world");
		
		// Full tests
		assertTrue(!(s1.isEmpty()));
		assertTrue(!(s2.isEmpty()));
		assertTrue(!(s3.isEmpty()));
		assertTrue(!(s4.isEmpty()));
		
	}
	
	/**
	 * Method for testing iterator()
	 */
	@Test
	public void testIterator()
	{
		// Test Integers
			// Add elements to the collection
			s1.add(1);
			s1.add(2);
		
		// get iterator and test functionality
		Iterator<Integer> test1 = s1.iterator();
		assertTrue(test1.hasNext());
		assertEquals(new Integer(1), test1.next());
		assertEquals(new Integer(2), test1.next());
		assertTrue(!(test1.hasNext()));
		
	// Test Strings
		// Add elements to the collection
		s4.add("This is a test");
		s4.add("It's going well");
		
		// get iterator and test functionality
		Iterator<String> test2 = s4.iterator();
		assertTrue(test2.hasNext());
		assertEquals("This is a test", test2.next());
		assertEquals("It's going well", test2.next());
		assertTrue(!(test2.hasNext()));
			
	}	
	
	/**
	 * Method for testing remove and Exceptions
	 */
	public void testIteratorExceptions()
	{
		// Test Integers
			// Add elements to the collection
			s1.add(1);
			s1.add(2);
			
			// get iterator and test functionality
			Iterator<Integer> test1 = s1.iterator();
			// nothing to remove so catch exception
			try{
				test1.remove();
				fail("No Exception thrown");
			} catch (IllegalStateException e){
			}
			// move iterator along
			test1.next();
			test1.remove();
			// can't remove multiple items in a row
			try{
				test1.remove();
				fail("No Exception thrown");
			} catch (IllegalStateException e){
			}
			
	}
	
	/**
	 * Method for testing size()
	 */
	@Test
	public void testSize()
	{
		// Test integers
		s1.add(4);
		s1.add(3);
		assertEquals(2, s1.size());
		
		// Test Strings
		s4.add("a");
		s4.add("b");
		assertEquals(2, s4.size());
	}		
	
// Comparators used for testing
	
/**
 * Integer comparator for testing
 * 
 * @author Cashe Rumsey and Zach Warrell
 *
 */
private class IntCompare implements Comparator<Integer> {

	/**
	 * @param arg0 - takes an int for comparing
	 * @param arg1 - takes another int for comparing
	 * @return - returns an int, which indicates the correct order of the two elements
	 */
	@Override
	public int compare(Integer arg0, Integer arg1) {
		return arg1.intValue()-arg0.intValue();
	}
	
}

/**
 * String Comparator for Testing
 * 
 * @author Cashe Rumsey and Zach Warrell
 *
 */
private class StringCompare implements Comparator<String> {

	/**
	 * @param arg0 - takes a String for comparing
	 * @param arg1 - takes another String for comparing
	 * @return - returns an int, which indicates the correct order of the two elements
	 */
	@Override
	public int compare(String arg0, String arg1) {
		return arg1.compareTo(arg0);
	}
	
}
	
}
