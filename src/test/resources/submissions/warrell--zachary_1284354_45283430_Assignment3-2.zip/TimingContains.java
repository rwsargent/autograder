package assignment3;

/**
 * Timing for the add() method
 * @author Zach Warrell and Cashe Rumsey
 *
 */
public class TimingContains {

	static // Create a MySorteSet<Integer> of size elements for timing
    MySortedSet<Integer> test;
	
  public static void main(String[] args) {
	  test = new MySortedSet<Integer>();
	  int number = 0;
	  

	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  for(int i=0 ; i < 100000; i++){
	    	test.add(number);
	    	number++;
	  }
	  timer();
	  
	  System.out.println("Size: " + test.size());
  }
  
  public static void timer(){
	  long startTime, total, stopTime;
	    
	  	total = 0;

	    // First, spin computing stuff until one second has gone by.
	    // This allows this thread to stabilize.

	    startTime = System.nanoTime();
	    while (System.nanoTime() - startTime < 1000000000) { // empty block
	    }

	    // Now, run the test.
	    
	    int timesToLoop = 1000000;

	    for (int i = 0; i < timesToLoop; i++){
	    	startTime = System.nanoTime();
	    	test.contains(-1);
	    	stopTime = System.nanoTime();
	    	
	    	total += stopTime - startTime;
	    	
	    }

	    double averageTime = (total) / timesToLoop;

	    System.out.println(averageTime);
	  }
}