package assignment3;

/**
 * @author Steven Sun, Andrew Yang
 */
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import assignment3.PhoneNumber;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.NoSuchElementException;

public class MySortedSetTest {

	private MySortedSet<Integer> msit1, msit2;
	private MySortedSet<PhoneNumber> mspt;
	private ArrayList<PhoneNumber> sss;
	private TrunkPhoneSort tps = new TrunkPhoneSort();

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Before
	public void setUp() throws Exception {
		msit1 = new MySortedSet();
		msit1.add(1); // By running this here we've tested add when testing
		msit1.add(1); // first() and last()
		msit1.add(2);
		msit1.add(4);
		msit1.add(3);

		msit2 = new MySortedSet(); // Only for first and last error cases

		mspt = new MySortedSet(tps); // A sorted list that uses the TrunkPhoneSort custom comparator to sort phone numbers
		
		sss = new ArrayList<PhoneNumber>(); // An array list that holds 11 Phone Numbers
		sss.add(new PhoneNumber("801.501.1234"));
		sss.add(new PhoneNumber("801.502.1234"));
		sss.add(new PhoneNumber("801.503.1234"));
		sss.add(new PhoneNumber("801.504.1234"));
		sss.add(new PhoneNumber("801.506.1234"));
		sss.add(new PhoneNumber("802.507.1234"));
		sss.add(new PhoneNumber("801.508.1234"));
		sss.add(new PhoneNumber("801.505.1234"));
		sss.add(new PhoneNumber("801.509.1234"));
		sss.add(new PhoneNumber("801.510.1234"));
		sss.add(new PhoneNumber("801.511.1234"));

		mspt.addAll(sss); // By using addAll we test it when we test containsAll and removeAll

	}
	
	/**
	 * Creates a comparator that sorts PhoneNumbers by their "trunks" (4th, 5th, and 6th number)
	 * from largest to smallest
	 */
	protected class TrunkPhoneSort implements Comparator<PhoneNumber> {
		@Override
		public int compare(PhoneNumber o1, PhoneNumber o2) {
			return o1.toIntTrunk() - o2.toIntTrunk();
		}
	}

	/**
	 * Tests if calling comparator() on a SortedSet with no comparator returns null
	 */
	@Test
	public void testComp1() {
		assertNull(msit1.comparator());
	}

	/**
	 * Tests if comparator() returns the correct Comparator
	 */
	@Test
	public void testComp2() {
		assertEquals(tps, mspt.comparator());
	}

	/**
	 * Tests first()
	 */
	@Test
	public void test1st() {
		assertEquals(1, (int) msit1.first());
	}

	/**
	 * Tests that first() throws a NoSuchElementException when called on an empty set
	 */
	@Test(expected = NoSuchElementException.class)
	public void test1stT() {
		msit2.first();
	}

	/**
	 * Tests last()
	 */
	@Test
	public void testlst() {
		assertEquals(4, (int) msit1.last());
	}

	/**
	 * Tests that last() throws a NoSuchElementException when called on an empty set
	 */
	@Test(expected = NoSuchElementException.class)
	public void testlstT() {
		msit2.last();
	}

	/**
	 * Tests clear() and toArray()
	 */
	@SuppressWarnings("deprecation")
	@Test
	public void testClear() {
		msit1.clear();
		Integer[] arr = new Integer[10];
		assertEquals(arr, msit1.toArray()); // Checks if msit1.toArray() returns an empty array of size 10 after msit1 is cleared
	}

	/**
	 * Tests when contains() is true
	 */
	@Test
	public void testCont1() {
		assertTrue(msit1.contains(1));
	}

	/**
	 * Tests when contains() is false
	 */
	@Test
	public void testCont2() {
		assertFalse(msit1.contains(5));
	}

	/**
	 * Tests containsAll (and addAll())
	 */
	@Test
	public void testContA() {
		assertTrue(mspt.containsAll((Collection<?>) sss));
	}

	/**
	 * Tests iterator's hasNext() method
	 */
	@Test
	public void testIter1() {
		assertEquals(true, mspt.iterator().hasNext());
	}

	/**
	 * Tests iterator's next() method
	 */
	@Test
	public void testIter2() {
		assertEquals(new PhoneNumber("801.511.1234"), mspt.iterator().next());
	}

	/**
	 * Test iterator's remove() method
	 */
	@Test
	public void testIter3() {
		mspt.iterator().next();
		mspt.iterator().remove();
		assertFalse(mspt.contains(new PhoneNumber("801.511.1234")));
	}

	/**
	 * Tests remove()
	 */
	@Test
	public void testRem1() {
		assertTrue(msit1.remove(1));
	}

	/**
	 * Tests that remove() returns false when arg does not appear in the set
	 */
	@Test
	public void testRem2() {
		assertFalse(msit1.remove(5));
	}

	/**
	 * Tests removeAll()
	 */
	@Test
	public void testRemA() {
		assertTrue(mspt.removeAll(sss));
	}

	/**
	 * Tests size()
	 */
	@Test
	public void testSize() {
		assertEquals(4, msit1.size());
	}

}
