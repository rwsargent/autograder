package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * A set that implements the SortedSet interface provided, with two
 * constructors.
 * 
 * @author Steven Sun, Andrew Yang
 * @param <E>
 *
 */
public class MySortedSet<E> implements SortedSet<E> {

	private E[] set = null; // Array that contains the data
	private Comparator<? super E> c = null; // Comparator specified by user

	/**
	 * Assumes that the elements are ordered using their natural ordering
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet() {
		set = (E[]) new Object[10]; // Holds an empty array of size 10 and type E
	}

	/**
	 * Assumes elements are ordered using the comparator provided
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> comparator) {
		set = (E[]) new Object[10];
		c = comparator; 
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		return c;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException {
		if (set[0] == null) 
			throw new NoSuchElementException();

		return set[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if (set[0] == null)
			throw new NoSuchElementException();

		for (int i = set.length - 1; i > 0; i--) { // Returns the object with the highest index in the set (does not count null)
			if (set[i] != null)
				return set[i];
		}

		return null;
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	public boolean add(E o) {

		int floor = 0;
		int ceiling = size();
		int check = 0;
		E[] set_ = null; // Creates a set to hold the new object and new object indexes
		
		if (o == null) // Ends the method and returns false if o is null
			return false;
		
		if (this.set[set.length - 1] != null) // Checks if the set size needs to be extended to hold the new object
			set_ = (E[]) new Object[set.length * 2];
		else
			set_ = (E[]) new Object[set.length];
		
		if (contains(o)) // Checks to see if o exists in the set, if it does, returns false
			return false;
		
		while (floor <= ceiling)
		{
			check = (ceiling - floor) / 2 + floor; // Sets check to the middle of the floor and ceiling being searched in the array
			
			if (o instanceof Comparable) { // Checks if the element is Comparable
		
				Comparable<E> o_ = (Comparable<E>) o; // Casts the element as a comparable
				
				if (check == set.length)
					break;
				
				if (set[check] == null || o_.compareTo(set[check]) > 0) // Checks if o is larger than the checked element and checks to avoid a NullPointerException
					floor = check + 1; // If o is larger, then increases the lower limit being checked (because the Set is sorted so o will be larger than all the objects before check too)
				
				
				else // If o is smaller than the checked element this code will run
					if (check == 0) // If the checked element is the first element and o is smaller than o will become the new first element and the loop breaks (this also avoids an ArrayIndexOutOfBoundsException)
						break;
				
					else if (o_.compareTo(set[check - 1]) > 0) // If the element immediately before the checked element is smaller than o, that means o fits in index check
						break;
					
					else // If o is also larger than the element immediately before the checked element than lowers the ceiling (since the Set is sorted)
						ceiling = check - 1;
				
			} else { // Runs if the element is not Comparable, same code as above except it uses the user provided comparator instead of the default compareTo()
				
				if (this.comparator() == null) // Checks if there is a comparator assigned to the set, if there is not, add() fails
					return false;
				
				if (set[check] == null || c.compare(set[check], o) > 0)
					floor = check + 1;
				
				else
					if (check == 0)
						break;
				
					else if (c.compare(set[check - 1], o) > 0)
						break;
				
					else
						ceiling = check - 1;
				}
			}
			
		for (int i = 0; i <= size(); i++) // Fills the new set based on where o was added
		{
			if (i < check) // If the element is before the added o, copy the element position directly
				set_[i] = set[i];
				
			else if (i == check) // If the index is at check, replace the element with o
				set_[i] = o;
				
			else if (i > check) // if the index is after check, move all the elements up one index
				set_[i] = set[i - 1];
			}
		set = set_; // Save the edited set
		return true;	
	}	
	
	

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@SuppressWarnings("unchecked")
	public boolean addAll(Collection<? extends E> c) {
		boolean b = false;
		Object[] set_ = (E[]) c.toArray(); // Converts c to a usable form
		for (int i = 0; i < set_.length; i++) // Adds each element in c
			if (this.add((E) set_[i]))
				b = true;
		return b;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		for (int i = 0; i < set.length; i++) // Sets all the objects in set to null
			set[i] = null;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings({ "unchecked" })
	public boolean contains(Object o) { 
		int floor = 0;
		int ceiling = size();
		int check = 0;
		
		if (o == null) // Ends the method and returns false if o is null
			return false;
		
		while (floor <= ceiling)
		{
			check = (ceiling - floor) / 2 + floor; // Sets check to the middle of the floor and ceiling being searched in the array
			
			if (check >= set.length) // If the method reaches the highest number without finding o, returns false
				return false;
			
			if (o instanceof Comparable) { // Checks if the element is Comparable
		
				Comparable<E> o_ = (Comparable<E>) o; // Casts the element as a comparable
				
				if (set[check] == null || o_.compareTo(set[check]) > 0) // Checks if o is larger than the checked element and checks to avoid a NullPointerException
					floor = check + 1; // Raises the search floor
				
				else if (o_.compareTo(set[check]) == 0) // If o and the checked element are the same, then return true
					return true;
				
				else // Lower the ceiling if o is smaller than the checked element
					ceiling = check - 1;
				
			} else {
				
				E o_ = (E) o; // Cast o as an Object E, then does the same as above
				
				if (set[check] == null || c.compare(set[check], o_) > 0)
					floor = check + 1;
				
				else if (c.compare(set[check], o_) == 0)
					return true;
				
				else
					ceiling = check - 1;
			}
		}
		
		return false;
	}
				


	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@SuppressWarnings("unchecked")
	public boolean containsAll(Collection<?> c) {

		Object[] set_ = (E[]) c.toArray();
		for (int i = 0; i < set_.length; i++)
			if (this.contains((E) set_[i]) != true)
				return false;
		
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		for (int i = 0; i < set.length; i++) {
			if (set[i] != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		@SuppressWarnings({ "rawtypes", "hiding" })
		class AnonIterator<E> extends MySortedSet implements Iterator<E> { // An anonymous iterator class created within the method
			
			private int index = 0; // Keeps track of the index that iterator is on
			private MySortedSet<E> mst;

			AnonIterator(MySortedSet<E> mst_) { // Constructor
				mst = mst_;
			}

			/**
			 * Checks if there is another object in the set
			 */
			@Override
			public boolean hasNext() {
				return index < mst.size();
			}

			/**
			 * @return The next object in the set and moves up the iterator
			 */
			@Override
			public E next() throws NoSuchElementException {
				return mst.set[index++];
			}

			/**
			 * Removes the object that the iterator is on
			 */
			@Override
			public void remove() throws NoSuchElementException {
				mst.set[index] = mst.set[index + 1]; // Removes object
				for (int i = index + 1; i < mst.set.length; i++) { // Moves all objects after the removed object up one index and sets the last index to null
					if (i == mst.set.length - 1)
						mst.set[i] = null;
					else
						mst.set[i] = mst.set[i + 1];
				}
			}
		}
		AnonIterator<E> anon = new AnonIterator<E>(this); // Creates a new AnonIterator and returns it
		return anon;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		if (this.contains(o))  // Checks if the set contains o
			for (int i = 0; i < set.length; i++) {
				if (o.equals(set[i])) { // Once the element is found
					
					set[i] = set[i + 1]; // Removes the element and the next element takes its index
					for (int j = i + 1; j < set.length; j++) {
						if (j + 1 == set.length) { // The last index is set to null
							set[j] = null;
							return true;
						}
						set[j] = set[j + 1]; // All other elements after o are moved down an index
					}
				}
			}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@SuppressWarnings("unchecked")
	public boolean removeAll(Collection<?> c) {
		boolean b = false;
		Object[] set_ = (E[]) c.toArray();
		for (int i = 0; i < set_.length; i++)
			if (this.remove((E) set_[i]))
				b = true;
		return b;
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size() {
		int i;
		for (i = 0; i < set.length; i++) {
			if (set[i] == null)
				break;
		}
		return i;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		return set;
	}
}
