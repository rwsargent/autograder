package assignment3;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import junit.framework.ComparisonCompactor;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Miriah Meyer
 * @author Jon Worms
 * @author Jen Simons
 * 
 * @param <E>
 *  -- the type of elements maintained by this set
 */
public class MySortedSet<E> implements SortedSet<E>, Iterable<E>{

	
	//Holds our data:
	@SuppressWarnings("unchecked")
	private E[] data = (E[]) new Object[2];
	private int itemsInData = 0;
	
	
	
	//Holds the comparator from our constructor:
	private Comparator<? super E> comparator;
	
	// CONSTRUCTORS ---------------------------------------------------------------------------------------------------
	/**
	 * Creates a new MySorted set that assumes that 'E' implements the Comparable interface
	 */
	public MySortedSet() {
		
	}
	
	
	
	/**
	 * Creates a new MySortedSet collection with a comparator
	 * @param comp
	 */
	public MySortedSet(Comparator<? super E> comp) {
		
		//Keep track of the comparator (for sorting and stuffs)
		this.comparator = comp;
		
	}
	
	
	
	
	
	// COMPARATOR -----------------------------------------------------------------------------------------------------
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		
		return this.comparator;
		
	}// end of comparator()

	
	
	
	// FIRST ---------------------------------------------------------------------------------------------------------
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {

		if(data[0] == null) {
			throw new NoSuchElementException("No data in MySortedSet");
		}

		return data[0];
		
	}// end of first()

	
	
	
	// LAST ----------------------------------------------------------------------------------------------------------
	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {

		if(data[0] == null) {
			throw new NoSuchElementException();
		}
		return data[itemsInData - 1];
		
	}// end of last()

	
	
	
	// ADD -----------------------------------------------------------------------------------------------------------
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {


		//We don't want to add null
		if(o == null) {
			return false;
		}
		
		
		//if the first index in the data array is null, just add o. Its the first object
		if(data[0] == null) {
			data[0] = o;
			itemsInData++;
			return true;
		}
		
		
		//Search our data, get the index of where the item should be
		int dataIndex = search(o);
		
		//Compare the data with o. (to determine where to add it in relation to what is at dataIndex
		int comparison = this.compare(o, data[dataIndex]);
		
		
		if(comparison > 0) {
			
			shiftRight(dataIndex + 1);
			data[dataIndex + 1] = o;
			
		} else if (comparison < 0) {
			
			// left of insertion point
			shiftRight(dataIndex);
			data[dataIndex] = o;

		} else {
			
			return false;
			
		}
		
		itemsInData++;
		return true;
		
	}// end of add()

	
	
	
	// ADD ALL -------------------------------------------------------------------------------------------------------
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {

		//When someone calls this method with no data.
		if(c == null || c.size() == 0){
			return false;
		}
		
		
		int currentNumberOfItemsInDataArray = itemsInData;
		
		
		Iterator cIterator = c.iterator();
		
		while(cIterator.hasNext()) {
			
			this.add((E) cIterator.next());
		}
		
		if(currentNumberOfItemsInDataArray != itemsInData) {
			//then some of the items in c were added to data
			return true;
		}
		
		return false;
		
	}// end of addAll()
	

	
	
	// CLEAR ---------------------------------------------------------------------------------------------------------
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		
		data = (E[]) new Object[16];
		itemsInData = 0;
		
	}// end of clear()
	
	

	
	// CONTAINS ------------------------------------------------------------------------------------------------------
	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		
		int resultIndex = this.search(o);
		if(data[resultIndex] == null) {
			return false;
		}
		if(data[resultIndex].equals(o)) {
			return true;
		}
		
		return false;
		
	}// end of contains()
	
	

	
	// CONTAINS ALL --------------------------------------------------------------------------------------------------
	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		
		Iterator cIterator = c.iterator();
		while(cIterator.hasNext()) {
			if(!this.contains(cIterator.next())) {
				return false;
			}
		}
		
		return true;
		
	}// end of containsAll()
	
	
	

	// COMPARE -------------------------------------------------------------------------------------------------------
	/**
	 * Compares o1 against o2, returns a number > 0 if o1 is greater than o2, returns a number < 0 if o2 is greater than o1
	 * and returns 0 if both o1 and o2 are equal.
	 * @return int
	 */
	public int compare(Object o1, Object o2) {
		
		
		if(comparator == null) {
			
			//natural comparison
			Comparable<E> e1 = (Comparable<E>) o1;
			return e1.compareTo((E) o2);
			
		} else {
			return comparator.compare((E) o1, (E) o2);
		}
		
		
	}// end of isEmpty()
		
	
	
	
	// IS EMPTY ------------------------------------------------------------------------------------------------------
	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		
		if(itemsInData == 0 && data[0] == null) {
			//its empty
			return true;
		}
		
		return false;
		
	}// end of isEmpty()
	
	

	
	// ITERATOR ------------------------------------------------------------------------------------------------------
	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {

		return new MySortedSetIterator(this, data);
		
	}// end of iterator()
	
	// ^^^^^ THE ITERATOR RETURNED FROM ABOVE ^^^^^
	private class MySortedSetIterator implements Iterator<E> {

		private MySortedSet<E> pointsAt; 	// points at the set for method calls
		private E[] dataInSet;    			// points directly to the data in the set
		private int currentIndex = 0;    	// what index our iterator is currently on
		private boolean nextHasBeenCalled = false;
		
		
		public MySortedSetIterator(MySortedSet<E> pointsAt, E[] dataArray) {
			this.pointsAt  = pointsAt;
			this.dataInSet = dataArray;
		}
		
		
		@Override
		public boolean hasNext() {
			
			if(this.dataInSet[currentIndex] == null) {
				return false;
			}
			
			return true;
		}

		@Override
		public E next() {

			if(this.dataInSet[currentIndex] == null) {
				throw new NoSuchElementException();
			}
			
			currentIndex++;					//NEXT INDEX
			nextHasBeenCalled = true;	
			return this.dataInSet[currentIndex - 1]; // We just advanced the index, but we're going to need the last item...
		}
		
		
		@Override
		public void remove() {
			
			if(nextHasBeenCalled) {
				//Remove the last item returned by next. That is currentIndex - 1
				pointsAt.remove(dataInSet[currentIndex - 1]);
			}
			
			//Only one remove() per next()
			nextHasBeenCalled = false;
		}
		
	}// end of iterator class

	
	
	
	
	// REMOVE --------------------------------------------------------------------------------------------------------
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int resultIndex = this.search(o);
		
		//Check that o is the object returned by our binary search:
		if(data[resultIndex].equals(o)) {
			
			//Null out the object:
			data[resultIndex] = null;
			//remove the null spot from our data array
			condense(resultIndex);
			
			//We have one less item so:
			itemsInData--;
			
			//the set contained o: 
			return true;
		}
		
		return false;
		
	}// end of remove()

	
	
	
	
	// REMOVE ALL ----------------------------------------------------------------------------------------------------
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		
		//set our lowest index to the highest index
		int lowestRemovedIndex = this.itemsInData;
		// ^ this is used in our conense
		
		//Track how many items we've removed:
		int totalItemsRemoved = 0;
		
		//Create an array of ints that will hold the indexes of any item in c that will be removed:
		Integer[] indexesToRemove = new Integer[c.size()];
		
		
		Iterator cIterator = c.iterator(); 	//Used to step through our argument collection (c)
		
		while(cIterator.hasNext()) {
			
			//Grab each object in c
			Object next = cIterator.next();
			
			//search for that object in our data array
			int resultIndex = search(next);
			
			
			//make sure that the object returned from the search is the same as the one in c
			if(data[resultIndex].equals(next)) {
				
				//if it is add it to our remove array:
				indexesToRemove[totalItemsRemoved] = resultIndex;
				totalItemsRemoved++;
				
				//track the lowest index to be removed. (used in the condense method)
				if(resultIndex < lowestRemovedIndex) {
					lowestRemovedIndex = resultIndex;
				}
				
			}// if(data is removed)
			
			
		}//end of while()
		
		if(totalItemsRemoved > 0) { // Here our data DID change, so lets clean out the null gaps and set
									// our size accordingly
			
			for(Integer i : indexesToRemove) {
				
				if(i == null) {
					continue;
				}
				
				data[i] = null;
				
			}
			
			//Condense the data array:
			condense(lowestRemovedIndex);
			
			//Update itemsInData accordingly
			itemsInData = itemsInData - totalItemsRemoved;
			return true;
		}
		
		//Nothing in c was in data:
		return false;
		
	}// end of removeAll()

	
	
	
	
	
	// SIZE ----------------------------------------------------------------------------------------------------------
	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		
		return itemsInData;
		
	}// end of size()

	
	
	
	
	// TO ARRAY ------------------------------------------------------------------------------------------------------
	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		//Create an empty array of length 'itemsInData'
		E[] retArray = (E[]) new Object[this.itemsInData];
		
		// step through data and add our items to our new array:
		for(int i = 0 ; i < this.itemsInData ; i++ ) {
			retArray[i] = data[i];
		}
		
		return retArray;
		
	}// end of toArray()

	
	
	
	
	// BINARY SEARCH --------------------------------------------------------------------------------------------------
	/**
	 * Performs a binary search on the objects data array
	 * Returns an index in the array of where the object is or where it SHOULD be. 
	 */
	public int search(Object o) {
		
		int minIndex = 0;               // far left
		int maxIndex = itemsInData - 1; //far right shifted to the left for index[0]
		
		int currentIndex = maxIndex / 2; //half way between left and right
		
		while(maxIndex > minIndex) {
		
			//Compare the argument to the object at the center of our search:
			int compResult = this.compare(o, data[currentIndex]);
			
			if(compResult > 0) {  //argument is greater than center:
				
				minIndex = currentIndex + 1;
				
			} else if (compResult < 0) { // less than center
				
				maxIndex = currentIndex - 1;
				
			} else { //they're equal
				
				return currentIndex;
				
			}
			
			//narrow the range
			currentIndex = (minIndex + maxIndex) / 2;
			
		}
		
		
		return currentIndex;
		
	}// end of search()
	
	
	
	
	// SHIFT RIGHT --------------------------------------------------------------------------------------------------
	/**
	 * Moves all items in the data array starting at the index data[startingAtIndex] (inclusive)
	 * @param startingAtIndex
	 */
	private void shiftRight(int startingAtIndex) {
		//Grab the object we're displacing:
		E displacedObject = data[startingAtIndex];
		
		if(data[data.length - 2] != null) {
			growArray(); //NO YOU GROW ARRAY!! :D
		}
		
		//right at the end of our data?
		if(data[startingAtIndex] == null) {
			return;
		}
		
		//Shift everything to the right by one:
		while(startingAtIndex < data.length) {
			//Grab the next object being displaced by our first displaced object
			E next = data[startingAtIndex + 1];
			
			//add our first displaced object back to the array:
			data[startingAtIndex + 1] = displacedObject;
			
			displacedObject = next;
			startingAtIndex++;
			
			//if the next index is null, we're done shifting!
			if(data[startingAtIndex] == null) {
				break;
			}
		}
		
	}// end of shiftRight()
	
	
	
	
	// GROW ARRAY --------------------------------------------------------------------------------------------
	/**
	 * doubles the capacity of the sets data array
	 */
	private void growArray() {
		
		E[] temp = (E[]) new Object[data.length * 2];
		
		for(int i = 0; i < data.length; i++) {
			temp[i] = data[i];
		}
		
		data = temp;
		
	}// end of grow()
	
	
	
	
	// CONDENSE DATA ------------------------------------------------------------------------------------------
	/**
	 * Removes any gaps in our data 
	 * @param startingAt
	 */
	private void condense(int startingAt) {
		
		//How many indexes we need to shift by
		int shiftDistance = 1;
		int index = startingAt;
		
		while(index < itemsInData) {
			
			if(index + shiftDistance > this.itemsInData) {
				return; // we're at the end of our data
				
			} else if(data[index + shiftDistance] != null) {

				//shift the next piece of data against our main chunk
				data[index] = data[index + shiftDistance];
				//null out the data we just shifted, because copies suck (memory)
				data[index + shiftDistance] = null;
				index++;
				
			} else {

				//here the place where data SHOULD be is null, lets look after that
				shiftDistance++;
				//do this if we're not at the end of our data slick right?
				
			}
			
		}// end of while()
		
	}// end of condense()
	
	
	
}// end of class
