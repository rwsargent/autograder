package assignment3;


import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;


/**
 * Contains a set of methods for timing both the contains() and add() method in the
 * MySortedSet class. Saves the test results to csv files in the working directory in eclipse
 * 
 * @author Jon Worms
 * @author Jen Simons
 * 
 */
public class MySortedSetBenchmarks {

	
	//Tracks the last number to add to the set:
	//We're going to be adding or checking for 0, so thats at the far end of the
	//binary search which means its the worst case scenario 
	private Integer latestNumberToAddToTheSet = 1;
	
	//THE OBJECT WE'RE TESTING
	private MySortedSet<Integer> testSet;
	
	
	//Test parameters:
	int intervalSize 	= 50000; //default is 100000
	int timesToLoop		= 20000000;   //how many times to run the test per added chunk of data
	
	//Size boundaries for set
	int maxSize 		= 2000000;
	
	//number of columns in our output data
	int columnCount 	= (maxSize  / intervalSize) + 1;
	int currentColumn;
	
	//test data:
	double[] testTimes;
	
	
	
	@Before
	public void setupForTest() {
		
		//clear out the set
		testSet = new MySortedSet<Integer>();
		
		//clear out any data from our last test:
		testTimes = new double[columnCount];
		
		//set our starting column back to 0
		currentColumn = 0;
		
		System.out.println("columns in data set: " + columnCount);
		
		//Reset our number counter (used when adding data to the set)
		latestNumberToAddToTheSet = 1;
		
	}
	
	
	
	
	/**
	 * Tests the contains() method and saves the data to csv files located in the working directory
	 * of eclipse
	 */
	@Test
	public void timeContainsMethodWithAveraging() {
		
		
		long startTime, midpointTime, stopTime;
		
		// Step through each column in our data table and add data after taking the test
		// After each column add some more data and then run the test again
		while(currentColumn < testTimes.length) {
			
			System.out.println(1 + currentColumn + " / " + testTimes.length);

			
			//Spin up our test:
		    startTime = System.nanoTime();
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    //RUN THE TEST HERE:
		    startTime = System.nanoTime();

		    for (long i = 0; i < timesToLoop; i++) {
		    	testSet.contains(0);
		    }
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.
		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    testTimes[currentColumn] = ((midpointTime - startTime) - (stopTime - midpointTime)) / timesToLoop;
		    
		    //next column
		    currentColumn++;
		    //add some data:
		    addData(intervalSize);
		    
		}// end of loop 
		
		//save the test to file:
		printDataToFile(testTimes, "contains.csv");
		
	}// end of method
	
	
	
	
	/**
	 * Tests the add() method and saves the data to csv files located in the working directory
	 * of eclipse
	 */
	@Test
	public void timeAddMethodWithAveraging() {
		
		
		long startTime, midpointTime, stopTime;
		int uniqueAdd = 0;
		// Step through each column in our data table and add data after taking the test
		// After each column add some more data and then run the test again
		while(currentColumn < testTimes.length) {
			
			System.out.println(currentColumn + " / " + testTimes.length);

			
			//Spin up our test:
		    startTime = System.nanoTime();
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    //RUN THE TEST HERE:
		    startTime = System.nanoTime();

		    for (long i = 0; i < timesToLoop; i++) {
		    	testSet.add(uniqueAdd);
		    }
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.
		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    testTimes[currentColumn] = ((midpointTime - startTime) - (stopTime - midpointTime)) / timesToLoop;
		    
		    //next column
		    currentColumn++;

		    //add some data:
		    addData(intervalSize - 1);
		    System.out.println("adding to set: " + (intervalSize - 1));
		    System.out.println("size: " + testSet.size());
		    System.out.println("first: " + testSet.first());
		    
		    uniqueAdd--;

		}// end of loop 
		
		//save the test to file:
		printDataToFile(testTimes, "add.csv");
		
	}// end of method

	
	
	
	/**
	 * Tests the add() method on an item that is all ready in the set and saves the data to csv 
	 * files located in the working directory of eclipse
	 */
	@Test
	public void timeAddMethodNoShiftWithAveraging() {
		
		
		long startTime, midpointTime, stopTime;
		// Step through each column in our data table and add data after taking the test
		// After each column add some more data and then run the test again
		while(currentColumn < testTimes.length) {
			
			System.out.println(currentColumn + " / " + testTimes.length);

			
			//Spin up our test:
		    startTime = System.nanoTime();
		    while (System.nanoTime() - startTime < 1000000000) { // empty block
		    }

		    //RUN THE TEST HERE:
		    startTime = System.nanoTime();

		    for (long i = 0; i < timesToLoop; i++) {
		    	testSet.add(1);
		    }
		    
		    midpointTime = System.nanoTime();

		    // Run an empty loop to capture the cost of running the loop.
		    for (long i = 0; i < timesToLoop; i++) { // empty block
		    }

		    stopTime = System.nanoTime();

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.

		    testTimes[currentColumn] = ((midpointTime - startTime) - (stopTime - midpointTime)) / timesToLoop;
		    
		    //next column
		    currentColumn++;

		    //add some data:
		    addData(intervalSize);
		    

		}// end of loop 
		
		//save the test to file:
		printDataToFile(testTimes, "addNoShift.csv");
		
	}// end of method

	
	
	

	/*
	 * COMMON METHODS
	 */
	
	
	
	
	/**
	 * Prints the data generated by our timing methods to csv files located in the working directory used by eclipse
	 * @param dataToPrint
	 * @param fileName
	 */
	private void printDataToFile(double[] dataToPrint, String fileName) {
		
		try {
			File file = new File(fileName);
			
			PrintWriter dataWriter = new PrintWriter(file);
			
			for(double dataValue : dataToPrint) {
				dataWriter.print(dataValue + ", ");
			}
			
			dataWriter.close();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	
	/**
	 * Adds a chunk of data to the testSet by the interval argument
	 */
	private void addData(int interval) {
		
		for(int i = 0; i < interval ; i++) {
			
			//Print to console if something goes wrong
			if(!testSet.add(latestNumberToAddToTheSet)) {
				System.out.println("add failed!!!!");
			}

			//This starts at 1
			latestNumberToAddToTheSet++;
			
		}
	}
	
	
	

	
}// end of class
