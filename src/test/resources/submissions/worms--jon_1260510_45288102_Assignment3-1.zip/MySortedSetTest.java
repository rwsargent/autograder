package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Test;

import assignment2.LibraryBook;
import assignment2.LibraryBookGeneric;


/**
 * Unit tests for MySortedSet
 * 
 * @author Jon Worms
 * @author Jen Simons
 */
public class MySortedSetTest {

	
	@Test
	public void testConstructor() {
		//Checking constructor for any exceptions...?
		MySortedSet<String> naturalSet = new MySortedSet<String>();
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		MySortedSet<LibraryBook> bookSet = new MySortedSet<LibraryBook>();
		
	}// end of testConstructor()
	
	
	
	@Test
	public void testComparator() {
		
		//Get comparator from set with natural ordering:
		MySortedSet<String> naturalSet = new MySortedSet<String>();
		if(naturalSet.comparator() != null) {
			fail("Naturally ordered collection did not return null");
		}
		
		
		//Get comparator from set with natural ordering:
		MySortedSet<Integer> naturalSet2 = new MySortedSet<Integer>();
		if(naturalSet2.comparator() != null) {
			fail("Naturally ordered collection did not return null");
		}
		
		
		//Get comparator from set with comparator ordering:
		MySortedSet<LibraryBookGeneric<String>> comparatorSet = new MySortedSet<LibraryBookGeneric<String>>(new OrderByAuthor<String>());
																											// ^ method below
		if(comparatorSet.comparator() == null) {
			fail("MySortedSet with comparator did not return its comparator");
		}
		
		
	}// end of testComparator()
	
	
	//A COMPARATOR TO TEST MYSORTEDSET with (used above)
	/**
	 * Comparator that defines an ordering among library books using the author,
	 * and book title as a tie-breaker.
	 */
	private class OrderByAuthor<Type> implements Comparator<LibraryBookGeneric<Type>> {

		public int compare(LibraryBookGeneric<Type> lhs, LibraryBookGeneric<Type> rhs) {
			
			return (lhs.getAuthor().compareTo(rhs.getAuthor()));
			
		}
		
	}

	
	
	
	@Test
	public void testFirst() {
		
		
		MySortedSet<String> testSet = new MySortedSet<String>();
		
		//Test for exception:
		boolean exceptionWasThrown = false; //Will be true if exception is thrown
		try {
			testSet.first();
			
		} catch (NoSuchElementException e){
			exceptionWasThrown = true;
		}

		if(!exceptionWasThrown) {
			fail("exception was not thrown after calling .first() on empty set");
		}
		
		
		//Add some data:
		testSet.add("d");
		testSet.add("b");
		testSet.add("f");
		testSet.add("a");
		testSet.add("z");
		testSet.add("e");
		
		//this should be "a"
		if(!testSet.first().equals("a")){
			fail("first/smallest element should be ''a''.");
		}
		
	}//end of testFirst()

	
	
	
	@Test
	public void testLast() {
		MySortedSet<String> testSet = new MySortedSet<String>();
		
		// test for exception:
		boolean exceptionWasThrown = false; //Will be true if exception is thrown
		try {
			testSet.last();
			
		} catch (NoSuchElementException e){
			exceptionWasThrown = true;
		}
		
		if(!exceptionWasThrown) {
			fail("exception was not thrown after calling .last() on empty set");
		}
		
		//Add some data:
		testSet.add("d");
		testSet.add("b");
		testSet.add("f");
		testSet.add("a");
		testSet.add("z");
		testSet.add("e");
		
		//get the last
		if(!testSet.last().equals("z")){
			fail("first/smallest element should be 'a'.");
		}
		
	}// end of testLast()

	
	
	
	
	@Test
	public void testAdd() {
		
		MySortedSet<String> testSet = new MySortedSet<String>();
		
		if(testSet.add(null)) {
			fail("Adding null object did not return false");
		}
		
		if(testSet.size() != 0) {
			fail("Null object has increased size of set. This is bad");
		}
		
		//A string to use in the next set of tests:
		String testString = "Test";
		if(!testSet.add(testString)) {
			fail("Adding unique object to the set did not return true");
		}
		
		if(testSet.size() != 1) {
			fail("Added unique object returned true, but was not added to set");
		}
		
		if(testSet.add(testString)) {
			fail("Adding duplicate object to set did not return false");
		}
		
		if(testSet.size() != 1) {
			fail("Added duplicate object returned false, but was still added to set");
		}
		
	}//end of testAdd()
	
	
	

	@Test
	public void testAddAll() {
		
		
		//Create a new (hopefully empty) set:
		MySortedSet<String> testMySet = new MySortedSet<String>();

		
		//Test for adding null:
		if(testMySet.addAll(null)) {
			fail("addAll(null) returned true");
		}
		
		//Add an array list with null in all of its values:
		ArrayList<String> nullList = new ArrayList<String>();
		nullList.add(null);
		nullList.add(null);
		nullList.add(null);
		
		if(testMySet.addAll(nullList)) {
			fail("addAll(Null collection) returned true");
		}
		
		
		
		//Make sure there aren't any objects in the set. While it may be 
		//unlikely (if not impossible) lets just be sure:
		if(testMySet.size() != 0) {
			fail("test set starting size > 0, cannot continue test");
		}
		
		
		//Create a collection of objects to add to the set: (test data)
		ArrayList<String> testCollection = new ArrayList<String>();
		testCollection.add("first object");
		testCollection.add("second object");
		testCollection.add("third object");
		
		
		
		//test the return value of the method, this should return true because
		//the set has changed (by three objects)
		if(!testMySet.addAll(testCollection)) {
			fail("set did not return true after change from addAll");
		}
		
		//test the size of the set for all 3 objects:
		if(testMySet.size() != 3) {
			fail("not every object was added to the Set");
		}
		
		
		//Create a second collection of objects to add to the set:
		ArrayList<String> testCollection2 = new ArrayList<String>();
		testCollection2.add("fourth object");
		//a duplicate object to add:
		testCollection2.add("first object");
		testCollection2.add("fifth object");
		
		//test the return value for change in set, because we're adding
		//new objects to the set: 'fourth object' and 'fifth object'
		//this should return true, because the set has changed.
		if(!testMySet.addAll(testCollection2)) {
			fail("test set should have changed, but returned false");
		}
		
		//Check size of set for the 'first object' if its 5, we're good.
		//If it's 6, 'first object' was added twice.
		if(testMySet.size() != 5) {
			fail("duplicate object was likely added to the set");
		}
		
		// Add a collection that is 100% duplicates, the set should not change
		// and therefore should return false
		if(testMySet.addAll(testCollection)) {
			fail("set did not change after addAll with non-unique objects but still returned true");
		}
		
	}// end of testAddAll()

	
	
	
	@Test
	public void testClear() {
		
		MySortedSet<String> testMySet = new MySortedSet<String>();
		testMySet.add("first");
		testMySet.add("second");
		testMySet.add("third");
		
		//Check to see if all objects were added:
		if(testMySet.size() != 3) {
			fail("something went wrong adding items to clear, cannot continue the test");
		}
		
		//THE ACTUAL TEST!
		testMySet.clear();
		
		if(testMySet.size() != 0) {
			fail("objects are still in the set after calling clear()");
		}
		
		testMySet.add("after clear");
		if(testMySet.size() != 1) {
			fail("adding object after calling clear failed");
		}
		
	}// end of testClear()

	
	
	
	@Test
	public void testContains() {
		
		MySortedSet<String> testMySet = new MySortedSet<String>();

		testMySet.add("first");
		testMySet.add("second");
		testMySet.add("third");
		
		// 'fourth' is not included, should return false
		if(testMySet.contains("fourth")) {
			fail("returned true for an object not contained in the set");
		}
		
		// 'first' IS included, should return true
		if(!testMySet.contains("first")) {
			fail("returned false for an object contained in the set");
		}
		
		// 'third' is included, but is at the end of the set, on the off chance that our
		// contains method is not stepping and checking through each value, we may be able
		// to catch that error here: 
		if(!testMySet.contains("third")) {
			fail("returned false for an object contained in the set");
		}
		
		
	}// end of testContains

	
	
	
	@Test
	public void testContainsAll() {

		MySortedSet<String> testMySet = new MySortedSet<String>();

		//Add some initial data:
		testMySet.add("first");
		testMySet.add("second");
		testMySet.add("third");
		
		
		//Create a collection that are all ready present in the set to test containsall
		ArrayList<String> allreadyInSet = new ArrayList<String>();
		allreadyInSet.add("first");
		allreadyInSet.add("second");
		allreadyInSet.add("third");
		
		if(!testMySet.containsAll(allreadyInSet)) {
			fail("test set returned false for collection that it already contains");
		}
				
		//Create a collection of with some of them all ready present in the set:
		ArrayList<String> someInSet = new ArrayList<String>();
		someInSet.add("first");
		someInSet.add("fourth");
		someInSet.add("third");
				
		if(testMySet.containsAll(someInSet)) {
			fail("test set returned true for collection that has objects that does not contain");
		}
		
		
		//Add some items to the set to check agains a collection of different sizes
		testMySet.add("fourth");
		testMySet.add("fifth");
		
		/*
		 * This shouldn't be a problem, and if anything it would throw some kind of exception
		 */
		
		if(!testMySet.containsAll(someInSet)) {
			fail("test set returned false for collection that contains objects already in set");
		}
		
	}// end of testContainsAll()

	
	
	@Test
	public void testIsEmpty() {

		MySortedSet<String> testMySet = new MySortedSet<String>();

		
		//the set IS empty, should return true:
		if(!testMySet.isEmpty()) {
			fail("isempty() returned false when it is in fact, empty");
		}
	
		// add an object to the set, so it is not empty any more.
		testMySet.add("object");
		
		// now that the set has objects, isEmpty should return false:
		if(testMySet.isEmpty()) {
			fail("isempty() returned true when it contains objects");
		}
		
	
	}// end of testIsEmpty()

	
	
	
	@Test
	public void testIterator() {
		
		
		MySortedSet<Integer> testMySet = new MySortedSet<Integer>();
		testMySet.add(8);
		testMySet.add(-1);
		testMySet.add(55);
		testMySet.add(9);
		testMySet.add(2);
		
		Iterator<Integer> resultIterator = testMySet.iterator();
		
		if(resultIterator == null) {
			fail("iterator() did not return an Iterator");
		}
		
		Integer lastValue = null;
		int itemCount = 0;
		
		//This loop tests the sort from our iterator
		while(resultIterator.hasNext()) {
			
			if(lastValue == null) { //for our first value in the collection:
				lastValue = resultIterator.next();
			} else {
				
				Integer nextValue = resultIterator.next();
				
				if(nextValue < lastValue) {
					fail("Items were not returned in ascending order");
				} else {
					lastValue = nextValue;
				}
				
			}
			
			itemCount++;
			
		}
		
		//This checks to make sure we got every item in the colleciton
		if(itemCount != 5) {
			fail("Iterator failed to step through every object in MySortedSet");
		}
		
		
		
		
	}//end of testIterator()
	
	
	@Test
	public void testIteratorRemove() {
		MySortedSet<Integer> testMySet = new MySortedSet<Integer>();
		testMySet.add(8);
		testMySet.add(-1);
		testMySet.add(55);
		testMySet.add(9);
		testMySet.add(2);
		
		Iterator<Integer> resultIterator = testMySet.iterator();
		
		if(resultIterator == null) {
			fail("iterator() did not return an Iterator");
		}
		
		
		//This loop tests the sort from our iterator
		while(resultIterator.hasNext()) {
			
			Integer next = resultIterator.next();
			if(next == 55) {
				resultIterator.remove();
			}
			
		}
		
		if(testMySet.contains(55)) {
			fail("Removal of 55 failed");
		}
		
		if(testMySet.size() != 4) {
			fail("Size after remove() is not correct");
		}
		
		
	}

	
	
	
	
	@Test
	public void testRemove() {
		
		MySortedSet<String> testMySet = new MySortedSet<String>();

		testMySet.add("first");
		testMySet.add("second");
		testMySet.add("third");
		
		if(testMySet.remove("not in the set")) {
			fail("remove() returned true while removing an object not contained in the set");
		}
		
		//Make sure remove isn't just grabbing something at random to remove
		if(testMySet.size() != 3) {
			fail("Item was removed from the set anyway...");
		}
		
		
		if(!testMySet.remove("second")) {
			fail("removal of object in set returned false, should return true");
		}
		
		if(testMySet.size() != 2) {
			fail("object that was supposed to be removed is still in the set");
		}
		
		if(testMySet.contains("second")) {
			fail("set removed the wrong object!!!!");
		}
		
		
		
	}// end of testRemove()

	
	
	
	
	@Test
	public void testRemoveAll() {
		MySortedSet<Integer> testMySet = new MySortedSet<Integer>();

		testMySet.add(1);  //1
		testMySet.add(2);  //3
		testMySet.add(3);  //4
		testMySet.add(4);  //2
		testMySet.add(5);  //0
		
		
		//Create a set that contains none of the objects in our test Set
		ArrayList<Integer> removeNone = new ArrayList<Integer>();
		removeNone.add(6);
		removeNone.add(7);
		removeNone.add(8);
		
		
		if(testMySet.removeAll(removeNone)) {
			fail("removeAll returned true for set of objects not contained in the set");
		}
		
		if(testMySet.size() != 5) {
			fail("some objects were removed anyway!!!");
		}
		
		//
		//Create an ArrayList containing only objects that are in the set:
		ArrayList<Integer> removeAll = new ArrayList<Integer>();
		removeAll.add(2);
		removeAll.add(5);
		removeAll.add(3);
		//
		//
		
		if(!testMySet.removeAll(removeAll)) {
			fail("removeAll() of set containing objects within the set did NOT return true");
		}
		
		if(testMySet.size() != 2) {
			fail("removeAll() failed to remove the objects contained in the argument");
		}
		
		//Re-add the objects we removed above
		testMySet.add(2);
		testMySet.add(5);
		testMySet.add(3);
		//Create an ArrayList that contains only some of the objects in the set,
		//and an extra object not included in the set:
		ArrayList<Integer> removeSome = new ArrayList<Integer>();
		removeSome.add(2);
		removeSome.add(42);
		removeSome.add(3);
		
		
		if(!testMySet.removeAll(removeSome)) {
			fail("objects contained in removeAll() arguments were not removed");
		}

		if(testMySet.size() != 3) { // 5 - 2 = 3
			fail("set is wrong size after removal of 2 objects: " + testMySet.size());
		}
		
	}// end of removeAll()

	
	@Test
	public void testRemoveAllWithStrings() {
		MySortedSet<String> testMySet = new MySortedSet<String>();

		testMySet.add("first");  //1
		testMySet.add("second");  //3
		testMySet.add("third");  //4
		testMySet.add("fourth");  //2
		testMySet.add("fifth");  //0
		
		
		//Create a set that contains none of the objects in our test Set
		ArrayList<String> removeNone = new ArrayList<String>();
		removeNone.add("sixth");
		removeNone.add("seventh");
		removeNone.add("eight");
		
		
		if(testMySet.removeAll(removeNone)) {
			fail("removeAll returned true for set of objects not contained in the set");
		}
		
		if(testMySet.size() != 5) {
			fail("some objects were removed anyway!!!");
		}
		
		//
		//Create an ArrayList containing only objects that are in the set:
		ArrayList<String> removeAll = new ArrayList<String>();
		removeAll.add("second");
		removeAll.add("fifth");
		removeAll.add("third");
		//
		//
		
		if(!testMySet.removeAll(removeAll)) {
			fail("removeAll() of set containing objects within the set did NOT return true");
		}
		
		if(testMySet.size() != 2) {
			fail("removeAll() failed to remove the objects contained in the argument");
		}
		
		//Re-add the objects we removed above

		testMySet.add("second");
		testMySet.add("fifth");
		testMySet.add("third");

		//Create an ArrayList that contains only some of the objects in the set,
		//and an extra object not included in the set:
		ArrayList<String> removeSome = new ArrayList<String>();
		removeSome.add("second");
		removeSome.add("wut");
		removeSome.add("third");
		
		
		if(!testMySet.removeAll(removeSome)) {
			fail("objects contained in removeAll() arguments were not removed");
		}

		if(testMySet.size() != 3) { // 5 - 2 = 3
			fail("set is wrong size after removal of 2 objects: " + testMySet.size());
		}
		
	}// end of removeAll()

	
	
	@Test
	public void testSize() {
		
		MySortedSet<String> testMySet = new MySortedSet<String>();

		if(testMySet.size() != 0) {
			fail("test set size() should be 0");
		}
		
		testMySet.add("first");
		
		if(testMySet.size() != 1) {
			fail("test set size() should be 1");
		}
		
		testMySet.add("second");
		testMySet.add("third");
		testMySet.add("fourth");
		testMySet.add("fifth");
		
		if(testMySet.size() != 5) {
			fail("size() after add failed: should be 5");
		}
		
		testMySet.remove("fourth");
		
		if(testMySet.size() != 4) {
			fail("size() after remove failed: should be 4");
		}
		
		
	}// end of testSize()

	
	
	
	
	@Test
	public void testToArray() {
		
		MySortedSet<String> testMySetString = new MySortedSet<String>();
		
		
		//With an empty set:
		if(testMySetString.toArray() == null) { // make sure we do have an array, and not just null 
			fail("toArray returned null instead of an empty array");
		}
		
		//Add some objects to our array. (purposely unsorted)
		testMySetString.add("d");
		testMySetString.add("b");
		testMySetString.add("f");
		testMySetString.add("a");
		testMySetString.add("z");
		testMySetString.add("e");
		
		//get our objects back as an array from the set:
		Object[] resultStringArray = testMySetString.toArray();
		
		//A string array to hold our results in after casting back to string:
		String[] properCastString = new String[resultStringArray.length];
		
		//Step through each object from our returned array, cast back to string, and add to the string array:
		for (int i = 0 ; i < properCastString.length; i++) {
			properCastString[i] = (String) resultStringArray[i];
		}
			
		
		//create a sorted array to compare to our results against:
		String[] rightStringArray = new String[6];
		rightStringArray[0] = "a";
		rightStringArray[1] = "b";
		rightStringArray[2] = "d";
		rightStringArray[3] = "e";
		rightStringArray[4] = "f";
		rightStringArray[5] = "z";
			
		//Step through each index of our result string array and compare it to our rightStringArray
		for(int i = 0; i < properCastString.length; i++) {
			
			//If any dont match:
			if(!properCastString[i].equals(rightStringArray[i])) {
				
				//Dump our result array into a string for print:
				String arrayDump = "";
				for(String s : properCastString) {
					arrayDump += " " + s;
				}
				
				fail("string array is not properly sorted: " + arrayDump);
			}
		}
		
	}//end of testToArray()
	
	
	@Test
	public void testCompareTo() {
		//Natural ordering:
		MySortedSet<String> stringSet = new MySortedSet<String>();
		if(stringSet.compare("a", "b") != "a".compareTo("b")) {
			fail("");
		}
		
		if(stringSet.compare("a", "a") != "a".compareTo("a")) {
			fail("");
		}
		
		MySortedSet<Integer> integerSet = new MySortedSet<Integer>();
		Integer one = 1;
		if(integerSet.compare(1, 2) != one.compareTo(2)) {
			fail();
		}
		
		//Comparator ordering:
		
		MySortedSet<LibraryBookGeneric<String>> libSet = new MySortedSet<LibraryBookGeneric<String>>(new OrderByAuthor<String>());
		LibraryBookGeneric<String> book1 = new LibraryBookGeneric<>(0L, "a", "a title");
		LibraryBookGeneric<String> book2 = new LibraryBookGeneric<>(0L, "b", "a title");
		
		if(libSet.compare(book1, book2) != "a".compareTo("b")) {
			fail();
		}
		
		if(libSet.compare(book1, book1) != 0) {
			fail();
		}
		
	}
	
	
	

	@Test
	public void testSearch() {
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		
		intSet.add(1);
		intSet.add(2);
		intSet.add(3);
		intSet.add(4);
		intSet.add(5);
		
		int resultIndex = intSet.search(3);
		
		if(resultIndex != 2) {
			fail("wrong index returned: " + resultIndex);
		}
		
		resultIndex = intSet.search(7);
		if(resultIndex != 4) {
			fail("wrong index returned: " + resultIndex + " should be index 4");
		}
		
	}

	
	
}// end of test cases! 
