/**
 * Runs a timing test on MySortedSet.
 * 
 * @author Aaron Pabst and Jeanette Arteaga
 * Last Updated: 2/5/2015
 */
package assignment3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

public class TimingTest {

  public static void main(String[] args) {
    long startTime, midpointTime, stopTime;
    MySortedSet<Integer> set = new MySortedSet<Integer>();
    
    //Add a huge collection to set
    //The add method places some serious constraints on this test.
    for(long c = 1000000; c < 1000001; c += 100000){ 
		for(int i = 0; i < c; i++){
			Random rand = new Random();
			double toAdd = rand.nextDouble() + (double)rand.nextInt(1000);
			set.add(toAdd);
		}
		//System.out.println("Done initializing set....");
	
	    // First, spin computing stuff until one second has gone by.
	    // This allows this thread to stabilize.
	
	    startTime = System.nanoTime();
	    while (System.nanoTime() - startTime < 1000000000) { // empty block
	    }
	
	    // Now, run the test.
	
	    long timesToLoop = 1;
	
	    startTime = System.nanoTime();
	
	    for (long i = 0; i < timesToLoop; i++)
	      for (double d = 1; d <= 10; d++)
	        set.contains(763.345);
	
	    midpointTime = System.nanoTime();
	
	    // Run an empty loop to capture the cost of running the loop.
	
	    for (long i = 0; i < timesToLoop; i++) { // empty block
	    }
	
	    stopTime = System.nanoTime();
	
	    // Compute the time, subtract the cost of running the loop
	    // from the cost of running the loop and computing square roots.
	    // Average it over the number of runs.
	
	    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
	        / timesToLoop;
	
	    System.out.println("It took " + averageTime + " to run contains for a set of " + c + " doubles.");
  }
  }
}