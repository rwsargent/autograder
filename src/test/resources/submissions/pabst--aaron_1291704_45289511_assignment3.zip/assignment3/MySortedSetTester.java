package assignment3;

public class MySortedSetTester {
	
	public static void main(String[]args){
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		
		//Attempt to add a bunch of number
		for(int i = 0; i < 100; i++)
			set.add(Math.random());
		
		//Attempt to get a number
		System.out.println(set.get(0));
	}

}
