/**
 * Runs a series of tests on MySortedSet
 * 
 * @author Aaron Pabst and Jeanette Arteaga
 * Last Updated: 2/5/2015
 */
package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;

import org.junit.Before;
import org.junit.Test;

public class SortedSetTest {

	MySortedSet<Integer> set;
	MySortedSet<Integer> test;
	
	@Before
	public void setup(){
		test = new MySortedSet<Integer>();
		
	}
	
	@Test
	public void addTest(){
		Integer toAdd = 2;
		assertTrue(test.add(toAdd));
		assertTrue(test.get(0) == 2);
	}
	
	@Test
	public void addTest3(){
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		assertTrue(set.add(2));
		assertTrue(set.add(1));
		assertTrue(set.add(3));
		assertEquals(3, set.size());
		
		assertTrue(set.add(4));
		
		assertEquals(4, set.size());
		
		assertTrue(!(set.add(2)));
		assertEquals(4, set.size());
		
		assertTrue(!(set.add(3)));
		assertEquals(4, set.size());
		
		assertTrue(set.add(0));
		System.out.println(set);
		
	}

	
	@Test
	public void containsTest(){
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		int toAdd = 42;
		set.add(toAdd);
		assertTrue(set.contains(toAdd));
		assertTrue(!(set.contains(-1)));
	}
	
	@Test
	public void growTest(){
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		for(int i = 0; i < 10000; i++){
			set.add(i);		
		}
		System.out.println(set);
	}
	
	@Test
	public void containsTest2(){
		MySortedSet<Double> set = new MySortedSet<Double>();
		double[] arr = new double[10000];
		for(int i = 0; i < 10000; i++){
			Random rand = new Random();
			double toAdd = rand.nextDouble() + (double)rand.nextInt(1000);
			arr[i] = toAdd;
			set.add(toAdd);
		}
		
		for(int i = 0; i < 100; i++){
			Random rand = new Random();
			int pos = rand.nextInt(99);
			double toCheck = arr[pos];
			assertTrue(set.contains(toCheck));
		}
	}

}
