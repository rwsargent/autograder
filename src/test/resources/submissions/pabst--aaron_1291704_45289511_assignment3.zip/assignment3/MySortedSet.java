/**
 * This class represents a generic set of objects that can be added and removed. Elements are sorted as they are added to make for fast searching.
 * 
 * @author Aaron Pabst and Jeanette Arteaga
 * Last Updated: 2/5/2015
 */
package assignment3;


import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E extends Comparable<E>> implements SortedSet {
	
	private Object[] list;
	private int size;
	private Comparator<? super E> comparator;
	
	/**
	 * Default constructor. No comparator, use natural ordering.
	 */
	public MySortedSet(){
		list = new Object[10];
		size = 0;
		comparator = null;
	}
	
	/**
	 * Constructs this set to use an alternate comparator.
	 * @param c -- The comparator to use when sorting and searching.
	 */
	public MySortedSet(Comparator<? super E> c){
		list = new Object[10];
		size = 0;
		comparator = c;
	}

	@Override
	/**
	 * @return The comparator that this object uses. Null if the natural ordering is used.
	 */
	public Comparator<? super E> comparator() {
		// TODO Auto-generated method stub
		return comparator;
	}

	@Override
	/**
	 * @return The first element in the list, if there is one. Throws NoSuchElementExcpetion for an empty set.
	 */
	public Object first() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if(size == 0)
			throw new NoSuchElementException();
		return list[0];
	}

	/**
	 * @return The last element in the list, if there is one. Throws NoSuchElementExcpetion for an empty set.
	 */
	@Override
	public Object last() throws NoSuchElementException {
		// TODO Auto-generated method stub
		if(size == 0)
			throw new NoSuchElementException();
		return list[size-1];
	}

	/**
	 * Inserts a new and unique element into the proper spot of the list, if the array containing the list is full, grow the array.
	 * 
	 * @param o -- The object to be added to the list
	 * 
	 * @return True if the object was added to the list, false otherwise. An object will not be added if it is already in the list.
	 */
	@Override
	@SuppressWarnings("unchecked")
	public boolean add(Object o) {
		//If the array is full, grow the array
		if(size == list.length-1){ // TODO Check the minus one part
			growArray();
		}

		Object[] newArr = new Object[list.length];
		
		if(size == 0){ //First add
			list[0] = o;
		}
		else if(size == 1){
			int compare = ((E)o).compareTo((E)list[0]);
			if(compare == 0) //Duplicate
				return false;
			else if(compare < 0){
				list[1] = list[0];
				list[0] = o;
			}
			else
				list[1] = o;
		}
		else if(size == 2){ //Size 2: Special Case
			//Check to see if new element goes before or after first
			int compare = ((E)o).compareTo((E)list[0]);
			if(compare < 0){ //Insert to left of first element
				newArr[0] = o;
				newArr[1] = list[0];
				newArr[2] = list[1];
				list = newArr;
			}
			else if(compare > 0 && !(((E)o).compareTo((E)list[1]) > 0)){ //Insert to right of position one
				newArr[0] = list[0];
				newArr[1] = o;
				newArr[2] = list[1];
				list = newArr;
			}
			//If neither, put it after 2nd.
			else{
				newArr[0] = list[0];
				newArr[1] = list[1];
				newArr[2] = o;
				list = newArr;
			}
		}
		else{
			boolean left = false;
			int first = 0;
			int last = size - 1;
			int pos = (first + last) / 2;
			E toAdd = (E)o;
				
			while(first <= last){
				E current = (E)list[pos];
				int compare = 0;
				if(comparator == null)
					compare = toAdd.compareTo(current);
				else
					compare = comparator.compare(toAdd, current);
				
				if(compare == 0)
					return false;
				else{
					if(pos == 0 || pos == size-1){
						if(compare < 0){
							left = true;
							break;
						}
						else{
							left = false;
							break;
						}
					}
					else{
						E toLeft = (E)list[pos-1];
						E toRight = (E)list[pos+1];
						
						int compareLeft = 0, compareRight = 0;
						if(comparator == null){
							compareRight = toAdd.compareTo(toRight);
							compareLeft = toAdd.compareTo(toLeft);
						}
						else{
							compareRight = comparator.compare(toAdd, toRight);
							compareLeft = comparator.compare(toAdd, toLeft);
						}
						
						if(compareRight < 0 && compare > 0){
							left = false;
							break;
						}
						else if(compareLeft > 0 && compare < 0){
							left = true;
							break;
						}
					}
				}
				
				if(compare < 0)
					last = pos - 1;
				else
					first = pos + 1;
				pos = (first + last) / 2;
			}
			if(left){
				for(int i = 0; i < pos; i++)
					newArr[i] = list[i];
				newArr[pos] = o;
				for(int i = pos+1; i <= size; i++)
					newArr[i] = list[i-1];
			}
			else{
				for(int i = 0; i <= pos; i++)
					newArr[i] = list[i];
				newArr[pos+1] = o;
				for(int i = pos+2; i <= size; i++)
					newArr[i] = list[i-1];
			}
			list = newArr;
		}
		size++;
		return true;
	}
	
	/**
	 * Grows the array that contains the list to double its original size.
	 */
	private void growArray(){
		Object[] tmp = new Object[list.length*2];
		for(int i = 0; i < list.length; i++)
			tmp[i] = list[i];
		list = tmp;
	}
	
	/**
	 * Returns an element from a specific spot in the array
	 * 
	 * @param pos -- The position to look for the element.
	 * @return Null if the selected position is out of bounds. The element at the selected position otherwise.
	 */
	@SuppressWarnings("unchecked")
	public E get(int pos){
		if(pos >= size)
			return null;
		return (E)list[pos];
	}
	
	
	/**
	 * Adds a collection of objects to this set by repeatedly calling the add method for each element in the provided collection.
	 * 
	 * @param c -- The collection to be added.
	 * @return True if the list was altered, false if it was not.
	 */
	@Override
	public boolean addAll(Collection c) {
		// TODO Auto-generated method stub
		Object[] collect = c.toArray();
		boolean changed = false;
		for(int i = 0; i < collect.length; i++)
			changed = add(collect[i]);
		return changed;
	}

	@Override
	/**
	 * Deletes all data in this set. A type of reset switch.
	 */
	public void clear() {
		list = new Object[list.length];
		size = 0;
	}

	/**
	 * Searches the list for an object and indicates whether or not the element is present in the array.
	 * 
	 * @param o -- The object to look for
	 * @return True if the object is in the list.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		if(search(o) != -1)
			return true;
		else
			return false;
	}

	@SuppressWarnings("rawtypes")
	@Override
	/** 
	 * Adds a collection of elements to the set.
	 * 
	 * @param Collection c -- The collection to be added.
	 * @return True if the set was altered, fasle otherwise.
	 */
	public boolean containsAll(Collection c) {
		Object[] toCheck = c.toArray();
		for(int i = 0; i < toCheck.length; i++){
			if(!this.contains(toCheck[i]))
				return false;
		}
		return true;
	}

	@Override
	/**
	 * @return True if the set is empty, false otherwise.
	 */
	public boolean isEmpty() {
		if(size == 0)
			return true;
		else
			return false;
	}
	
	/**
	 * The iterator for this collection.
	 */
	private class iterator implements Iterator<E>{

		int currPos;
		boolean canRemove;
		E current;
		
		iterator(){
			currPos = 0;
			current = (E)list[currPos];
			canRemove = false;
		}
		
		@Override
		public boolean hasNext() {
			return currPos < size;
		}

		@Override
		public E next() throws NoSuchElementException{
			if(!hasNext())
				throw new NoSuchElementException();
	
			current = (E)list[currPos];
			
			currPos++;
			canRemove = true;
			return current;
		}

		@Override
		public void remove() throws IllegalStateException{
			if(currPos == 0 || !canRemove)
				throw new IllegalStateException();
			else
				MySortedSet.this.remove(list[currPos-1]);
			canRemove = false;
		}
		
	}
	
	@Override
	/**
	 * @return An iterator for this object.
	 */
	public Iterator<E> iterator() {
		return new iterator();
		
	}

	@Override
	public boolean remove(Object o) {
		int pos = search(o);
		if(pos == -1)
			return false;
		for(int i = pos; i < size; i++){
			if(i+1 == list.length)
				break;
			list[i] = list[i+1];
		}
		//list[size-1] = null;
			
		size--;
		return true;
	}
	
	/**
	 * Searches the set for an object.
	 * 
	 * @param o -- The object to be searched for.
	 * @return The position of the object, -1 if not found.
	 */
	public int search(Object o){
		int first = 0;
		int last = size-1;
		int middle = (first + last) / 2;
		E toAdd = (E)o;
		
		while (first <= last){
			E current = (E)list[middle];
			int compare = 0;
			if(comparator == null)
				compare = toAdd.compareTo(current);
			else
				compare = comparator.compare(toAdd, current);
			if(compare < 0)
				last = middle - 1;
			else if(compare == 0){
				return middle;
			}
			else
				first = middle + 1;
			
			middle = (first + last) / 2;
		}
		
		return -1;
	}

	@Override
	/**
	 * Remove a collection of elements from the set.
	 * 
	 * @param Collection c-- The collection to be removed.
	 * @return True if the set was altered, false otherwise.
	 */
	public boolean removeAll(Collection c) {
		boolean changed = false;
		Object[] toRemove = c.toArray();
		for(int i = 0; i < toRemove.length; i++){
			if(remove(toRemove[i]))
				changed = true;
		}
		return changed;
	}

	/**
	 * @return The size of the set.
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * @return This set as an array.
	 */
	@Override
	public Object[] toArray() {
		Object[] result = new Object[size];
		for(int i = 0; i < size; i++)
			result[i] = list[i];
		return result;
	}
	
	/**
	 * This collection represented as a String.
	 */
	public String toString(){
		String result = "[";
		for(int i = 0; i < size; i++)
			result += list[i].toString() + (i != size-1 ? "," : "");
		result += "]";
		return result;
	}

}
