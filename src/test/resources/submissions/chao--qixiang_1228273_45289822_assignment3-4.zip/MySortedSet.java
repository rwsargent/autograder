package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
/**
 * this class implements SortedSet<E> interface, and the behavior likes other Java List, such as ArrayList, LinkedList, 
 * it can sorted the element when you tried to add element by the compareTo method inside of the Object. 
 * it also can be sorted by the Comparator if the user pass into one.
 *  
 * @author Jin He && Qixiang Chao
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E> {
	private E[] set;
	private Comparator<? super E> comparator;
	private int size;
	private final int DEFAULT_SIZE = 5;
	
	/**
	 * Construct a "MySortedSet" constructor without parameter, so the
	 * comparator should be null.
	 */	
	@SuppressWarnings("unchecked")
	public MySortedSet() {
		size = 0;
		set = (E[]) new Object[DEFAULT_SIZE];
		this.comparator = null;
	}

	/**
	 * Construct a "MySortedSet", and the parameter should equal to the
	 * parameter Comparator.
	 * 
	 * @param a
	 *            comparator,and the generic should be <? super E>; return
	 *            nothing.
	 */

	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> A) {
		set = (E[]) new Object[DEFAULT_SIZE];
		this.comparator = A;
		size = 0;
	}

	// Iterator
	/**
	 * This method is used to get the comparator if the user used the second
	 * parameter to construct the "MySortedSet". If the user used the first
	 * constructor to construct the MySortedSet, it will return null.
	 * 
	 * 
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		if (this.comparator == null) {
			return null;
		} else {
			return this.comparator;
		}
	}

	/**
	 * 
	 * This method is used to get the first element if the "MySortedSet" is not
	 * Empty.
	 * 
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (size == 0) {
			throw new NoSuchElementException();
		} else {
			// Return the first element in the set.
			return set[0];
		}
	}

	/**
	 * This method is used to get the last element in the MySortedSet if it is
	 * not empty.
	 * 
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (size == 0) {
			throw new NoSuchElementException();
		} else {
			// Return the last element in the set.
			return set[size - 1];
		}
	}

	/**
	 * This is a helper method that is used to find the position that the new
	 * element to be inserted.
	 * 
	 * @param the
	 *            element you want to insert.
	 * @return the index of the element should be insert.
	 */

	@SuppressWarnings("unchecked")
	public int indexSearching(E o) {
		// if there is no specific Comparator for this MySortedSet, it will just
		// use the compareTo Method inside of the Object.
		if (this.comparator == null) {
			Comparable<E> elementInsert = (Comparable<E>) o;
			int index = 0;
			if (size == 0) {
				return 0;
			}
			if (size == 1) {
				if (elementInsert.compareTo(set[0]) > 0) {
					return 1;
				} else {
					return 0;
				}
			}
			if (size != 0 && size != 1) {
				// Compare the element with the last element, it will return the
				// size of the set if it should be inserted after the last
				// element.
				if (elementInsert.compareTo(set[size - 1]) > 0) {
					return size;
				}
				// Compare the element with the first element, it will return 0
				// if it should be inserted before the first element.
				if (elementInsert.compareTo(set[0]) < 0) {
					return 0;
				} else {
					int low = 0;
					int high = size - 1;
					// This binary search loop is used to get the index where
					// the element should be inserted, it will cover all the
					// elements expect
					// the first one and the last one.
					while (low <= high) {
						int middle = (low + high) / 2;
						if (elementInsert.compareTo(set[middle]) > 0
								&& elementInsert.compareTo(set[middle + 1]) < 0) {
							index = middle + 1;
							break;
						}
						if (elementInsert.compareTo(set[middle]) > 0
								&& elementInsert.compareTo(set[middle + 1]) > 0) {
							low = middle + 1;
						}
						if (elementInsert.compareTo(set[middle]) < 0
								&& elementInsert.compareTo(set[middle + 1]) < 0) {
							high = middle - 1;
						}
					}
				}
			}
			return index;
		} else {
			Comparator<? super E> elementInsert = this.comparator;
			int index = 0;
			if (size == 0) {
				return 0;
			}
			if (size == 1) {
				if (elementInsert.compare(o, set[0]) > 0) {
					return 1;
				} else {
					return 0;
				}
			}
			if (size != 0 && size != 1) {
				if (elementInsert.compare(o, set[size - 1]) > 0) {
					return size;
				}
				if (elementInsert.compare(o, set[0]) < 0) {
					return 0;
				} else {
					int low = 0;
					int high = size - 1;
					while (low <= high) {
						int middle = (high + low) / 2;
						if (elementInsert.compare(o, set[middle]) > 0
								&& elementInsert.compare(o, set[middle + 1]) < 0) {
							index = middle + 1;
							break;
						}
						if (elementInsert.compare(o, set[middle]) < 0
								&& elementInsert.compare(o, set[middle + 1]) < 0) {
							high = middle - 1;
						}
						if (elementInsert.compare(o, set[middle]) > 0
								&& elementInsert.compare(o, set[middle + 1]) > 0) {
							low = middle + 1;
						}
					}
				}
			}
			return index;
		}
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {
		if (this.contains(o)) {
			return false;
		}
		if (size + 1 > set.length) {
			E[] newSet = (E[]) new Object[size * 2];
			for (int indexOfArray = 0; indexOfArray < size; indexOfArray++) {
				newSet[indexOfArray] = set[indexOfArray];
			}
			set = newSet;
		}
		int index = indexSearching(o);
		if (index != size) {
			for (int indexOfArray = size - 1; indexOfArray >= index; indexOfArray--) {
				E temp = set[indexOfArray];
				set[indexOfArray + 1] = temp;
			}
			set[index] = o;
			size++;
			return true;
		} else {
			set[index] = o;
			size++;
			return true;
		}
	}

	/**
	 * this method is used to get the result of this MySortedSet.
	 * 
	 * @return return the result as String.
	 */
	@Override
	public String toString() {
		String A = "";
		for (int i = 0; i < size; i++) {
			A += set[i] + " ";
		}
		return A;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */

	@Override
	public boolean addAll(Collection<? extends E> c) {
		int count = 0;
		for (E element : c) {
			if (element != null) {

				if (add(element)) {
					count++;
				}
			}// Whether all of the elements should be add? It should return
				// false if one or two elements that have already existed in
				// this set
		}
		if (count != 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		E[] newSet = (E[]) new Object[DEFAULT_SIZE];
		set = newSet;
		size = 0;
	}

	/**
	 * This method is used to judge whether the element have already existed in
	 * the "MySortedSet" class.
	 * 
	 * @param the
	 *            element you want to check. -- element whose presence in this
	 *            set is to be tested
	 * @return true if this set contains the specified element
	 */
	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object o) {
		if (this.comparator() == null) {
			int low = 0;
			int high = size - 1;
			E checkElement = (E) o;
			Comparable<E> forCheck = (Comparable<E>) checkElement;
			while (low <= high) {
				int middle = (low + high) / 2;
				if (forCheck.compareTo(set[middle]) == 0) {
					return true;
				} else if (forCheck.compareTo(set[middle]) > 0) {
					low = middle + 1;

				} else if (forCheck.compareTo(set[middle]) < 0) {

					high = middle - 1;
				}
			}
			return false;
		} else {
			int low = 0;
			int high = size - 1;
			E checkElement = (E) o;
			while (low <= high) {
				int middle = (high + low) / 2;
				if (this.comparator.compare(checkElement, set[middle]) == 0) {
					return true;
				}
				if (this.comparator.compare(checkElement, set[middle]) > 0) {
					low = middle + 1;
				}
				if (this.comparator.compare(checkElement, set[middle]) < 0) {
					high = middle - 1;
				}
			}
			return false;
		}
	}

	/**
	 * This method is used to add all of the elements from the collection c to
	 * the "MySortedSet". It will return true if the size is changed.
	 * 
	 * @param c
	 *            the collection you want to add to the MySortedSet. --
	 *            collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public boolean containsAll(Collection<?> c) {
		Iterator iterator = c.iterator();
		int count = 0;
		while (iterator.hasNext()) {
			E temp = (E) iterator.next();
			if (this.contains(temp)) {
				count++;
			}

		}
		if (count == c.size()) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check whether the "MySortedSet" is empty.
	 * 
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * This method is used to get the Iterator of this MySortedSet.
	 * 
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new myIterator();
	}

	/**
	 * This method is used to get the element index which have already existed
	 * in the MySortedSet. It will return -1 if the element does not exist.
	 * 
	 * @param o
	 *            the parameter you want to check.
	 * @return return the index of this element, it will return -1 if this
	 *         element is not exist.
	 */
	@SuppressWarnings("unchecked")
	public int elementSearching(Object o) {
		if (this.comparator == null) {
			E element = (E) o;
			Comparable<E> forCheck = (Comparable<E>) element;
			int low = 0;
			int high = size - 1;
			while (low <= high) {
				int middle = (low + high) / 2;
				if (forCheck.compareTo(set[middle]) == 0) {
					return middle;
				}
				if (forCheck.compareTo(set[middle]) > 0) {
					low = middle + 1;
				}
				if (forCheck.compareTo(set[middle]) < 0) {
					high = middle - 1;
				}
			}
			return -1;
		} else {
			E element = (E) o;
			int low = 0;
			int high = size - 1;
			while (low <= high) {
				int middle = (high + low) / 2;
				if (this.comparator.compare(element, set[middle]) == 0) {
					return middle;
				}
				if (this.comparator.compare(element, set[middle]) > 0) {
					low = middle + 1;
				}
				if (this.comparator.compare(element, set[middle]) < 0) {
					high = middle - 1;
				}
			}
			return -1;
		}
	}

	// 0 1 2 3
	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            the element you want delete in this MySortedSet. -- object to
	 *            be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int index = elementSearching(o);
		if (index == -1) {
			return false;
		} else {
			if (index == size - 1) {
				set[size - 1] = null;
				size--;
				return true;
			} else {
				for (int indexOfArray = index; indexOfArray < size - 1; indexOfArray++) {
					E B = set[indexOfArray + 1];
					set[indexOfArray] = B;
				}
				set[size - 1] = null;
				size--;
				return true;
			}
		}
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            the collection you want to delete from this MySortedSet. --
	 *            collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public boolean removeAll(Collection<?> c) {
		Iterator iterator = c.iterator();
		int count = 0;
		while (iterator.hasNext()) {
			E temp = (E) iterator.next();
			if (temp != null) {
				if (this.remove(temp)) {
					count++;
				}
			}
		}
		if (count != 0) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * This method is used to get the size of the "MySortedSet".
	 * 
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * Convert this MySortedSet to an array.
	 * 
	 * 
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object[] toArray() {
		E[] newSet = (E[]) new Object[size];
		for (int index = 0; index < size; index++) {
			newSet[index] = set[index];
		}
		return newSet;
	}

	/**
	 * This class is a Iterator class for MySortedSet. the behavior of this
	 * Iterator like the Iterator of ArrayList
	 * 
	 * @author Jin He && Qixiang Chao
	 *
	 */
	private class myIterator implements Iterator<E> {
		int check = -1;

		/**
		 * This method used to check whether this MySortedSet has next Element.
		 * 
		 * @return return true if it has next element, false if it doesn't have.
		 */
		@Override
		public boolean hasNext() {
			if (check != size - 1) {
				return true;
			} else {
				return false;
			}
		}

		/**
		 * This method is used to get the next element if it have the next
		 * element
		 * 
		 * @return return the next element if it have, else, it will throw
		 *         NoSuchElementException;
		 */
		@Override
		public E next() {
			check++;
			if (check > size - 1) {
				throw new NoSuchElementException();
			}
			return set[check];
		}

		/**
		 * this method is used to remove previous element which is just invoked
		 * the next() method.
		 * 
		 */
		@Override
		public void remove() {
			if (check == -1) {
				throw new IllegalStateException();
			}
			MySortedSet.this.remove(set[check]);
		}
	}
}
