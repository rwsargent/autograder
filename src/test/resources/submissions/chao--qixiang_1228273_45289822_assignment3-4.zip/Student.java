package assignment3;
/**
 * this class we created for test, and it has three variables which are age, name and grade. 
 * @author Jin He && Qixiang Chao
 *
 */
public class Student {
	private String name;
	private int age;
	private int grade;
	
	public Student(String name, int age, int grade)
	{
		this.name=name;
		this.age=age;
		this.grade=grade;
	}
	public int getAge()
	{
		return this.age;
	}
	public int getGrade()
	{
		return this.grade;
	}
	public String getName()
	{
		return this.name;
	}
	@Override
	public String toString()
	{
		return this.name;
	}
	
}
