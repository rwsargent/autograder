package assignment3;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import javax.swing.text.html.HTMLDocument.Iterator;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
/**
 * for this Test, I tried to use two kinds of class to do it. 
 * @author Jin He && Qixiang Chao
 *
 */
@SuppressWarnings("unused")
public class TestMySortedSet {
	private MySortedSet<Integer> test1;
	private MySortedSet<String> test2;
	private MySortedSet<Integer> test3;
	private MySortedSet<Integer> test4;
	private intCompare testComparator;
	private MySortedSet<Student> test5;
	private java.util.Iterator<Student> test6;

	/**
	 * set up the initial status to the representation.
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {
		test1 = new MySortedSet<Integer>();
		test2 = new MySortedSet<String>();
		testComparator = new intCompare();
		test3 = new MySortedSet<Integer>(testComparator);
		test1.add(4);
		test1.add(6);
		test1.add(1);
		test1.add(9);
		test2.add("c");
		test2.add("a");
		test2.add("e");
		test2.add("d");
		test4 = new MySortedSet<Integer>(testComparator);
		test4.add(4);
		test4.add(6);
		test4.add(9);
		test4.add(1);
		test5 = new MySortedSet<Student>(new StudentCompare());
		test5.add(new Student("Dana", 20, 777));
		test5.add(new Student("Amber", 12, 444));
		test5.add(new Student("Cathy", 21, 666));
		test6 = test5.iterator();
	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * This method is used to test Comparator.
	 */
	@Test
	public void testComparator() {
		assertEquals(null, test1.comparator());
		assertEquals(testComparator, test3.comparator());
	}

	/**
	 * This Method is used to test whether the "MySortedSet" can get the first
	 * element.
	 */
	@Test
	public void testFirst() {
		assertEquals(1, test1.first().intValue());
		assertEquals("a", test2.first());
		assertEquals(9, test4.first().intValue());
		assertEquals("Amber", test5.first().toString());
	}

	/**
	 * It will throw Exception if this MySortedSet is Empty.
	 */
	@Test(expected = NoSuchElementException.class)
	public void testException() {
		test3.first();
	}

	/**
	 * it will throw Exception if this MySortedSet is Empty.
	 */
	@Test(expected = NoSuchElementException.class)
	public void testException2() {
		test3.last();
	}

	/**
	 * this method is used to test last method, it will return the last element
	 * in this MySortedSet.
	 */
	@Test
	public void testLast() {
		assertEquals(9, test1.last().intValue());
		assertEquals("e", test2.last());
		assertEquals(1, test4.last().intValue());
		assertEquals("Dana", test5.last().toString());
	}

	/**
	 * This method is used to test indexSearching method,
	 */
	@Test
	public void testIndexSearching() {
		assertEquals(2, test1.indexSearching(5));
		assertEquals(0, test1.indexSearching(0));
		assertEquals(4, test1.indexSearching(10));
		assertEquals(1, test2.indexSearching("b"));
		assertEquals(4, test2.indexSearching("f"));
		assertEquals(0, test4.indexSearching(100));
		assertEquals(2, test4.indexSearching(5));
		assertEquals(4, test4.indexSearching(0));
		assertEquals(1, test5.indexSearching(new Student("Black", 81, 222)));
		assertEquals(3, test5.indexSearching(new Student("Elice", 99, 555)));

	}

	/**
	 * This method is used test add method.
	 */
	@Test
	public void testAdd() {
		assertEquals(true, test1.add(-1));
		assertEquals(false, test1.add(4));
		assertEquals(true, test2.add("z"));
		assertEquals(false, test2.add("a"));
		assertEquals(true, test5.add(new Student("Police", 55, 888)));
		assertEquals(false, test5.add(new Student("Amber", 4, 666)));
	}

	/**
	 * This method is used to test addAll method.
	 */
	@Test
	public void testAddAll() {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(11);
		list.add(12);
		list.add(13);
		assertEquals(true, test1.addAll(list));
		HashSet<String> set = new HashSet<String>();
		set.add("a");
		set.add("c");
		set.add("e");
		set.add("d");
		assertEquals(false, test2.addAll(set));
		LinkedList<Student> studentList = new LinkedList<Student>();
		studentList.add(new Student("Newton", 33, 999));
		studentList.add(new Student("Turing", 35, 999));
		studentList.add(new Student("Einstein", 11, 666));
		assertEquals(true, test5.addAll(studentList));
	}

	/**
	 * This method is used to test clear() method.
	 */
	@Test
	public void testClear() {
		test1.clear();
		assertEquals(0, test1.size());
	}

	/**
	 * This method is used to test contains method.
	 */
	@Test
	public void testContains() {
		assertEquals(true, test1.contains(4));
		assertEquals(false, test1.contains(99));
		assertEquals(true, test5.contains(new Student("Amber", 12, 444)));
		assertEquals(false, test5.contains(new Student("Lincoln", 44, 666)));
	}

	/**
	 * This method is used to test
	 */
	@Test
	public void testContainsAll() {
		ArrayList<Integer> A = new ArrayList<Integer>();
		A.add(1);
		A.add(6);
		assertEquals(true, test1.containsAll(A));
		A.add(1000);
		assertEquals(false, test1.containsAll(A));
	}

	/**
	 * This method is used to test isEmpty method.
	 */
	@Test
	public void testIsEmpty() {
		assertEquals(false, test1.isEmpty());
		assertEquals(true, test3.isEmpty());
	}

	/**
	 * This method is used to rest remove() method.
	 */
	@Test
	public void testRemove() {
		assertEquals(false, test1.remove(8));
		assertEquals(true, test1.remove(1));
	}

	/**
	 * This method is used to test removeAll method.
	 */
	@Test
	public void testRemoveAll() {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(99);
		list.add(100);
		assertEquals(false, test1.removeAll(list));
		list.clear();
		list.add(1);
		list.add(4);
		list.add(9);
		assertEquals(true, test1.removeAll(list));
	}

	/**
	 * This method is used to test size method.
	 */
	@Test
	public void testSize() {
		assertEquals(4, test1.size());
		assertEquals(4, test2.size());
	}

	/**
	 * This method is used to test toArray method.
	 */
	@Test
	public void testToArray() {
		int[] A = { 1, 4, 6, 9 };
		Object[] B = test1.toArray();
		assertEquals(4, test1.toArray().length);
		assertEquals(A[1], B[1]);
		assertEquals(A[2], B[2]);
		assertEquals(A[3], B[3]);
		assertEquals(A[0], B[0]);
	}

	/**
	 * This method is used to test hasNext in Iterator.
	 */
	@Test
	public void testHasNextIterator() {
		assertEquals(true, test6.hasNext());
		test6.next();
		test6.next();
		test6.next();
		assertEquals(false, test6.hasNext());
	}

	/**
	 * This method is used to test Exception for Iterator, if the invoked times
	 * bigger than the size of MySortedSet, it will throw NoSuchElementException
	 */
	@Test(expected = NoSuchElementException.class)
	public void testException3() {
		test6.next();
		test6.next();
		test6.next();
		test6.next();
	}

	/**
	 * This method is used to test the Exception for Iterator, it will throw
	 * IllegalStateException if you invoke remove remove method but you didn't
	 * invoke next() method
	 */
	@Test(expected = IllegalStateException.class)
	public void testException4() {
		test6.remove();
	}

	/**
	 * This class is just a Comparator used to implement descending order for
	 * Integer.
	 *
	 */
	@SuppressWarnings("rawtypes")
	private class intCompare implements Comparator {
		@Override
		public int compare(Object o1, Object o2) {
			int A = (int) o1;
			int B = (int) o2;
			return B - A;
		}
	}

	/**
	 * This Comparator is used to compare Student Objects by student's name.
	 * 
	 *
	 */
	@SuppressWarnings("rawtypes")
	private class StudentCompare implements Comparator {
		@Override
		public int compare(Object o1, Object o2) {
			Student A = (Student) o1;
			Student B = (Student) o2;
			return A.getName().compareTo(B.getName());
		}
	}
}
