/**
 * Michael Cline and Nicholas Madsen
 * CS 2420
 * January 5, 2015
 */
package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestMySortedSetOperations 
{
	/**
	 * Create test variables
	 */
	private MySortedSet<Integer> testSet1;
	private MySortedSet<String> testSet2;
	private MySortedSet<Integer> testSet3;
	private ArrayList<Integer> testList1;
	private ArrayList<String> testList2;
	private ArrayList<Integer> testList3;
	private Object[] testObjArray;
	private ArrayList<Integer> testListArray;
	
	/**
	 * Preliminary test preparations
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception 
	{
		/**
		 * Initialize test variables
		 */
		testSet1 = new MySortedSet<Integer>();
		testSet2 = new MySortedSet<String>();
		testSet3 = new MySortedSet<Integer>();
		testList1 = new ArrayList<Integer>();
		testList2 = new ArrayList<String>();
		testList3 = new ArrayList<Integer>();
		testListArray = new ArrayList<Integer>();
		testObjArray = new Object[5];

		/**
		 * Add elements to array
		 */
		testListArray.add(0);
		testListArray.add(1);
		testListArray.add(2);
		testListArray.add(3);
		testListArray.add(4);
		
		/**
		 * Add elements to object array
		 */
		for(int i = 0; i < testObjArray.length; i++){
			testObjArray[i] = i;
		}
		
		/**
		 * Setup lists
		 */
		testList2.add("hi");
		testList2.add("hello");
		testList2.add("hola");
		testList2.add("halo");
		
		testList1.add(-89);
		testList1.add(13);
		testList1.add(-29);
		testList1.add(-909);
		testList1.add(22);
		
		testSet1.add(10);
		testSet1.add(-1);
		testSet1.add(93);
		testSet1.add(91);
		
		/**
		 * Add whole list to set
		 */
		testSet1.addAll(testList1);
		
		
		
	}

	@After
	public void tearDown() throws Exception {}

	/**
	 * These test the add method
	 */
	@Test
	public void testAdd1() 
	{
		assertEquals(false, testSet1.add(10));
		assertEquals(false, testSet1.add(null));
		assertEquals(false, testSet1.add(-1));
		assertEquals(false, testSet1.add(93));
		assertEquals(false, testSet1.add(91));
		assertEquals(false, testSet1.add(null));
		assertEquals(true, testSet1.add(33));
		assertEquals(true, testSet1.add(1));
		assertEquals(true, testSet1.add(3));
		assertEquals(true, testSet1.add(60));
	}
	
	/**
	 * These test the contains method
	 */
	@Test
	public void testContains1() 
	{
		assertEquals(true, testSet1.contains(10));
		assertEquals(false, testSet1.contains(-10));
		assertEquals(false, testSet1.contains(-99));
		assertEquals(false, testSet1.contains(null));
		assertEquals(true, testSet1.contains(-1));
	}
	
	/**
	 * These test the contains method
	 */
	@Test
	public void testRemove1() 
	{
		assertEquals(false, testSet1.remove(null));
		assertEquals(true,  testSet1.remove(-1));
		assertEquals(false, testSet1.remove(69));
	}
		
	/**
	 * This tests the addAll method
	 */
	@Test
	public void testAddAll1() 
	{
		assertEquals(false, testSet1.addAll(testList1));
	}
	
	/**
	 * This tests the size method
	 */
	@Test
	public void testSize1() 
	{

		assertEquals(9, testSet1.size());
	}
	
	/**
	 * This tests the contains all method
	 */
	@Test
	public void testContainsAll1() 
	{
		assertEquals(true, testSet1.containsAll(testList1));
	}
	
	/**
	 * These test the removeAll method
	 */
	@Test
	public void testRemoveAll1() 
	{
		assertEquals(true, testSet1.removeAll(testList1));
		testSet1.removeAll(testList1);
		assertEquals(false, testSet1.removeAll(testList1));
	}
	
	/**
	 * These test the isEmpty method
	 */
	@Test
	public void testIsEmpty1() 
	{
		assertEquals(false, testSet1.isEmpty());
		assertEquals(true, testSet3.isEmpty());
	}
	
	/**
	 * These test the add method with a different set
	 */
	@Test
	public void testAddAll2() 
	{
		assertEquals(true, testSet2.addAll(testList2));
		assertEquals(false, testSet2.addAll(testList2));
	}
	
	/**
	 * This tests the clear method
	 */
	@Test
	public void testClear1() 
	{
		testSet1.clear();
		assertEquals(true, testSet1.isEmpty());
	}
	
	/**
	 * This tests the toArray method
	 */
	@Test
	public void testToArray1() 
	{
		testSet3.addAll(testListArray);
		assertArrayEquals("They were not equal", testObjArray, testSet3.toArray());

	}
	
}
