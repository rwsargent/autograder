/**
 * Michael Cline and Nicholas Madsen
 * CS 2420
 * January 5, 2015
 */
package assignment3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E>
{
	private E[] MySortedSet;
	private Comparator<? super E> field;
	private int elementCount = 0;
	private int capacity = 10;

	public MySortedSet() 
	{
		MySortedSet = (E[]) new Object[capacity];
	}
	

	public MySortedSet(Comparator<? super E> field)
	{
		this();
		this.field = field;
		
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() 
	{
		//If the set is empty throw the no such element exception
		if(elementCount == 0)
			throw new  NoSuchElementException();
		//If an invalid field typecast to a comparator
		return (Comparator) field;   
	}
	
	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException 
	{
		return MySortedSet[0];
		
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException 
	{
		return MySortedSet[elementCount-1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	public boolean add(E o) 
	{
		
		//does not accept null
		if(o == null){
			return false;
		}
		//if array is empty add first element
		if(elementCount == 0){
			MySortedSet[elementCount] = o;
			elementCount++;
			return true;
		}
		
		//is element already in the set
		if(contains(o)){
			return false;
		}
		
		// Grow the array and copy the elements over into new array
		if (elementCount == capacity){								
            E[] bigger = (E[]) new Object[capacity*2]; 
            for (int i = 0; i < elementCount; i++)
            {
                bigger[i] = MySortedSet[i];
            }
            capacity = bigger.length;
            MySortedSet = bigger;
        }
		//add element
		MySortedSet[elementCount] = o;
		elementCount++;
		//search to see if element needs to be inserted before end element
		int insertion = binarySearchPos(o);
		//if element needs to be inserted in between other elements, shift everything over and do it
		if( insertion < elementCount){
			for(int i = elementCount-1; i > insertion; i--){
					MySortedSet[i] = MySortedSet[i-1];
			}
			MySortedSet[insertion] = o;
			return true;
		}
		return false;
		
	}
	
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) 
	{
		//create an iterator that is constant
		Iterator cycle = c.iterator();
		int checkForChange = elementCount;
		
		while(cycle.hasNext()){
			E listEle = (E) cycle.next();//use iterator to cycle through the list
			add(listEle);
		}
		//check to see if the array size has changed, if it has, something was added
		if(checkForChange != elementCount)
			return true;
		else
			return false;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() 
	{
		//Loop through the set and empty the elements by setting them equal to null.
		for(int i = 0; i < elementCount; i++)
		{
			MySortedSet[i] = null;
		}
		
		//reset element count make new set
		elementCount = 0;
		MySortedSet = (E[]) new Object[capacity];
		
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) 
	{
		if(o == null)
			return false;
		
		if(binarySearch((E)o))
			return true;
		
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c) 
	{
		Iterator cycle = c.iterator();
		
		while(cycle.hasNext()){
			if(!binarySearch((E)cycle.next()))
				return false;
		}
			
	return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() 
	{
		// Check to see if there are elements in the array
		if(elementCount == 0)
			return true;
		else
			return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() 
	{
		return new Iterator<E>(){
		//declare and init variables
		int pointer = -1;
		boolean wasRemoved = false;
		//checks to see if there is anything else in the array
		public boolean hasNext(){
			return (pointer < elementCount-1);
		}
		//returns what is at the pointer and keeps track if remove was called
		@Override
		public E next() {
			if(wasRemoved){
				return null;
			}
			wasRemoved = true;
			pointer++;
			return MySortedSet[pointer];
		}
		//sets wasRemoved to show that remove was called once, then perform the remove and reset the pointer
		public void remove(){
			if(wasRemoved){	
				wasRemoved = false;
				MySortedSet.this.remove((Object)MySortedSet[pointer]);
				pointer--;
			}
			else{
			}
		}
		
		};
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) 
	{
		if(o == null)
			return false;
		//check to make sure that element is in array
		if(!binarySearch((E)o))
			return false;
		
		int removal=binarySearchPos((E)o);		
		int checkForChange = elementCount;
		//shifts everything over and decreases the elementCount
		if( removal < elementCount){
			for(int i = removal; i < elementCount; i++){
					MySortedSet[i] = MySortedSet[i+1];
			}
			elementCount--;
			return true;
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) 
	{
		Iterator cycle = c.iterator();
		int checkForChange = elementCount;
		
		while(cycle.hasNext()){
			E listEle = (E) cycle.next();
			remove(listEle);
		}
		if(checkForChange != elementCount)
			return true;
		else
			return false;

	}

	/**
	 * @return the number of elements in this set
	 */
	public int size() 
	{
		return elementCount;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() 
	{
		// don't run if there is not anything
		if(elementCount == 0)
			return null;
		
		//create the array
		Object[] temp = new Object[elementCount];
		
		//copy elements into the temp array
		for(int i = 0; i < elementCount; i++){
			temp[i] = MySortedSet[i];
		}
		return temp;

	}

	/**
	 * helper method prints the current list that this method is called on.
	 */
	public void getList(){
		for(int i = 0; i < elementCount; i++){
			System.out.println(MySortedSet[i]);
		}
	}
	
	/**
	 * 
	 * @param o -- the element that we are looking for
	 * @return true if the element is within the set, otherwise false
	 */
	private boolean binarySearch (E o)
	{
		int front = 0;
		int end = elementCount - 1;
		int middle = (front + end) / 2;
		
		if(field == null){
			//only run if there are elements in the array
			if(elementCount != 0)
			{
				//create index variables
				Comparable<E> middleCompare = (Comparable<E>) o;				
			
				//run loop while index at front of array is less than index at end
				while(front <= end)
				{
					//check if objects at each position are equal to input object
					if(((Comparable<E>) MySortedSet[middle]).compareTo((E) middleCompare) == 0 ){
						//if it is not equal move front index to the next position
						return true;
					}
	
					//if object is equal return true
					else if(((Comparable<E>) MySortedSet[middle]).compareTo((E) middleCompare) < 0){
						
						front = middle +1;
					}
	
					//move the end index back(which is technically forwards) in the array
					else
						end = middle - 1;
	
					//re-calculate the middle index
					middle = (front + end) / 2;
	
					//if end index runs past the front index, object is not in the array
					if(front > end)
						return false;
				}
			}	
		}
		else
		{
			//create index variables

		
			//run loop while index at front of array is less than index at end
			while(front <= end)
			{
				//check if objects at each position are equal to input object
				if(field.compare(MySortedSet[middle], o) < 0 )
					//if it is not equal move front index to the next position
					front = middle + 1;

				//if object is equal return true
				else if(field.compare(MySortedSet[middle], o) == 0)
					return true;

				//move the end index back(which is technically forwards) in the array
				else
					end = middle - 1;

				//re-calculate the middle index
				middle = (front + end) / 2;

				//if end index runs past the front index, object is not in the array
				if(front > end)
					return false;
					
			}
		}	
		return false;
	}
	
	/**
	 * 
	 * @param o -- the element that we are searching for.
	 * @return returns an int -- the position of the element in the set.
	 */
	private int binarySearchPos (E o)
	{
		int front = 0;
		int end = elementCount - 1;
		int middle = (front + end) / 2;
		
		if(field == null){
			//only run if there are elements in the array
			if(elementCount != 0)
			{
				//create index variables
				Comparable<E> middleCompare = (Comparable<E>) o;				
			
				//run loop while index at front of array is less than index at end
				while(front <= end)
				{
					//check if objects at each position are equal to input object
					if(((Comparable<E>) MySortedSet[middle]).compareTo((E) middleCompare) == 0 ){
						//if it is not equal move front index to the next position
						return middle;
					}
	
					//if object is equal return true
					else if(((Comparable<E>) MySortedSet[middle]).compareTo((E) middleCompare) < 0){
						
						front = middle + 1;
					}
	
					//move the end index back(which is technically forwards) in the array
					else
						end = middle - 1;
	
					//re-calculate the middle index
					middle = (front + end) / 2;
	
					//if end index runs past the front index, object is not in the array
					if(front > end){
						if((front + end)%2 > 0)
							middle++;
						return middle;
					}
				}
			}	
		}
		else
		{
			//create index variables

		
			//run loop while index at front of array is less than index at end
			while(front <= end)
			{
				//check if objects at each position are equal to input object
				if(field.compare(MySortedSet[middle], o) < 0 )
					//if it is not equal move front index to the next position
					front = middle + 1;

				//if object is equal return true
				else if(field.compare(MySortedSet[middle], o) == 0)
					return middle;

				//move the end index back(which is technically forwards) in the array
				else
					end = middle - 1;

				//re-calculate the middle index
				middle = (front + end) / 2;

				//if end index runs past the front index, object is not in the array
				if(front > end){
					if((front + end)%2 > 0)
						middle++;
					return middle;
				}
			}
		}	
		return middle;
	}

}
