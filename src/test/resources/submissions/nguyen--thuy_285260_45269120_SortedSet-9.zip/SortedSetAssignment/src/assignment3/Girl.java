/**
 * Girl.java
 * Description:
 * 
 * @author Thuy Nguyen
 *         Feb 4, 2015
 */
package assignment3;

/**
 * The Girl class purpose is for the testing of MySortedSet addAll method,
 * in which a List<Girl> will be passed into the addAll method of a
 * MySortedSet<Person>
 * Since Girl extends Person, Girl objects should be added to the set wherever
 * a Person type is accepted.
 * 
 * @author Thuy Nguyen and Fred Javalera
 *
 */
public class Girl extends Person
{

	/**
	 * Constructor for Girl object
	 * 
	 * @param n
	 *            the name of the girl
	 */
	public Girl(String n)
	{
		super(n);

	}

}
