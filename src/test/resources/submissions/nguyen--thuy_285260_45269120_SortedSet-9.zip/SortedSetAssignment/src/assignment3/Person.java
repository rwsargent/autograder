/**
 * Person.java
 * Description:
 * 
 * @author Thuy Nguyen
 *         Feb 4, 2015
 */
package assignment3;

/**
 * The Person class is for the testing of addAll method in MySortedSet.
 * The Person class will be the super class for the Girl class, extending
 * Person.
 * We will make a List<Girl> to hold Girl objects, which will be passed into
 * the addAll method for a MySortedSet<Person>. Since Girl extends person,
 * We can add a Girl where a Person object is accepted.
 * 
 * @author Thuy Nguyen and Fred Javalera
 *
 */
public class Person implements Comparable<Person>
{
	// field
	String name;

	// constructor
	/**
	 * Constructor for Person object
	 * 
	 * @param n
	 *            name of the person
	 */
	public Person(String n)
	{
		name = n;
	}

	// public methods
	/**
	 * Returns the person's name
	 * 
	 * @return the person's name
	 */
	public String getName( )
	{
		return name;
	}

	/**
	 * Returns positive if this person's name is greater than
	 * the other person's name according to Ascii math.
	 * 
	 * Returns negative if this person's name is less than the other person's
	 * name.
	 * 
	 * Returns zero if this person's name is the same as the other person's
	 * name.
	 * 
	 */
	@Override
	public int compareTo(Person other)
	{
		return name.compareTo(other.name);
	}
}
