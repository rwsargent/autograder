package assignment3;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Test class for MySortedSet methods
 * 
 * @author Fred Javalera and Thuy Nguyen
 *
 */
public class MySortedSetTester
{
	MySortedSet<String> set1 = new MySortedSet<String>();
	MySortedSet<Integer> set2 = new MySortedSet<Integer>();
	MySortedSet<Double> set3 = new MySortedSet<Double>();
	MySortedSet<Character> set4 = new MySortedSet<Character>();
	MySortedSet<Character> set5 = new MySortedSet<Character>();
	MySortedSet<GregorianCalendar> set6 = new MySortedSet<GregorianCalendar>();
	MySortedSet<Integer> set7 = new MySortedSet<Integer>();
	MySortedSet<Integer> set8 = new MySortedSet<Integer>();

	@Before
	public void setUp( ) throws Exception
	{
		set1.add("Joe");
		set1.add("John");
		set1.add("Fred");
		set1.add("James");
		set1.add("Steve");
		set1.add("Bob");
		set1.add("Ryan");
		set1.add("Zohan");

		set2.add(0);
		set2.add(10);
		set2.add(3);
		set2.add(-1);
		set2.add(9);
		set2.add(8);
		set2.add(100);
		set2.add(200);
		set2.add(5);

		set3.add(2.5);
		set3.add(.5);
		set3.add(.1);
		set3.add(.0001);

		set4.add('z');
		set4.add('Z');

		set5.add('(');
		set5.add('Z');
		set5.add('z');

		set6.add(new GregorianCalendar(1981, 3, 14));
		set6.add(new GregorianCalendar(1981, 3, 17));
		set6.add(new GregorianCalendar(1991, 3, 15));
		set6.add(new GregorianCalendar(1981, 3, 15));
		set6.add(new GregorianCalendar(2001, 3, 16));
		set6.add(new GregorianCalendar(2015, 1, 31));

		set7.add(-10);
		set7.add(40);
		set7.add(30);
		set7.add(-20);
		set7.add(-40);
		set7.add(10);
		set7.add(50);
		set7.add(-30);
		set7.add(20);
		set7.add(-50);
		set7.add(0);
	}

	@After
	public void tearDown( ) throws Exception
	{

	}

	// first() tests

	@Test
	public void set1FirstTest( )
	{
		assertEquals("Bob", set1.first());
	}

	@Test
	public void set2FirstTest( )
	{
		assertEquals(-1, (int) set2.first());
	}

	@Test
	public void set3FirstTest( )
	{
		assertEquals(.0001, (double) set3.first(), .0001);
	}

	@Test
	public void set4FirstTest( )
	{
		assertEquals("Z", set4.first().toString());
	}

	@Test
	public void set5FirstTest( )
	{
		assertEquals("(", set5.first().toString());
	}

	@Test
	public void set6FirstTest( )
	{
		assertEquals(new GregorianCalendar(1981, 3, 14), set6.first());
	}

	// last() tests

	@Test
	public void set1LastTest( )
	{
		assertEquals("Zohan", set1.last());
	}

	@Test
	public void set2LastTest( )
	{
		assertEquals(200, (int) set2.last());
	}

	@Test
	public void set3LastTest( )
	{
		assertEquals(2.5, (double) set3.last(), .0001);
	}

	@Test
	public void set4LastTest( )
	{
		assertEquals("z", set4.last().toString());
	}

	@Test
	public void set5LastTest( )
	{
		assertEquals("z", set5.last().toString());
	}

	@Test
	public void set6LastTest( )
	{
		assertEquals(new GregorianCalendar(2015, 1, 31), set6.last());
	}

	/*
	 * size() and add() tests (since size must be called in order to know they
	 * were added)
	 */

	@Test
	public void set1SizeAndAddTest( )
	{
		assertEquals(8, set1.size());
	}

	@Test
	public void set2SizeAndAddTest( )
	{
		assertEquals(9, set2.size());
	}

	@Test
	public void set3SizeAndAddTest( )
	{
		assertEquals(4, set3.size());
	}

	@Test
	public void set4SizeAndAddTest( )
	{
		assertEquals(2, set4.size());
	}

	@Test
	public void set5SizeAndAddTest( )
	{
		assertEquals(3, set5.size());
	}

	@Test
	public void set6SizeAndAddTest( )
	{
		assertEquals(6, set6.size());
	}

	// clear() and isEmpty() tests

	@Test
	public void set1ClearTest( )
	{
		set1.clear();
		assertEquals(true, set1.isEmpty());
	}

	@Test
	public void set2ClearTest( )
	{
		set2.clear();
		assertEquals(true, set2.isEmpty());
	}

	@Test
	public void set3ClearTest( )
	{
		set3.clear();
		assertEquals(true, set3.isEmpty());
	}

	@Test
	public void set4ClearTest( )
	{
		set4.clear();
		assertEquals(true, set4.isEmpty());
	}

	@Test
	public void set5ClearTest( )
	{
		set5.clear();
		assertEquals(true, set5.isEmpty());
	}

	@Test
	public void set6ClearTest( )
	{
		set6.clear();
		assertEquals(true, set6.isEmpty());
	}

	@Test
	public void set6ClearFalseTest( )
	{
		assertEquals(false, set6.isEmpty());
	}

	// contains() (and, implicitly, binarySearch) tests

	@Test
	public void set1ContainsTest( )
	{
		assertEquals(false, set1.contains("Henry"));
	}

	@Test
	public void set2ContainsTest( )
	{
		assertEquals(true, set2.contains(8));
	}

	@Test
	public void set3ContainsTest( )
	{
		assertEquals(false, set3.contains(98.6));
	}

	@Test
	public void set4ContainsTest( )
	{
		assertEquals(true, set4.contains('Z'));
	}

	@Test
	public void set5ContainsTest( )
	{
		assertEquals(false, set5.contains('A'));
	}

	@Test
	public void set6ContainsTest( )
	{
		assertEquals(true, set6.contains(new GregorianCalendar(1981, 3, 15)));
	}

	// remove() tests

	@Test
	public void set1RemoveTest( )
	{
		assertEquals(true, set1.remove("Bob"));
	}

	@Test
	public void set2RemoveTest( )
	{
		assertEquals(false, set2.remove(1));
	}

	@Test
	public void set3RemoveTest( )
	{
		assertEquals(true, set3.remove(.0001));
	}

	@Test
	public void set4RemoveTest( )
	{
		assertEquals(false, set4.remove('D'));
	}

	@Test
	public void set5RemoveTest( )
	{
		assertEquals(true, set5.remove('('));
	}

	@Test
	public void set6RemoveTest( )
	{
		assertEquals(false, set6.remove(new GregorianCalendar(1981, 3, 18)));
	}

	// toArray() tests

	@Test
	public void set1ToArrayTest( )
	{
		assertArrayEquals(new String[] { "Bob", "Fred", "James", "Joe", "John",
				"Ryan", "Steve", "Zohan", null, null, null, null, null, null,
				null }, set1.toArray());
	}

	@Test
	public void set2ToArrayTest( )
	{
		assertArrayEquals(new Integer[] { -1, 0, 3, 5, 8, 9, 10, 100, 200,
				null, null, null, null, null, null }, set2.toArray());
	}

	@Test
	public void set3ToArrayTest( )
	{
		assertArrayEquals(new Double[] { .0001, .1, .5, 2.5, null, null, null,
				null, null, null, null, null, null, null, null },
				set3.toArray());
	}

	@Test
	public void set4ToArrayTest( )
	{
		assertArrayEquals(new Character[] { 'Z', 'z', null, null, null, null,
				null, null, null, null, null, null, null, null, null },
				set4.toArray());
	}

	@Test
	public void set5ToArrayTest( )
	{
		assertArrayEquals(new Character[] { '(', 'Z', 'z', null, null, null,
				null, null, null, null, null, null, null, null, null },
				set5.toArray());
	}

	@Test
	public void set6ToArrayTest( )
	{
		assertArrayEquals(new GregorianCalendar[] {
				new GregorianCalendar(1981, 3, 14),
				new GregorianCalendar(1981, 3, 15),
				new GregorianCalendar(1981, 3, 17),
				new GregorianCalendar(1991, 3, 15),
				new GregorianCalendar(2001, 3, 16),
				new GregorianCalendar(2015, 1, 31), null, null, null, null,
				null, null, null, null, null }, set6.toArray());
	}

	// multiple method tests

	@Test
	public void set7AddRemoveAndToArrayTest( )
	{
		set7.add(100);
		set7.remove(100);
		assertArrayEquals(new Integer[] { -50, -40, -30, -20, -10, 0, 10, 20,
				30, 40, 50, null, null, null, null }, set7.toArray());
	}

	@Test
	public void set7ClearAndRebuildTest( )
	{
		set7.clear();
		set7.add(-10);
		set7.add(40);
		set7.add(30);
		set7.add(-20);
		set7.add(-40);
		set7.add(10);
		set7.add(50);
		set7.add(-30);
		set7.add(20);
		set7.add(-50);
		set7.add(0);
		assertArrayEquals(new Integer[] { -50, -40, -30, -20, -10, 0, 10, 20,
				30, 40, 50, null, null, null, null }, set7.toArray());
	}

	// addAll() tests

	@Test
	public void set8AddAllCollectionTest( )
	{
		ArrayList<Integer> intArr = new ArrayList<Integer>(Arrays.asList(-10,
				40, 30, -20, -40, 10, 50, -30, 20, -50, 0));
		set8.addAll(intArr);
		assertArrayEquals(new Integer[] { -50, -40, -30, -20, -10, 0, 10, 20,
				30, 40, 50, null, null, null, null }, set8.toArray());
	}

	@Test
	public void set1AddAllCollectionTest( )
	{
		set1.clear();
		ArrayList<String> stringArr = new ArrayList<String>(
				Arrays.asList("Joe", "John", "Fred", "James", "Steve", "Bob",
						"Ryan", "Zohan"));
		set1.addAll(stringArr);
		assertArrayEquals(new String[] { "Bob", "Fred", "James", "Joe", "John",
				"Ryan", "Steve", "Zohan", null, null, null, null, null, null,
				null }, set1.toArray());
	}

	@Test
	public void set3AddAllCollectionTest( )
	{
		set3.clear();
		ArrayList<Double> doubleArr = new ArrayList<Double>(Arrays.asList(2.5,
				.5, .1, .0001));
		set3.addAll(doubleArr);
		assertArrayEquals(new Double[] { .0001, .1, .5, 2.5, null, null, null,
				null, null, null, null, null, null, null, null },
				set3.toArray());
	}

	// containsAll() tests

	@Test
	public void set8ContainsAllTest( )
	{
		set8.clear();
		ArrayList<Integer> intArr = new ArrayList<Integer>(Arrays.asList(-10,
				40, 30, -20, -40, 10, 50, -30, 20, -50, 0));
		set8.addAll(intArr);
		assertEquals(true, set8.containsAll(intArr));
	}

	@Test
	public void set1ContainsAllTest( )
	{
		set1.clear();
		ArrayList<String> stringArr = new ArrayList<String>(
				Arrays.asList("Joe", "John", "Fred", "James", "Steve", "Bob",
						"Ryan", "Zohan"));
		set1.addAll(stringArr);
		set1.remove("Joe");
		assertEquals(false, set1.containsAll(stringArr));
	}

	@Test
	public void set3ContainsAllTest( )
	{
		set3.clear();
		ArrayList<Double> doubleArr = new ArrayList<Double>(Arrays.asList(2.5,
				.5, .1, .0001));
		set3.addAll(doubleArr);
		assertEquals(true, set3.containsAll(doubleArr));
	}

	// removeAll() tests

	@Test
	public void set8RemoveAllTest( )
	{
		set8.clear();
		ArrayList<Integer> intArr = new ArrayList<Integer>(Arrays.asList(-10,
				40, 30, -20, -40, 10, 50, -30, 20, -50, 0));
		set8.addAll(intArr);
		assertEquals(true, set8.removeAll(intArr));
	}

	@Test
	public void set1RemoveAllTest( )
	{
		set1.clear();
		ArrayList<String> stringArr = new ArrayList<String>(
				Arrays.asList("Joe", "John", "Fred", "James", "Steve", "Bob",
						"Ryan", "Zohan"));
		set1.addAll(stringArr);
		set1.clear();
		assertEquals(false, set1.removeAll(stringArr));
	}

	@Test
	public void set3RemoveAllTest( )
	{
		set3.clear();
		ArrayList<Double> doubleArr = new ArrayList<Double>(Arrays.asList(2.5,
				.5, .1, .0001));
		set3.addAll(doubleArr);
		assertEquals(true, set3.removeAll(doubleArr));
	}
}