/**
 * Student.java
 * Description:
 * 
 * @author Thuy Nguyen
 *         Feb 3, 2015
 */
package assignment3;

/**
 * A class for the purpose of testing the MySortedSet constructor
 * that takes in a Comparator.
 * 
 * @author Thuy Nguyen and Fred Javalera
 *         February 3, 2015
 */
public class Student
{

	// enum for students grades kindergarten - college senior
	public enum Grade
	{
		KINDERGARTEN, FIRST, SECOND, THIRD, FOURTH, FIFTH, SIXTH, SEVENTH, EIGHTH, NINETH, TENTH, ELEVENTH, TWELVETH, COLLEGE_FRESHMAN, COLLEGE_SOPHOMORE, COLLEGE_JUNIOR, COLLEGE_SENIOR
	}

	// fields
	private String name;
	private double gpa;
	private Grade grade;
	private long id;
	private static long count;

	// constructor
	/**
	 * Constructs a student object with a name, gpa, and a grade level
	 * 
	 * @param name
	 *            student's name
	 * @param gpa
	 *            student's gpa
	 * @param grade
	 *            student's grade level (kindergarten - college senior)
	 */
	public Student(String name, double gpa, Grade grade)
	{
		this.name = name;
		this.gpa = gpa;
		this.grade = grade;
		id = ++count;
	}

	/**
	 * Returns id of student, that was privately assigned by class.
	 * 
	 * @return student's id
	 */
	public long getID( )
	{
		return id;
	}

	/**
	 * Returns name of Student
	 * 
	 * @return the name of the student
	 */
	public String getName( )
	{
		return name;
	}

	/**
	 * Returns Student's GPA on a scale of 0.0 to 4.0
	 * 
	 * @return the gpa from 0.0 to 4.0
	 */
	public double getGpa( )
	{
		return gpa;
	}

	/**
	 * The student's grade from 1 - 12
	 * 
	 * @return the grade
	 */
	public Grade getGrade( )
	{
		return grade;
	}

	/**
	 * Displays the object as student name and id number
	 */
	@Override
	public String toString( )
	{
		return String.format("%s %d", name, id);
	}

}
