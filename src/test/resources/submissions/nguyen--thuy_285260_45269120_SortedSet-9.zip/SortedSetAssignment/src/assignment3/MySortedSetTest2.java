/**
 * MySortedSetTest2.java
 * Description:
 * 
 * @author Thuy Nguyen
 *         Feb 3, 2015
 */
package assignment3;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;

import org.junit.Test;

/**
 * This class test the creation of MySortedSet using the constructor
 * that takes in a Comparator.
 * 
 * @author Thuy Nguyen
 *         February 3, 2015
 *
 */
public class MySortedSetTest2
{

	private MySortedSet<Student> studentSet;

	@Test
	public void testComparatorStudent( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				// sort students according to name
				return s1.getName().compareTo(s2.getName());
			}
		});

		studentSet.add(new Student("Andy McNeil", 2.9, Student.Grade.THIRD));
		studentSet.add(new Student("Thuy Nguyen", 3.96,
				Student.Grade.COLLEGE_FRESHMAN));
		studentSet.add(new Student("Jone Smith", 3.25, Student.Grade.ELEVENTH));
		// add duplicate
		studentSet.add(new Student("Andy McNeil", 2.9, Student.Grade.THIRD));
		studentSet.add(new Student("Jone Adams", 3.25, Student.Grade.TENTH));
		studentSet.add(new Student("Amy McNeil", 2.7, Student.Grade.EIGHTH));
		// add duplicate
		studentSet.add(new Student("Andy McNeil", 2.9, Student.Grade.THIRD));

		assertEquals(5, studentSet.size());

		// names of students in sorted order
		String[] names = { "Amy McNeil", "Andy McNeil", "Jone Adams",
				"Jone Smith", "Thuy Nguyen" };

		Iterator<Student> it = studentSet.iterator();

		int index = 0;
		while (it.hasNext())
		{
			// assert that students are in sorted order according to name
			assertEquals(names[index++], it.next().getName());
		}

	}

	@Test
	public void testStudentSetOrderbyGrades( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				// sort by grades
				int comparedGrades = s1.getGrade().compareTo(s2.getGrade());
				if (comparedGrades == 0)
				{
					// if grades are the same, sort by gpa - highest gpa first
					int comparedGpa = Double.compare(s2.getGpa(), s1.getGpa());
					if (comparedGpa == 0)
					{
						// if gpa are the same, sort by id
						return Long.compare(s1.getID(), s2.getID());
					}
					else
					{
						return comparedGpa;
					}
				}
				else
				{
					return comparedGrades;
				}
			}
		});

		studentSet.add(new Student("Thuy Nguyen", 3.96,
				Student.Grade.COLLEGE_JUNIOR));
		studentSet
				.add(new Student("Stacy Nguyen", 3.95, Student.Grade.TWELVETH));
		studentSet
				.add(new Student("Tracy Nguyen", 3.5, Student.Grade.TWELVETH));
		studentSet.add(new Student("Jane Yogi", 3.96,
				Student.Grade.COLLEGE_JUNIOR));
		studentSet.add(new Student("Margo Blue", 2.4, Student.Grade.TWELVETH));
		studentSet
				.add(new Student("Tiny Tim", 3.0, Student.Grade.KINDERGARTEN));
		studentSet.add(new Student("Daffy Duck", 4.0, Student.Grade.NINETH));
		studentSet.add(new Student("Bugs Bunny", 2.74, Student.Grade.FIFTH));
		studentSet.add(new Student("Evil Bunny", 2.75, Student.Grade.FIFTH));

		// students sorted according to grade, gpa, and id
		String[] names = { "Tiny Tim", "Evil Bunny", "Bugs Bunny",
				"Daffy Duck", "Stacy Nguyen", "Tracy Nguyen", "Margo Blue",
				"Thuy Nguyen", "Jane Yogi" };

		Iterator<Student> it = studentSet.iterator();
		int index = 0;
		while (it.hasNext())
		{
			// assert that students are sorted according to grade, gpa, and id
			assertEquals(names[index++], it.next().getName());
		}
	}

	@Test
	public void testAddAll_ExpandSetArray( )
	{
		// see if set capacity can grow to contain all the students after the
		// add all method
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Long.compare(s1.getID(), s2.getID());
			}
		});

		// add 16 students to a list of students
		ArrayList<Student> moreStudents = new ArrayList<>();
		for (int i = 1; i <= 16; i++)
		{
			moreStudents.add(new Student(i + " Student", 3.7,
					Student.Grade.COLLEGE_JUNIOR));
		}

		// add all the students in the list to the set
		studentSet.addAll(moreStudents);
		assertEquals(16, studentSet.size());

		String[] names = { "1 Student", "2 Student", "3 Student", "4 Student",
				"5 Student", "6 Student", "7 Student", "8 Student",
				"9 Student", "10 Student", "11 Student", "12 Student",
				"13 Student", "14 Student", "15 Student", "16 Student" };

		// iterate through the set of students to see if they are in correct
		// order
		// and to see if the array grew dynamically upon adding more students
		// than the initial capacity
		Iterator<Student> it = studentSet.iterator();
		int index = 0;
		while (it.hasNext())
		{
			assertEquals(names[index++], it.next().getName());
		}

		// add more students to see if array grows dynamically the second time
		for (int i = 17; i <= 36; i++)
		{
			studentSet.add(new Student(i + "th Student", 3.4,
					Student.Grade.SEVENTH));
		}

		assertEquals(36, studentSet.size());

	}

	@Test
	public void testRemoveAll( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Long.compare(s1.getID(), s2.getID());
			}
		});

		// add students to list
		ArrayList<Student> students = new ArrayList<>();
		for (int i = 1; i <= 16; i++)
		{
			students.add(new Student(i + " Student", 3.7,
					Student.Grade.COLLEGE_JUNIOR));
		}

		// add list of all students to set
		// see if set is correct size after add all and remove all
		studentSet.addAll(students);
		assertEquals(16, studentSet.size());
		assertTrue(studentSet.removeAll(students));
		assertEquals(0, studentSet.size());
		assertFalse(studentSet.removeAll(students));
		assertEquals(0, studentSet.size());
		assertTrue(studentSet.isEmpty());
	}

	@Test
	public void testRemoveAll_DifferentObjects( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Long.compare(s1.getID(), s2.getID());
			}
		});

		// adds 4 students to the set
		for (int i = 1; i <= 4; i++)
		{
			studentSet.add(new Student(i + " Student", 3.7,
					Student.Grade.TWELVETH));
		}

		// remove non-Student objects from studentSet
		assertFalse(studentSet.remove("Not a student"));
		ArrayList<Integer> numbers = new ArrayList<Integer>()
		{
			{
				add(1);
				add(2);
				add(3);
				add(4);
			}
		};

		// see if non student objects can be removed from set
		assertFalse(studentSet.removeAll(numbers));
		assertFalse(studentSet.contains(2));
		assertFalse(studentSet.containsAll(numbers));
		assertEquals(4, studentSet.size());

		// remove student objects from studentSet
		Student newKid = new Student("New Kid", 3.7, Student.Grade.FOURTH);
		studentSet.add(newKid);
		assertEquals(5, studentSet.size());
		assertTrue(studentSet.contains(newKid));
		assertTrue(studentSet.remove(newKid));
		assertEquals(4, studentSet.size());
	}

	@Test
	public void testAddAll_Polymorphism( )
	{
		List<Girl> girls = new ArrayList<Girl>();
		girls.add(new Girl("ZeZe"));
		girls.add(new Girl("Jessica"));
		girls.add(new Girl("Yami"));

		// add List<Girl> of girls to a MySortedSet<Person>
		MySortedSet<Person> personSet = new MySortedSet<>();
		personSet.addAll(girls);

		assertEquals(3, personSet.size());
		assertEquals("Jessica", personSet.first().getName());
		assertEquals("ZeZe", personSet.last().getName());

		personSet.add(new Girl("Amy"));
		assertEquals("Amy", personSet.first().getName());
	}

	@Test
	public void testPolymorphism( )
	{

		Girl g1 = new Girl("ZeZe");
		Girl g2 = new Girl("Jessica");
		Girl g3 = new Girl("Yami");
		Girl g4 = new Girl("ReallyLongName");

		List<Girl> girls = new ArrayList<Girl>(Arrays.asList(g1, g2, g3, g4));

		MySortedSet<Person> personSet = new MySortedSet<Person>(
				new Comparator<Person>()
				{
					@Override
					public int compare(Person p1, Person p2)
					{
						// instead of Person's natural ordering, we order Person
						// by name length using Comparator
						return Integer.compare(p1.getName().length(), p2
								.getName().length());
					}
				});

		assertTrue(personSet.add(g1));
		assertFalse(personSet.add(g3));
		assertTrue(personSet.contains(g3)); // g3 is in the personSet because
											// g3's name length is the same as
											// g1's name length. And the set
											// contains equal things.

		personSet.addAll(girls);

		assertEquals(3, personSet.size());
		assertEquals("ZeZe", personSet.first().getName());
		assertEquals("ReallyLongName", personSet.last().getName());
		assertTrue(personSet.remove(g2));

		Person p1 = new Person("I");
		personSet.add(p1);
		assertEquals("I", personSet.first().getName());
	}

	@Test
	public void testAddRemoveNonComparables( )
	{
		// create a set of java.util.Scanner objects - does not implement
		// Comparable<Scanner>
		// set should not add non comparables.
		MySortedSet<Scanner> scannerSet = new MySortedSet<Scanner>();
		assertFalse(scannerSet.add(new Scanner(System.in)));
		assertEquals(0, scannerSet.size());
		assertTrue(scannerSet.isEmpty());

		// try to add a list of scanners to the scannerSet - scanners are non
		// comparables so they should not be added.
		Scanner scan = new Scanner("I'm not a Comparable");
		ArrayList<Scanner> scanners = new ArrayList<Scanner>()
		{
			{
				add(new Scanner(System.in));
				add(new Scanner("Hi there"));
				add(new Scanner("Computer Science is Cool!"));
			}
		};

		assertFalse(scannerSet.addAll(scanners));
		assertEquals(0, scannerSet.size());
		assertTrue(scannerSet.isEmpty());
		assertFalse(scannerSet.contains(scan));
		assertFalse(scannerSet.removeAll(scanners));

	}

	@Test
	public void testGetComparator( )
	{
		studentSet = new MySortedSet<Student>();
		Comparator<? super Student> comparator = studentSet.comparator();
		assertEquals(null, comparator);

		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Double.compare(s2.getGpa(), s1.getGpa());
			}
		});

		comparator = studentSet.comparator();
		Student s1 = new Student("Bad Student", 1.7, Student.Grade.TWELVETH);
		Student s2 = new Student("Good Student", 4.0, Student.Grade.TWELVETH);
		int compareGpa = Double.compare(s2.getGpa(), s1.getGpa());
		assertEquals(compareGpa, comparator.compare(s1, s2));
	}

	@Test(expected = NoSuchElementException.class)
	public void testFirstNoSuchElement( )
	{
		studentSet = new MySortedSet<Student>();
		studentSet.first();
	}

	@Test(expected = NoSuchElementException.class)
	public void testLastNoSuchElement( )
	{
		studentSet = new MySortedSet<Student>();
		studentSet.last();
	}

	@Test(expected = NoSuchElementException.class)
	public void testFirstElementException( )
	{
		studentSet = new MySortedSet<Student>();
		// cannot add a new student because Student is not a comparable.
		// can only add a new student if MySortedSet was created with a
		// Comparator<Student>
		studentSet.add(new Student("Dr. Phil", 3.8, Student.Grade.TENTH));
		studentSet.first();
	}

	@Test
	public void testFirstElement( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Long.compare(s1.getID(), s2.getID());
			}
		});

		studentSet.add(new Student("Dr. Phil", 3.8, Student.Grade.TENTH));
		Student first = studentSet.first();
		assertEquals("Dr. Phil", first.getName());
		assertEquals(3.8, first.getGpa(), .0001);
		assertEquals(Student.Grade.TENTH, first.getGrade());

		Student last = studentSet.last();
		assertEquals(first, last);
	}

	@Test
	public void testLastElement( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				// sort the students from highest gpa to lowest
				// if gpa is the same, then sort according to id
				int comparedGpa = Double.compare(s2.getGpa(), s1.getGpa());
				if (comparedGpa == 0)
				{
					return Long.compare(s1.getID(), s2.getID());
				}
				else
				{
					return comparedGpa;
				}
			}
		});

		studentSet.add(new Student("Bad One", 1.5, Student.Grade.FIFTH));
		studentSet.add(new Student("Bad Two", 1.5, Student.Grade.FOURTH));
		studentSet.add(new Student("Dr. Phil", 3.8, Student.Grade.TENTH));
		studentSet.add(new Student("Sherlock Holmes", 3.9,
				Student.Grade.ELEVENTH));
		studentSet.add(new Student("Thuy Nguyen", 3.9,
				Student.Grade.COLLEGE_FRESHMAN));
		studentSet.add(new Student("Ophra", 3.8, Student.Grade.NINETH));

		Student last = studentSet.last();
		assertEquals("Bad Two", last.getName());
		assertEquals(1.5, last.getGpa(), .0001);
		assertEquals(Student.Grade.FOURTH, last.getGrade());

		Student first = studentSet.first();
		assertEquals("Sherlock Holmes", first.getName());

	}

	@Test
	public void testDuplicates( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return s1.getName().compareTo(s2.getName());
			}
		});

		Student s1 = new Student("S1", 3.5, Student.Grade.COLLEGE_FRESHMAN);
		Student s2 = new Student("S2", 3.5, Student.Grade.COLLEGE_FRESHMAN);
		Student s3 = new Student("S3", 3.5, Student.Grade.COLLEGE_FRESHMAN);

		studentSet.add(s1);
		studentSet.add(s2);
		studentSet.add(s3);

		assertEquals(3, studentSet.size());

		// add duplicates
		ArrayList<Student> duplicates = new ArrayList<>(Arrays.asList(s1, s2,
				s3));
		assertFalse(studentSet.addAll(duplicates));
		assertEquals(3, studentSet.size());

		// add duplicates and a new student
		Student s4 = new Student("S4", 3.5, Student.Grade.COLLEGE_FRESHMAN);
		duplicates.add(s4);
		assertTrue(studentSet.addAll(duplicates));
		assertEquals(4, studentSet.size());

	}

	@Test
	public void testIterator( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Long.compare(s1.getID(), s2.getID());
			}
		});

		for (int i = 1; i <= 4; i++)
		{
			studentSet.add(new Student("S" + i, 3.5, Student.Grade.FOURTH));
		}

		Iterator<Student> it = studentSet.iterator();
		// iterates to last element
		it.next();
		it.next();
		it.next();
		it.next();

		String[] names = { "S1", "S2", "S3", "S4" };

		// removes from last student to first student
		for (int i = 3; i >= 0; i--)
		{
			assertEquals(names[i], studentSet.last().getName());
			it.remove();
		}
	}

	@Test(expected = NoSuchElementException.class)
	public void testIteratorNextException( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Long.compare(s1.getID(), s2.getID());
			}
		});

		for (int i = 1; i <= 4; i++)
		{
			studentSet.add(new Student("S" + i, 3.5, Student.Grade.FOURTH));
		}

		Iterator<Student> it = studentSet.iterator();
		// iterates to last element
		it.next();
		it.next();
		it.next();
		it.next();

		// remove the last element
		it.remove();

		// try to get a non-existing element
		it.next();
	}

	@Test(expected = IllegalStateException.class)
	public void testIteratorRemoveException( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Long.compare(s1.getID(), s2.getID());
			}
		});

		for (int i = 1; i <= 4; i++)
		{
			studentSet.add(new Student("S" + i, 3.5, Student.Grade.FOURTH));
		}

		Iterator<Student> it = studentSet.iterator();
		// iterates to the last element
		it.next();
		it.next();
		it.next();
		it.next();

		// remove more elements than what we have
		for (int i = 0; i < 5; i++)
		{
			it.remove();
		}
	}

	@Test
	public void testIteratorRemove_ExceptForLastElement( )
	{
		studentSet = new MySortedSet<Student>(new Comparator<Student>()
		{
			@Override
			public int compare(Student s1, Student s2)
			{
				return Long.compare(s1.getID(), s2.getID());
			}
		});

		for (int i = 1; i <= 4; i++)
		{
			studentSet.add(new Student("S" + i, 3.5, Student.Grade.FOURTH));
		}

		Iterator<Student> it = studentSet.iterator();
		// iterates to the penultimate element
		it.next();
		it.next();
		it.next();

		// remove all but the last element
		it.remove();
		it.remove();
		it.remove();

		// see if last element is last student
		assertEquals("S4", studentSet.first().getName());
		assertEquals("S4", studentSet.last().getName());
		assertTrue(it.hasNext());
		assertEquals("S4", it.next().getName());
		assertFalse(it.hasNext());
		assertFalse(studentSet.isEmpty());
		assertEquals(1, studentSet.size());
	}

	@Test(expected = ConcurrentModificationException.class)
	public void testIterator_ConcurrentModificationNext()
	{
		MySortedSet<String> set = new MySortedSet<>();
		set.add("Hi");
		set.add("Milk");
		set.add("Mustache");
		
		Iterator<String> it = set.iterator();
		assertEquals("Hi", it.next());
		set.clear();
		it.next();
		
	}
	
	@Test(expected = ConcurrentModificationException.class)
	public void testIterator_ConcurrentModificationRemove()
	{
		MySortedSet<String> set = new MySortedSet<>();
		set.add("Hi");
		set.add("Milk");
		set.add("Mustache");
		
		Iterator<String> it = set.iterator();
		assertEquals("Hi", it.next());
		set.clear();
		it.remove();
	}
}
