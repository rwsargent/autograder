package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * MySortedSet represents a container that holds Comparable objects
 * or objects that are compared by a Comparator.
 * 
 * MySortedSet supports operations such as add, remove, contains,
 * toArray, iterator, first, last, and isEmpty. The typical methods
 * found in the java.util.Collection interface.
 * 
 * A MySortedSet that implements SortedSet and provides a total ordering on its
 * elements. The elements are ordered using their natural ordering, or by a
 * Comparator provided at sorted set creation time. Thus, all elements inserted
 * into a sorted set must implement the Comparable interface or be accepted by
 * the specified Comparator. The set's iterator will traverse the set in
 * ascending element order.
 * 
 * @author Thuy Nguyen and Fred Javalera
 *         February 3, 2015
 *
 * @param <E>
 *            Generic type
 */
public class MySortedSet<E> implements SortedSet<E>
{
	// fields
	private E[] array;
	private final int INITIAL_CAPACITY = 15;
	private int capacity = INITIAL_CAPACITY;
	private int size = 0;
	private Comparator<? super E> comparator;

	// constructors

	/**
	 * Constructs a MySortedSet object
	 */
	public MySortedSet( )
	{
		array = (E[]) new Object[capacity];
	}

	/**
	 * Constructs a MySortedSet object that takes in a specific comparator.
	 */
	public MySortedSet(Comparator<? super E> c)
	{
		array = (E[]) new Object[capacity];
		comparator = c;
	}

	// public methods

	/**
	 * Returns this sets comparator.
	 * 
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator( )
	{
		return comparator;
	}

	/**
	 * Returns first element in set.
	 * 
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first( ) throws NoSuchElementException
	{
		if (size == 0)
			throw new NoSuchElementException();
		return array[0];
	}

	/**
	 * Returns last element found in set.
	 * 
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last( ) throws NoSuchElementException
	{
		if (size == 0)
			throw new NoSuchElementException();
		return array[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o)
	{
		if (!canAdd(o))
			return false;
		else
			addE(o);
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c)
	{
		boolean changed = false;
		for (E o : c)
		{
			if (add(o))
			{
				changed = true;
			}
		}

		return changed;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear( )
	{
		array = (E[]) new Object[15];
		size = 0;
		capacity = INITIAL_CAPACITY;
	}

	/**
	 * Returns true if set contains o. False, otherwise.
	 * 
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o)
	{
		if (comparator == null)
		{
			if (!isComparableO(o))
				return false;
		}

		return binarySearch(o) != -1;

	}

	/**
	 * Returns true if this set contains all of the elements of collection c.
	 * False, otherwise.
	 * 
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c)
	{
		for (Object o : c)
		{
			if (!contains(o))
				return false;
		}
		return true;
	}

	/**
	 * Returns true if set is empty. False, otherwise.
	 * 
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty( )
	{
		return size == 0;
	}

	/**
	 * Returns this sets iterator.
	 * 
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator( )
	{
		// SetIterator object is made with private inner class
		return new SetIterator();
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public boolean remove(Object o)
	{
		if (comparator == null)
		{
			if (!isComparableO(o))
				return false;
		}

		int index = binarySearch(o);

		if (index == -1)
		{
			return false;
		}

		removeE(index);
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c)
	{
		boolean changed = false;
		// see if all the elements are in the array first
		for (Object o : c)
		{
			if (remove(o))
			{
				changed = true;
			}
		}

		return changed;
	}

	/**
	 * Returns number of elements in this set.
	 * 
	 * @return the number of elements in this set
	 */
	@Override
	public int size( )
	{
		return size;
	}

	/**
	 * Returns the set as an array
	 * 
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray( )
	{
		return array;
	}

	// private helper methods

	/**
	 * Binary search for element and returns element's index.
	 * 
	 * @param o
	 *            element to search for
	 * @return index of element in array if found, -1 if not found
	 */
	private int binarySearch(Object o)
	{
		int lower = 0; // first element index of array
		int upper = size - 1; // last element index of array
		int middle = (upper + lower) / 2; // middle index between lower and
											// upper bound
		int compared = -1;

		try
		{
			while (lower <= upper)
			{
				if (comparator != null)
				{
					// compare the elements based on the comparator passed into
					// the constructor
					compared = comparator.compare((E) o, array[middle]);
				}
				else
				{
					// compare the elements based on their natural ordering
					Comparable<E> compO = (Comparable<E>) o;

					compared = compO.compareTo(array[middle]);
				}

				// if compared is less than 0, then our object is smaller than
				// middle so search in the lower half
				if (compared < 0)
				{
					upper = middle - 1;
				}
				// if compared is greater than 0, then our object is bigger than
				// middle, so search in the upper half.
				else if (compared > 0)
				{
					lower = middle + 1;
				}
				else
				{
					// found the object, return its array index
					return middle;

				}

				// search in the middle of the upper and lower half for the
				// object
				middle = (upper + lower) / 2;
			}

		}
		catch (Exception e)
		{
			return -1;
		}

		// return -1 if object is not found
		return -1;

	}

	/**
	 * Checks to see if the object is a Comparable
	 * 
	 * @param object
	 *            that is checked as a Comparable
	 * @return true if object is a comparable, false otherwise
	 */
	private boolean isComparableO(Object o)
	{
		try
		{
			return isComparableE((E) o);
		}
		catch (Exception e)
		{
			return false;
		}
	}

	/**
	 * Checks to see if element can be casted as a Comparable
	 * 
	 * @param o
	 *            element to be checked as being a Comparable
	 * @return true if the element does implement the Comparable interface,
	 *         false othewise
	 */
	private boolean isComparableE(E o)
	{
		try
		{
			Comparable<E> compO = (Comparable<E>) o;
		}
		catch (ClassCastException e)
		{
			return false;
		}

		return true;

	}

	/**
	 * Checks to see if we can add the element - it must be a comparable
	 * or there must be a comparator, and it is not a duplicate of another
	 * element
	 * already in our set.
	 * 
	 * @param o
	 *            the element being checked for whether it can be added to the
	 *            set
	 * @return true if the element can be added, false otherwise
	 */
	private boolean canAdd(E o)
	{
		// if there is no comparator, then the objects must implement Comparable
		if (comparator == null)
		{
			if (!isComparableE(o))
				return false;
		}

		// if there is no duplicates then add and return true
		// if there are duplicates, don't add and return false;
		if (binarySearch(o) != -1)
		{
			return false;
		}

		return true;
	}

	/**
	 * Adds an element to the set and increases size of set
	 * Set grows dynamically and orders the element accordingly.
	 * 
	 * @param o
	 *            the element added to the set
	 */
	private void addE(E o)
	{
		size++;
		ensureCapacity();
		// do insertion sort
		insertionSort(o);
	}

	/**
	 * Removes element at specified index.
	 * 
	 * @param index
	 *            of element to be removed
	 */
	private void removeE(int index)
	{
		array[index] = null;

		// shift array
		for (int i = index; i < size - 1; i++)
		{
			array[i] = array[i + 1];
			array[i + 1] = null;
		}

		size--;
	}

	/**
	 * Does insertion sort on each new element that was just inserted
	 * into the set
	 * 
	 * @param o
	 *            the element inserted into the set and needing to be sorted
	 */
	private void insertionSort(E o)
	{
		array[size - 1] = o; // added object to end of array

		E tempO = o;

		// start with object on the left of the element that was just inserted
		// go backwards to beginning of the array
		for (int i = size - 1; i > 0; i--)
		{
			// compare the current element with the one on the left
			// compare with either a comparator or the natural ordering of
			// the elements
			int compared = 0;
			if (comparator != null)
			{
				compared = comparator.compare(tempO, array[i - 1]);
			}
			else
			{
				Comparable<E> compO = (Comparable<E>) tempO;
				compared = compO.compareTo(array[i - 1]);
			}

			// if the current element is bigger than or equal to the
			// neighbor on the left, then break out of the loop. Sorting
			// completed.
			if (compared >= 0)
			{
				break;
			}
			// else if the current element is smaller than its left neighbor,
			// then swap them, and continue toward beginning of array,
			// repeating the comparison and swapping necessary until
			// the array has been sorted.
			else if (compared < 0)
			{
				E temp = array[i - 1];
				array[i - 1] = tempO;
				array[i] = temp;
			}

			tempO = array[i - 1];
		}
	}

	/**
	 * Grows the backing array twice as big when the number of
	 * elements reaches the capacity of the array. Copies
	 * every element of the current smaller array over to the new
	 * bigger array.
	 */
	private void ensureCapacity( )
	{
		if (size > capacity)
		{
			// double size of array
			E[] newArray = (E[]) new Object[capacity * 2];
			capacity = capacity * 2;
			for (int i = 0; i < size - 1; i++)
			{
				newArray[i] = array[i];
			}
			array = newArray;
		}
	}

	/**
	 * Private inner class that implements the Iterator interface
	 * in order to traverse our backing array. This class
	 * supports functions next, hasNext, and remove,
	 * methods that Client classes can use to traverse a MySortedSet.
	 *
	 */
	private class SetIterator implements Iterator<E>
	{

		// index of the current iteration in the array
		private int currentIndex;
		
		// current size of the array to keep track of array modifications
		// outside of SetIterator class
		private int currentSize = size;

		/**
		 * Returns true if there is a next element during the iteration,
		 * false otherwise
		 */
		@Override
		public boolean hasNext( )
		{
			return currentIndex < size;
		}

		/**
		 * Returns the memory location of the next element
		 * during the iteration
		 * 
		 * @throws NoSuchElementException
		 *             if there is no element
		 *             to traverse over during iteration
		 *             
		 * @throws ConcurrentModificationException
		 *             if the MySortedSet
		 *             array was modified outside of SetIterator class
		 */
		@Override
		public E next( )
		{
			if (arrayModified())
			{
				throw new ConcurrentModificationException();
			}

			if (hasNext())
			{
				return array[currentIndex++];
			}
			else
			{
				throw new NoSuchElementException("No next element");
			}
		}

		/**
		 * Mutates the backing array by removing the current element
		 * from it during iteration.
		 * 
		 * @throws IllegalStateException
		 *             if there is no current element for removal
		 *             during the iteration of the array
		 * 
		 * @throws ConcurrentModificationException
		 *             if the MySortedSet
		 *             array was modified outside of SetIterator class
		 */
		@Override
		public void remove( )
		{
			if (arrayModified())
			{
				throw new ConcurrentModificationException();
			}

			if (!(currentIndex <= 0))
			{
				removeE(currentIndex - 1);
				currentIndex--;
				currentSize--;
			}
			else
			{
				throw new IllegalStateException();
			}

		}

		/**
		 * Returns true if the MySortedSet array has bee modified - such
		 * as the .remove() and .clear() methods were called on the set.
		 * 
		 * @return true if the underlying array in MySortedSet has
		 *         been modified outside of the SetIterator class, false
		 *         otherwise.
		 */
		private boolean arrayModified( )
		{
			if (currentSize != size)
			{
				currentSize = -10; // to make sure that currentSize will never
									// equal array size again, so iterator can't
									// be used after array has been modified
				return true;
			}
			else
			{
				return false;
			}
		}
	}

}
