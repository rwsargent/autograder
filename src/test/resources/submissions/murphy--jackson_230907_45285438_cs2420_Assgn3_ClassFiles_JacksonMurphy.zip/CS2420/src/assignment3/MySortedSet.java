package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Represents a generic collection of objects. Implements the SortedSet
 * interface (defined in this package).
 * 
 * @author Jacob Luke and Jackson Murphy
 *
 */
public class MySortedSet<E> implements SortedSet<E> {

	// Use a basic array for the set's internal representation
	private E[] array;

	// Keep track of the array's effective size
	private int size;

	// The comparator for the set, if one was given in the constructor. If the
	// set is created by a constructor that doesn't provide a comparator, then
	// this will be null.
	private Comparator<? super E> comparator;

	/**
	 * Creates a new MySortedSet. Uses Comparable for ordering objects
	 */
	public MySortedSet() {

		this.size = 0; // the set's size is initially zero b/c it has no items
		this.array = (E[]) (new Object[8]); // creates a new array to store the
		// objects. Initialized to store 8 to avoid incessant doubling
		this.comparator = null; // objects will be sorted with Comparable
								// instead of a comparator
	}

	/**
	 * Creates a new MySortedSet, given a Comparator object. The MySortedSet
	 * will use this Comparator for ordering the set.
	 */
	public MySortedSet(Comparator<? super E> comparator) {

		this.size = 0; // the size will be zero when it's initialized
		this.array = (E[]) (new Object[8]); // creates a new array to store the
		// objects. Initialized to store 8 to avoid lots of initial doubling.
		this.comparator = comparator; // the provided comparator will be used to
										// sort the set's objects
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		if (this.comparator == null) // if this set uses Comparable, then this
										// should already be null
			return null;

		return this.comparator; // this should be defined from the constructor
								// if we are using comparator
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {

		if (array[0] == null) // in an empty set, the first element is null
			throw new NoSuchElementException();

		return array[0]; // the set isn't empty. Return the first element
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {

		if (array[0] == null) // in an empty set, the first element is null
			throw new NoSuchElementException();

		return array[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element,
	 *         false if the set already has it or if the object is null
	 */
	public boolean add(E o) {

		if (o == null)
			return false;

		if (array.length == size) {
			// If the array is filled up, double its size
			E[] temp = Arrays.copyOf(array, array.length * 2);
			array = temp; // point the array to this new doubled temp array
		}

		// This will perform the binary search

		int low = 0;
		int high = size - 1;
		int mid;

		// Find the correct insertion position.
		while (low <= high) {

			mid = (low + high) / 2;

			if (array[mid] == null) { // if mid is null, we know mid is at the
										// end of the list and we should insert
										// o here.
				array[mid] = o;
				size++;
				return true;
			}

			if (comparator == null)// if the comparator is null, then we will be
									// using the object's comparable method
			{
				if (o instanceof Comparable) { // makes sure that the object
												// that's being added actually
												// has a comparable method
					if (((Comparable) o).compareTo(array[mid]) == 0)// if the
																	// objects
																	// are the
																	// same,
																	// then we
																	// don't
																	// want to
																	// add it
						return false;

					if (((Comparable) o).compareTo(array[mid]) < 0)// if the
																	// object
																	// should be
																	// in the
																	// first
																	// half, we
																	// adjust
																	// accordingly
						high = mid - 1;

					if (((Comparable) o).compareTo(array[mid]) > 0)// if the
																	// object
																	// should be
																	// in the
																	// second
																	// half, we
																	// adjust
																	// accordingly
						low = mid + 1;
				}
			} else// we'll be using the comparator
			{
				if (comparator.compare((E) o, (E) array[mid]) == 0)// if the
																	// objects
																	// are the
																	// same,
																	// then we
																	// don't
																	// want to
																	// add it
					return false;
				if (comparator.compare((E) o, (E) array[mid]) < 0)// if the
																	// object
																	// should be
																	// in the
																	// first
																	// half, we
																	// adjust
																	// accordingly
					high = mid - 1;
				if (comparator.compare((E) o, (E) array[mid]) > 0)// if the
																	// object
																	// should be
																	// in the
																	// second
																	// half, we
																	// adjust
																	// accordingly
					low = mid + 1;
			}
		}

		// Shift all the elements to the right of the insertion point one index
		// to the right
		for (int i = size; i > low; i--) {
			array[i] = array[i - 1];
		}

		// Add the input item in its correct position, and return true
		array[low] = o;
		size++;
		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call, false if
	 *         otherwise
	 */
	@Override
	public boolean addAll(Collection c) {

		// Store the size of the set before trying to add the collection.
		int initialSize = this.size();

		// Use a for-each loop to add each item of the collection to our set
		for (Object thing : c) {
			E newthing = (E) thing; // type cast it to the array type
			this.add(newthing);
		}

		// Check if any items from the collection were added to our set, and
		// return the appropriate boolean.
		if (this.size() != initialSize)
			return true;
		else
			return false; // no items were added to the set
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		// Create a new empty array of size 8, point the old array to this new
		// one, and set size to 0
		E[] newArray = (E[]) (new Object[8]);
		this.array = newArray;
		this.size = 0;

	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element. False if it does
	 *         not
	 */
	@Override
	public boolean contains(Object o) {

		// If the set is empty, it doesn't contain o
		if (this.size == 0) {
			return false;
		}

		// If the set isn't empty, proceed with the binary search algorithm

		// Use low, mid, and high indices to narrow in on the search item.
		int low = 0;
		int high = size - 1;
		int mid;

		// The algorithm ends when high's index is less than low's
		while (low <= high) {

			mid = (low + high) / 2;

			if (comparator == null)// if the comparator is null, then we will be
									// using the object's comparable method
			{
				if (o instanceof Comparable) { // makes sure that the object
												// that's being added actually
												// has a comparable method
					if (((Comparable) o).compareTo(array[mid]) == 0)// if the
																	// objects
																	// are the
																	// same,
																	// then we
																	// don't
																	// want to
																	// add it
						return true;

					if (((Comparable) o).compareTo(array[mid]) < 0)// if the
																	// object
																	// should be
																	// in the
																	// first
																	// half, we
																	// adjust
																	// accordingly
						high = mid - 1;

					if (((Comparable) o).compareTo(array[mid]) > 0)// if the
																	// object
																	// should be
																	// in the
																	// second
																	// half, we
																	// adjust
																	// accordingly
						low = mid + 1;
				}
			} else// we'll be using the comparator
			{
				if (comparator.compare((E) o, (E) array[mid]) == 0)// if the
																	// objects
																	// are the
																	// same,
																	// then we
																	// don't
																	// want to
																	// add it
					return true;
				if (comparator.compare((E) o, (E) array[mid]) < 0)// if the
																	// object
																	// should be
																	// in the
																	// first
																	// half, we
																	// adjust
																	// accordingly
					high = mid - 1;
				if (comparator.compare((E) o, (E) array[mid]) > 0)// if the
																	// object
																	// should be
																	// in the
																	// second
																	// half, we
																	// adjust
																	// accordingly
					low = mid + 1;
			}
		}

		return false; // The object o is not found in this set.
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection c) {
		// Use a for-each loop to look at each item of the collection
		for (Object thing : c) {
			if (!this.contains(thing))
				return false;
		}

		return true; // every item in the collection was found in our set
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (this.size == 0)
			return true;
		else
			return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {

		// Create a MySortedSetIterator, passing this set as the parameter.
		// MySortedSetIterator is a nested class inside this file
		return new MySortedSetIterator<E>(this);
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {

		E obj = (E) o;

		// If the set is empty, it doesn't contain o
		if (this.size == 0) {
			return false;
		}

		// If the set isn't empty, proceed with the binary search algorithm

		// Use low, mid, and high indices to narrow in on the search item.
		int low = 0;
		int high = size - 1;
		int mid = (low + high) / 2;

		boolean contains = false; // this will tell us if the object is in the
									// set

		// We use a try block b/c an exception may be thrown when casting o to
		// type E
		try {
			// The algorithm ends when high is lower than low
			while (low <= high) {

				mid = (low + high) / 2;

				if (comparator == null)// if the comparator is null, then we
										// will be using the object's comparable
										// method
				{
					if (obj instanceof Comparable) { // makes sure that the
														// object that's being
														// added actually has a
														// comparable method

						// If the objects are the same, our search is done
						if (((Comparable) obj).compareTo(array[mid]) == 0) {
							contains = true; // we've found the object we need
							break;
						}

						if (((Comparable) obj).compareTo(array[mid]) < 0)// if
																			// the
																			// object
																			// should
																			// be
																			// in
																			// the
																			// first
																			// half,
																			// we
																			// adjust
																			// accordingly
							high = mid - 1;

						if (((Comparable) obj).compareTo(array[mid]) > 0)// if
																			// the
																			// object
																			// should
																			// be
																			// in
																			// the
																			// second
																			// half,
																			// we
																			// adjust
																			// accordingly
							low = mid + 1;
					}
				} else// if it's not null, we'll be using the comparator
				{
					// If the objects are the same, our search is done
					if (comparator.compare((E) obj, (E) array[mid]) == 0) {
						contains = true; // we've found the object we need
						break;
					}
					if (comparator.compare((E) obj, (E) array[mid]) < 0)// if
																		// the
																		// object
																		// should
																		// be in
																		// the
																		// first
																		// half,
																		// we
																		// adjust
																		// accordingly
						high = mid - 1;
					if (comparator.compare((E) obj, (E) array[mid]) > 0)// if
																		// the
																		// object
																		// should
																		// be in
																		// the
																		// second
																		// half,
																		// we
																		// adjust
																		// accordingly
						low = mid + 1;
				}
			}

			if (contains == false)
				return false; // The object o is not found in this set.

			// removes the given entry and shifts elements over to close the gap
			for (int i = mid + 1; i < size; i++) {
				this.array[i - 1] = this.array[i];
			}
			this.array[size - 1] = null;
			size--; // our set is now one item smaller

			return true;
		}

		catch (ClassCastException e) {
			return false; // Object o is not of type E
		}
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection c) {

		int initialSize = this.size;

		// Use a for-each loop to remove each item of the collection
		for (Object thing : c) {
			this.remove(thing);
		}

		if (this.size == initialSize)// if the size is the same then it hasn't
										// changed
			return false;

		return true; // every item in the collection was found in our set
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {

		return this.size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order. If the size is zero, return null
	 */
	@Override
	public Object[] toArray() {

		if (size == 0)
			return null;

		return Arrays.copyOf(this.array, size); // Does not include the
												// nulls at the end of the
												// array.
	}

	/**
	 * An equals method. This is useful for testing the class.
	 * 
	 * @param set
	 *            -- the MySortedSet object that we'll compare with "this"
	 *            object
	 * @returns true if the sets contain the same items added in the same order.
	 *          False otherwise.
	 */
	public boolean equals(MySortedSet<E> set) {
		if (this.size() != set.size()) // They are not equal if they don't have
										// the same size
			return false;

		for (int i = 0; i < this.size; i++) { // Checks to see if every element
												// in the array is the same
			if (set.array[i].equals(this.array[i]) == false)
				return false;
		}

		return true; // if it makes it to this point, then everything should be
						// equal
	}
}

/**
 * A nested class for an Iterator specific to a MySortedSet
 * 
 * @author Jacob Luke and Jackson Murphy
 *
 * @param <E>
 */
class MySortedSetIterator<E> implements Iterator<E> {

	// An iterator has a copy of its set's array. And it has a pointer for
	// keeping track of its position in the set
	Object[] iteratorArray;
	int pointer;
	MySortedSet<E> set;

	public MySortedSetIterator(MySortedSet<E> set) {
		iteratorArray = set.toArray();
		pointer = 0; // the iterator is initially at the beginning of the set
		this.set = set;
	}

	/**
	 * Returns true if there are any elements remaining to be iterated through.
	 * Returns false otherwise.
	 */
	@Override
	public boolean hasNext() {
		return pointer < iteratorArray.length;
	}

	/**
	 * Returns the next element in the collection.
	 * 
	 * @throws NoSuchElementException
	 *             if hasNext() is false
	 * 
	 */
	@Override
	public E next() {

		// checks to see if there is a next object
		if (pointer == iteratorArray.length)
			throw new NoSuchElementException("The iterator SHALL NOT PASS!"); // The
																				// iterator
																				// has
																				// reached
																				// the
																				// end
																				// of
																				// the
																				// collection

		return (E) iteratorArray[pointer++]; // return the element and increment
												// the
												// pointer
	}

	/**
	 * Removes the element just before the iterator from the collection
	 */
	@Override
	public void remove() {
		// Do nothing if next() has never been called
		if (pointer == 0)
			return;

		// Use the remove() method defined in MySortedSet
		Object item = iteratorArray[pointer - 1];
		set.remove(item);
		pointer--;
	}

}
