package assignment3;

import java.util.Comparator;
/**
 * We created this class so we could have a comparator to test our MySortedSet class
 * 
 * @author Jacob Luke and Jackson Murphy
 *
 */
public class ComparatorStringLength implements Comparator<String> {
	
	/**
	 * returns -1 if lhs is shorter in length than rhs
	 * returns 1 if lhs is longer in length than rhs
	 * 
	 * if they are the same length, it will sort alphabetically
	 * 
	 */
	@Override
	public int compare(String lhs, String rhs) 
	{		
		if (lhs.length() == rhs.length())//if they are the same length, it will sort alphabetically
			return lhs.compareTo(rhs);
			
		return lhs.length() - rhs.length();
	}
}
