package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.Test;

/**
 * Tests the classes in the assignment3 package.
 * 
 * @author Jacob Luke and Jackson Murphy
 *
 */
public class Assignment3Tests {

	/// MySortedSet Tests


	/**
	 * Tests the comparator method
	 */
	@Test
	public void comparatorTest(){
		
		ComparatorStringLength comparator = new ComparatorStringLength(); //creates a comparator
		
		MySortedSet<String> set1 = new MySortedSet<String>(); //This is not provided with a comparator
		MySortedSet<String> set2 = new MySortedSet<String>(comparator); //constructs a set with a comparator
		
		
		assertEquals(null, set1.comparator());
		assertEquals(comparator, set2.comparator());
	} 
	
	
	/**
	 * Checks whether the add() method works if comparables are being used.
	 */
	@Test
	public void addComparableTests() {

		// Test #1: Add an object to a full array.

		// Create a new MySortedSet
		MySortedSet<String> set = new MySortedSet<String>();
		set.add("a");
		set.add("b");
		set.add("c");
		set.add("d");
		set.add("t"); //this makes sure that the array will sort as it adds
		set.add("e");
		set.add("f");
		set.add("g"); // Initial array size is 8.
		assertEquals(true, set.add("h")); // To add the ninth item, the array must be expanded.


		// Test #2: Add an object to the set where the set already contains said object.

		assertEquals(false, set.add("c"));

		// Test #3: Adding a null object to the set should return false

		assertEquals(false, set.add(null));

		// Test # 4: Make sure add() works for various Comparable classes
		MySortedSet<Integer> numSet = new MySortedSet<Integer>();

		numSet.add(4);
		numSet.add(10);
		numSet.add(3);
		numSet.add(20);
		numSet.add(99);
		numSet.add(30);
		numSet.add(22);
		numSet.add(44);
		numSet.add(11); // Array should be doubled at this step.
		numSet.add(-20);
		numSet.add(33);

		assertEquals(-20, numSet.toArray()[0]);
		assertEquals(99, numSet.toArray()[10]);

	}


	/**
	 * Checks whether the add() method works if comparators are used.
	 */
	@Test
	public void addComparatorTests() {

		// Test #1: Add an object to a full array.
		
			// Create a new set using the comparator constructor
			ComparatorStringLength comparator = new ComparatorStringLength();
			MySortedSet<String> stringSet = new MySortedSet<String>(comparator);
			
			stringSet.add("Bob Johnson");
			stringSet.add("I think therefore I am");
			stringSet.add("6");
			stringSet.add("Hello.");
			stringSet.add("If you wish to make an apple pie from scratch, you must first invent the universe");
			stringSet.add("Nintendo 64"); //This should be the same length as Bob Johnson, so it should sort it alphabetically
			stringSet.add("Hello world.");
			stringSet.add("Beef stew");
			stringSet.add("The array should expand when I add this.");
			
			assertEquals("6", stringSet.toArray()[0]);
			assertEquals("If you wish to make an apple pie from scratch, you must first invent the universe", stringSet.toArray()[8]);
		
		// Test #2: Add an object to the set where the set already contains said object.

			assertEquals(false, stringSet.add("6"));
			
		// Test #3: Adding a null object to the set should return false

			assertEquals(false, stringSet.add(null));
		
	}
	
	/*
	 * This tests the first and last functions in the MySortedSet class
	 */
	@Test
	public void firstLastTests(){
		
		//FIRST
			//This tests if an exception will be thrown if the set is empty
			MySortedSet<String> stringSet = new MySortedSet<String>(); //it is initialized, but it doesn't have anything in it
			try{
				String str = (String) stringSet.first();
				fail("Should throw an exception");
			}
			catch(NoSuchElementException e) {
				assertEquals("We caught the exception- pass", "We caught the exception- pass");
			}
			
			//This tests to make sure the correct first word will be returned
			stringSet.add("Hello");
			stringSet.add("Beef stew");
			
			assertEquals("Beef stew", stringSet.first());
			
		
		//LAST
			//This tests if an exception will be thrown if the set is empty
			MySortedSet<String> stringSet2 = new MySortedSet<String>(); //it is initialized, but it doesn't have anything in it
			try{
				String str = (String) stringSet2.last();
				fail("Should throw an exception");
			}
			catch(NoSuchElementException e) {
				assertEquals("We caught the exception- pass", "We caught the exception- pass");
			}
			
			//This tests to make sure the correct last word will be returned
			stringSet2.add("Hello");
			stringSet2.add("Beef stew");
			
			assertEquals("Hello", stringSet2.last());
		
	}
	/**
	 * We made an equals test for our convenience, so we're going to test it here
	 */
	@Test
	public void equalsTest(){
		//Create two different sets
		MySortedSet<Integer> intSet1= new MySortedSet<Integer>();
		MySortedSet<Integer> intSet2= new MySortedSet<Integer>();
		
		//Add the same things to them
		intSet1.add(4);
		intSet1.add(42);
		intSet1.add(23);
		
		intSet2.add(4);
		intSet2.add(42);
		intSet2.add(23);
		
		assertEquals(true, intSet1.equals(intSet2));
	}
	
	/*
	 * Tests the addAll function
	 */
	@Test
	public void addAllTest(){
		//Create an ArrayList which we can add to our MySortedSet using the addAll function
		ArrayList<Integer> intList = new ArrayList<Integer>();
		intList.add(5);
		intList.add(3);
		intList.add(7);
		intList.add(18);
		intList.add(1234);
		
		//Adds it to the set with the addAll function
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.addAll(intList);
		
		//Creates the same set using the add function
		MySortedSet<Integer> intSet2 = new MySortedSet<Integer>();
		intSet2.add(5);
		intSet2.add(3);
		intSet2.add(7);
		intSet2.add(18);
		intSet2.add(1234);
		
		//These two sets should be the same, so we compare them using the awesome equals function we made
		assertEquals(true, intSet.equals(intSet2));
		
		//Try adding an empty array to the set
		MySortedSet<Integer> emptySet = new MySortedSet<Integer>();
		ArrayList<Integer> emptyList = new ArrayList<Integer>(); //this is empty
		intSet.addAll(emptyList); //add nothing to the list
		assertEquals(0, emptySet.size());
	}
	
	
	/**
	 * Tests the clear function
	 */
	@Test
	public void clearTest(){
		
		//Create a new MySortedSet
		
		MySortedSet<Short> shortSet = new MySortedSet<Short>();
		shortSet.add((short)3);
		shortSet.add((short)4);
		shortSet.add((short)5);
		shortSet.add((short)6);
		shortSet.add((short)12);
		shortSet.add((short)14);
		shortSet.add((short)1);
		shortSet.add((short)2134);
		shortSet.add((short)123);
		shortSet.add((short)9);
		
		assertEquals(shortSet.size(), 10);//the size should be ten now
		
		shortSet.clear();
		
		assertNull(shortSet.toArray());//the array should be empty now and will return null
		assertTrue(shortSet.size() == 0); //make sure all elements are gone
		
	}
	
	
	
	
	/**
	 * Tests the size function
	 */
	@Test
	public void sizeTest(){
		
		//After we initialize a set, its size should be 0
		MySortedSet<Double> doubleSet = new MySortedSet<Double>();
		
		assertEquals(0, doubleSet.size());
		
		//Add a few things to the set and check its size
		doubleSet.add(3.14);
		doubleSet.add(2.718);
		doubleSet.add(1.618);
		
		assertEquals(3, doubleSet.size());
		
	}
	
	
	/**
	 * Tests the contains function
	 */
	@Test
	public void containsTest() {
		
		// Create a set and add some stuff to it
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add(4);
		intSet.add(7);
		intSet.add(1);
		intSet.add(80);
		intSet.add(30);
		
		// The set contains 1, but not 99
		assertEquals(true, intSet.contains(1));
		assertEquals(false, intSet.contains(99));
		
	}
	
	/**
	 * Tests the containsAll function
	 * 
	 */
	@Test
	public void containsAllTest(){
		
		//Creates an array of Integers
		ArrayList<Integer> numList = new ArrayList<Integer>();
		numList.add(4);
		numList.add(7);
		numList.add(1);
		numList.add(80);
		numList.add(30);
		
		//Creates a different array of Integers that is the same except for the last entry
		ArrayList<Integer> badList = new ArrayList<Integer>();
		badList.add(4);
		badList.add(7);
		badList.add(1);
		badList.add(80);
		badList.add(31);
		
		
		// Create a set and add the same stuff that numList has to it
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add(4);
		intSet.add(7);
		intSet.add(1);
		intSet.add(80);
		intSet.add(30);
		
		//checks the function
		assertEquals(true, intSet.containsAll(numList));
		assertEquals(false, intSet.containsAll(badList));
		
		//Checks to see that the function will still work if the set is empty
		MySortedSet<Integer> emptySet = new MySortedSet<Integer>(); //this set is empty
		assertEquals(false, emptySet.containsAll(numList));
	}
	
	/**
	 * Tests the isEmpty function
	 */
	@Test
	public void isEmptyTest(){
		
		MySortedSet stringSet = new MySortedSet(); //set is empty
		
		assertEquals(true, stringSet.isEmpty());
		
		stringSet.add("Hey"); //the set is not empty
		
		assertEquals(false, stringSet.isEmpty());
	}
	
	
	/**
	 * Tests the remove function
	 */
	@Test
	public void removeTest(){
		
		MySortedSet stringSet = new MySortedSet(); //the set is empty
		
		//Tests to see if the remove function will work if the set is empty
		assertEquals(false, stringSet.remove("Bob Johnson"));
		
		stringSet.add("Hello");
		stringSet.add("How are you?");
		stringSet.add("BBBBBBBBB");
		stringSet.add("ZZZZZZZ");
		stringSet.add("A");
		
		//Tests removing the first entry of a set
		assertEquals(true, stringSet.remove("A"));
		assertEquals(false, stringSet.contains("A"));
		
		//Tests removing an entry in the middle
		assertEquals(true, stringSet.remove("Hello"));
		assertEquals(false, stringSet.contains("Hello"));
		
		//Tests removing an entry at the end
		assertEquals(true, stringSet.remove("ZZZZZZZ"));
		assertEquals(false, stringSet.contains("ZZZZZZZ"));
		
		//Tests to make sure it will return false if we try to remove a different kind of object
		MySortedSet<Character> normalSet = new MySortedSet<Character>();
		normalSet.add('\'');
		normalSet.add('!');
		
		assertFalse(normalSet.remove(1234L));
	
	}
	
	
	/**
	 * Tests the removeAll function
	 */
	@Test
	public void removeAllTest(){
		//Creates an array of Integers
		ArrayList<Integer> numList = new ArrayList<Integer>();
		numList.add(4);
		numList.add(7);
		numList.add(1);
		numList.add(80);
		numList.add(30);
		
		//Creates an array with nothing in it
		ArrayList<Integer> badList = new ArrayList<Integer>();
		
		//Creates an array that has all different numbers in it
		ArrayList<Integer> badList2 = new ArrayList<Integer>();
		badList2.add(6);
		badList2.add(8);
		
		// Create a set and add the same stuff that numList has to it
		MySortedSet<Integer> intSet = new MySortedSet<Integer>();
		intSet.add(4);
		intSet.add(7);
		intSet.add(1);
		intSet.add(80);
		intSet.add(30);		
		
		//checks the function
		assertEquals(false, intSet.removeAll(badList)); //subtract an empty array from the set
		assertEquals(false, intSet.removeAll(badList2)); //subtract an array that has no common entries
		assertEquals(true, intSet.removeAll(numList)); //subtract an array from the set
		assertEquals(true, intSet.isEmpty());
		assertEquals(false, intSet.removeAll(numList)); //subtract an array from an empty set
		
		//Checks to see that the function will still work if the set is empty
		MySortedSet<Integer> emptySet = new MySortedSet<Integer>(); //this set is empty
		assertEquals(false, emptySet.containsAll(numList));

	}
	
	/**
	 * Tests the toArray function
	 */
	@Test
	public void toArrayTest(){
		
		//create a new MySortedSet
		//the maximum size can technically only be two because of duplicates not being allowed, but this should still serve its purpose
		MySortedSet<Boolean> booleanSet = new MySortedSet<Boolean>(); 
		booleanSet.add(false);
		booleanSet.add(true);
		
		//So the toArray function should return an array of size 2 and remove all of the null values
		Object[] booleanArray = booleanSet.toArray();
		
		assertTrue(booleanArray.length == 2);
		
		//using the toArray method with an empty set should return null
		
		MySortedSet<Byte> byteSet = new MySortedSet<Byte>(); //this is empty
		
		assertNull(byteSet.toArray());
	}
	
	/**
	 * Tests the iterator function and the various functions inside MySortedSetIterator
	 */
	@Test
	public void iteratorTest(){
		
		// Create a set, add some items, and then call the iterator() function
		MySortedSet<Character> set = new MySortedSet<Character>();
		set.add('z');
		set.add('e');
		set.add('b');
		
		Iterator iterator = set.iterator();
		
		// The iterator has room to iterate
		assertTrue(iterator.hasNext());
		
		// The iterator should return the appropriate values when next() is called
		assertEquals('b', iterator.next());
		assertEquals('e', iterator.next());
		assertEquals('z', iterator.next());
		
		// The iterator has no more elements to iterate through
		assertFalse(iterator.hasNext());
		
		// Make sure calling next() throws a NoSuchElementException.
		try {
			iterator.next();
			fail("This should not run"); // if exception is thrown, this line will never be executed
		}
		catch (NoSuchElementException e) {
			assertTrue(true);
		}
		
		// Remove the last item of the collection with the iterator's remove() method
		iterator.remove();
		
			// Check that this removed an element
			assertTrue(set.size() == 2);
			
			// Check that we removed the correct element
			Object[] array = set.toArray();
			assertTrue(array[1] == (Character)'e');
	}
	
	
	/// TIME EFFICIENCY TESTS
	
	// Check to make sure our add, contains, and remove functions complete in a reasonable amount of time for large N.
	
	
	@Test
	public void efficiencyTests() {
	
	MySortedSet<Integer> bigSet = new MySortedSet<Integer>();
	
	int setSize = 100_000;
	
	// Stabilize thread by "spinning" for 1 second
	long startTime = System.nanoTime();
    while (System.nanoTime() - startTime < 1000000000) { // empty block
    }

    Double random; //We'll use this to make numbers randomly positive or negative
	

	for (int i = 0; i < setSize; i++) {
		
		random = Math.random();
		if(random < .5)
			bigSet.add((int)(Math.random()*1_000_000));
		else
			bigSet.add((int)(Math.random()* 1_000_000 * -1));
	}
	
	// Time how long it takes to add one element to a set of 100,000
	 startTime = System.nanoTime();
	 
	 bigSet.add((Integer)50); // add an integer to the set.
	 
	// A single add() operation should take less than a hundredth of a second
	assertTrue(System.nanoTime() - startTime < 10_000_000); 
	 
	// The contains() operation should take less than a thousandth of a second
		 startTime = System.nanoTime();
		 
		 bigSet.contains(50); // add an arbitrary to the set.
		 assertTrue(System.nanoTime() - startTime < 1_000_000); 
	
	 
	 // A single remove() operation should take less than a hundredth of a second
		 startTime = System.nanoTime();
		 
		 bigSet.remove(50); // add an arbitrary to the set.
		 assertTrue(System.nanoTime() - startTime < 10_000_000); 
		 
	}
	
	
	
	
	
	
	
	
	
	
}
