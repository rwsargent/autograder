package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * A class used to test MySortedSet.
 * 
 * @author Mitchell Terry and Alexander Weech
 */
public class MySortedSetTest 
{
	// Class fields:
	// Declare the variables that hold MySortedSets
	private MySortedSet<Integer> set1, set2;
	// Declare the variable to hold a TestComparator
	private TestComparator comparatorExample;
	// Declare the variable to hold an ArrayList
	private ArrayList<Integer> array;
	
	@Before
	public void setUp() throws Exception 
	{
		// Assign values to the class fields
		set1 = new MySortedSet<Integer>();
		comparatorExample = new TestComparator();
		set2 = new MySortedSet<Integer>(comparatorExample);
		array = new ArrayList<Integer>();
	}

	@After
	public void tearDown() throws Exception 
	{
		
	}

	/**
	 * Tests that the comparator() method returns null when using the base constructor and the
	 * Comparator otherwise.
	 */
	@Test
	public void comparatorTest() 
	{
		// Test that comparator() is null from a MySortedSet that was not given a comparator
		assertEquals(null, set1.comparator());
		// Test that comparator() is the example comparator from a MySortedSet that was given a comparator
		assertEquals(comparatorExample, set2.comparator());
	}
	
	/**
	 * Tests that the first() method returns the first value in the set.
	 */
	@Test
	public void firstTest()
	{
		// Test that first() throws NoSuchElementException when there have been no items added
		try {
			set1.first();
			fail("Exception not thrown!");
		} catch (NoSuchElementException e) {
			// Test has passed
		}
		// Add item
		set1.add(20);
		// Test that first() returns the only item
		assertEquals(new Integer(20), set1.first());
		// Add items
		set1.add(4);
		set1.add(12);
		// Test that first() returns the smallest value, which is smaller than the previous test
		assertEquals(new Integer(4), set1.first());
	}
	
	/**
	 * Tests that the last() method returns the last value in the set.
	 */
	@Test
	public void lastTest() {
		// Test that last() throws NoSuchElementException when there have been no items added
		try {
			set1.last();
			fail("Exception not thrown!");
		} catch (NoSuchElementException e) {
			// Test has passed
		}
		// Add item
		set1.add(15);
		// Test that last() returns the only item
		assertEquals(new Integer(15), set1.last());
		// Add items
		set1.add(4);
		set1.add(12);
		set1.add(20);
		// Test that last() returns the greatest value, which is larger than the first item that was added
		assertEquals(new Integer(20), set1.last());
	}
	
	/**
	 * Tests that the add() method works.
	 */
	@Test public void addTest()
	{
		// Test that add() returns true when adding a valid item
		assertTrue(set1.add(1));
		// Add some more items
		set1.add(3);
		set1.add(-1);
		set1.add(2);
		// Test that the output array has expected values
		assertArrayEquals(set1.toArray(), new Integer[] {-1, 1, 2, 3});
		// Add more items
		set1.add(9);
		// Test that add() returns false if an item was already added
		assertFalse(set1.add(9));
		// Test that add() returns false if the input is null
		assertFalse(set1.add(null));
		// Add more items
		set1.add(8);
		set1.add(90);
		set1.add(50);
		set1.add(30);
		// Make sure that the array grows at size = 9, and that the output array has expected values
		assertArrayEquals(set1.toArray(), new Integer[] {-1, 1, 2, 3, 8, 9, 30, 50, 90});
	}

	/**
	 * Tests that the addAll() method works.
	 */
	@Test
	public void addAllTest() {
		// Add values to an ArrayList
		array.add(21);
		array.add(15);
		array.add(2);
		array.add(6);
		// Test that addAll() returns true when adding the array
		assertTrue(set1.addAll(array));
		// Test that the output array has expected values
		assertArrayEquals(new Integer[] {2, 6, 15, 21}, set1.toArray());
		// Test that addAll() returns false when trying to add the array again
		assertFalse(set1.addAll(array));
		// Test that the output array was not affected
		assertArrayEquals(new Integer[] {2, 6, 15, 21}, set1.toArray());
		// Add one more item to the array
		array.add(8);
		// Test that addAll() returns true when adding the modified array
		assertTrue(set1.addAll(array));
		// Test that the output array has expected values
		assertArrayEquals(new Integer[] {2, 6, 8, 15, 21}, set1.toArray());
	}
	
	/**
	 * Tests that the clear() method clears the set.
	 */
	@Test
	public void clearTest() {
		// Add items to the set
		set1.add(10);
		set1.add(52);
		set1.add(5);
		set1.add(8);
		// Clear the set
		set1.clear();
		// Test that the output array is empty
		assertArrayEquals(new Integer[] {}, set1.toArray());
	}
	
	/**
	 * Tests that the contains() method works.
	 */
	@Test
	public void containsTest() {
		// Test that contains() returns false with an empty set
		assertFalse(set1.contains(5));
		// Add items
		set1.add(10);
		set1.add(3);
		set1.add(42);
		set1.add(70);
		set1.add(19);
		// Test that contains() returns true when input is 3, the lowest item
		assertTrue(set1.contains(3));
		// Test that contains() returns true when input is 42, a middle-ish item
		assertTrue(set1.contains(42));
		// Test that contains() returns true when input is 70, the highest item
		assertTrue(set1.contains(70));
		// Test that contains() returns false when input is 100
		assertFalse(set1.contains(100));
		// Test that contains() returns false when input is 30
		assertFalse(set1.contains(30));
	}
	
	/**
	 * Tests that the containsAll() method works.
	 */
	@Test
	public void containsAllTest() {
		// Add values to an ArrayList
		array.add(1);
		array.add(16);
		array.add(10);
		array.add(54);
		array.add(3);
		// Add array to set
		set1.addAll(array);
		// Test that containsAll() returns true when input is the array
		assertTrue(set1.containsAll(array));
		// Add an item to the array
		array.add(6);
		// Test that containsAll() returns false when input is the modified array
		assertFalse(set1.containsAll(array));
	}
	
	/**
	 * Tests that the isEmpty() method works.
	 */
	@Test
	public void isEmptyTest() {
		// Test that isEmpty() returns true with an empty set
		assertTrue(set1.isEmpty());
		// Add an item
		set1.add(18);
		// Test that isEmpty() returns false with the set
		assertFalse(set1.isEmpty());
		// Clear the set
		set1.clear();
		// Test that isEmpty() returns true with the cleared set
		assertTrue(set1.isEmpty());
	}
	
	/**
	 * Tests that the iterator() method returns an iterator.
	 */
	@Test
	public void iteratorTest() {
		// Save the output of iterator() to a variable
		Iterator<Integer> iter = set1.iterator();
		// Test that iter is not null
		assertNotEquals(null, iter);
		// Test that iter is the same object as the set
		assertTrue(set1 == iter);
	}
	
	/**
	 * Tests that the remove() method works.
	 */
	@Test
	public void removeTest() {
		// Test that remove() returns false with an empty set
		assertFalse(set1.remove(10));
		// Add items to set
		set1.add(5);
		set1.add(10);
		set1.add(18);
		set1.add(82);
		set1.add(3);
		set1.add(8);
		set1.add(60);
		// Test that remove() returns true with the input 3, the lowest item
		assertTrue(set1.remove(3));
		// Test that remove() returns true with the input 82, the highest item
		assertTrue(set1.remove(82));
		// Test that remove() returns true with the input 10, a middle-ish item
		assertTrue(set1.remove(10));
		// Test that the output array has expected values
		assertArrayEquals(new Integer[] {5, 8, 18, 60}, set1.toArray());
	}
	
	/**
	 * Tests that the removeAll() method works.
	 */
	@Test
	public void removeAllTest() {
		// Add items to an ArrayList
		array.add(17);
		array.add(21);
		array.add(4);
		array.add(12);
		array.add(43);
		// Add items to set
		set1.add(16);
		set1.add(2);
		// Add the array
		set1.addAll(array);
		// Test that removeAll() returns true when input is the array
		assertTrue(set1.removeAll(array));
		// Test that the output array has expected values
		assertArrayEquals(new Integer[] {2, 16}, set1.toArray());
		// Test that removeAll() returns false when input is the array
		assertFalse(set1.removeAll(array));
		// Add a value to the array
		array.add(16);
		// Test that removeAll() returns true when input is the modified array
		assertTrue(set1.removeAll(array));
		// Test that the output array has expected values
		assertArrayEquals(new Integer[] {2}, set1.toArray());
	}
	
	/**
	 * Tests that the size() method returns the size.
	 */
	@Test
	public void sizeTest() {
		// Test that size() is 0 for empty set
		assertEquals(0, set1.size());
		// Add items
		set1.add(10);
		set1.add(4);
		set1.add(25);
		set1.add(6);
		// Test that size() is 4
		assertEquals(4, set1.size());
		// Remove an item
		set1.remove(10);
		// Test that size() is 3
		assertEquals(3, set1.size());
		// Clear the set
		set1.clear();
		// Test that size() is 0
		assertEquals(0, set1.size());
	}
	
	/**
	 * Tests that the toArray() method works.
	 */
	@Test
	public void toArrayTest() {
		// Test that toArray() returns an empty array for an empty set
		assertArrayEquals(new Integer[] {}, set1.toArray());
		// Add items
		set1.add(53);
		set1.add(19);
		set1.add(43);
		set1.add(64);
		// Test that toArray() returns expected values
		assertArrayEquals(new Integer[] {19, 43, 53, 64}, set1.toArray());
	}
	
	/**
	 * Tests that the hasNext() method works.
	 */
	@Test
	public void hasNextTest() {
		// Test that hasNext() returns false with an empty set
		assertFalse(set1.hasNext());
		// Add item
		set1.add(30);
		// Test that hasNext() returns true
		assertTrue(set1.hasNext());
		// Add items
		set1.add(3);
		set1.add(33);
		set1.add(60);
		set1.add(81);
		// Use next() to get to end
		set1.next();
		set1.next();
		set1.next();
		// Test that hasNext() returns true
		assertTrue(set1.hasNext());
		// Use next() twice more
		set1.next();
		set1.next();
		// Test that hasNext() returns false
		assertFalse(set1.hasNext());
	}
	
	/**
	 * Tests that the next() method works.
	 */
	@Test
	public void nextTest() {
		// Test that next() throws NoSuchElementException with an empty set
		try {
			set1.next();
			fail("Exception not thrown!");
		} catch (NoSuchElementException e) {
			// Test has passed
		}
		// Add items
		set1.add(20);
		set1.add(5);
		set1.add(14);
		set1.add(8);
		// Test that next() returns 5
		assertEquals(new Integer(5), set1.next());
		// Test that next() returns 8
		assertEquals(new Integer(8), set1.next());
		// Use next() to get to end
		set1.next();
		set1.next();
		// Test that next() throws NoSuchElementException
		try {
			set1.next();
			fail("Exception not thrown!");
		} catch (NoSuchElementException e) {
			// Test has passed
		}
	}
	
}
