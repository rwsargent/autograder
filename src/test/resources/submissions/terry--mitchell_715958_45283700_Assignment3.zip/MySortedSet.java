package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A class used to add, remove, search, and get items in a sorted order and with
 * no duplicates.
 * 
 * @author Mitchell Terry and Alexander Weech
 *
 * @param <E>
 *            The type of class to store.
 */
public class MySortedSet<E> implements SortedSet<E>, Iterator<E> {

	// Class Fields:
	// The variable to store the data given to the class. Since the class cannot
	// create an array of a generic type, the array is of Objects. Output
	// methods will type cast data when they return it.
	private Object[] dataArray;
	// The variable to store the expected size of the class' data
	private int size;
	// The variable to store a comparator that can be given in one of the
	// constructors. If the comparable is null, the code should use the natural
	// sorting order of the object alternatively.
	private Comparator<? super E> comparator;
	// The variable that is used for the Iterator interface. It keeps track of
	// an index in the dataArray.
	private int pointer;

	/**
	 * Constructor that has elements sorted by their natural order.
	 */
	public MySortedSet() {
		// Initialize the size of dataArray to 8 items
		dataArray = new Object[8];
		// Initialize the size to be 0
		size = 0;
		// Initialize the pointer
		pointer = 0;
		// Set the comparator to be null
		comparator = null;
		
		
	}

	/**
	 * Constructor that has elements sorted by a given Comparator.
	 * 
	 * @param c
	 *            The Comparator to sort items with.
	 */
	public MySortedSet(Comparator<? super E> c) {
		// Use the previous constructor to set several values
		this();
		// Set the comparator to the given input
		comparator = c;
	}

	@Override
	public Comparator<? super E> comparator() {
		// Return the stored comparator
		return comparator;
	}

	@Override
	public E first() throws NoSuchElementException {
		// Return the first element in the set. If the size is 0, throw a
		// NoSuchElementException.
		if (size == 0)
			throw new NoSuchElementException();
		return (E) dataArray[0];
	}

	@Override
	public E last() throws NoSuchElementException {
		// Return the last element in the set. If the size is 0, throw a
		// NoSuchElementException.
		if (size == 0)
			throw new NoSuchElementException();
		return (E) dataArray[size - 1];
	}

	@Override
	public boolean add(E o) {
		// Add the given element to the set. If the element was already added,
		// or if the element is null, do not add then return false. The item
		// will be added so that the array is sorted, then returns true.
		if (o == null || this.contains(o))
			return false;
		else if (size == 0){
			// Add the object to the start of the dataArray
			dataArray[0] = o;
			// Increase size
			size++;
			// Return true
			return true;
		}
		else {
			// Find the index the element can go to
			int index = findSortIndex(o);
			// Store all elements at the index onward to a placeholder array
			Object[] placeholder = new Object[size - index];
			for (int i = index; i < size; i++) {
				placeholder[i - index] = dataArray[i];
			}
			// Add the new element to the index in the dataArray, then increment
			// the size
			dataArray[index] = o;
			size++;
			// Check if the size of dataArray is smaller than the class' size.
			// Double the size of dataArray if so.
			if (size > dataArray.length) {
				// Create a temporary array that is double in size
				Object[] temp = new Object[dataArray.length * 2];
				// Duplicate dataArray's elements into temp
				for (int i = 0; i < dataArray.length; i++) {
					temp[i] = dataArray[i];
				}
				// Set dataArray to point to the temp array
				dataArray = temp;
			}
			// Add the previous element(s) back an index later
			for (int i = index + 1; i <= index + placeholder.length; i++) {
				dataArray[i] = placeholder[i - index - 1];
			}
			// Return true
			return true;
		}
	}

	/**
	 * Returns the index that the given object will be added to in the array. If the object will
	 * go first or last in the array, returns 0 or the length of the array respectively.
	 * 
	 * @param o - The object to be sorted into the set.
	 * @return The index that the object should be inserted into.
	 */
	private int findSortIndex(Object o) 
	{
		// Initialize/declare values to use for the search
		int min = 0;
		int max = size - 1;
		int result;

		// Check if a comparator is available to use.
		if (comparator != null)
		{
			// Check to make sure the index we need isn't beyond the min or max. Return the min or max + 1 if either case occurs.
			if (comparator.compare((E) dataArray[min], (E) o) > 0)
			{
				return min;
			}
			else if (comparator.compare((E) dataArray[max], (E) o) < 0)
			{
				return max + 1;
			}
			else
			{
				// Loop through the steps of binary search. If the maximum ever equals
				// the minimum, end the loop.
				while ((max - min) > 0) 
				{
					// Calculate the middle of the min and max
					int mid = (max + min) / 2;
					
					// Compare the middle and the given object
					result = comparator.compare((E) dataArray[mid], (E) o);
	
					// Check if the middle element is greater than the given object
					if (result > 0) {
						// Set the max to the mid - 1
						max = mid - 1;
					}
					// Check if the middle element is less than the given object
					else if (result < 0) {
						// Set the min to the mid + 1
						min = mid + 1;
					}
				}
				
				// The min could either be one more or one less than the object, so check which case it is then return the correct index
				if (comparator.compare((E) dataArray[min], (E) o) < 0)
				{
					return min + 1;
				}
				else
				{
					return min;
				}
			}
		}
		else
		{
			// Check to make sure the index we need isn't the max or min. Return the min or max + 1 if either case occurs.
			if (((Comparable) dataArray[min]).compareTo(o) > 0)
			{
				return min;
			}
			else if (((Comparable) dataArray[max]).compareTo(o) < 0)
			{
				return max + 1;
			}
			else
			{
				// Loop through the steps of binary search. If the maximum ever equals
				// the minimum, end the loop.
				while ((max - min) > 0) 
				{
					// Calculate the middle of the min and max
					int mid = (max + min) / 2;
					
					// Compare the middle and the given object
					result = ((Comparable) dataArray[mid]).compareTo(o);
					
					// Check if the middle element is greater than the given object
					if (result > 0) 
					{
						// Set the max to the mid - 1
						max = mid - 1;
					}
					// Check if the middle element is less than the given object
					else if (result < 0) 
					{
						// Set the min to the mid + 1
						min = mid + 1;
					}
				}
				
				// The min could either be one more or one less than the object, so check which case it is then return the correct index
				if (((Comparable) dataArray[min]).compareTo(o) < 0)
				{
					return min + 1;
				}
				else
				{
					return min;
				}
			}
		}
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {
		// Create an Object array from the collection
		Object[] array = c.toArray();
		// Create a variable to represent if the method should return true
		boolean output = false;
		// Add the elements of the given collection
		for (int i = 0; i < array.length; i++) {
			// Check if the add() method returns true when adding an element
			if (this.add((E) array[i])) {
				output = true;
			}
		}
		// Return the resulting output
		return output;
	}

	@Override
	public void clear() {
		// Remove the elements of dataArray by creating a new array
		dataArray = new Object[8];
		// Set the size to 0
		size = 0;
	}

	@Override
	public boolean contains(Object o) {
		// Initialize/declare values to use for the search
		int min = 0;
		int max = size;
		int mid = (max + min) / 2;
		int result;
		// Check if the size is zero. Return false if so.
		if (size == 0) {
			return false;
			// Else, check if a comparator is available to use
		} else if (comparator != null)
		{
			// Loop through the steps of binary search. If the middle ever equals
			// the minimum, end the loop.
			while (mid != min) 
			{
				// Compare the middle and the given object
				result = comparator.compare((E) dataArray[mid], (E) o);

				// Check if the middle element is greater than the given object
				if (result > 0) {
					// Set the max to the mid - 1
					max = mid - 1;
				}
				// Check if the middle element is less than the given object
				else if (result < 0) {
					// Set the min to the mid + 1
					min = mid + 1;
				}
				// The object will equal the element in this case, so return true
				else 
				{
					return true;
				}
				
				// Calculate the middle of the min and max
				mid = (max + min) / 2;
			}
			
			// Check the middle and the right side of the middle in case the given value is in one of them
			if (dataArray[mid] != null && mid < size && comparator.compare((E) dataArray[mid], (E) o) == 0)
			{
				return true;
			}
			else if (dataArray[mid+1] != null && mid < size && comparator.compare((E) dataArray[mid+1], (E) o) == 0)
			{
				return true;
			}
		}
		else
		{
			// Loop through the steps of binary search. If the middle ever equals
			// the minimum, end the loop.
			while (mid != min) 
			{
				// Compare the middle and the given object
				result = ((Comparable) dataArray[mid]).compareTo((Comparable) o);
				
				// Check if the middle element is greater than the given object
				if (result > 0) 
				{
					// Set the max to the mid - 1
					max = mid - 1;
				}
				// Check if the middle element is less than the given object
				else if (result < 0) 
				{
					// Set the min to the mid + 1
					min = mid + 1;
				}
				
				// The object will equal the element in this case, so return true
				else 
				{
					return true;
				}

				// Calculate the middle of the min and max
				mid = (max + min) / 2;
			}
			
			// Check the middle and the right side of the middle in case the given value is in one of them
			if (dataArray[mid] != null && mid < size && ((Comparable) dataArray[mid]).compareTo(o) == 0)
			{
				return true;
			}
			else if (dataArray[mid+1] != null && mid < size && ((Comparable) dataArray[mid + 1]).compareTo(o) == 0)
			{
				return true;
			}
		}
		// The while loop failed to find the object, so it is not in the array. Return false.
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		// Create an Object array from the collection
		Object[] array = c.toArray();
		// Check if each element is contained
		for (int i = 0; i < array.length; i++) {
			// Check if the contains() method ever returns false. Return false
			// if so.
			if (!this.contains((E) array[i])) {
				return false;
			}
		}
		// Return true since the contains() method never returned false
		return true;
	}

	@Override
	public boolean isEmpty() {
		// Return the boolean of size equalling 0
		return size == 0;
	}

	@Override
	public Iterator<E> iterator() {
		// Return this object, since it implements Iterator
		return this;
	}

	@Override
	public boolean remove(Object o) {
		// Remove the element if it is present. Return false if the element
		// isn't present, or it is null. Return true if it has been removed.
		if (o == null || !this.contains(o))
			// The element is not contained or null, so it can't be removed
			return false;
		else {
			// Find the index of the element
			int index = findRemoveIndex(o);
			// Shift each element past the index to the previous index
			for (int i = index + 1; i < size; i++) {
				dataArray[i - 1] = dataArray[i];
			}
			// Decrement the size
			size--;
			// Return true
			return true;
		}
	}
	
	/**
	 * Returns the index that the given object will be removed from in the
	 * array. If an error occurs, returns -99.
	 * 
	 * @param o - The object to be removed from the set.
	 * @return The index that the object can be found at.
	 */
	private int findRemoveIndex(Object o) 
	{		
		// Initialize/declare values to use for the search
		int min = 0;
		int max = size - 1;
		int result;
		int mid = (max + min) / 2;
		// Check if a comparator is available to use.
		if (comparator != null)
		{
			// Check to make sure the index we need isn't the max or min
			if (comparator.compare((E) dataArray[min], (E) o) == 0)
			{
				return min;
			}
			else if (comparator.compare((E) dataArray[max], (E) o) == 0)
			{
				return max;
			}
			else
			{
				// Loop through the steps of binary search. If the middle ever equals
				// the minimum, end the loop.
				while (mid != min) 
				{
					// Calculate the middle of the min and max
					mid = (max + min) / 2;
					
					// Compare the middle and the given object
					result = comparator.compare((E) dataArray[mid], (E) o);
	
					// Check if the middle element is greater than the given object
					if (result > 0) {
						// Set the max to the mid - 1
						max = mid - 1;
					}
					// Check if the middle element is less than the given object
					else if (result < 0) {
						// Set the min to the mid + 1
						min = mid + 1;
					}
					// The object will equal the element in this case, so return mid
					else {
						return mid;
					}
				}
				
				// Check the middle in case the given value is there. Return the right side of the middle otherwise.
				if (dataArray[mid] != null && comparator.compare((E) dataArray[mid], (E) o) == 0)
				{
					return mid;
				}
				else
				{
					return mid + 1;
				}
			}
		}
		else
		{
			// Check to make sure the index we need isn't the max or min
			if (((Comparable) dataArray[min]).compareTo(o) == 0)
			{
				return min;
			}
			else if (((Comparable) dataArray[max]).compareTo(o) == 0)
			{
				return max;
			}
			else
			{
				// Loop through the steps of binary search. If the middle ever equals
				// the minimum, end the loop.
				while (mid != min) 
				{
					// Calculate the middle of the min and max
					mid = (max + min) / 2;
					
					// Compare the middle and the given object
					result = ((Comparable) dataArray[mid]).compareTo(o);
					
					// Check if the middle element is greater than the given object
					if (result > 0) 
					{
						// Set the max to the mid - 1
						max = mid - 1;
					}
					// Check if the middle element is less than the given object
					else if (result < 0) 
					{
						// Set the min to the mid + 1
						min = mid + 1;
					}
					
					// The object will equal the element in this case, so return mid
					else 
					{
						return mid;
					}
				}
				
				// Check the middle in case the given value is there. Return the right side of the middle otherwise.
				if (dataArray[mid] != null && ((Comparable) dataArray[mid]).compareTo(o) == 0)
				{
					return mid;
				}
				else
				{
					return mid + 1;
				}
			}
		}
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		// Create an array of the Collection
		Object[] array = c.toArray();
		// Create a variable that will represent the return value
		boolean output = false;
		// Loop through the container
		for (int i = 0; i < array.length; i++) {
			// Check if the remove() method ever returns true. Set output to
			// true if so.
			if (this.remove(array[i])) {
				output = true;
			}
		}
		// Return the output
		return output;
	}

	@Override
	public int size() {
		// Return the size
		return size;
	}

	@Override
	public Object[] toArray() {
		// Place dataArray values into a temporary array that is the same length
		// as size
		Object[] temp = new Object[size];
		for (int i = 0; i < size; i++) {
			temp[i] = dataArray[i];
		}
		// return the temp array
		return temp;
	}

	@Override
	public boolean hasNext() {
		// Return the comparison of the pointer being less than the size
		return pointer < size;
	}

	@Override
	public E next() {
		// If the iterator does not have a next value, throw a NoSuchElementException
		if (!this.hasNext())
			throw new NoSuchElementException();
		// Set the element at the pointer to an output variable
		Object output = dataArray[pointer];
		// Increment the pointer
		pointer++;
		// Return the output
		return (E) output;
	}

}
