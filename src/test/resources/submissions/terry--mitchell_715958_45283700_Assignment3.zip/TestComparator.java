package assignment3;

import java.util.Comparator;

/**
 * A class used in MySortedSetTest as a place holder Comparator.
 * 
 * @author Mitchell Terry and Alexander Weech
 */
public class TestComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) 
	{
		// TODO Auto-generated method stub
		return 0;
	}
	

}
