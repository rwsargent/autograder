//Tanner Marshall
//Tim Dorny
//Assignment 3
//2/5/2015

package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

import org.junit.Test;

public class MySortedSetTest {
	//comparator used for testing, orders strings in reverse alphabetical order	
	class StringCompare implements Comparator<String>{

			@Override
			public int compare(String o1, String o2) {
				int answer = o1.compareTo(o2);
				answer = answer*(-1);
				return answer;
			}
			
		}

	@Test
	public void testFirst() {
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("Words");
		test.add("GoodBye");
		assertEquals("GoodBye", test.first());
		
		StringCompare comp = new StringCompare(); 
		MySortedSet<String> test2 = new MySortedSet<String>(comp);
		test2.add("Hello");
		test2.add("Words");
		test2.add("GoodBye");
		assertEquals("Words", test2.first());
		
		MySortedSet<String> test3 = new MySortedSet<String>();
		assertEquals(null, test3.first());
	}
	
	@Test
	public void testLast(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("Words");
		test.add("GoodBye");
		assertEquals(true, test.contains("GoodBye"));
		assertEquals("Words", test.last());
		
		StringCompare comp = new StringCompare(); 
		MySortedSet<String> test2 = new MySortedSet<String>(comp);
		test2.add("Hello");
		test2.add("Words");
		test2.add("GoodBye");
		assertEquals("GoodBye", test2.last());
	}

	@Test
	public void testClear(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("GoodBye");
		test.add("Words");
		test.clear();
		assertEquals(null, test.first());
	}
	
	@Test
	public void testAddAll(){
		MySortedSet<String> test = new MySortedSet<String>();
		ArrayList<String> collection = new ArrayList<String>();
		collection.add("GoodBye");
		collection.add("Hello");
		collection.add("Words");
		test.addAll(collection);
		assertEquals("GoodBye", test.first());
		assertEquals("Words", test.last());
		
		StringCompare comp = new StringCompare(); 
		MySortedSet<String> test2 = new MySortedSet<String>(comp);
		ArrayList<String> collection2 = new ArrayList<String>();
		collection2.add("GoodBye");
		collection2.add("Hello");
		collection2.add("Words");
		test2.addAll(collection);
		assertEquals("Words", test2.first());
		assertEquals("GoodBye", test2.last());
	}
	
	@Test
	public void testContains(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("GoodBye");
		test.add("Words");
		assertEquals(true, test.contains("Hello"));
		assertEquals(true, test.contains("GoodBye"));
		assertEquals(true, test.contains("Words"));
		assertEquals(false, test.contains("asdfasdf"));
	}
	
	@Test
	public void testContainsAllTrue(){
		MySortedSet<String> test = new MySortedSet<String>();
		ArrayList<String> collection = new ArrayList<String>();
		collection.add("GoodBye");
		collection.add("Hello");
		collection.add("Words");
		test.addAll(collection);
		assertEquals(true, test.containsAll(collection));
	}
	@Test
	public void testContainsAllFalse(){
		MySortedSet<String> test = new MySortedSet<String>();
		ArrayList<String> collection = new ArrayList<String>();
		collection.add("GoodBye");
		collection.add("Hello");
		collection.add("Words");
		test.addAll(collection);
		collection.add("world");
		assertEquals(false, test.containsAll(collection));
	}
	
	@Test
	public void testIsEmptyTrue(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("GoodBye");
		test.add("Words");
		test.clear();
		assertEquals(true, test.isEmpty());
	}
	
	@Test
	public void testIsEmptyFalse(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("GoodBye");
		test.add("Words");
		assertEquals(false, test.isEmpty());
	}
	
	@Test
	public void testRemove(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("GoodBye");
		test.add("Words");
		test.remove("Hello");
		test.remove("Words");
		assertEquals(false, test.contains("Hello"));
		assertEquals(true, test.contains("GoodBye"));
		assertEquals(false, test.contains("Words"));
		assertEquals(false, test.contains("asdfasdf"));
	}
	
	@Test
	public void testRemoveAll(){
		MySortedSet<String> test = new MySortedSet<String>();
		ArrayList<String> collection = new ArrayList<String>();
		collection.add("GoodBye");
		collection.add("Hello");
		collection.add("Words");
		test.addAll(collection);
		test.removeAll(collection);
		assertEquals(true, test.isEmpty());
		
		StringCompare comp = new StringCompare(); 
		MySortedSet<String> test2 = new MySortedSet<String>(comp);
		ArrayList<String> collection2 = new ArrayList<String>();
		collection2.add("GoodBye");
		collection2.add("Hello");
		collection2.add("Words");
		test2.addAll(collection);
		test2.removeAll(collection);
		assertEquals(true, test2.isEmpty());
	}
	
	@Test
	public void testSize(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("GoodBye");
		test.add("Words");
		assertEquals(3, test.size());
	}
	
	@Test
	public void testToArray(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("GoodBye");
		test.add("Words");
		String[] str = new String[10];
		str[0] = "GoodBye";
		str[1] = "Hello";
		str[2] = "Words";
		assertEquals(str[0], test.toArray()[0]);
		assertEquals(str[1], test.toArray()[1]);
		assertEquals(str[2], test.toArray()[2]);
	}
	
	@Test
	public void testGrowingArray(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("Words");
		test.add("GoodBye");
		test.add("Jello");
		test.add("Mello");
		test.add("q");
		test.add("w");
		test.add("e");
		test.add("r");
		test.add("t");
		test.add("y");
		test.add("u");
		test.add("i");
		assertEquals(true, test.contains("GoodBye"));
		assertEquals("y", test.last());
		
		StringCompare comp = new StringCompare(); 
		MySortedSet<String> test2 = new MySortedSet<String>(comp);
		test2.add("Hello");
		test2.add("Words");
		test2.add("GoodBye");
		test2.add("Jello");
		test2.add("Mello");
		test2.add("q");
		test2.add("w");
		test2.add("E");
		test2.add("r");
		test2.add("t");
		test2.add("y");
		test2.add("u");
		test2.add("i");
		assertEquals("E", test2.last());
	}
	
	@Test
	public void testIterator(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("Hello");
		test.add("GoodBye");
		test.add("Words");
		Iterator<String> iter = test.iterator();
		assertEquals(true, iter.hasNext());
		assertEquals(true, iter.hasNext());
		assertEquals("GoodBye", iter.next());
		assertEquals(true, iter.hasNext());
		assertEquals("Hello", iter.next());
		assertEquals("Words", iter.next());
		assertEquals(false, iter.hasNext());
		iter.remove();
		
	}
	
	@Test
	public void testGrowdffddfgingArray(){
		MySortedSet<String> test = new MySortedSet<String>();
		test.add("x");
		test.add("a");
		test.add("d");
		test.add("j");
		test.add("h");
		test.add("q");
		test.add("g");
		test.add("w");
		test.add("r");
		test.add("t");
		test.add("y");
		test.add("z");
		test.add("i");
		test.add("q");
		test.add("s");
		test.add("e");
		test.add("r");
		test.add("f");
		test.add("g");
		test.add("u");
		test.add("i");
		test.add("w");
		test.add("e");
		test.add("j");
		test.add("t");
		test.add("y");
		test.add("k");
		test.add("l");
		Iterator iter = test.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());
		}
		
		
	}
}
