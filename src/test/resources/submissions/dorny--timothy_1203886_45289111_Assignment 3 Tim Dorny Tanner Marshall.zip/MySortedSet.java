//Tanner Marshall
//Tim Dorny
//Assignment 3
//2/5/2015

package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E>{
	
	private E[] set;
	private Comparator comp;
	//used to keep track of number of items currently stored in array
	private int numElements;
	
	
	public MySortedSet() {
		
		set = (E[]) new Object[10];
		numElements = 0;
		comp = null;
	}
	
	public MySortedSet(Comparator<? super E> e) {
		
		set = (E[]) new Object[10];
		numElements = 0;
		this.comp = e;
	}
	
	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator comparator() {
		return comp;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (set == null) {
			throw new NoSuchElementException();
		}
		return (E) set[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		//exception thrown
		if (set == null) {
			throw new NoSuchElementException();
		}
		Object last = set[0];
		for (int i = 1; i < set.length; i++) {
			if (set[i] == null) {
				return (E) last;
			}
			last = set[i];
		}
		return (E) set[set.length - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(Object o) {
		if (set[0] == null) {
			
			set[0] = (E) o;
			numElements = 1;
			return true;
		} else if (numElements == set.length) {
			// create new array with double the size
			E[] tempSet = (E[]) new Object[set.length * 2];
			// fill new array with values from original set
			for (int j = 0; j < set.length; j++) {

				tempSet[j] = set[j];
			}
			set = tempSet;
		}
		//adds specified element	
		
		//if using natural ordering
			if (comp == null) {
				//starting index
				int index = numElements / 2;
				int top = numElements;
				int bot = 0;
				//becomes true once final index is reached
				boolean finalIndex = false;
				while (true) {

					//compares the objects
					int compareValue = ((Comparable<E>) set[index]).compareTo((E) o);
					//changes bounds based on result of compareTo
					if (compareValue > 0) {
						if (top - bot == 1) {
							index = bot;
							finalIndex = true;

						}
						top = index;
						index = (top + bot) / 2;
					}
					else if (compareValue < 0) {
						if (top - bot == 1) {
							index = top;
							finalIndex = true;
							
						}
						bot = index;
						index = (top + index) / 2;
					}
					//if duplicate is found, returns false
					else if (compareValue == 0) {
						return false;
					}

					//once final index is reached creates new array with new object place in correct order
					if (finalIndex) {

						// create new array with double the size
						E[] tempSet = (E[]) new Object[set.length];
						// fill new array with values from original set
						for (int j = 0; j < index; j++) {
							tempSet[j] = set[j];
						}
						tempSet[index] = (E) o;
						for (int j = index + 1; j < set.length; j++) {
							tempSet[j] = set[j - 1];
						}
						numElements ++;
						set = tempSet;
						return true;
					}
				}
			}			//if constructor was given a comparator
						else if (comp != null) {
							//starting index
							int index = numElements / 2;
							int top = numElements;
							int bot = 0;
							//becomes true once final index is reached
							boolean finalIndex = false;
							while (true) {

								//compares the objects
								int compareValue = comp.compare(set[index], (E) o);
								//changes bounds based on result of compareTo
								if (compareValue > 0) {
									if (top - bot == 1) {
										index = bot;
										finalIndex = true;

									}
									top = index;
									index = (top + bot) / 2;
								}
								else if (compareValue < 0) {
									if (top - bot == 1) {
										index = top;
										finalIndex = true;
										
									}
									bot = index;
									index = (top + index) / 2;
								}
								//if duplicate is found, returns false
								else if (compareValue == 0) {
									return false;
								}

								//once final index is reached creates new array with new object place in correct order
								if (finalIndex) {

									// create new array with double the size
									E[] tempSet = (E[]) new Object[set.length];
									// fill new array with values from original set
									for (int j = 0; j < index; j++) {
										tempSet[j] = set[j];
									}
									tempSet[index] = (E) o;
									for (int j = index + 1; j < set.length; j++) {
										tempSet[j] = set[j - 1];
									}
									numElements ++;
									set = tempSet;
									return true;

					}
				}

			}
		return false;

	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection c) {
		Boolean ans = false;
		for( Object o : c){
			add(o);
			// Once set has changed ans will equal true
			if(add(o) && ans==false){
				ans=true;
			}
		}
		return ans;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		for( int i=0; i<numElements; i++){
			set[i]=null;
		}
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		//using natural ordering
		if (comp == null) {
			// starting index
			int index = numElements / 2;
			int top = numElements;
			int bot = 0;
			// becomes true once match is found
			boolean finalIndex = false;
			while (true) {

				// compares the objects
				int compareValue = ((Comparable<E>) set[index]).compareTo((E) o);
				// changes bounds based on result of compareTo
				if (compareValue > 0) {
					if (top - bot == 1) {
						index = bot;
						finalIndex = true;
					}
					top = index;
					index = (top + bot) / 2;
				} else if (compareValue < 0) {
					if (top - bot == 1) {
						index = top;
						finalIndex = true;
					}
					bot = index;
					index = (top + index) / 2;
				}
				// if match is found, returns true
				else if (compareValue == 0) {
					return true;
				}

				//if no match is found, returns false
				if (finalIndex) {
					return false;
				}
			}
		} 
		//essentially same code as above, just using Comparator's compare method rather than compareTo
		//after writing these two methods, we realized we should have just made a separate binary search method
		else {

			int index = numElements / 2;
			int top = numElements;
			int bot = 0;
			// becomes true once match is found
			boolean finalIndex = false;
			while (true) {

				// compares the objects
				int compareValue = comp.compare(set[index], (E) o);
				// changes bounds based on result of compareTo
				if (compareValue > 0) {
					if (top - bot == 1) {
						index = bot;
						finalIndex = true;

					}
					top = index;
					index = (top + bot) / 2;
				} else if (compareValue < 0) {
					if (top - bot == 1) {
						index = top;
						finalIndex = true;

					}
					bot = index;
					index = (top + index) / 2;
				}
				// if match is found, returns true
				else if (compareValue == 0) {
					return true;
				}

				//if no match is found returns false
				if (finalIndex) {
					return false;
				}
			}
		}

	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection c) {
		for( Object o : c){
			contains(o);
			// Once one object from collection is not found, method will return false
			if(!contains(o)){
				return false;
			}
		}
		//if each element is found, returns true
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		for( int i=0; i<set.length; i++){
			if(set[i]!=null)
				return false;
		}
		return true;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator iterator() {
		Iterator iter = new SetIterator();
		return iter;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		for (int i = 0; i < numElements; i++) {
			if (set[i] == o) {
				//new array with specified object removed
				E[] tempSet = (E[]) new Object[set.length];
				//fill up to index of removed item
				for (int j = 0; j < i; j++) {
					tempSet[j] = set[j];
				}
				//fill rest of array, excluding item to be removed
				for (int j = i; j < set.length - 1; j++) {
					tempSet[j] = set[j + 1];
				}
				set = tempSet;
				numElements--;
				return true;
			}
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection c) {
		Boolean ans = false;
		for( Object o : c){
			remove(o);
			// Once set has changed ans will equal true
			if(remove(o) && ans==false){
				ans=true;
			}
		}
		return ans;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {

		return numElements;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {

		return set;
	}
	
	// new class
	private class SetIterator<E> implements Iterator<E> {
		
		private int index;
		private E selection;
		
		public SetIterator () {
			index = 0;
		}

		@Override
		public boolean hasNext() {
			if (set[index] == null)
				return false;
				
			return true;
		}

		@Override
		public E next() {
			selection = (E)set[index];
			index++;
			return selection;
		}
		
		@Override
		public void remove() {
			selection = null;
		}

	}
}
