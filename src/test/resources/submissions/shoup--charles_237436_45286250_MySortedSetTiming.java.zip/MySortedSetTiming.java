package assignment3;
/**
 * 
 * @author Charles Shoup
 *
 */
public class MySortedSetTiming 
{
		
	public static void main(String[] args)
	{
		MySortedSet set = new MySortedSet();
		
		long startTime, midpointTime, stopTime, timesToLoop, timeForOperation, timeForLoop;
		int adds;
		
		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) {} //empty block
		
		startTime = System.nanoTime();
		for(int i = 0; i < 10000; i++){}
		stopTime = System.nanoTime();
		
		timeForLoop = (stopTime - startTime)/10000;
		timeForOperation = 0;
		timesToLoop = 100;
		
		for (int x = 1; x <= 20; x++)
			{
				for (int y = 1; y < timesToLoop; y++)
				{
					startTime = System.nanoTime();
					for (int i = 0; i < x*100000; i++)
						{
							set.add(i);
						}			
					stopTime = System.nanoTime();
							    
					timeForOperation += stopTime - startTime - (timeForLoop*100000);
				}
				
				adds = x*100000;
				timeForOperation = timeForOperation / timesToLoop;				
				
				System.out.println("Time to perform " + adds + " adds is " + timeForOperation + " nanoseconds");
				
				timeForOperation = 0;
			}			
		
		System.out.println("---------------------------------------------------");
		
		for (int x = 1; x <= 20; x++)
		{
			for (int y = 1; y < timesToLoop; y++)
			{
				
				for (int i = 0; i < x*100000; i++)
					{
						set.add(i);
					}	
				int value = (-x*100000)-6570+y;
				startTime = System.nanoTime();
				set.add(value);
				stopTime = System.nanoTime();
						    
				timeForOperation += stopTime - startTime;
			}
			
			adds = x*100000;
			timeForOperation = timeForOperation / timesToLoop;				
			
			System.out.println("Time to perform one ~random add on a " + adds + " member set is "+ timeForOperation + " nanoseconds");
			
			timeForOperation = 0;
		}
		
		
		
		
	}        
}
