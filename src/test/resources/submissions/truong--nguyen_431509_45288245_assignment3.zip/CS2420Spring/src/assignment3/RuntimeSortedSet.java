package assignment3;

import java.util.Random;

/**
 * @author Richard Campbell
 * @author Nguyen Truong
 *
 */
public class RuntimeSortedSet {
	private static MySortedSet<Integer> setInt = new MySortedSet();
	
	public static void generateRandomNumbers(MySortedSet arr, long _size){
		/* generate random negative & positive # (no duplicate) */
		Random num = new Random();
		int random;
		for(int count = 0; count < _size; count++){
			random = (num.nextInt(99999999));
			/* Also test & add contains, */
			if(arr.contains(random) == true){
				count--;
			}else if(arr.contains(random) == false){
				arr.add(random);
			}
		}
	}

	public static void main(String[] args) {
		long startTime, midpointTime, stopTime;
		generateRandomNumbers(setInt, 400000);
	    // First, spin computing stuff until one second has gone by.
	    // This allows this thread to stabilize.

	    startTime = System.nanoTime();
	    while (System.nanoTime() - startTime < 1000000000) { // empty block
	    }

	    // Now, run the test.

	    long timesToLoop = 1000;

	    startTime = System.nanoTime();

	    for (long i = 0; i < timesToLoop; i++)
	      setInt.add(6);

	    midpointTime = System.nanoTime();

	    // Run an empty loop to capture the cost of running the loop.

	    for (long i = 0; i < timesToLoop; i++) { // empty block
	    	
	    }

	    stopTime = System.nanoTime();
	    setInt.remove(6);
	    // Compute the time, subtract the cost of running the loop
	    // from the cost of running the loop and computing square roots.
	    // Average it over the number of runs.

	    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
	        / timesToLoop;

	    System.out.println("It takes exactly " + averageTime
	        + " nanoseconds to setInt.contain()");

	}

}
