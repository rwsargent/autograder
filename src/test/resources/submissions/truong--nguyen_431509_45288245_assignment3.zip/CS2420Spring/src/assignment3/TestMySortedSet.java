package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author Richard Campbell
 * @author Nguyen Truong
 *
 */
public class TestMySortedSet {
	/* My Sorted Set variable for testing method */
	private MySortedSet<Integer> setInt; 
	private MySortedSet<String> setString;
	/* Arrays to use for testing add, remove, contain collection method */
	private ArrayList<Integer> arr1 = new ArrayList<>();
	private ArrayList<Integer> arr2 = new ArrayList<>();
	private ArrayList<Integer> arr3 = new ArrayList<>();

	@Before
	public void setUp() throws Exception {
		/* Initialize variable & arrays */
		setInt = new MySortedSet();
		setString = new MySortedSet();
		
		/* Add to setString */
		setString.add("John");
		setString.add("Bill");
		setString.add("Luke");
		setString.add("Larry");
		setString.add("Lisa");
		setString.add("Jane");
		setString.add("Larry");
		
		arr1.add(23);
		arr1.add(11);
		arr1.add(-12);
		arr1.add(33);
		arr1.add(986);
		arr1.add(5687);
		arr1.add(-4356);
		arr1.add(45);
		arr1.add(91);
		arr1.add(0);
		
		arr2.add(23);
		arr2.add(11);
		arr2.add(-12);
		arr2.add(33);
		arr2.add(986);
		
		arr3.add(23);
		arr3.add(11);
		arr3.add(-12);
		arr3.add(33);
		arr3.add(9000);
	}

	@After
	public void tearDown() throws Exception {
	}

	/* Test Size, Normal Case: Add, Contain Method */
	@Test
	public void testSizeMethod() {
		/* generate random negative & positive # (no duplicate) */
		Random num = new Random();
		int random;
		int arrSize = 10;
		for(int count = 0; count < arrSize; count++){
			random = 10 - (num.nextInt(20));
			/* Also test & add contains, */
			if(setInt.contains(random) == true){
				count--;
			}else if(setInt.contains(random) == false){
				setInt.add(random);
			}
		}

		assertEquals(arrSize, setInt.size());
	}
	
	/* Test Add Method */
	@Test
	public void testAddMethodInt() {
		setInt.add(7);
		assertEquals(true, setInt.contains(7));
		setInt.add(8);
		assertEquals(true, setInt.contains(8));
	}
	
	@Test
	public void testAddMethodNullInt() {
		assertEquals(false, setInt.add(null));
	}
	
	@Test
	public void testAddMethodDuplicateInt() {
		setInt.add(1);
		assertEquals(false, setInt.add(1));
	}
	
	@Test
	public void testAddAllInt() {
		setInt.addAll(arr1);
		for(int i = 0; i < arr1.size(); i++){
			assertEquals(true, setInt.contains(arr1.get(i)));
		}	
	}
	
	@Test
	public void testAddMethodDuplicationString(){
		assertEquals(6, setString.size());
	}
	
	@Test
	public void testRemoveMethodString() {
		assertEquals(true, setString.remove("Lisa"));		
	}
	
	@Test
	public void testRemoveAll() {
		setInt.addAll(arr1);
		assertEquals(true, setInt.removeAll(arr2));
	}
	
	@Test
	public void testFirstMethodInt() {
		setInt.add(7);
		setInt.add(-3);
		int result = -3;
		assertEquals((Integer) result, setInt.first());
	}
	
	@Test
	public void testLastMethodInt(){
		setInt.add(52);
		setInt.add(-3);
		setInt.add(10);
		int result = 52;
		assertEquals((Integer) result, setInt.last());
	}
	
	@Test
	public void testContainsMethodString() {
		assertEquals(true, setString.contains("Bill"));
	}
	
	@Test
	public void testContainsMethodFalseString() {
		assertEquals(false, setString.contains("Alice"));
	}
	
	@Test
	public void testContainsAllMethod() {
		setInt.addAll(arr1);
		assertEquals(true, setInt.containsAll(arr2));
	}
	
	@Test
	public void testContainsAllFalse() {
		setInt.addAll(arr1);
		assertEquals(false,setInt.containsAll(arr3));
	}
	
	@Test
	public void testClearMethodString() {
		setString.clear();
		assertEquals(0, setString.size());
	}
	
	@Test
	public void testIsEmptyMethodString() {
		setString.clear();
		assertEquals(true, setString.isEmpty());
	}
	
	@Test
	public void testIsEmptyMethodFalseString() {
		setString.add("Larry");
		assertEquals(false, setString.isEmpty());
	}
	
	@Test
	public void testToArrayMethod(){
		Object[] arrString = setString.toArray();
		for(int i = 0; i < setString.size(); i++){
			assertEquals(true, setString.contains(arrString[i]));
		}
	}
	
	@Test
	public void testShrink(){
		setInt.addAll(arr1);
		boolean shrink = false;
		setInt.removeAll(arr2);
		setInt.remove(91);
		setInt.remove(0);
		if(setInt.length() <= setInt.size()){
			shrink=true;
		}
		else
			shrink=false;
	}

	@Test
	public void testGrow(){
		setInt.addAll(arr1);
		assertEquals(true, setInt.length() > 7);
	}
}
