package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;


/**
 * @author Nguyen Truong
 * @author Richard Campbell
 *
 * @param <E>
 */

public class MySortedSet<E> implements SortedSet<E> {
	/* Initialize needed variable */
	private int maxLength = 7;
	private int itemsInArray;
	private E[] mainArray;
	private Comparator<? super E> comp; 
	
	/**
	 * Constructor is used to create sorted set that would use Comparable
	 * It's elements are ordered using their natural ordering
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(){
		Object arr[] = new Object[maxLength];
		mainArray = (E[]) arr;
		itemsInArray = 0;
	}
	
	/**
	 * Constructor is used to created sorted set that would use provided Comparator
	 * It's assumed that elements are ordered using the provided comparator
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> _comp){
		Object arr[] = new Object[maxLength];
		mainArray = (E[]) arr;
		itemsInArray = 0;
		comp = _comp;
	}



	@Override
	/**
	 * Get the comparator use to sort this set, provided by user
	 * @return The comparator used to order the elements in this set
	 * @return: null, if this set uses the natural ordering of its elements (i.e., uses Comparable).
	 */
	public Comparator<? super E> comparator() {
		if(this.comparator() != null)
			return comp;				
		return null;
	}

	@Override
	/**
	 * Get the first element in sorted set
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException if the set is empty
	 */
	public E first() throws NoSuchElementException {
		if(itemsInArray == 0)
			throw new NoSuchElementException();
		else
			return mainArray[0];
	}

	@Override
	/**
	 * Get the last element in sorted set
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if(itemsInArray == 0)
			throw new NoSuchElementException();
		else
			return mainArray[itemsInArray-1];
	}

	@Override
	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * @param o: element to be added to this set
	 * @return: true if this set did not already contain the specified element
	 */
	public boolean add(E o) {
		/* if there duplicate or element is null, return false */
		if(o == null)
			return false;
		if(this.contains(o) == true)
			return false;
		/* If there are no more room in array, double the array size */
		if(itemsInArray >= maxLength){
			E[] tempArr = (E[]) new  Object[maxLength * 2];
			for(int i = 0; i < mainArray.length; i++){
				tempArr[i] = mainArray[i];
			}
			mainArray = tempArr;
			maxLength = mainArray.length;
		}
		
		/* Add element o to sorted set using binary search (call binarySearchPos()), 
		 * assuming that set is sorted */
		int insertIndex = binarySearchPos(mainArray, o);
		for(int i = itemsInArray-1 ; i >= insertIndex; i--){
			int j = i;
			mainArray[j+1] = mainArray[i];
		}
		mainArray[insertIndex] = o;
		itemsInArray++;
		return true;
	}
	
	/**
	 * Helper class, check and use the correct compare method depend on which constructor was called
	 * @param item1
	 * @param item2
	 * @return
	 */
	private int compare(E item1, E item2){
		if(comp == null)
			return ((Comparable<E>) item1).compareTo(item2);
		else
			return comp.compare(item1, item2);
	}
	
	/**
	 * Helper class
	 * Find the appropriate index to insert an element in sortedSet
	 * @param arr: array to search through
	 * @param element: element we need to insert
	 * @return: correct index where element would be if it were to be added in the array
	 */
	private int binarySearchPos(E[] arr, E element) {
		int midIndex = 0;
		int left = 0;
		int right = itemsInArray - 1;
		if (itemsInArray == 0)
			return midIndex;
		while (true) {
			midIndex = (right + left) / 2;
			if (compare(element, arr[midIndex]) == 0) {
				return midIndex;
			/* if element is less than the mid-element, it belong to the left side */
			} else if (compare(element, arr[midIndex]) > 0) {
				left = midIndex + 1;
				if (left > right)
					return midIndex + 1;
			/* if element is greater then the mid-element, it belong to the right side */
			} else {
				right = midIndex - 1;
				if (left > right)
					return midIndex;
			}
		}
	}

	@Override
	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * @param c: collection containing elements to be added to this set
	 * @return: true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
		boolean setChange = false;
		for(E element: c){
			add(element); 
			setChange = true;
		}
		return setChange;
	}

	@Override
	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		for(E element : mainArray){
			remove(element);
		}
		itemsInArray = 0;
		
	}

	@Override
	/**
	 * Check if sorted set array contain a specific element
	 * @param o: element whose presence in this set is to be tested
	 * @return: true if this set contains the specified element
	 * @return: false, if set doesn't contain specified item, or is an empty array
	 */
	public boolean contains(Object o) {
		if(itemsInArray == 0)
			return false;
		if(found(mainArray, (E) o) == -1)
			return false;
		else
			return true;
		
	}
	
	/**
	 * Helper method for contain, go through array binary
	 * @param arr: array for searching
	 * @param element: element to look for
	 * @return: -1 if not found element
	 * @return: index where element is found
	 */
	private int found(E[] arr, E element){	// change to int for remove method
		int left = 0;
		int right = itemsInArray - 1;
		while(left <= right){
			int midIndex = (right + left)/2;
			if(compare(element, arr[midIndex]) == 0){
				//System.out.println(midIndex + "hi");
				return midIndex;
			}else if(compare(element, arr[midIndex]) < 0){
				right = midIndex - 1;
			}else if(compare(element, arr[midIndex]) > 0){
				left = midIndex + 1;
			}
		}
		return -1;
	}

	@Override
	/**
	 * Check if sorted set contain a collection of element
	 * @param c: collection to be checked for containment in this set
	 * @return: true if this set contains all of the elements of the specified collection
	 */
	public boolean containsAll(Collection<?> c) {
		boolean containsAllElement = true;
		for(Object element: c){
			if(contains(element) == false)
				containsAllElement = false;
		}
		return containsAllElement;
	}

	@Override
	/**
	 * Check if sorted set is empty
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		if(itemsInArray == 0)
			return true;
		return false;
	}

	@Override
	/**
	 * Create an iterator
	 * Uses the class MyIterator on the bottom
	 * @return: an iterator over the elements in this set, 
	 * 			where the elements are returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		Iterator<E> traverse = new MyIterator();
		return traverse;
	}

	@Override
	/**
	 * Removes the specified element from this set if it is present.
	 * @param o: object to be removed from this set, if present
	 * @return: true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		if(o == null){
			return false;
		}
		/* If the item does not exist in the array, return false */
		if(this.contains(o) == false){
			return false;
		}
		/* If more than half of the array are empty, shrink array by half */
		if(itemsInArray == maxLength/2){
			E[] tempArr = (E[]) new  Object[maxLength / 2 + 1];
			for(int i = 0; i < itemsInArray; i++){
				tempArr[i] = mainArray[i];
			}
			mainArray = tempArr;
		}
		/* Remove item using binary search*/
		int removeIndex = found(mainArray, (E) o);
		for(int i = removeIndex; i < itemsInArray; i++){
			mainArray[i] = mainArray[i+1];
		}
		itemsInArray--;
		return true;
	}

	@Override
	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * @param c: collection containing elements to be removed from this set
	 * @return: true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		boolean setChange = false;
		for(Object element: c){
			remove(element); 
			setChange = true;
		}
		return setChange;
	}

	@Override
	/**
	 * Get size of the sorted set
	 * @return the number of elements in this set
	 */
	public int size() {
		return itemsInArray;
	}
	
	/**
	 * Get the length of the sorted set
	 * @return: the length of this set
	 */
	public int length(){
		return mainArray.length;
	}

	@Override
	/**
	 * Get all elements in sorted set into an array
	 * @return: an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		Object arr[] = new Object[itemsInArray];
		for(int i=0; i < itemsInArray; i++){
				arr[i] = mainArray[i];
		}
		return arr;
	}
	
	/**
	 * Iterator class
	 * this is called above by iterator()
	 *
	 */
	public class MyIterator implements Iterator<E>{
		/* variable keep track of index & whether next has been called */
		private int index = 0;
		private boolean calledNext = false;
		
		/**
		 * @return: true if array have a next item
		 * @return: false otherwise
		 */
		@Override
		public boolean hasNext() {
			return (index < itemsInArray);
		}

		/**
		 * @return: next element in array
		 */
		@Override
		public E next() throws NoSuchElementException {
			if(!this.hasNext())
				throw new NoSuchElementException();
			calledNext = true;
			return mainArray[index++];
		}
		
		/**
		 * Remove the last item called by next
		 * Don't need to throw UnsupportedMethodException because we do have a remove method
		 */
		@Override
		public void remove() throws IllegalStateException{
			/* if next haven't been called, throw exception */
			if(calledNext != true)
				throw new IllegalStateException();
			mainArray[index] = null;
			itemsInArray--;
			calledNext = false;
		}
		
	}
}
