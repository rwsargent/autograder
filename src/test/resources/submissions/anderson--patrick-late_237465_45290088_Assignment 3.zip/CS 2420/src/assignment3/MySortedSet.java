package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 * Patrick Egan Anderson & Cole Wilkes
 *
 */
public class MySortedSet<E> implements SortedSet<E> {
	private Object[] mySet; // this array is compatible with all object types
							// and backs MySortedSet
	private int totalElements; // keeps track of the size of the array
	private Comparator<? super E> comparator; // the comparator returned by the
												// comparator method
	private int initialLength = 3; // sets the initial length of mySet
	private boolean hasComparator;

	/**
	 * This constructor is used to create the sorted set when it is assumed that
	 * the elements are ordered using their natural ordering
	 */
	public MySortedSet() {
		hasComparator = false;
		mySet = new Object[initialLength];
		totalElements = 0;
	}

	/**
	 * This constructor is used to create the sorted set when it is assumed that
	 * the elements are ordered using the provided comparator
	 */
	public MySortedSet(Comparator<? super E> comp) {
		hasComparator = true;
		mySet = new Object[initialLength];
		totalElements = 0;
		comparator = comp;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (mySet[0] != null)
			return (E) mySet[0]; // returns the first element of the set if it
									// exists
		else
			throw new NoSuchElementException(); // throws an exception if the
												// first element doesn't exist
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (mySet[0] != null)
			return (E) mySet[totalElements - 1]; // returns the last element of
													// the
													// set if it exists
		else
			throw new NoSuchElementException(); // throws an exception if the
												// last element doesn't exist
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		if (o == null) {
			return false;
		}
		if (totalElements == mySet.length) { // if the size of mySet reaches
												// the maximum length, the
												// length is doubled
			Object[] temp = new Object[mySet.length * 2];
			for (int i = 0; i < totalElements; i++)
				temp[i] = mySet[i];
			mySet = temp;
		}
		if (mySet[0] == null) { // inserts the first element without conducting
								// a binary search
			mySet[0] = o;
			totalElements++;
			return true;
		}
		int location = search(o); // uses binary search to determine where the
									// new element should be added
		// System.out.println("Location = " + location + "\nObject = " + o);

		if (!hasComparator)  {
			if (location < totalElements && mySet[location] == o) // checks if the object is already contained
										// in mySet
				return false; // if the object is null or if it is already contained
								// in mySet, returns false
			else {
				for (int i = totalElements - 1; i >= location; i--) {
					mySet[i + 1] = mySet[i]; // every element larger than the input
						// element is moved to the right,
						// and the input element is inserted
				}
			}
			mySet[location] = o;
			totalElements++; // the size of mySet is incremented
			return true; // returns true if the object was not already in mySet
		} else {
			if (location < totalElements && comparator.compare((E) mySet[location], o) == 0) // checks if the object is already contained
										// in mySet
				return false; // if the object is null or if it is already contained
								// in mySet, returns false
			else {
				for (int i = totalElements - 1; i >= location; i--) {
					mySet[i + 1] = mySet[i]; // every element larger than the input
						// element is moved to the right,
						// and the input element is inserted
				}
			}
			mySet[location] = o;
			totalElements++; // the size of mySet is incremented
			return true; // returns true if the object was not already in mySet
		}
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean changed = false;
		for (E o : c) { // if any changes are made to mySet, changed = true
			if (add(o)) // adds all elements that are not already contained
				changed = true;
		}
		return changed; // returns either true or false
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		for (int i = 0; i < totalElements; i++)
			mySet[i] = null; // goes through every element of mySet and sets
								// them all to null
		totalElements = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {
		int location = search(o);
		if (hasComparator) {
			if (location < totalElements && comparator.compare((E) mySet[location], (E)o) == 0) {
				return true;
			} else {
				return false;
			}
		} else {
			if (location < totalElements && mySet[location] == o) // checks if the object is already contained
										// in mySet
				return true; // returns true if the element is in mySet
			else
				return false; // returns false otherwise
		}
		
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for (Object o : c)
			if (mySet[search(o)] != o)
				return false; // returns false if any elements of the specified
								// collection are not in mySet
		return true; // returns true otherwise
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (mySet[0] == null)
			return true; // returns true if the first element is null
		else
			return false; // returns false otherwise
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new SortedSetIterator(); // returns an iterator object
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int location = search(o);
		if(hasComparator) {
			if (location >= totalElements || comparator.compare((E) mySet[location],(E) o) != 0)
				return false; // returns false if the specified element was not
								// contained in mySet
			else {
				for (int i = location; i < totalElements - 1; i++) {
					mySet[i] = mySet[i + 1]; // moves all elements to the left,
												// replacing the specified object
				}
				totalElements--; // decrements the size of mySet
				return true; // returns true if the specified element was contained
								// in mySet
			}
		} else {
			if (location >= mySet.length || mySet[location] != o)
				return false; // returns false if the specified element was not
								// contained in mySet
			else {
				for (int i = location; i < totalElements - 1; i++) {
					mySet[i] = mySet[i + 1]; // moves all elements to the left,
												// replacing the specified object
				}
				totalElements--; // decrements the size of mySet
				return true; // returns true if the specified element was contained
								// in mySet
			}
		}
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean changed = false;
		for (Object o : c) {
			if (remove(o)) // removes from mySet all elements contained in c
				changed = true; // if any elements are removed, changed = true
		}
		return changed; // returns either true or false
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return totalElements; // returns the size of mySet
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object[] output = new Object[totalElements];
		for (int i = 0; i <= totalElements - 1; i++)
			output[i] = mySet[i];
		return output; // returns mySet
	}

	/**
	 * This binary search is used to determine where an object should be
	 * inserted if it isn't already contained in mySet, or where the object is
	 * located if it is contained in mySet.
	 * 
	 * @param o
	 *            -- object that is being searched for
	 * @return if the input object isn't already contained, the index where it
	 *         should be inserted is returned. if the input object is contained,
	 *         its index is returned
	 */
	public int search(Object o) {
		int startpoint = 0;
		int endpoint = totalElements - 1;
		int midpoint;

		if (comparator == null) { // If the MySortedSet object doesn't include a
									// comparator, the compareTo method will be
									// used for the comparisons
			Comparable comparableO = (Comparable) o;
			while (startpoint <= endpoint) {
				// System.out.println("Inside while loop (Comparable)");
				midpoint = (startpoint + endpoint) / 2;
				if (comparableO.compareTo(mySet[midpoint]) < 0)
					endpoint = midpoint - 1;
				// else if (comparableO.compareTo(mymySet[midpoint]) < 0
				// || midpoint == 0)
				// endpoint = midpoint;
				else if (comparableO.compareTo(mySet[midpoint]) > 0)
					startpoint = midpoint + 1;
				else
					return midpoint;
			}
			if (endpoint > -1 && comparableO.compareTo(mySet[endpoint]) < 0)
				return endpoint;
			else
				return endpoint + 1;

		} else { // If the MySortedSet object includes a
					// comparator, it will be used for the comparisons
			while (startpoint <= endpoint) {
				// System.out.println("Inside while loop (Comparator)");
				midpoint = (startpoint + endpoint) / 2;
				if (comparator.compare((E) o, (E) mySet[midpoint]) < 0)
					endpoint = midpoint - 1;
				// else if (comparator.compare((E) o, (E) mySet[midpoint]) < 0)
				// endpoint = midpoint;
				else if (comparator.compare((E) o, (E) mySet[midpoint]) > 0)
					startpoint = midpoint + 1;
				else
					return midpoint;
			}
			if (endpoint > -1
					&& comparator.compare((E) o, (E) mySet[endpoint]) < 0)
				return endpoint;
			else
				return startpoint;

		}
	}

	/*
	 * public int search2(Object o) { int startpoint = 0; int endpoint =
	 * totalElements - 1; int midpoint;
	 * 
	 * Comparable compO = (Comparable) o;
	 * 
	 * while (startpoint <= endpoint) { midpoint = (startpoint + endpoint) / 2;
	 * if (compO.compareTo(mySet[midpoint]) > 0) { startpoint = midpoint + 1; }
	 * else if (compO.compareTo(mySet[midpoint]) < 0){ endpoint = midpoint - 1;
	 * } else { return midpoint; } }
	 * 
	 * return 0; }
	 */

	protected class SortedSetIterator<E> implements Iterator {
		private int index = -1;
		private boolean isValid = false;

		/**
		 * Returns true if the iteration has more elements. (In other words,
		 * returns true if next() would return an element rather than throwing
		 * an exception.
		 */
		@Override
		public boolean hasNext() {
			return (index < totalElements - 1);
		}

		/**
		 * Returns the next element in the iteration.
		 */
		@Override
		public E next() {
			index++;
			isValid = true;
			if (index >= totalElements) {
				throw new NoSuchElementException();
			}
			return (E) mySet[index];
		}

		/**
		 * Removes from the underlying collection the last element returned by
		 * this iterator (optional operation). This method can be called only
		 * once per call to next(). The behavior of an iterator is unspecified
		 * if the underlying collection is modified while the iteration is in
		 * progress in any way other than by calling this method.
		 */
		@Override
		public void remove() {
			if (isValid) {
				MySortedSet.this.remove(mySet[index]);
				isValid = false;
				index--;
			} else
				throw new IllegalStateException();

		}
	}
}
