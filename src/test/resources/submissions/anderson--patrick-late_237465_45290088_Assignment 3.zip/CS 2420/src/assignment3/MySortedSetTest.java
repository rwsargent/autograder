package assignment3;

import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.math.BigInteger;

import org.junit.Test;

/**
 * 
 * Patrick Egan Anderson & Cole Wilkes
 *
 */
public class MySortedSetTest {
	private MySortedSet<Integer> sortedSet;
	private MySortedSet<BigInteger> sortedSetWithComparator;
	private Collection c;

	/**
	 * Method being tested: toArray - Tests that a sortedSet is properly
	 * returned as an array
	 */
	@Test
	public void testToArray1() {
		sortedSet = new MySortedSet<Integer>();

		assertArrayEquals(sortedSet.toArray(), new Object[0]);
	}

	/**
	 * Method being tested: toArray - Tests that a sortedSet is properly
	 * returned as an array
	 */
	@Test
	public void testToArray2() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(4);

		Object[] collection = new Object[4];
		collection[0] = 1;
		collection[1] = 2;
		collection[2] = 3;
		collection[3] = 4;

		assertArrayEquals(sortedSet.toArray(), collection);
	}

	/**
	 * Method being tested: search Tests that an object is correctly located in
	 * a list (if it exists)
	 */
	@Test
	public void testSearch1() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();

		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(4);

		assertEquals(sortedSet.search(3), 2);

		// test using constructor that takes comparator
		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
		
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("2"));
		sortedSetWithComparator.add(new BigInteger("3"));
		sortedSetWithComparator.add(new BigInteger("4"));
		
		assertEquals(sortedSet.search(3), 2);
		
	}

	/**
	 * Method being tested: search Should return the location where an object
	 * should be inserted if it isn't already on the list
	 */
	@Test
	public void testSearch2() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();

		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(6);

		assertEquals(sortedSet.search(5), 3);
		
		// test using constructor that takes comparator
		// test using constructor that takes comparator
		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
				
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("2"));
		sortedSetWithComparator.add(new BigInteger("3"));
		sortedSetWithComparator.add(new BigInteger("6"));
				
		assertEquals(sortedSet.search(5), 3);
	}

	/**
	 * method being tested: add - Tests to make sure that elements are being added
	 * in sorted order
	 */
	@Test
	public void testAdd1() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(6);
		sortedSet.add(2);

		Object[] expectedArr = { 2, 6 };

		assertArrayEquals(sortedSet.toArray(), expectedArr);

		// test using constructor that takes comparator
		BigInteger[] expectedArray = { new BigInteger("2"), new BigInteger("6") };

		sortedSetWithComparator = new MySortedSet<BigInteger>(
				new OurComparator());
		sortedSetWithComparator.add(new BigInteger("6"));
		sortedSetWithComparator.add(new BigInteger("2"));
		sortedSetWithComparator.add(new BigInteger("2"));

		assertArrayEquals(sortedSetWithComparator.toArray(), expectedArray);
	}

	/**
	 * Method being tested: add Tests to make sure that "null" cannot be added
	 * to MySortedSet
	 */
	@Test
	public void testAdd2() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(null);
		sortedSet.add(3);
		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(null);

		Object[] expectedArray = { 1, 2, 3 };

		assertArrayEquals(sortedSet.toArray(), expectedArray);
		
		// test using constructor that takes comparator
		BigInteger[] expectedArr = { new BigInteger("1"), new BigInteger("2"), new BigInteger("3") };

		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
		sortedSetWithComparator.add(null);
		sortedSetWithComparator.add(new BigInteger("3"));
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("2"));
		sortedSetWithComparator.add(null);

		assertArrayEquals(sortedSetWithComparator.toArray(), expectedArr);
	}

	/**
	 * Method being tested: add Tests to make sure that a duplicate cannot be
	 * added to MySortedSet
	 */
	@Test
	public void testAdd3() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(3);
		sortedSet.add(1);
		sortedSet.add(2);

		Object[] expectedArray = { 1, 2, 3 };

		assertArrayEquals(sortedSet.toArray(), expectedArray);
		
		// test using constructor that takes comparator
		BigInteger[] expectedArr = { new BigInteger("1"), new BigInteger("2"), new BigInteger("3") };

		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("3"));
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("2"));

		assertArrayEquals(sortedSetWithComparator.toArray(), expectedArr);
	}

	/**
	 * Method being tested: add - Tests to see if true is returned when an
	 * element is added, false when element is not added
	 */
	@Test
	public void testAdd4() {
		sortedSet = new MySortedSet<Integer>();

		assertEquals(sortedSet.add(6), true);
		assertEquals(sortedSet.add(2), true);
		assertEquals(sortedSet.add(null), false);
		
		// test using constructor that takes comparator
		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
		
		assertEquals(sortedSetWithComparator.add(new BigInteger("6")), true);
		assertEquals(sortedSetWithComparator.add(new BigInteger("2")), true);
		assertEquals(sortedSetWithComparator.add(null), false);
	}

	/**
	 * Method being tested: add - Tests to see if false is returned when an
	 * element is not added
	 */
	@Test
	public void testAdd5() {
		sortedSet = new MySortedSet<Integer>();

		assertEquals(sortedSet.add(6), true);
		assertEquals(sortedSet.add(6), false);
		
		// test using constructor that takes comparator
		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
				
		assertEquals(sortedSetWithComparator.add(new BigInteger("6")), true);
		assertEquals(sortedSetWithComparator.add(new BigInteger("6")), false);
	}

	/**
	 * Method being tested: addAll - Adds each element from the given array to
	 * sortedSet. Should return true if any changes are made to sortedSet.
	 */
	@Test
	public void testAddAll1() {
		sortedSet = new MySortedSet<Integer>();
		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(2);
		collection.add(3);
		collection.add(4);

		Object[] expectedArray = { 1, 2, 3, 4 };

		assertEquals(sortedSet.addAll(collection), true);
		assertArrayEquals(sortedSet.toArray(), expectedArray);
	}

	/**
	 * Method being tested: addAll - Should return false because no new elements
	 * are added
	 */
	@Test
	public void testAddAll2() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(4);

		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(2);
		collection.add(3);
		collection.add(4);

		assertEquals(sortedSet.addAll(collection), false);
	}

	/**
	 * Method being tested: first - Should return the first element in the set
	 */
	@Test
	public void testFirst1() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(2);

		assertEquals(sortedSet.first(), (Integer) 1);
	}

	/**
	 * Method being tested: first - Should throw an exception if there is no
	 * first element
	 */
	@Test
	public void testFirst2() {
		sortedSet = new MySortedSet<Integer>();
		try {
			sortedSet.first();
		} catch (NoSuchElementException e) {
			System.out.println("Congrats, you caught an exception.");
		}
	}

	/**
	 * Method being tested: first - Should return the first element in the set
	 */
	@Test
	public void testLast1() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(2);

		System.out.println(sortedSet.last());
		assertEquals(sortedSet.last(), (Integer) 2);
	}

	/**
	 * Method being tested: first - Should throw an exception if there is no
	 * first element
	 */
	@Test
	public void testLast2() {
		sortedSet = new MySortedSet<Integer>();
		try {
			sortedSet.last();
		} catch (NoSuchElementException e) {
			System.out.println("Congrats, you caught an exception.");
		}
	}

	/**
	 * Method being tested: clear - Add elements, clear the elements, make sure
	 * first element is null
	 */
	@Test
	public void testClear() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(13);
		sortedSet.add(14);
		sortedSet.add(150);
		sortedSet.add(12);

		sortedSet.clear();

		assertArrayEquals(sortedSet.toArray(), new Object[0]);
		assertEquals(sortedSet.isEmpty(), true);
	}

	/**
	 * Method being tested: contains - Tests that true is returned when the
	 * object is in the list
	 * 
	 */
	@Test
	public void testContains1() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(3);
		sortedSet.add(4);
		sortedSet.add(2);

		assertEquals(sortedSet.contains(4), true);
		
		// test using constructor that takes comparator
		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("3"));
		sortedSetWithComparator.add(new BigInteger("4"));
		sortedSetWithComparator.add(new BigInteger("2"));
				
		assertEquals(sortedSetWithComparator.contains(new BigInteger("3")), true);
	}

	/**
	 * Method being tested: contains - Tests that false is returned when the
	 * object is not in the list
	 * 
	 */
	@Test
	public void testContains2() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(3);
		sortedSet.add(4);
		sortedSet.add(2);

		assertEquals(sortedSet.contains(5), false);
		
		// test using constructor that takes comparator
		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("3"));
		sortedSetWithComparator.add(new BigInteger("4"));
		sortedSetWithComparator.add(new BigInteger("2"));
						
		assertEquals(sortedSetWithComparator.contains(new BigInteger("5")), false);
	}

	/**
	 * Method being tested: addAll - Should return true because all of the
	 * elements from collection are contained in sortedSet
	 */
	@Test
	public void testContainsAll1() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(4);

		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(2);
		collection.add(3);
		collection.add(4);

		assertEquals(sortedSet.containsAll(collection), true);
	}

	/**
	 * Method being tested: addAll - Should return false because not all of the
	 * elements from collection are contained in sortedSet
	 */
	@Test
	public void testContainsAll2() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(4);

		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(2);
		collection.add(3);
		collection.add(5);

		assertEquals(sortedSet.containsAll(collection), false);
	}

	/**
	 * Method being tested: isEmpty - Tests that true is returned when the list
	 * is empty
	 * 
	 */
	@Test
	public void testIsEmpty1() {
		sortedSet = new MySortedSet<Integer>();

		assertEquals(sortedSet.isEmpty(), true);
	}

	/**
	 * Method being tested: isEmpty - Tests that false is returned when the list
	 * is not empty
	 * 
	 */
	@Test
	public void testIsEmpty2() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		assertEquals(sortedSet.isEmpty(), false);
	}

	/**
	 * Method being tested: remove - Tests that the specified object is removed
	 * 
	 */
	@Test
	public void testRemove1() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(3);
		sortedSet.add(1);
		sortedSet.add(2);

		Object[] expectedArray = { 1, 3 };

		assertEquals(sortedSet.remove(2), true);
		assertArrayEquals(sortedSet.toArray(), expectedArray);
		
		// test using constructor that takes comparator
		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
		sortedSetWithComparator.add(new BigInteger("3"));
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("2"));
		
		BigInteger[] expectedArr = { new BigInteger("1"), new BigInteger("3") };
	
		assertEquals(sortedSetWithComparator.remove(new BigInteger("2")), true);
		assertArrayEquals(sortedSetWithComparator.toArray(), expectedArr);
	}

	/**
	 * Method being tested: remove - Tests that the specified object is removed
	 * 
	 */
	@Test
	public void testRemove2() {
		// test using constructor without comparator
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(3);
		sortedSet.add(1);
		sortedSet.add(2);

		Object[] expectedArray = { 1, 2, 3 };

		assertEquals(sortedSet.remove(4), false);
		assertArrayEquals(sortedSet.toArray(), expectedArray);
		
		// test using constructor that takes comparator
		sortedSetWithComparator = new MySortedSet<BigInteger>(new OurComparator());
		sortedSetWithComparator.add(new BigInteger("3"));
		sortedSetWithComparator.add(new BigInteger("1"));
		sortedSetWithComparator.add(new BigInteger("2"));
				
		BigInteger[] expectedArr = { new BigInteger("1"), new BigInteger("2"), new BigInteger("3") };
			
		assertEquals(sortedSetWithComparator.remove(new BigInteger("4")), false);
		assertArrayEquals(sortedSetWithComparator.toArray(), expectedArr);
	}

	/**
	 * Method being tested: removeAll - Removes each element from sortedSet.
	 * Should return true if any changes are made to sortedSet.
	 */
	@Test
	public void testRemoveAll1() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(4);

		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(1);
		collection.add(2);
		collection.add(3);

		Object[] expectedArray = { 4 };

		assertEquals(sortedSet.removeAll(collection), true);
		assertArrayEquals(sortedSet.toArray(), expectedArray);
	}

	/**
	 * Method being tested: removeAll - Returns false if no elements are removed
	 * from sortedSet
	 */
	@Test
	public void testRemoveAll2() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);
		sortedSet.add(2);
		sortedSet.add(3);
		sortedSet.add(4);

		ArrayList<Integer> collection = new ArrayList<Integer>();
		collection.add(5);
		collection.add(7);
		collection.add(8);

		assertEquals(sortedSet.removeAll(collection), false);
	}

	/**
	 * Method being tested: size - Returns the number of elements in sortedSet
	 */
	@Test
	public void testSize1() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(4);
		sortedSet.add(3);
		sortedSet.add(5);

		assertEquals(sortedSet.size(), 3);

		sortedSet.clear();

		assertEquals(sortedSet.size(), 0);
	}

	/**
	 * Iterator method to test:
	 */
	@Test
	public void testIterator1() {
		sortedSet = new MySortedSet<Integer>();
		sortedSet.add(1);

		Iterator<Integer> myIterator = sortedSet.iterator();

		assertEquals(myIterator.hasNext(), true);
		assertSame(myIterator.next(), 1);
		sortedSet.clear();
		sortedSet.add(5);
		sortedSet.add(9);
		sortedSet.add(3);
		Iterator<Integer> myIterator2 = sortedSet.iterator();
		
		myIterator2.next();
		myIterator2.next();
		myIterator2.next();
		myIterator2.remove();
		assertSame(5,sortedSet.last());

		
		
	}

	/**
	 * Method being tested: add Tests to see if the length of MySortedSet
	 * increases when max capacity is reached
	 */
	/*
	 * @Test public void testAdd6() { sortedSet = new MySortedSet();
	 * 
	 * sortedSet.add(1); sortedSet.add(3); sortedSet.add(7); sortedSet.add(2);
	 * 
	 * System.out.println("length = " + sortedSet.toArray().length); Object[]
	 * expectedArray = {1, 2, 3, 7, null, null};
	 * 
	 * assertArrayEquals(sortedSet.toArray(), expectedArray); // compare entire
	 * array assertEquals(sortedSet.toArray().length, 6); // compares length of
	 * each array System.out.println("Finished testAdd6"); }
	 */
	protected class OurComparator implements Comparator<BigInteger> {

		@Override
		public int compare(BigInteger lhs, BigInteger rhs) {
			return lhs.compareTo(rhs);
		}

	}
}
