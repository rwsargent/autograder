package assignment3;


import java.util.Random;

/**
 * 
 * Patrick Egan Anderson & Cole Wilkes
 *
 */
public class RunningTime {

	public static void main(String[] args) {
	    long startTime, midpointTime, stopTime;

	    // First, spin computing stuff until one second has gone by.
	    // This allows this thread to stabilize.

	    startTime = System.nanoTime();
	    while (System.nanoTime() - startTime < 1000000000) { // empty block
	    }
	    // Now, run the test.

	    long timesToLoop = 100000;

	    startTime = System.nanoTime();
	    
	    Random random = new Random();

	    for (long i = 100000; i < 2000000; i+=100000){
	    	MySortedSet <Integer> test = new MySortedSet();
	    	for(int j = 0; j < i; j++)
	    		test.add(j);
	    	startTime = System.nanoTime();
	    	
	    	test.add(-1);
//	    	for (long k = 0; k < timesToLoop; k++)
//	        	test.contains(random.nextInt());

	    	midpointTime = System.nanoTime();

	    	// Run an empty loop to capture the cost of running the loop.

//	    	for (long l = 0; l < timesToLoop; l++) { 
//	    		random.nextInt();
//	    	}

	    	stopTime = System.nanoTime();
	    	test.remove(-1);

		    // Compute the time, subtract the cost of running the loop
		    // from the cost of running the loop and computing square roots.
		    // Average it over the number of runs.
	
		    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
		        / timesToLoop;
	
		    System.out.println(i + "\t" + averageTime);
	  }
	}
	
}
