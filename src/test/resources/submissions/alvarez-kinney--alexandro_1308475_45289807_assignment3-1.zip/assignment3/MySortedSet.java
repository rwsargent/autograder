package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author AJ Kinney and America Nishimoto
 */

public class MySortedSet<E> implements SortedSet<E> {

	private E[] data;
	private Comparator<? super E> comparer;
	private int length;
	
	/**
	 * 
	 * Creates a new sorted set, if the elements to be added are Comparable
	 * 
	 */
	public MySortedSet() {
		comparer = new DefaultComparator<E>();
		length = 0; //set to 0 initially
		data = (E[]) new Object[32];
	}
	
	/**
	 * Creates a new sorted set, to be sorted by the given Comparator
	 * 
	 * @param comp
	 *            Comparator to be used to sort the list
	 */
	public MySortedSet(Comparator<? super E> comp) {
		comparer = comp;
		length = 0; //set to 0 initially
		data = (E[]) new Object[32];
	}
	
	@Override
	/**
	 * Gives the comparator that is being used to sort the set
	 * 
	 * @return the comparator that was passed in at creation time, or a DefaultComparator
	 */
	public Comparator<? super E> comparator() {
		return this.comparer;
	}

	@Override
	/**
	 * @return the first element in the set
	 * @throws NoSuchElementException
	 *             if there are no elements
	 */
	public E first() throws NoSuchElementException {
		if(length == 0)
			throw new NoSuchElementException();
		return data[0];
	}

	@Override
	/**
	 * @return the last element in the set
	 * @throws NoSuchElementException
	 *             if there are no elements
	 */
	public E last() throws NoSuchElementException {
		if(length == 0)
			throw new NoSuchElementException();
		return data[length-1];
		
	}

	@Override
	/**
	 * Adds an element to the list, in the appropriately sorted position
	 * 
	 * @param o
	 * The object to add
	 * 
	 * @return true if the element was not already in the set and not null
	 * 
	 */
	public boolean add(E o) {
		if(o == null)
			return false;
		
		if(length == data.length) { //if the set is exactly equal to the array storing it
			E[] newData = (E[]) new Object[data.length * 2]; //double the size of the array
			for(int i = 0; i < data.length; i++) { //move everything into the new array
				newData[i] = data[i];
			}
			data = newData; //and replace the old one
		}
		
		int offset = 0;
		
		
		int lower = 0;
		int upper = length - 1;
		int midpoint = length / 2;
		int n = 0;
		while(lower <= upper) {
			midpoint = lower + ((upper - lower) / 2);
			int result = comparer.compare(data[midpoint], o); //compare o with an element in the set
			if(result == 0) //if they are equal then return false
				return false;
			if(lower == upper) {
				if(result > 0)
					n = midpoint;
				else
					n = midpoint + 1;
				break;
			}
			if(result < 0) //if o comes after the element, add the offset so that we search to the right of the element
				lower = midpoint + 1;
			else
				upper = midpoint - 1;
		}
		
		length++;
		for(int i = length; i > n; i--) { //starting from the end and working to where we want to insert the new element
			data[i] = data[i - 1]; //shift every element by one to the right
		}
		data[n] = o; //then insert the new element
		return true;
	}

	@Override
	/**
	 * Adds all elements from a Collection to the set, in the appropriately sorted position
	 * 
	 * @param c
	 * The Collection of elements to add to the set
	 * 
	 * @return true if all elements were not already in the set and not null
	 * 
	 */
	public boolean addAll(Collection<? extends E> c) {
		boolean allOkay = true;
		for (E o : c) {
			allOkay = add(o) && allOkay; //by ANDing the result of adding with allOkay,
			//the method will only return true if ALL of the elements were non null and not already in the set
		}
		return allOkay;
	}

	@Override
	/**
	 * Removes all elements and set the size to zero.
	 * 
	 */
	public void clear() {
		data = (E[]) new Object[32];
		length = 0;
	}

	@Override
	/**
	 * Checks if the Object is already in the set.
	 * 
	 * @param o
	 * the object to look for in the set.
	 * 
	 * @return true if it is already in the set and false if not.
	 * 
	 */
	public boolean contains(Object o) {
		if(o == null)
			return false;
		E obj = (E) o;

		int lower = 0;
		int upper = length - 1;
		int midpoint = length / 2;
		while(lower <= upper) {
			midpoint = lower + ((upper - lower) / 2);
			int result = comparer.compare(data[midpoint], obj); //compare o with an element in the set
			if(result == 0) //if they are equal then return false
				return true;
			if(result < 0) //if o comes after the element, add the offset so that we search to the right of the element
				lower = midpoint + 1;
			else
				upper = midpoint - 1;
		}
		return false;
	}

	@Override
	/**
	 * Checks if all the elements in the collection are in the set 
	 * 
	 * @param c
	 * the collection of objects to look for
	 * 
	 * @return true if all elements in c are in the set, false if not.
	 * 
	 */
	public boolean containsAll(Collection<?> c) {
		for (Object o : c) {
			if(!contains(o))
				return false;
		}
		return true;
	}

	@Override
	/**
	 * @return whether it is an empty list
	 *
	 */
	public boolean isEmpty() {
		return (length == 0);
	}

	@Override
	/**
	 * @return an iterator to go over each element in sorted order
	 */
	public Iterator<E> iterator() {
		return new MyIterator();
	}

	@Override
	/**
	 * Removes an element from the list, and shifts elements as needed
	 * 
	 * @param o
	 * The object to remove
	 * 
	 * @return true if the element was already in the set and not null
	 * 
	 */
	public boolean remove(Object o) {
		if(o == null || length == 0)
			return false;
		E obj = (E) o;

		if(length == 1) {
			if(data[0].equals(o)) {
				clear();
				return true;
			}
			return false;
		}
		int lower = 0;
		int upper = length - 1;
		int midpoint = length / 2;
		while(lower <= upper) {
			midpoint = lower + ((upper - lower) / 2);
			int result = comparer.compare(data[midpoint], obj); //compare o with an element in the set
			if(result == 0) { //if they are equal then return false
				for(int j = midpoint; j < length; j++) { //starting from the element and working to the end, shift elements to the left
					data[j] = data[j + 1]; //shift every element by one to the right
				}
				length--;
				return true;
			}
			if(result < 0) //if o comes after the element, add the offset so that we search to the right of the element
				lower = midpoint + 1;
			else
				upper = midpoint - 1;
		}
		return false; //if we never found the element then return false
	}

	@Override
	/**
	 * Removes all elements in a Collection from the set
	 * 
	 * @param c
	 * The Collection of elements to remove
	 * 
	 * @return true if all elements were in the set and removed
	 * 
	 */
	public boolean removeAll(Collection<?> c) {
		boolean allOkay = true;
		for (Object o : c) {
			allOkay = remove(o) && allOkay; //by ANDing the result of adding with allOkay,
			//the method will only return true if ALL of the elements were non null and not already in the set
		}
		return allOkay;
	}

	@Override
	/**
	 * @return how many elements are in the list
	 */
	public int size() {
		
		return length;
	}

	@Override
	/**
	 * converts the sorted set into an array of the elements
	 * @return an array of Objects 
	 */
	public Object[] toArray() {
		Object[] array = new Object[length];
		for (int i = 0; i < length; i++){
			array[i] = (Object) data[i]; // this copies the elements from data into array as Objects.
		}
		return array;
			
	}
	
	private class DefaultComparator<E> implements Comparator<E> {
		@Override
		/**
		 * Compares two comparable objects
		 * 
		 * @param lhs
		 *            thing to be compared on left hand side
		 * @param rhs
		 *            what the left hand side is compared to
		 * @return an integer representing if the rhs is greater than, equal to, or less than lhs
		 */
		public int compare(E lhs, E rhs) {
			if(lhs == null && rhs == null)
				return 0;
			Comparable<E> left = (Comparable<E>) lhs;
			return left.compareTo(rhs);
		}
	}
	
	private class MyIterator implements Iterator<E> {
		private int index;
		
		public MyIterator() {
			index = -1;
		}

		@Override
		/**
		 * @return true if there are more elements in the set, false if the end has been reached
		 */
		public boolean hasNext() {
			return (index + 1) < length;
		}

		@Override
		/**
		 * moves the pointer ahead one element, and returns the element
		 * @return the next element in the set
		 */
		public E next() {
			if(!hasNext())
				return null;
			index++;
			return data[index];
		}

		@Override
		/**
		 * removes the last element that was returned by next() from the set
		 */
		public void remove() {
			if(index < 0)
				return;
			MySortedSet.this.remove(data[index]);
			index--;
		}
	}

}
