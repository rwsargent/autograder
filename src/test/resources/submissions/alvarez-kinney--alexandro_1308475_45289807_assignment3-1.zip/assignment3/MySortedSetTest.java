/**
 * 
 */
package assignment3;

import static org.junit.Assert.*;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Arrays;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * @author AJ Kinney and America Nishimoto
 *
 */
public class MySortedSetTest {

	private MySortedSet<String> arr1, arr2, arr3, arr4;
	private MySortedSet<Integer> arr5, arr6, arr7, arr8;
	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		arr1 = new MySortedSet<String>();
		arr2 = new MySortedSet<String>();
		arr3 = new MySortedSet<String>(new ReverseComparator<String>());
		arr4 = new MySortedSet<String>(new ReverseComparator<String>());
		arr5 = new MySortedSet<Integer>();
		arr6 = new MySortedSet<Integer>();
		arr7 = new MySortedSet<Integer>(new ReverseComparator<Integer>());
		arr8 = new MySortedSet<Integer>(new ReverseComparator<Integer>());
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#comparator()}.
	 */
	@Test
	public void testComparator() {
		assertTrue(arr3.comparator() instanceof ReverseComparator);
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#first()}.
	 */
	@Test
	public void testFirst() {
		arr1.clear();
		try {
			String s = arr1.first();
			fail("With an empty set, there is no first element");
		} catch(NoSuchElementException e) {
			assertNotNull(e);
		}
		arr1.add("A");
		arr1.add("D");
		arr1.add("B");
		assertEquals(Arrays.toString(arr1.toArray()), "A", arr1.first());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#last()}.
	 */
	@Test
	public void testLast() {
		arr1.clear();
		try {
			String s = arr1.first();
			fail("With an empty set, there is no last element");
		} catch(NoSuchElementException e) {
			assertNotNull(e);
		}
		assertTrue(arr1.add("A"));
		assertTrue(arr1.add("D"));
		assertTrue(arr1.add("B"));
		assertTrue(arr1.add("E"));
		assertTrue(arr1.add("Z"));
		assertTrue(arr1.add("C"));
		assertEquals(Arrays.toString(arr1.toArray()), "Z", arr1.last());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#add(java.lang.Object)}.
	 */
	@Test
	public void testAdd() {
		assertTrue(arr1.add("E"));
	}


	/**
	 * Test method for {@link assignment3.MySortedSet#clear()}.
	 */
	@Test
	public void testClear() {
		arr1.clear();
		assertTrue(arr1.isEmpty());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#contains(java.lang.Object)}.
	 */
	@Test
	public void testContains() {
		assertTrue(arr1.add("A"));
		assertTrue(arr1.add("D"));
		assertTrue(arr1.add("B"));
		assertTrue(arr1.add("E"));
		assertTrue(arr1.add("Z"));
		assertTrue(arr1.add("C"));
		assertTrue(arr1.contains("B"));
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#isEmpty()}.
	 */
	@Test
	public void testIsEmpty() {
		assertTrue(arr1.add("A"));
		assertTrue(arr1.add("D"));
		assertTrue(arr1.add("B"));
		assertTrue(arr1.add("E"));
		assertTrue(arr1.add("Z"));
		assertTrue(arr1.add("C"));
		assertFalse(arr1.isEmpty());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#iterator()}.
	 */
	@Test
	public void testIterator() {
		assertTrue(arr1.add("A"));
		assertTrue(arr1.add("D"));
		assertTrue(arr1.add("B"));
		assertTrue(arr1.add("E"));
		assertTrue(arr1.add("Z"));
		assertTrue(arr1.add("C"));
		Iterator<String> i = arr1.iterator();
		int n = 0;
		while(i.hasNext()) {
			String s = i.next();
			n++;
		}
		assertEquals(6, n);
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#remove(java.lang.Object)}.
	 */
	@Test
	public void testRemove() {
		assertTrue(arr1.add("A"));
		assertTrue(arr1.add("D"));
		assertTrue(arr1.add("B"));
		assertTrue(arr1.add("E"));
		assertTrue(arr1.add("Z"));
		assertTrue(arr1.add("C"));
		assertTrue(arr1.remove("E"));
		assertArrayEquals(new String[]{"A", "B", "C", "D", "Z"}, arr1.toArray());
		
		arr2.add("LOL");
		arr2.remove("LOL");
		assertTrue(arr2.isEmpty());
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#size()}.
	 */
	@Test
	public void testSize() {
		assertTrue(arr1.add("A"));
		assertTrue(arr1.add("D"));
		assertTrue(arr1.add("B"));
		assertEquals(arr1.size(), 3);
	}

	/**
	 * Test method for {@link assignment3.MySortedSet#toArray()}.
	 */
	@Test
	public void testToArray() {
		assertTrue(arr1.add("A"));
		assertTrue(arr1.add("D"));
		assertTrue(arr1.add("B"));
		assertTrue(arr1.add("E"));
		assertTrue(arr1.add("Z"));
		assertTrue(arr1.add("C"));
		assertArrayEquals(new String[]{"A", "B", "C", "D", "E", "Z"}, arr1.toArray());
	}

	private class ReverseComparator<E> implements Comparator<E> {
		@Override
		/**
		 * Compares two comparable objects
		 * 
		 * @param lhs
		 *            thing to be compared on left hand side
		 * @param rhs
		 *            what the left hand side is compared to
		 * @return an integer representing if the rhs is greater than, equal to, or less than lhs
		 */
		public int compare(E lhs, E rhs) {
			if(lhs instanceof Comparable) {
				Comparable<E> right = (Comparable<E>) rhs;
				return right.compareTo(lhs);
			} else {
				return 0;
			}
		}
	}
}
