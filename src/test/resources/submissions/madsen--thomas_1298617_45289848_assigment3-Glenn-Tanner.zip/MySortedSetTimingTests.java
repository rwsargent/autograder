package assignment3;

public class MySortedSetTimingTests {
	
	public static void main(String[] args) {
		int loop = 200000000; //Takes about 5-10 minutes at this level.
		System.out.println("Timeings for contain function averaged over " + loop + " times.");
		for (int i = 1; i <= 20; i++) {
			System.out.println(100000 * i + " Items : " + timeContain(100000 * i, loop) + " nanoseconds average");
		}
	}
	
	private static MySortedSet<Integer> getSetOf(int size) {
		MySortedSet<Integer> set = new MySortedSet<Integer>();
		for (int i = 0; i < size; i++) {
			set.add(i);
		}
		return set;
	}
	
	private static double timeContain(int size, int timesToLoop) {
		MySortedSet<Integer> set = getSetOf(size);
		long startTime, midTime, stopTime;
		int searchTerm = 5453;
		
		// Wait tell stable
		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) {
		}
		
		// Start test
		startTime = System.nanoTime();
		
		for (int i = 0; i < timesToLoop; i++) {
			// Test function
			set.contains(searchTerm);
		}
		
		// Mid point
		midTime = System.nanoTime();
		
		for (int i = 0; i < timesToLoop; i++) {
		}
		
		// End test
		stopTime = System.nanoTime();
		
		return ((midTime - startTime) - (stopTime - midTime)) / (double)timesToLoop;
	}
}
