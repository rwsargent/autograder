package assignment3;

import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author Tanner Wilson
 * @author Thomas Glenn Madsen
 * 
 */
public class MySortedSetTest {
	private MySortedSet<Integer> sortedSet1, sortedSet2, sortedSet3, sortedSet4;
	private MySortedSet<String> sortedSet5;
	private ArrayList<Integer> list1, list2, list3;

	@Before
	public void setUp() throws Exception {
		// list1 = empty
		// list2 = {1,3,23,65,73,29,0,-3,100,-1,16}
		// list2 (sorted) = {-3, -1, 0, 1, 3, 16, 23, 29, 65, 73, 100}
		// list3 = {1,3,23,65,73,29,36,555,4937,0,63,2,9,18,28,37,-26,-3,92,20,21}
		// list3 (sorted) = {-26, -3, 0, 1, 2, 3, 9, 18, 20, 21, 23, 28, 29, 36, 37, 63, 65, 73, 92, 555, 4937}
		
		//
		// Initialize ArrayLists
		//
		list1 = new ArrayList<Integer>();
		list2 = new ArrayList<Integer>();
		list3 = new ArrayList<Integer>();

		// Adds numbers to the ArrayList list2
		list2.add(1);
		list2.add(3);
		list2.add(23);
		list2.add(65);
		list2.add(73);
		list2.add(29);
		list2.add(0);
		list2.add(-3);
		list2.add(100);
		list2.add(-1);
		list2.add(16);

		// Adds numbers to the ArrayList list3
		list3.add(1);
		list3.add(3);
		list3.add(23);
		list3.add(65);
		list3.add(73);
		list3.add(29);
		list3.add(36);
		list3.add(555);
		list3.add(4937);
		list3.add(0);
		list3.add(63);
		list3.add(2);
		list3.add(9);
		list3.add(18);
		list3.add(28);
		list3.add(37);
		list3.add(-26);
		list3.add(-3);
		list3.add(92);
		list3.add(20);
		list3.add(21);
		
		//
		// Initialize MyArrayLists
		//
		sortedSet1 = new MySortedSet<Integer>();
		sortedSet2 = new MySortedSet<Integer>();
		sortedSet3 = new MySortedSet<Integer>();
		sortedSet4 = new MySortedSet<Integer>();
		sortedSet5 = new MySortedSet<String>(String.CASE_INSENSITIVE_ORDER);
		
		
		// Fill MyArrayLists
		sortedSet1.addAll(list1); 
		sortedSet2.addAll(list2);
		sortedSet3.addAll(list3);
		sortedSet4.add(0);
		sortedSet4.add(9);
		sortedSet4.add(1);
		sortedSet4.add(8);
		sortedSet4.add(2);
		sortedSet4.add(7);
		sortedSet4.add(3);
		sortedSet4.add(6);
		sortedSet4.add(4);
		sortedSet4.add(5);
		sortedSet4.add(-1);
		
		sortedSet5.add("a");
		sortedSet5.add("aa");
		sortedSet5.add("bc");
		sortedSet5.add("bb");
		sortedSet5.add("cc");
		sortedSet5.add("ad");
		sortedSet5.add("e");
	}

	/*
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 *         
	 *         ***Most errors should be caught by SetUp()***
	 */
	@Test
	public void testComparator() {
		assertEquals(null, sortedSet1.comparator());
		assertEquals(null, sortedSet2.comparator());
		assertEquals(null, sortedSet3.comparator());
		assertEquals(null, sortedSet4.comparator());
		
		if (!sortedSet5.comparator().equals(String.CASE_INSENSITIVE_ORDER)) 
			fail(".comparator() did not return the correct Comparator for String.");
	}
	
	/*
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Test
	public void testFirst() {
		try {
			sortedSet1.first();
			fail("No Error Thrown for empty set calling .first().");
		} catch(NoSuchElementException e) {
		}
		assertEquals(Integer.valueOf(-3), sortedSet2.first());
		assertEquals(Integer.valueOf(-26), sortedSet3.first());
		assertEquals(Integer.valueOf(-1), sortedSet4.first());
		assertEquals("a", sortedSet5.first());
	}

	/*
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Test
	public void testLast() {
		try {
			sortedSet1.last();
			fail("No Error Thrown for empty set calling .first().");
		} catch(NoSuchElementException e) {
		}
		assertEquals(Integer.valueOf(100), sortedSet2.last());
		assertEquals(Integer.valueOf(4937), sortedSet3.last());
		assertEquals(Integer.valueOf(9), sortedSet4.last());
		assertEquals("e", sortedSet5.last());
	}

	/**
	 * 
	 * ***Tests add, contains, and remove methods***
	 * 
	 */
	@Test
	public void testAddContainsRemove() {
		assertTrue(sortedSet1.add(256));
		assertFalse(sortedSet1.add(256));
		assertTrue(sortedSet1.contains(256));
		assertFalse(sortedSet1.contains(-256));
		assertTrue(sortedSet1.remove(256));
		assertFalse(sortedSet1.remove(256));
		assertFalse(sortedSet1.contains(256));
		
		assertTrue(sortedSet2.add(256));
		assertFalse(sortedSet2.add(256));
		assertTrue(sortedSet2.contains(256));
		assertFalse(sortedSet2.contains(-256));
		assertTrue(sortedSet2.remove(256));
		assertFalse(sortedSet1.remove(256));
		assertFalse(sortedSet2.contains(256));
		
		assertTrue(sortedSet3.add(-256));
		assertFalse(sortedSet3.add(-256));
		assertTrue(sortedSet3.contains(-256));
		assertFalse(sortedSet3.contains(256));
		assertTrue(sortedSet3.remove(-256));
		assertFalse(sortedSet1.remove(-256));
		assertFalse(sortedSet3.contains(-256));
		
		assertTrue(sortedSet4.add(-256));
		assertFalse(sortedSet4.add(-256));
		assertTrue(sortedSet4.contains(-256));
		assertFalse(sortedSet4.contains(256));
		assertTrue(sortedSet4.remove(-256));
		assertFalse(sortedSet4.remove(-256));
		assertFalse(sortedSet4.contains(-256));
		
		assertTrue(sortedSet5.add("T"));
		assertFalse(sortedSet5.add("T"));
		assertFalse(sortedSet5.add(null));
		assertFalse(sortedSet5.contains(null));
		assertTrue(sortedSet5.contains("T"));
		assertFalse(sortedSet5.contains("z"));
		assertTrue(sortedSet5.remove("T"));
		assertFalse(sortedSet5.remove("T"));
		assertFalse(sortedSet5.contains("T"));
	}

	/**
	 * 
	 * ***Tests addAll, containsAll, and removeAll methods***
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Test
	public void testAddContainsRemoveAll() {
		// Integer tests
		ArrayList<Integer> intArray = new ArrayList<Integer>();
		intArray.add(5000);
		intArray.add(-15000);
		intArray.add(15000);
		intArray.add(-5000);
		
		ArrayList<Integer> modArray = (ArrayList<Integer>) intArray.clone();
		modArray.add(123456789);
		
		assertTrue(sortedSet1.addAll(intArray));
		assertFalse(sortedSet1.addAll(intArray));
		assertTrue(sortedSet1.containsAll(intArray));
		assertFalse(sortedSet1.containsAll(modArray));
		assertTrue(sortedSet1.removeAll(intArray));
		assertFalse(sortedSet1.removeAll(intArray));
		assertFalse(sortedSet1.containsAll(intArray));
		
		assertTrue(sortedSet2.addAll(intArray));
		assertFalse(sortedSet2.addAll(intArray));
		assertTrue(sortedSet2.containsAll(intArray));
		assertFalse(sortedSet2.containsAll(modArray));
		assertTrue(sortedSet2.removeAll(intArray));
		assertFalse(sortedSet2.removeAll(intArray));
		assertFalse(sortedSet2.containsAll(intArray));
		
		assertTrue(sortedSet3.addAll(intArray));
		assertFalse(sortedSet3.addAll(intArray));
		assertTrue(sortedSet3.containsAll(intArray));
		assertFalse(sortedSet3.containsAll(modArray));
		assertTrue(sortedSet3.removeAll(intArray));
		assertFalse(sortedSet3.removeAll(intArray));
		assertFalse(sortedSet3.containsAll(intArray));
		
		assertTrue(sortedSet4.addAll(intArray));
		assertFalse(sortedSet4.addAll(intArray));
		assertTrue(sortedSet4.containsAll(intArray));
		assertFalse(sortedSet4.containsAll(modArray));
		assertTrue(sortedSet4.removeAll(intArray));
		assertFalse(sortedSet4.removeAll(intArray));
		assertFalse(sortedSet4.containsAll(intArray));
		
		
		// String test
		ArrayList<String> strArray = new ArrayList<String>();
		strArray.add("q");
		strArray.add("w");
		strArray.add("r");
		strArray.add("t");
		
		ArrayList<String> modStrArray = (ArrayList<String>) strArray.clone();
		modStrArray.add("z");
		ArrayList<String> modNullStrArray = (ArrayList<String>) strArray.clone();
		modNullStrArray.add(null);
		
		
		assertTrue(sortedSet5.addAll(strArray));
		assertFalse(sortedSet5.addAll(strArray));
		assertTrue(sortedSet5.containsAll(strArray));
		assertFalse(sortedSet5.containsAll(modStrArray));
		assertFalse(sortedSet5.containsAll(modNullStrArray));
		assertTrue(sortedSet5.removeAll(strArray));
		assertFalse(sortedSet5.removeAll(strArray));
		assertFalse(sortedSet5.containsAll(strArray));
	}

	/*
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Test
	public void testClear() {
		// Make sure that add() isn't making it pass.
		assertTrue(sortedSet2.size() > 0);
		
		// Test clearing each set.
		sortedSet1.clear();
		assertFalse(sortedSet1.contains(0));
		sortedSet2.clear();
		assertFalse(sortedSet2.contains(73));
		sortedSet3.clear();
		assertFalse(sortedSet3.contains(18));
		sortedSet4.clear();
		assertFalse(sortedSet4.contains(6));
		sortedSet5.clear();
		assertFalse(sortedSet5.contains("a"));
	}

	/*
	 * @return true if this set contains no elements
	 */
	@Test
	public void testIsEmpty() {
		assertTrue(sortedSet1.isEmpty());
		assertFalse(sortedSet2.isEmpty());
		assertFalse(sortedSet3.isEmpty());
		assertFalse(sortedSet4.isEmpty());
		assertFalse(sortedSet5.isEmpty());
	}

	/*
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Test
	public void testIterator() {
		Iterator<Integer> iter1 = sortedSet1.iterator();
		assertFalse(iter1.hasNext());
		try {
			iter1.next();
			fail("Iterator did not throw NoSuchElementException");
		} catch (NoSuchElementException e) {		
		}
		
		Iterator<Integer> iter2 = sortedSet2.iterator();
		assertTrue(iter2.hasNext());
		assertEquals(Integer.valueOf(-3), iter2.next());
		iter2.remove();
		assertFalse(sortedSet2.contains(-2));
		
		Iterator<Integer> iter3 = sortedSet3.iterator();
		assertTrue(iter3.hasNext());
		assertEquals(Integer.valueOf(-26), iter3.next());
		iter3.remove();
		assertFalse(sortedSet3.contains(-26));
		
		Iterator<Integer> iter4 = sortedSet4.iterator();
		assertTrue(iter4.hasNext());
		assertEquals(Integer.valueOf(-1), iter4.next());
		iter4.remove();
		assertFalse(sortedSet4.contains(-1));
		
		Iterator<String> iter5 = sortedSet5.iterator();
		assertTrue(iter5.hasNext());
		assertEquals("a", iter5.next());
		iter5.remove();
		assertFalse(sortedSet5.contains("a"));
	}

	/*
	 * @return the number of elements in this set
	 */
	@Test
	public void testSize() {
		assertEquals(0, sortedSet1.size());
		assertEquals(11, sortedSet2.size());
		assertEquals(21, sortedSet3.size());
		assertEquals(11, sortedSet4.size());
		assertEquals(7, sortedSet5.size());
	}
	
	@Test
	public void testBinarySearch() {
		// In set
		assertEquals(5, sortedSet2.binarySearch(16));
		assertEquals(12, sortedSet3.binarySearch(29));
		assertEquals(4, sortedSet4.binarySearch(3));
		assertEquals(3, sortedSet5.binarySearch("bb"));
		
		// Not in set
		assertEquals(-1, sortedSet1.binarySearch(-599));
		assertEquals(-1, sortedSet2.binarySearch(-599));
		assertEquals(-1, sortedSet3.binarySearch(-599));
		assertEquals(-1, sortedSet4.binarySearch(-599));
		assertEquals(-1, sortedSet5.binarySearch("z"));
	}

}
