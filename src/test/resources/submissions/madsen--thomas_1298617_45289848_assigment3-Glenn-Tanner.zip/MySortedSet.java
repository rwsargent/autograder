package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A set that provides a total ordering on its elements. The elements are
 * ordered using their natural ordering, or by a Comparator provided at sorted
 * set creation time. Thus, all elements inserted into a sorted set must
 * implement the Comparable interface or be accepted by the specified
 * Comparator. The set's iterator will traverse the set in ascending element
 * order.
 * 
 * @author Tanner Wilson
 * @author Thomas Glenn Madsen
 * @param <E> The type of element to be held by the MySortedSet object.
 */
public class MySortedSet<E> implements SortedSet<E>, Iterator<E>, Iterable<E> {
	private Comparator<E>	comparator;
	private Object[]		data;
	private int				size;
	private int				position;
	
	/**
	 * This constructor assumes that the elements are ordered using their
	 * natural ordering (i.e., E implements Comparable<? super E>).
	 */
	public MySortedSet() {
		// Initialize private variables.
		data = new Object[10];
		size = 0;
		position = 0;
	}
	
	/**
	 * This constructor assumes that the elements are ordered using the provided
	 * comparator.
	 * 
	 * @param type
	 * @param comp Comparator for type.
	 */
	@SuppressWarnings("unchecked")
	public MySortedSet(Comparator<? super E> comp) {
		this();
		try {
			comparator = ( Comparator<E> )comp;
		} catch (ClassCastException e) {
			throw new IllegalArgumentException("Given Object is not of generic type Comparator<E>.");
		}
	}
	
	@Override
	public Comparator<? super E> comparator() {
		return comparator;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public E first() throws NoSuchElementException {
		if (this.isEmpty())
			throw new NoSuchElementException();
		return (E) data[0];
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public E last() throws NoSuchElementException {
		if (this.isEmpty())
			throw new NoSuchElementException();
		return (E) data[size - 1];
	}
	
	@Override
	public boolean add(E o) {
		if (o == null) return false;
		
		// Check to see if its already inside.
		int index = binarySearch(o);
		if (index > -1) return false;
		
		// Check to see if a size increase is necessary.
		if (size == data.length-1) {
			data = Arrays.copyOf(data, data.length * 2);
		}
		
		// Insert
		for (int i = size; i >= 0; i--) {
			if (i == 0 || compare(data[i - 1], o) < 0) {
				data[i] = o;
				break;
			}
			data[i] = data[i - 1];
		}
		size++;
		return true;
	}
	
	@Override
	public boolean addAll(Collection<? extends E> c) {
		Boolean changed = false;
		for (E item : c) {
			// Add item.
			if (this.add(item)) {
				// Track changed status.
				changed = true;
			}
		}
		return changed;
	}
	
	@Override
	public void clear() {
		data = new Object[10];
		size = 0;
	}
	
	@Override
	public boolean contains(Object o) {
		if (o == null || size == 0) return false;
		int index = binarySearch(o);
		if (index < 0) return false;
		if (compare(data[index], o) != 0) return false;
		return true;
	}
	
	@Override
	public boolean containsAll(Collection<?> c) {
		for (Object item : c) {
			if (!contains(item)) return false;
		}
		return true;
	}
	
	@Override
	public boolean isEmpty() {
		return (size <= 0);
	}
	
	@Override
	public Iterator<E> iterator() {
		return this;
	}
	
	@Override
	public boolean remove(Object o) {
		if (o == null || size == 0) return false;
		int index = binarySearch(o);
		if (index < 0 || compare(data[index], o) != 0) return false;
		
		// Remove
		for (int i = index; i < size; i++) {
			data[i] = data[i + 1];
		}
		data[size - 1] = null;
		size--;
		return true;
	}
	
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean changed = false;
		for (Object item : c) {
			if (remove(item)) {
				// Track changed status.
				changed = true;
			}
		}
		return changed;
	}
	
	@Override
	public int size() {
		return size;
	}
	
	@Override
	public Object[] toArray() {
		return data;
	}
	
	/**
	 * Wrapper for Comparing two objects. Expect outputs like that of the
	 * Comparable method .compareTo() and the Comparator method .compare. That
	 * is Compares this object with the specified object for order. Returns a
	 * negative integer, zero, or a positive integer as the left object is less
	 * than, equal to, or greater than the right object.
	 * 
	 * @param l
	 * @param r
	 * @return -# when l<r, 0 when l=r, +# when l>r.
	 */
	@SuppressWarnings("unchecked")
	private int compare(Object l, Object r) {
		try {
			if (comparator == null) {
				// Comparable (natural order)
				Comparable<E> leftHand = ( Comparable<E> )l;
				return leftHand.compareTo(( E )r);
			} else {
				// Comparator
				return comparator.compare(( E )l, ( E )r);
			}
		} catch (ClassCastException e) {
			throw new IllegalArgumentException("Given Objects are not of generic type E.");
		}
	}
	
	/**
	 * Performs a binary search on data[].
	 * @param t Object to search for.
	 * @return -1 if not found, otherwise the index at which t was found.
	 */
	@SuppressWarnings("unchecked")
	protected int binarySearch(Object t) {
		if (size == 0) return -1;
		
		// Cast the argument to the generic type.
		E target;
		try {
			target = ( E )t;
		} catch (ClassCastException e) {
			throw new IllegalArgumentException("Given Objects are not of generic type E.");
		}
		
		// Initialize loop variables.
		int high = size;
		int low = 0;
		int mid = 0;
		
		while (high >= low) {
			mid = (high + low) / 2;
			
			try {
				// Lesser Case: data[mid] < target
				if (this.compare(data[mid], target) < 0) {
					low = mid + 1;
				}
				// Greater Case: data[mid] > target
				else if (this.compare(data[mid], target) > 0) {
					high = mid - 1;
				}
				// Equals Case: data[mid] =s target, found.
				else {
					return mid;
				}
			} catch (NullPointerException e) {
				break;
			}
		}
		return -1;
	}

	@Override
	public boolean hasNext() {
		return (position < size);
	}

	@SuppressWarnings("unchecked")
	@Override
	public E next() {
		if (!hasNext()) throw new NoSuchElementException();
		return ( E )data[position++];
	}
	
	@Override
	public void remove() {
		remove(data[--position]);
	}
}
