/**
 * @author Names:Yiliang Shi u0793198; David Gillespie u0720569
 * Class: Implements a sorted set
 */
package assignment3;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> {

	private Comparator<? super E> compareVar;
	private int lastIndex = -1; // Indicates the index of the last element of
								// the
	// array. -1 when array is empty, increases
	// everytime an element is added
	private int arrayCapacity = 20;
	private Object array[] = new Object[arrayCapacity];

	public MySortedSet() {
		compareVar = null;
	}

	public MySortedSet(Comparator<? super E> compareVar) {
		this.compareVar = compareVar;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	public Comparator<? super E> comparator() {
		return compareVar;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E first() throws NoSuchElementException {
		if (lastIndex >= 0)
			return (E) array[0];
		else
			throw new NoSuchElementException();
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	public E last() throws NoSuchElementException {
		if (lastIndex >= 0)
			return (E) array[lastIndex];
		else
			throw new NoSuchElementException();
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */

	@SuppressWarnings("unchecked")
	public boolean add(E o) {
		// Check if null or if o already exist in set
		if (o == null || contains(o))
			return false;
		// double the array if array is full
		if (lastIndex + 1 == arrayCapacity) {
			arrayCapacity *= 2;
			Object temp[] = new Object[arrayCapacity];
			for (int i = 0; i <= lastIndex; i++) {
				temp[i] = array[i];
			}
			array = temp.clone();

		}
		// If second constructor is called a conparator exist
		if (compareVar != null) {
			array[++lastIndex] = o;
			if (lastIndex == 0) // check to see if the collection is empty
			{
				array[0] = o;
				return true;
			}

			int low = 0;
			int high = lastIndex;
			int mid;

			while (low < high) {

				mid = low + (high - low) / 2;

				if (compareVar.compare((E) array[mid], o) < 0)
					low = mid + 1;
				else if (compareVar.compare((E) array[mid], o) > 0) {
					high = mid;
				} else {
					insert(o, mid);
					return true;
				}

			}
			insert(o, low);
			return true;
		} else {
			if (!(o instanceof Comparable))
				return false;
			else {
				Comparable object = (Comparable) o;
				array[++lastIndex] = o;
				if (lastIndex == 0) // check to see if the collection is empty
				{
					array[0] = o;
					return true;
				}

				int low = 0;
				int high = lastIndex;
				int mid;

				while (low < high) {

					mid = low + (high - low) / 2;

					if (((Comparable) array[mid]).compareTo(object) < 0)
						low = mid + 1;
					else if (((Comparable) array[mid]).compareTo(o) > 0) {
						high = mid;
					} else {
						insert(o, mid);
						return true;
					}

				}
				insert(o, low);
				return true;

			}

		}
	}

	/**
	 * Adds an entry o into the array in location index
	 * 
	 * @param o
	 * @param index
	 */
	private void insert(Object o, int index) {
		Object[] temp = new Object[lastIndex - index];
		for (int i = 0; i < lastIndex - index; i++) {
			temp[i] = array[index + i];
		}
		array[index] = o;
		for (int i = 0; i < lastIndex - index; i++) {
			array[index + 1 + i] = temp[i];
		}
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean addAll(Collection<? extends E> c) {
		boolean change = false;
		for (E item : c) {
			if (add(item)) {
				change = true;
			}
		}
		return change;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	public void clear() {
		arrayCapacity = 20;
		lastIndex = -1;
		array = new Object[arrayCapacity];

	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	public boolean contains(Object o) {
		int low = 0;
		int high = lastIndex;
		if (compareVar != null) {
			while (low <= high) {
				int middle = low + (high - low) / 2;
				if (compareVar.compare((E) o, (E) array[middle]) == 0) {
					return true;
				}
				if (compareVar.compare((E) o, (E) array[middle]) < 0) {
					high = middle - 1;
				}
				if (compareVar.compare((E) o, (E) array[middle]) > 0) {
					low = middle + 1;
				}
			}
			return false;
		} else {
			if (o instanceof Comparable) {
				while (low <= high) {
					int middle = low + (high - low) / 2;
					if (((Comparable) o).compareTo((Comparable) array[middle]) == 0) {
						return true;
					}
					if (((Comparable) o).compareTo((Comparable) array[middle]) < 0) {
						high = middle - 1;
					}
					if (((Comparable) o).compareTo((Comparable) array[middle]) > 0) {
						low = middle + 1;
					}
				}
				return false;
			}
			return false;
		}
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	public boolean containsAll(Collection<?> c) {
		for (Object item : c) {
			if (!contains(item))
				return false;
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	public boolean isEmpty() {
		if (lastIndex == -1)
			return true;
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	public Iterator<E> iterator() {
		return new Iterator<E>() {
			private int position = 0;

			public boolean hasNext() {
				return lastIndex > position;
			}

			public E next() {
				if(position<=lastIndex)
					return (E) array[position++];
				else
					throw new NoSuchElementException();
			}

		};

	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	public boolean remove(Object o) {
		int index = -1;
		int low = 0;
		int high = lastIndex;
		if (compareVar != null) {
			while (low <= high) {
				int middle = low + (high - low) / 2;
				if (compareVar.compare((E) o, (E) array[middle]) == 0) {
					for (int i = middle; i < lastIndex; i++) {
						array[i] = array[i + 1];
					}
					array[lastIndex] = null;
					lastIndex--;
					return true;
				}
				if (compareVar.compare((E) o, (E) array[middle]) < 0) {
					high = middle - 1;
				}
				if (compareVar.compare((E) o, (E) array[middle]) > 0) {
					low = middle + 1;
				}
			}
		} else {
			if( !(o instanceof Comparable))
				return false;
			while (low <= high) {
				int middle = low + (high - low) / 2;
				if (((Comparable) o).compareTo((Comparable) array[middle]) == 0) {
					for (int i = middle; i < lastIndex; i++) {
						array[i] = array[i + 1];
					}
					array[lastIndex] = null;
					lastIndex--;
					return true;
				}
				if (((Comparable) o).compareTo((Comparable) array[middle]) < 0) {
					high = middle - 1;
				}
				if (((Comparable) o).compareTo((Comparable) array[middle]) > 0) {
					low = middle + 1;
				}
			
			}
		}
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	public boolean removeAll(Collection<?> c) {
		boolean change = false;

		for (Object item : c) {
			if (remove(item)) {
				change = true;
			}
		}
		return change;
	}

	/**
	 * @return the number of elements in this set
	 */
	public int size() {

		return lastIndex + 1;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	public Object[] toArray() {
		Object[] output = new Object[lastIndex + 1];
		for (int i = 0; i <= lastIndex; i++)
			output[i] = array[i];
		return output;
	}

}
