/**
 * @author Names:Yiliang Shi u0793198; David Gillespie u0720569
 */
package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MySortedSetTest {
	private MySortedSet <Integer>set;
	private MySortedSet <Integer>set2;

	@Before
	public void setUp() throws Exception {
		set=new MySortedSet<Integer>(new IntegerComparator());
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddComparator() {
		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		set.add(new Integer(5));
		set.add(new Integer(8));
		set.add(new Integer(7));
		set.add(new Integer(1));
		set.add(new Integer(6));
		set.add(new Integer(0));
		set.add(new Integer(91));
		set.add(new Integer(24));
		set.add(new Integer(11));
		set.add(new Integer(14));
		set.add(new Integer(65));
		set.add(new Integer(342));
		set.add(new Integer(43));
		set.add(new Integer(59));
		set.add(new Integer(90));
		set.add(new Integer(74));
		set.add(new Integer(22));
		set.add(new Integer(93));
		set.add(new Integer(40));
		Object []a=new Integer[]{0,1,2,4,5,6,7,8,9,11,14,22,24,40,43,59,65,74,90,91,93,342};
		assertArrayEquals(a,set.toArray());
		assertFalse(set.add(null));
		assertFalse(set.add(new Integer(90)));
	}
	public void testAddComparable(){
		set2=new MySortedSet();
		set2.add(new Integer(2));
		set2.add(new Integer(9));
		set2.add(new Integer(4));
		set2.add(new Integer(5));
		set2.add(new Integer(8));
		set2.add(new Integer(7));
		set2.add(new Integer(1));
		set2.add(new Integer(6));
		set2.add(new Integer(0));
		set2.add(new Integer(91));
		set2.add(new Integer(24));
		set2.add(new Integer(11));
		set2.add(new Integer(14));
		set2.add(new Integer(65));
		set2.add(new Integer(342));
		set2.add(new Integer(43));
		set2.add(new Integer(59));
		set2.add(new Integer(90));
		set2.add(new Integer(74));
		set2.add(new Integer(22));
		set2.add(new Integer(93));
		set2.add(new Integer(40));
		Object []a=new Integer[]{0,1,2,4,5,6,7,8,9,11,14,22,24,40,43,59,65,74,90,91,93,342};
		assertArrayEquals(a,set2.toArray());
		assertFalse(set2.add(null));
		assertFalse(set2.add(new Integer(90)));
	}
	
	@Test
	public void testAddAll(){
		ArrayList <Integer>test = new ArrayList<Integer>(Arrays.asList(new Integer(2),new Integer(3),new Integer(4)));
		set.add(new Integer(24));
		set.add(new Integer(11));
		set.add(new Integer(14));
		set.add(new Integer(65));
		assertTrue(set.addAll(test));
		Object [] a = new Integer[]{2,3,4,11,14,24,65};
		set.addAll(test);
		assertArrayEquals(a,set.toArray());
		assertFalse(set.addAll(test));
	}
	@Test
	public void testClear(){
		set.add(new Integer(24));
		set.add(new Integer(11));
		set.add(new Integer(14));
		set.clear();
		assertEquals(0,set.size());
		assertEquals(true,set.isEmpty());
	}
	@Test
	public void testContains()
	{
		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		assertTrue(set.contains(new Integer(9)));
		assertFalse(set.contains(new Integer(5)));
	}

	@Test
	public void testContainsComparables()
	{
		set2=new MySortedSet();
		set2.add(new Integer(2));
		set2.add(new Integer(9));
		set2.add(new Integer(4));
		assertTrue(set2.contains(new Integer(9)));
		assertFalse(set2.contains(new Integer(5)));
	}

	@Test
	public void testContainsAll(){

		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		set.add(new Integer(5));
		set.add(new Integer(8));
		set.add(new Integer(7));
		ArrayList <Integer>test = new ArrayList<Integer>(Arrays.asList(new Integer(2),new Integer(3),new Integer(4)));
		assertFalse(set.containsAll(test));
		set.add(new Integer(3));
		assertTrue(set.containsAll(test));
		
	}
	
	@Test
	public void testFirst(){
		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		assertEquals(new Integer(2),set.first());
	}
	@Test
	public void testLast(){
		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		assertEquals(new Integer(9),set.last());
	}
	@Test
	public void testComparator(){
		Comparator compare=new IntegerComparator();
		set2=new MySortedSet<Integer>(compare);
		assertEquals(compare,set2.comparator());
	}
	@Test
	public void testIsEmpty(){
		assertTrue(set.isEmpty());
		set.add(new Integer(2));
		assertFalse(set.isEmpty());
	}
	@Test
	public void testIterator(){
		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		Iterator<Integer> iter=set.iterator();
		assertTrue(iter.hasNext());
		assertEquals(new Integer(2),iter.next());
		iter.next();
		iter.next();
		assertFalse(iter.hasNext());
	}
	@Test
	public void testRemove(){
		set2 =new MySortedSet();
		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		set2.add(new Integer (2));
		set2.add(new Integer(4));
		assertTrue(set.remove(new Integer (9)));
		
		assertArrayEquals(set.toArray(),set2.toArray());
		assertFalse(set.remove(new Integer (12)));
		
		set2.add(new Integer(5));
		assertTrue(set2.remove(new Integer (5)));
		assertArrayEquals(set2.toArray(),set.toArray());
		assertFalse(set2.remove(new Integer (5)));
		
	}



	@Test
	public void testRemoveAll(){

		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		set.add(new Integer(5));
		set.add(new Integer(8));
		set.add(new Integer(7));
		ArrayList <Integer>test = new ArrayList<Integer>(Arrays.asList(new Integer(2),new Integer(3),new Integer(4)));
		assertTrue(set.removeAll(test));
		assertFalse(set.removeAll(test));
	}
	@Test
	public void testToArray(){
		set.add(new Integer(2));
		set.add(new Integer(9));
		set.add(new Integer(4));
		set.add(new Integer(5));
		assertArrayEquals(new Integer[]{2,4,5,9},set.toArray());
	}
	@Test
	public void testSize(){
		set2 =new MySortedSet();
		assertEquals(0,set2.size());
		set2.add(new Integer(2));
		assertEquals(1,set2.size());
	}
}

class IntegerComparator implements Comparator<Integer> {

	/**
	 * Returns a negative value if lhs is smaller than rhs. Returns a
	 * positive value if lhs is larger than rhs. Returns 0 if lhs and rhs
	 * are equal.
	 */
	public int compare(Integer lhs,
			Integer rhs) {
		return (lhs).compareTo(rhs);
	}



}
