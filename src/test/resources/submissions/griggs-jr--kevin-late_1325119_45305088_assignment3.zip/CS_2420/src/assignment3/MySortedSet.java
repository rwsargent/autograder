package assignment3;

// Authored by Joshua Callahan and Kevin Griggs

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class MySortedSet<E> implements SortedSet<E> {
	private int capacity;
	private E[] list;
	private Comparator<? super E> comparator;
	private int elementCount;

	/**
	 * Constructor for a sorted set that uses natural ordering through a
	 * Comparable interface.
	 */
	public MySortedSet() {
		capacity = 10;
		list = (E[]) new Object[capacity];
		elementCount = 0;
		comparator = null;
	}

	/**
	 * Constructor for a sorted set that uses a custom comparator to sort
	 * objects.
	 * 
	 * @param Comparator
	 *            - Allows custom sorting from the user
	 */
	public MySortedSet(Comparator<? super E> _comparator) {
		capacity = 10;
		list = (E[]) new Object[capacity];
		comparator = _comparator;
		elementCount = 0;

	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		if (this instanceof Comparable) {
			return null;
		}
		return this.comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (elementCount < 1) {
			throw new NoSuchElementException();
		}
		return list[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (elementCount < 1) {
			throw new NoSuchElementException();
		}
		return list[elementCount - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {

		// Grows the array by doubling the capacity when current capacity is
		// reached.
		if (elementCount == (capacity - 1)) {
			capacity *= 2;

			// Capacity is doubled and the existing array is copied into a new
			// array
			E[] tempBigger = (E[]) new Object[capacity];
			for (int i = 0; i < list.length; i++) {
				tempBigger[i] = list[i];
			}
			list = tempBigger;
		}

		// If there is only one element, then manually compare and insert.
		if (elementCount == 1) {
			if (compare(o, list[0]) > 0)
				list[1] = o;
			else {
				list[1] = list[0];
				list[0] = o;
			}
		}

		// If there are more than one element, perform a binary search and
		// locate insertion position
		else {
			int first = 0;
			int last = elementCount;
			int mid = last / 2;
			while ((last - first) > 1) {
				if (compare(o, list[mid]) == 0)
					return false;
				if (compare(o, list[mid]) < 0)
					last = mid;
				else
					first = mid;
				mid = (first + last) / 2;
			}

			// Ensure item is inserted in correct position
			if (last == 1) {
				if (compare(o, list[0]) < 0)
					last = 0;
			}

			// Insert item in indicated position
			int position = last;
			for (int i = elementCount; i >= position; i--)
				list[i + 1] = list[i];
			list[position] = o;
		}
		elementCount++;

		return true;
	}

	/**
	 * Helper method for comparisons
	 * 
	 * @param E
	 *            item1 - the first item to be compared E item2 - the second
	 *            item to be compared
	 * @return result of comparison: result > 0 if item1 is greater than item2
	 *         result < 0 if item1 is less than item2 result = 0 if item1 is
	 *         equal to item2
	 */
	private int compare(E item1, E item2) {
		if (comparator == null) {
			return ((Comparable<E>) item1).compareTo(item2);
		} else {
			return comparator.compare(item1, item2);
		}
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		int initialCount = elementCount;
		for (E item : c) {
			add(item);
		}
		if (initialCount == elementCount)
			return false;
		else
			return true;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		// Every element is set to null.
		for (int i = 0; i < elementCount; i++) {
			list[i] = null;
		}
		elementCount = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {

		// A binary search is performed to find Object o
		int first = 0;
		int last = elementCount;
		int mid = last / 2;

		while ((last - first) > 1) {
			if (compare((E) o, list[mid]) == 0)
				return true;
			if (compare((E) o, list[mid]) < 0)
				last = mid;
			else
				first = mid;
			mid = (first + last) / 2;
		}
		// Ensure item is not located in the first index
		if (last - first == 1) {
			if (compare((E) o, list[mid]) == 0)
				return true;
		}
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for (Object item : c) {
			if (!contains(item))
				return false;
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (elementCount == 0)
			return true;
		return false;
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MyIterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		if (!contains(o))
			return false;
		// A binary search is performed to find Object o
		int first = 0;
		int last = elementCount;
		int mid = last / 2;
		while ((last - first) > 1) {
			if (compare((E) o, list[mid]) < 0)
				last = mid;
			else
				first = mid;
			mid = (first + last) / 2;
		}
		// Ensure Object o is not located in the first index
		if (last == 1) {
			if (compare((E) o, list[0]) < 0)
				last = 0;
		}
		int position = mid;
		// The elements are shifted to fill the empty space
		for (int i = position; i < elementCount; i++)
			list[i] = list[i + 1];
		elementCount--;
		return true;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean returnValue = false;
		for (Object item : c) {
			if (contains(item))
				remove(item);
			returnValue = true;
		}
		return returnValue;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return elementCount;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		E[] returnArray = (E[]) new Object[elementCount];
		// An array is created that is the exact size of the elementCount
		for (int i = 0; i < elementCount; i++) {
			returnArray[i] = list[i];
		}
		return returnArray;
	}

	/**
	 * An iterator can be created for the user to explore the contents of
	 * MySortedSet
	 */
	class MyIterator implements Iterator<E> {
		int pos = 0;

		/**
		 * The iterator will check to see if there is another element contained
		 * in the array.
		 * 
		 * @return true if so
		 */
		@Override
		public boolean hasNext() {
			if (pos == MySortedSet.this.elementCount)
				return false;
			return true;
		}

		/**
		 * The iterator will return the next value contained in the array.
		 * 
		 * @return the next value
		 * @throws NoSuchElementException
		 */
		@Override
		public E next() throws NoSuchElementException {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			return MySortedSet.this.list[pos++];

		}

	}
}
