package assignment3;

//Authored by Joshua Callahan and Kevin Griggs

import java.util.Comparator;

public class MyComp implements Comparator<String> {

	@Override
	public int compare(String lhs, String rhs) {
		if (lhs.length() == rhs.length()) {
			return 0;
		}
		if (lhs.length() > rhs.length()) {
			return 1;
		}
		return -1;
	}

}
