package assignment3;
/*
 * @Authors: modified by Josh Callahan and Kevin Griggs
 */
import java.util.ArrayList;
import java.util.Random;

public class MySortedSetTiming {
	public static String generateString(Random rng, String characters,
			int length) {
		char[] text = new char[length];
		for (int i = 0; i < length; i++) {
			text[i] = characters.charAt(rng.nextInt(characters.length()));
		}
		return new String(text);
	}

	public static void main(String[] args) {
		int setSize = 2000000;
		ArrayList<String> testSet = new ArrayList<String>();
		for (int i = 0; i < setSize; i++) {
			testSet.add(generateString(new Random(), "0123456789", 5));
		}
		MySortedSet timingSet = new MySortedSet();
		timingSet.addAll(testSet);
		String generatedString = generateString(new Random(), "0123456789", 5);

		long startTime, midpointTime, stopTime;

		// First, spin computing stuff until one second has gone by.
		// This allows this thread to stabilize.

		startTime = System.nanoTime();
		while (System.nanoTime() - startTime < 1000000000) { // empty block
		}

		// Now, run the test.

		long timesToLoop = 10000;

		startTime = System.nanoTime();

		for (long i = 0; i < timesToLoop; i++)

			timingSet.contains(generatedString);

		midpointTime = System.nanoTime();

		// Run an empty loop to capture the cost of running the loop.

		for (long i = 0; i < timesToLoop; i++) { // empty block
		}

		stopTime = System.nanoTime();

		// Compute the time, subtract the cost of running the loop
		// from the cost of running the loop and computing square roots.
		// Average it over the number of runs.

		double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))
				/ timesToLoop;

		System.out.println("It takes exactly " + averageTime
				+ " nanoseconds to run the MySortedSet contains method "
				+ " numbers 1..10.");
	}
}
