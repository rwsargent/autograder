package assignment3;

// Authored by Joshua Callahan and Kevin Griggs

import static org.junit.Assert.*;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import assignment3.MySortedSet.MyIterator;

public class MySortedSetTest {

	private MySortedSet<String> set1 = new MySortedSet<String>();
	private ArrayList<String> set2;
	private MySortedSet<String> set3 = new MySortedSet<String>(new MyComp());
	private Iterator<String> myIt;

	@Before
	public void setUp() throws Exception {

		// Ten elements are added to set1
		set1.add("Z");
		set1.add("B");
		set1.add("A");
		set1.add("X");
		set1.add("F");
		set1.add("L");
		set1.add("Y");
		set1.add("N");
		set1.add("U");
		set1.add("T");

		// myIt is created to set an iterator for set 1
		myIt = set1.iterator();

		// set2 is created to test the addition of collections to set1
		set2 = new ArrayList<String>();
		set2.add("R");
		set2.add("Q");
		set2.add("S");
		set2.add("H");

		// set3 is created to test a set of objects that includes a custom
		// comparator.
		set3.add("mouse");
		set3.add("a");
		set3.add("elephant");
		set3.add("cat");

	}

	@After
	public void tearDown() throws Exception {
	}

	/**
	 * An 11th element is added to the array to make sure the size will change.
	 */
	@Test
	public void testSize() {
		assertEquals(10, set1.size());
		set1.add("W");
		assertEquals(11, set1.size());
	}

	/**
	 * Tests the add method
	 */
	@Test
	public void testAdd1() {
		assertTrue(set1.add("D"));
		assertTrue(set3.add("octupus"));
		assertTrue(set3.contains("octupus"));
	}

	/**
	 * Tests to ensure duplicate values are not added
	 */
	@Test
	public void testAddRepeat() {
		assertFalse(set1.add("Z"));
		assertFalse(set3.add("cat"));
	}

	/**
	 * Tests the toArray method
	 */
	@Test
	public void toArrayTest() {
		String[] set4 = new String[] { "A", "B", "F", "L", "N", "T", "U", "X",
				"Y", "Z" };
		for (int i = 0; i < set1.size(); i++) {
			assertEquals(set4[i], set1.toArray()[i]);
		}
	}

	/**
	 * Tests the contains method
	 */
	@Test
	public void testContains() {
		assertEquals(true, set1.contains("A"));
		assertEquals(true, set1.contains("B"));
		assertEquals(false, set1.contains("D"));
		assertEquals(true, set1.contains("L"));
		assertEquals(true, set1.contains("X"));
		assertEquals(false, set1.contains("P"));
		assertEquals(false, set1.contains("V"));

		assertTrue(set3.contains("mouse"));
		assertTrue(set3.contains("cat"));
		assertFalse(set3.contains("monkey"));
		assertTrue(set3.contains("mouse"));
	}

	/**
	 * Tests the remove method
	 */
	@Test
	public void testRemove() {
		assertEquals(10, set1.size());
		assertTrue(set1.remove("A"));
		assertEquals(9, set1.size());
		assertTrue(set1.remove("L"));
		set1.remove("Y");
		set1.remove("U");
		assertFalse(set1.contains("L"));
		assertFalse(set1.contains("Y"));
		assertFalse(set1.contains("U"));
		assertFalse(set1.remove("P"));
	}

	/**
	 * Tests the clear method
	 */
	@Test
	// Elements are added to set2 and then cleared.
	public void testClear() {
		set1.clear();
		assertEquals(0, set1.size());
		assertEquals(true, set1.isEmpty());

	}

	/**
	 * Tests the isEmpty method
	 */
	@Test
	public void testIsEmpty() {
		assertEquals(false, set1.isEmpty());
	}

	/**
	 * Tests the first and last methods
	 */
	@Test
	public void firstLastTest() {
		assertEquals("A", set1.first());
		assertEquals("Z", set1.last());
		assertEquals("a", set3.first());
		assertEquals("elephant", set3.last());

	}

	/**
	 * Tests the addAll method
	 */
	@Test
	public void addAllTest() {
		assertTrue(set1.addAll(set2));
		assertFalse(set1.addAll(set2));
	}

	/**
	 * Tests the containsAll method
	 */
	@Test
	public void containsAllTest() {
		set1.addAll(set2);
		assertTrue(set1.containsAll(set2));
	}

	/**
	 * Tests the removeAll method
	 */
	@Test
	public void removeAllTest() {
		set1.addAll(set2);
		assertTrue(set1.containsAll(set2));
		assertTrue(set1.removeAll(set2));
		assertFalse(set1.containsAll(set2));
	}

	/**
	 * Tests the Iterator methods
	 */
	@Test
	public void iteratorTest() {
		assertEquals("A", myIt.next());
		assertEquals("B", myIt.next());
		assertTrue(myIt.hasNext());
		myIt.next();
		myIt.next();
		myIt.next();
		myIt.next();
		myIt.next();
		myIt.next();
		myIt.next();
		myIt.next();
		assertFalse(myIt.hasNext());
	}

}
