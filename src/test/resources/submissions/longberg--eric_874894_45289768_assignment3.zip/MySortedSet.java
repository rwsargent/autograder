package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 * @author Eric Longberg, Derek Dixon
 *
 *         A set that is guaranteed to always be sorted.
 * @param <E>
 *            type of items this set has.
 */
public class MySortedSet<E> implements SortedSet<E>, Iterable<E> {

	private E[] data;
	private int size; // Space available within array
	private int elementCount; // Number of elements within array
	private Comparator<? super E> comparer;

	/**
	 * Sets up the MySortedSet. Assumed to use natural ordering.
	 */
	public MySortedSet() {
		size = 100;
		data = (E[]) new Object[size];
		comparer = null;
	}

	/**
	 * Sets up the MySortedSet for use with a given comparator.
	 * 
	 * @param c
	 *            comparator to be used with data.
	 */
	public MySortedSet(Comparator<? super E> c) {
		size = 100;
		data = (E[]) new Object[size];
		comparer = c;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator() {
		return comparer;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException {
		if (elementCount == 0)
			throw new NoSuchElementException();
		return data[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException {
		if (elementCount == 0)
			throw new NoSuchElementException();
		return data[elementCount - 1];
	}

	/**
	 * Inserts element at specified position, shifting all later values
	 * rightward.
	 * 
	 * @param element
	 * @param pos
	 */
	private void insert(E o, int pos) {
		elementCount++;
		// Two cases, need to grow and don't need to grow

		// case 1, don't need to grow
		if (elementCount < size) {
			E[] temp = (E[]) new Object[size];
			for (int i = 0; i < pos; i++) {
				temp[i] = data[i];
			}
			// add new element
			temp[pos] = (E) o;
			for (int i = pos + 1; i <= elementCount - 1; i++) {
				temp[i] = data[i - 1];
			}
			data = temp;
		}
		// case 2, do need to grow
		else {
			E[] temp = (E[]) new Object[size * 2];
			for (int i = 0; i < pos; i++) {
				temp[i] = data[i];
			}
			// add new element
			temp[pos] = (E) o;
			for (int i = pos + 1; i <= elementCount - 1; i++) {
				temp[i] = data[i - 1];
			}
			data = temp;
			size *= 2;
		}
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o) {
		if (elementCount == 0) {
			insert(o, 0);
			return true;
		}

		int right = elementCount - 1; // right endpoint
		int left = 0; // left endpoint
		int mid = (right + left) / 2; // current midpoint

		if (o instanceof Comparable && comparer == null) { // comparable ==
															// compareTo
			while (left <= right) {
				mid = (left + right) / 2;
				if (((Comparable<E>) o).compareTo(data[mid]) == 0) {
					// If already present
					return false;
				} else if (((Comparable<E>) o).compareTo(data[mid]) < 0) {
					// Want to insert somewhere to the left
					right = mid - 1;
				} else if (((Comparable<E>) o).compareTo(data[mid]) > 0) {
					// Want to insert somewhere to the right
					left = mid + 1;
				}
			}

			if (right < 0) {
				insert(o, 0);
			} else if (((Comparable<E>) o).compareTo(data[right]) > 0) {
				// above current highest
				// Insert at position (right + 1)
				insert(o, right + 1);

			} else {
				// below current highest
				// Insert at position (right)
				insert(o, right);
			}

		} else { // comparator == compare
			while (left <= right) {
				mid = (left + right) / 2;
				if (comparer.compare(o, data[mid]) == 0) {
					// If already present
					return false;
				} else if (comparer.compare(o, data[mid]) < 0) {
					// Want to insert somewhere to the left
					right = mid - 1;
				} else if (comparer.compare(o, data[mid]) > 0) {
					// Want to insert somewhere to the right
					left = mid + 1;
				}
			}
			if (right < 0) {
				insert(o, 0);
			} else if (comparer.compare(o, data[right]) > 0) {
				// above current highest
				// Insert at position (right + 1)
				insert(o, right + 1);

			} else {
				// below current highest
				// Insert at position (right)
				insert(o, right);
			}
		}

		return true;
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c) {
		boolean changed = false;
		for (E obj : c) {
			boolean dummy = add(obj);
			if (dummy == true) {
				changed = true;
			}
		}
		return changed;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear() {
		data = (E[]) new Object[size];
		elementCount = 0;
	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o) {

		int left = 0; // left endpoint
		int right = elementCount - 1; // right endpoint
		int mid = (left + right) / 2; // midpoint

		while (left <= right) {
			mid = (left + right) / 2;
			if (o instanceof Comparable && comparer == null) { // comparable
				if (((Comparable<E>) o).compareTo(data[mid]) == 0) {
					// If present
					return true;
				} else if (((Comparable<E>) o).compareTo(data[mid]) < 0) {
					// somewhere to the left
					right = mid - 1;
				} else if (((Comparable<E>) o).compareTo(data[mid]) > 0) {
					// somewhere to the right
					left = mid + 1;
				}

			} else { // comparator
				if (comparer.compare((E) o, data[mid]) == 0) {
					// If already present
					return true;
				} else if (comparer.compare((E) o, data[mid]) < 0) {
					// Want to insert somewhere to the left
					right = mid - 1;
				} else if (comparer.compare((E) o, data[mid]) > 0) {
					// Want to insert somewhere to the right
					left = mid + 1;
				}

			}
		}
		// not found
		return false;
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c) {
		for (Object obj : c) {
			boolean dummy = contains(obj);
			if (dummy == false) {
				return false;
			}
		}
		return true;
	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty() {
		if (elementCount == 0)
			return true;
		return false;
	}

	private class MySortedSetIterator<T> implements Iterator<T> {

		int pos = 0;

		/**
		 * Returns true if iterator has a next element.
		 */
		public boolean hasNext() {
			if (pos < elementCount) {
				return true;
			}
			return false;
		}

		/**
		 * Returns next element if one exists, otherwise throws
		 * NoSuchElementException.
		 */
		public T next() throws NoSuchElementException {
			if (!hasNext()) {
				throw new NoSuchElementException();
			}
			pos++;
			return (T) data[pos - 1];
		}

	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator() {
		return new MySortedSetIterator<E>();
	}

	/**
	 * Takes the element at the specified position out of the data, shifting
	 * everything right.
	 * 
	 * @param pos
	 */
	private void takeOut(int pos) {
		E[] temp = (E[]) new Object[size];
		for (int i = 0; i < pos; i++) {
			temp[i] = data[i];
		}
		for (int i = pos; i < elementCount; i++) {
			temp[i] = data[i + 1];
		}
		data = temp;
		elementCount--;
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o) {
		int left = 0; // left endpoint
		int right = elementCount - 1; // right endpoint
		int mid = (left + right) / 2; // midpoint

		while (left <= right) {
			mid = (left + right) / 2;
			if (o instanceof Comparable && comparer == null) { // comparable
				if (((Comparable<E>) o).compareTo(data[mid]) == 0) {
					// If present, remove
					takeOut(mid);
					return true;
				} else if (((Comparable<E>) o).compareTo(data[mid]) < 0) {
					// somewhere to the left
					right = mid - 1;
				} else if (((Comparable<E>) o).compareTo(data[mid]) > 0) {
					// somewhere to the right
					left = mid + 1;
				}

			} else { // comparator
				if (comparer.compare((E) o, data[mid]) == 0) {
					// If present, remove
					takeOut(mid);
					return true;
				} else if (comparer.compare((E) o, data[mid]) < 0) {
					// Want to insert somewhere to the left
					right = mid - 1;
				} else if (comparer.compare((E) o, data[mid]) > 0) {
					// Want to insert somewhere to the right
					left = mid + 1;
				}

			}
		}
		// not found
		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c) {
		boolean changed = false;
		for (Object obj : c) {
			boolean dummy = remove(obj);
			if (dummy == true) {
				changed = true;
			}
		}
		return changed;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size() {
		return elementCount;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray() {
		Object[] out = new Object[elementCount];
		for (int i = 0; i < elementCount; i++) {
			out[i] = data[i];
		}
		return out;
	}

	/**
	 * 
	 * @return String representation of data, in form [a0, a1, ..., an]
	 */
	public String toString() {
		String out = "[";
		for (int i = 0; i < elementCount; i++) {
			out += data[i];
			if (i < elementCount - 1) {
				out += ", ";
			}
		}
		out += "]";
		return out;
	}
}
