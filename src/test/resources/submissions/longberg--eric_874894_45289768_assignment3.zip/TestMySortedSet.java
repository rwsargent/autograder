package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * 
 * @author Eric Longberg, Derek Dixon
 * 
 *         Tests MySortedSet class. Any tests ending in 1 are testing with
 *         Integers and their default ordering, while any tests ending in 2 are
 *         testing Strings with a special Comparator ordering by length.
 *
 */
public class TestMySortedSet {

	MySortedSet<Integer> intSet;
	ArrayList<Integer> addMeInteger;

	MySortedSet<String> stringSet;
	OrderByLength stringComparator;
	ArrayList<String> addMeString;

	/**
	 * Comparator that defines an ordering among Strings using their length.
	 */
	private class OrderByLength implements Comparator<String> {

		/**
		 * Returns a negative value if lhs is shorter than rhs. Returns a
		 * positive value if lhs is longer than rhs. Returns 0 if lhs and rhs
		 * are equal in length (which is not allowed in these tests.
		 */
		public int compare(String lhs, String rhs) {
			return (lhs.length() - rhs.length());
		}
	}

	@Before
	public void setUp() throws Exception {
		intSet = new MySortedSet<Integer>();

		addMeInteger = new ArrayList<Integer>(6);
		addMeInteger.add(10);
		addMeInteger.add(-4);
		addMeInteger.add(30);
		addMeInteger.add(27);
		addMeInteger.add(100);
		addMeInteger.add(101);

		stringComparator = new OrderByLength();
		stringSet = new MySortedSet<String>(stringComparator);

		addMeString = new ArrayList<String>(8);
		addMeString.add("12");
		addMeString.add("a");
		addMeString.add("1234567");
		addMeString.add("654321");
		addMeString.add("hello");
		addMeString.add("cauchyriemann");
		addMeString.add("ccc");
		addMeString.add("Slutsky's Theorem");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAdd1() {
		intSet.add(5);
		intSet.add(8);
		intSet.add(7);
		intSet.add(-50);
		intSet.add(10);
		intSet.add(5);
		intSet.add(0);

		assertEquals("[-50, 0, 5, 7, 8, 10]", intSet.toString());
	}

	@Test
	public void testAdd2() {
		stringSet.add("aaaa");
		stringSet.add("bb");
		stringSet.add("fffff");
		stringSet.add("ddddddd");
		stringSet.add("fffff");

		assertEquals("[bb, aaaa, fffff, ddddddd]", stringSet.toString());
	}

	@Test
	public void testAddAll1() {
		intSet.addAll(addMeInteger);

		assertEquals("[-4, 10, 27, 30, 100, 101]", intSet.toString());
	}

	@Test
	public void testAddAll2() {
		stringSet.addAll(addMeString);

		assertEquals(
				"[a, 12, ccc, hello, 654321, 1234567, cauchyriemann, Slutsky's Theorem]",
				stringSet.toString());
	}

	@Test
	public void testClear1() {
		intSet.addAll(addMeInteger);
		intSet.clear();
		assertEquals("[]", intSet.toString());
		assertEquals(true, intSet.isEmpty());
	}

	@Test
	public void testClear2() {
		stringSet.addAll(addMeString);
		stringSet.clear();
		assertEquals("[]", stringSet.toString());
		assertEquals(true, stringSet.isEmpty());
	}

	@Test
	public void testContains1() {
		assertEquals(false, intSet.contains(1));
		intSet.add(1);
		assertEquals(true, intSet.contains(1));
	}

	@Test
	public void testContains2() {
		assertEquals(false, stringSet.contains("mememememe"));
		stringSet.add("mememememe");
		assertEquals(true, stringSet.contains("mememememe"));
	}

	@Test
	public void testContainsAll1() {
		intSet.add(10);
		intSet.addAll(addMeInteger);
		intSet.add(100);
		intSet.add(50000);
		intSet.add(3501);
		assertEquals(true, intSet.containsAll(addMeInteger));
	}

	@Test
	public void testContainsAll2() {
		stringSet.add("hello");
		stringSet.addAll(addMeString);
		stringSet.add("adfasdfsadfsdfsadfasdfasdfasfsaf");
		stringSet.add("c");
		stringSet.add("''''''''''''''");
		assertEquals(true, stringSet.containsAll(addMeString));
	}

	@Test
	public void testSize1() {
		intSet.addAll(addMeInteger);
		assertEquals(addMeInteger.size(), intSet.size());
	}

	@Test
	public void testSize2() {
		stringSet.addAll(addMeString);
		assertEquals(addMeString.size(), stringSet.size());
	}

	@Test
	public void testRemove1() {
		intSet.addAll(addMeInteger);
		intSet.remove(30);
		intSet.remove(-4);
		assertEquals("[10, 27, 100, 101]", intSet.toString());
	}

	@Test
	public void testRemove2() {
		stringSet.addAll(addMeString);
		stringSet.remove("b");
		assertEquals(
				"[12, ccc, hello, 654321, 1234567, cauchyriemann, Slutsky's Theorem]",
				stringSet.toString());
	}

	@Test
	public void testRemoveAll1() {
		intSet.add(325324);
		intSet.addAll(addMeInteger);
		intSet.removeAll(addMeInteger);
		assertEquals("[325324]", intSet.toString());
	}

	@Test
	public void testRemoveAll2() {
		stringSet.add("4 8 15 16 23 42");
		stringSet.addAll(addMeString);
		stringSet.removeAll(addMeString);
		assertEquals("[4 8 15 16 23 42]", stringSet.toString());
	}
}
