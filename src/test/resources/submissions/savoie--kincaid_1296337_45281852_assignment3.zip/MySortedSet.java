package assignment3;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Creates generic lists sorted either using natural ordering or a specified
 * comparator. The lists do not contain duplicates.
 * 
 * @author Kincaid Savoie
 * @author Tanner Martin
 *
 * @param <E> - The type of list to be created.
 */
public class MySortedSet<E> implements SortedSet<E>
{
	// Array containing the data.
	private E[] data;
	// The number of slots filled in the data array.
	private int size = 0;
	// Comparator provided to sort the set.
	private Comparator<? super E> comparator = null;

	/**
	 * If this constructor is used to create the sorted set, it is assumed that
	 * the elements are ordered using their natural ordering (i.e., E implements
	 * Comparable<? super E>).
	 */
	public MySortedSet()
	{
		// Initializes the array that will hold all our data.
		data = (E[]) new Object[10];
	}

	/**
	 * If this constructor is used to create the sorted set, it is assumed that
	 * the elements are ordered using the provided comparator.
	 * 
	 * @param comparator
	 */
	public MySortedSet(Comparator<? super E> comparator)
	{
		this();

		// Sets the comparator to the one specified.
		this.comparator = comparator;
	}

	/**
	 * @return The comparator used to order the elements in this set, or null if
	 *         this set uses the natural ordering of its elements (i.e., uses
	 *         Comparable).
	 */
	@Override
	public Comparator<? super E> comparator()
	{
		return comparator;
	}

	/**
	 * @return the first (lowest, smallest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E first() throws NoSuchElementException
	{
		return data[0];
	}

	/**
	 * @return the last (highest, largest) element currently in this set
	 * @throws NoSuchElementException
	 *             if the set is empty
	 */
	@Override
	public E last() throws NoSuchElementException
	{
		return data[size - 1];
	}

	/**
	 * Adds the specified element to this set if it is not already present and
	 * not set to null.
	 * 
	 * @param o
	 *            -- element to be added to this set
	 * @return true if this set did not already contain the specified element
	 */
	@Override
	public boolean add(E o)
	{
		// If there is nothing in data, set the first element in data to the
		// object and return true.
		if (data[0] == null)
		{
			data[0] = o;
			size++;
			return true;
		}

		// The index where the object should be inserted.
		int index = binarySearch(o);

		// If the data at the index is the same as the data we want to set it
		// to, return false and don't do anything.
		if (data[index] != null && compare(data[index], o) == 0)
		{
			return false;
		}

		// If the object contained at the index happens to be less than our
		// object, shift the index one to the right.
		if (data[index] != null && compare(data[index], o) < 0)
		{
			index++;
		}

		// Increase the size of the array.
		size++;

		// If the size of our new list is greater than the current size of the
		// array, double the size of the array.
		if (size > data.length)
		{
			E[] tempArray = (E[]) new Object[size * 2];

			// Copies all of the data before the index to the temporary array.
			for (int i = 0; i < index; i++)
			{
				tempArray[i] = data[i];
			}

			// Copies all of the data after the index to the temporary array,
			// shifting it one to the right.
			for (int i = index + 1; i < size; i++)
			{
				tempArray[i] = data[i - 1];
			}

			// Set the specified index of the array to the object.
			tempArray[index] = o;

			// Set our data to be the new array.
			data = tempArray;
			return true;
		}
		else
		{
			// Shifts the elements in the array to the left at the index
			for (int i = size - 1; i > index; i--)
			{
				data[i] = data[i - 1];
			}

			data[index] = o;

			return true;

		}
	}

	/**
	 * Adds all of the elements in the specified collection to this set if they
	 * are not already present and not set to null.
	 * 
	 * @param c
	 *            -- collection containing elements to be added to this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean addAll(Collection<? extends E> c)
	{
		boolean returnValue = false;

		// Adds everything in the collection to the list
		for (E o : c)
		{
			// sets the return value to true through our add() method
			returnValue = add(o);
		}
		return returnValue;
	}

	/**
	 * Removes all of the elements from this set. The set will be empty after
	 * this call returns.
	 */
	@Override
	public void clear()
	{
		// sets the size to 0
		size = 0;

		// sets data to a new empty array
		data = (E[]) new Object[10];

	}

	/**
	 * @param o
	 *            -- element whose presence in this set is to be tested
	 * @return true if this set contains the specified element
	 */
	@Override
	public boolean contains(Object o)
	{

		E object = (E) o;

		// finds index of the object
		int index = binarySearch(object);

		// compares the objects
		if (compare(data[index], object) == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * @param c
	 *            -- collection to be checked for containment in this set
	 * @return true if this set contains all of the elements of the specified
	 *         collection
	 */
	@Override
	public boolean containsAll(Collection<?> c)
	{
		// The value to be returned.
		boolean returnValue = true;

		// If nothing is in the given collection, return false.
		if (c.size() == 0)
		{
			return false;
		}

		// Check and see if any of the objects specified are not contained in
		// the set, and change the return value to false if they aren't.
		for (Object o : c)
		{
			returnValue = contains(o);
		}
		return returnValue;

	}

	/**
	 * @return true if this set contains no elements
	 */
	@Override
	public boolean isEmpty()
	{
		// checks if size is 0
		if (size == 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * @return an iterator over the elements in this set, where the elements are
	 *         returned in sorted (ascending) order
	 */
	@Override
	public Iterator<E> iterator()
	{
		return new MySortedSetIterator();
	}

	/**
	 * Removes the specified element from this set if it is present.
	 * 
	 * @param o
	 *            -- object to be removed from this set, if present
	 * @return true if this set contained the specified element
	 */
	@Override
	public boolean remove(Object o)
	{
		E object = (E) o;

		// finds the index of the object
		int index = binarySearch(object);

		// checks if the object at the index is the same in data
		if (compare(data[index], object) == 0)
		{
			// copies the elements of the array and shifts them to the left
			for (int i = index; i < size - 1; i++)
			{
				data[i] = data[i + 1];
			}

			size--;
			return true;
		}

		return false;
	}

	/**
	 * Removes from this set all of its elements that are contained in the
	 * specified collection.
	 * 
	 * @param c
	 *            -- collection containing elements to be removed from this set
	 * @return true if this set changed as a result of the call
	 */
	@Override
	public boolean removeAll(Collection<?> c)
	{
		boolean returnValue = false;

		// checks if the given Collection's size is empty
		if (c.size() == 0)
		{
			return false;
		}

		// removes all the objects in the collection
		for (Object o : c)
		{
			returnValue = remove(o);
		}
		return returnValue;
	}

	/**
	 * @return the number of elements in this set
	 */
	@Override
	public int size()
	{
		return size;
	}

	/**
	 * @return an array containing all of the elements in this set, in sorted
	 *         (ascending) order.
	 */
	@Override
	public Object[] toArray()
	{
		return Arrays.copyOf(data, size);
	}

	/**
	 * Performs a binary search on the given array using the specified
	 * comparator and returns the index of the specified object.
	 * 
	 * @param x
	 *            - the object to be searched for
	 * @return - the index of the object
	 */
	private int binarySearch(E x)
	{
		// The lower bound of the search.
		int low = 0;
		// The upper bound of the search.
		int high = size - 1;
		// The middle value of the search.
		int mid = 0;

		while (low < high)
		{
			// Set the middle bound between the upper and lower bounds.
			mid = (low + high) / 2;

			// If the object at the middle bound is less than the specified
			// object, move the lower bound up.
			if (this.compare(data[mid], x) < 0)
			{
				low = mid + 1;
			}
			// If the data is equal to or more than the specified object, set
			// the upper bound to the middle.
			else
			{
				high = mid;
			}
		}

		// If the value at the lower bound is equal to the specified object,
		// return the lower bound.
		if (this.compare(data[low], x) == 0)
		{
			return low;
		}

		// Return the value that is between the lower and upper bounds.
		return (low + high) / 2;
	}

	/**
	 * Compares two objects using either natural ordering or specified
	 * comparator.
	 * 
	 * @param x
	 *            - object to be compared
	 * @param y
	 *            - other object to be compared
	 * @return - -1 if the left object is less than the right one, 1 if the
	 *         right object is less than the left one, and 0 if the two objects
	 *         are equal.
	 */
	private int compare(E x, E y)
	{
		// If there is no comparator, use the natural ordering to do the
		// comparison, otherwise, use the specified comparator.
		if (comparator == null)
		{
			return ((Comparable<E>) x).compareTo(y);
		}
		else
		{
			return comparator.compare(x, y);
		}

	}

	class MySortedSetIterator implements Iterator
	{
		// The index where the iterator will begin
		int index = 0;

		// finds size of the Set
		int size = MySortedSet.this.size;

		/**
		 * Returns true if there is an item after the current index of the
		 * iterator
		 */
		@Override
		public boolean hasNext()
		{
			if (index < size)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/**
		 * Returns the item after the current index of the iterator
		 */
		@Override
		public Object next()
		{
			// if there is another item, increments the index and returns the
			// item at that index.
			if (hasNext())
			{
				index++;
				return MySortedSet.this.data[index - 1];
			}
			else
			{
				return null;
			}
		}
	}
}
