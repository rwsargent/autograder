package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * Suite of tests for the MySortedSet class.
 * 
 * NOTE: The iterator method is used for most of the tests checking ordering in
 * this class, so it does not require a separate method to test.
 * 
 * @author Kincaid Savoie
 * @author Tanner Martin
 *
 */
public class TestMySortedSet
{
	MySortedSet<Integer> testSet1;
	MySortedSet<String> testSet2;

	@Before
	public void setUp() throws Exception
	{
		testSet1 = new MySortedSet<Integer>();
		for (int i = 1; i < 15; i++)
		{
			testSet1.add(i);
		}

		testSet2 = new MySortedSet<String>();
		testSet2.add("b");
		testSet2.add("c");
		testSet2.add("e");
		testSet2.add("d");
		testSet2.add("a");

	}

	@After
	public void tearDown() throws Exception
	{
		testSet1 = null;
	}

	/**
	 * Tests the class's functionality regarding specified comparators.
	 */
	@Test
	public void testComparator()
	{
		// Creates a new set using the TestComparator and adds some items to it.
		TestComparator testComparator = new TestComparator();
		MySortedSet<Integer> testSetComparator = new MySortedSet<Integer>(
				testComparator);
		for (int i = 0; i < 15; i++)
		{
			testSetComparator.add(i);
		}
		testSetComparator.add(4);

		// Creates an iterator for testing.
		Iterator iterator = testSetComparator.iterator();

		// Checks to make sure the items in the set were ordered according to
		// the specified comparator.
		for (int i = 14; i > 0; i--)
		{
			assertEquals(i, (int) iterator.next());
		}

		// Ensures that the given iterator is returned by the comparator()
		// method.
		assertTrue(testSetComparator.comparator().equals(testComparator));
	}

	@Test
	public void testFirst()
	{
		// makes sure the first elements of the arrays are correct
		assertEquals(1, (int) testSet1.first());
		assertEquals("a", testSet2.first());
	}

	@Test
	public void testLast()
	{
		// makes sure the last elements of the arrays are correct
		assertEquals(14, (int) testSet1.last());
		assertEquals("e", testSet2.last());
	}

	@Test
	public void testAdd()
	{
		// Adds some duplicate numbers. to ensure no duplicates are added to the
		// set.
		testSet1.add(4);
		testSet1.add(5);

		// Checks if the set is ordered properly.
		Iterator<Integer> iterator = testSet1.iterator();
		for (int i = 1; i < 15; i++)
		{
			assertEquals(i, (int) iterator.next());
		}
		
		// Checks ordering for a set using non-primitive values.
		Iterator<String> iterator2 = testSet2.iterator();
		assertEquals("a", iterator2.next());
		assertEquals("b", iterator2.next());
		assertEquals("c", iterator2.next());
		assertEquals("d", iterator2.next());
		assertEquals("e", iterator2.next());

	}

	@Test
	public void testAddAll()
	{
		// initiates the list to be added
		ArrayList<Integer> addList = new ArrayList<Integer>();
		addList.add(15);
		addList.add(17);
		addList.add(16);
		addList.add(17);

		// adds the elements to testSet1
		testSet1.addAll(addList);

		// checks the index of testSet1
		Iterator<Integer> iterator = testSet1.iterator();
		for (int i = 1; i < 18; i++)
		{
			assertEquals(i, (int) iterator.next());
		}

		// testing addAll with non-primitive values
		ArrayList<String> addList2 = new ArrayList<String>();
		addList2.add("g");
		addList2.add("f");
		addList2.add("j");
		addList2.add("i");
		addList2.add("h");
		addList2.add("k");

		testSet2.addAll(addList2);

		// Tests ordering and insertion with non-primitive numbers.
		Iterator<String> iterator2 = testSet2.iterator();
		assertEquals("a", iterator2.next());
		assertEquals("b", iterator2.next());
		assertEquals("c", iterator2.next());
		assertEquals("d", iterator2.next());
		assertEquals("e", iterator2.next());
		assertEquals("f", iterator2.next());
		assertEquals("g", iterator2.next());
		assertEquals("h", iterator2.next());
		assertEquals("i", iterator2.next());
		assertEquals("j", iterator2.next());
		assertEquals("k", iterator2.next());

	}

	@Test
	public void testClear()
	{
		// clears all the elements in testSet1
		testSet1.clear();
		assertEquals(0, testSet1.toArray().length);
	}

	@Test
	public void testContains()
	{
		// tests elements that aren't in testSet1
		assertFalse(testSet1.contains(19));
		assertFalse(testSet1.contains(100));

		// tests elements that are in testSet1
		assertTrue(testSet1.contains(5));
		assertTrue(testSet1.contains(7));

		// tests the contains method with non-primitive values.

		// tests with values that aren't there
		assertFalse(testSet2.contains("z"));
		assertFalse(testSet2.contains("w"));

		// tests with values that are there.
		assertTrue(testSet2.contains("a"));
		assertTrue(testSet2.contains("c"));
		assertTrue(testSet2.contains("c"));
	}

	@Test
	public void testContainsAll()
	{
		// Tests with primitive values.

		// Tests with a list where none of the values are contained.
		ArrayList<Integer> falseList1 = new ArrayList<Integer>();
		falseList1.add(85);
		falseList1.add(675);
		falseList1.add(-1);

		assertFalse(testSet1.containsAll(falseList1));

		// Tests with a list where some of the values are contained.
		ArrayList<Integer> falseList2 = new ArrayList<Integer>();
		falseList2.add(1);
		falseList2.add(2);
		falseList2.add(5);
		falseList2.add(57489);

		assertFalse(testSet1.containsAll(falseList2));

		// Tests with a list where all of the values are contained.
		ArrayList<Integer> trueList = new ArrayList<Integer>();
		trueList.add(1);
		trueList.add(2);
		trueList.add(5);

		assertTrue(testSet1.containsAll(trueList));

		// Tests with non-primitive values

		// Tests with a list where none of the values are contained.
		ArrayList<String> falseList3 = new ArrayList<String>();
		falseList3.add("z");
		falseList3.add("y");
		falseList3.add("x");

		assertFalse(testSet1.containsAll(falseList1));

		// Tests with a list where some of the values are contained.
		ArrayList<String> falseList4 = new ArrayList<String>();
		falseList4.add("a");
		falseList4.add("z");
		falseList4.add("d");
		falseList4.add("p");

		assertFalse(testSet2.containsAll(falseList4));

		// Tests with a list where all of the values are contained.
		ArrayList<String> trueList2 = new ArrayList<String>();
		trueList2.add("a");
		trueList2.add("c");
		trueList2.add("e");

		assertTrue(testSet2.containsAll(trueList2));

	}

	@Test
	public void testIsEmpty()
	{
		// initiates an empty MySortedSet
		MySortedSet<Integer> testSetEmpty = new MySortedSet<Integer>();
		assertTrue(testSetEmpty.isEmpty());

		// adds something to the array to make sure it's not empty
		testSetEmpty.add(1);
		assertFalse(testSetEmpty.isEmpty());
	}

	@Test
	public void testRemove()
	{
		// removes an element from testSet1
		testSet1.remove(1);

		// ensures that the first elements of the set (1) was removed and
		// everything was shifted over correctly.
		Iterator<Integer> iterator = testSet1.iterator();
		for (int i = 2; i < 15; i++)
		{
			assertEquals(i, (int) iterator.next());
		}
	}

	@Test
	public void testRemoveAll()
	{
		// Initiates list for items to be removed
		ArrayList<Integer> removeList = new ArrayList<Integer>();
		removeList.add(1);
		removeList.add(2);
		removeList.add(14);

		// removes all the items
		testSet1.removeAll(removeList);

		// ensures that the items were removed and the list was shifted
		// accordingly.
		Iterator<Integer> iterator = testSet1.iterator();
		for (int i = 3; i < 14; i++)
		{
			assertEquals(i, (int) iterator.next());
		}
	}

	@Test
	public void testSize()
	{
		assertEquals(14, testSet1.size());
		assertEquals(5, testSet2.size());
	}

	@Test
	public void testToArray()
	{
		// Creates an array for comparison.
		Object[] resultArray = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 };

		// Compares our expected result array with the array generated by the
		// method we're testing.
		assertTrue(Arrays.deepEquals(resultArray, testSet1.toArray()));
	}

	/**
	 * A comparator that reverses the order of integers, to be used for testing
	 * the sorting abilities of the MySortedSet class.
	 * 
	 * @author Kincaid Savoie
	 * @author Tanner Martin
	 *
	 */
	class TestComparator implements Comparator<Integer>
	{

		@Override
		public int compare(Integer o1, Integer o2)
		{
			return o1.compareTo(o2) * -1;
		}

	}

}
