package assignment3;


import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 * @author Keanu Interone and Jeremy Anderson
 *
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E>{
	
	
	private Object [] arr;
	private int size; 
	private Comparator comp;//To be used if the constructor doesn't supply Comparable
	
	public MySortedSet()
	{ 
		arr = new Object[10];
		size = 0;
		comp = null;
	}
	
	public MySortedSet(Comparator<? super E> c)
	{
		this();
		comp = c;	
	}

	
	@Override
	public Comparator<? super E> comparator() {
		
		return comp;
	}

	
	@Override
	public E first() throws NoSuchElementException
	{
		if(size == 0)
			throw new NoSuchElementException();
		else
			return (E) arr[0];
	}

	@Override
	public E last() throws NoSuchElementException 
	{
		if(size == 0)
			throw new NoSuchElementException();
		else
			return (E) arr[size - 1];
	}

	@Override
	public boolean add(E o) 
	{
		if(size == 0)
		{
			size++;
			arr[0] = o;
			return true;
		}
		
		size++;
		if (size == arr.length)// If the new size is greater the the array. The array will double in length. 
		{
			Object[] temp = new Object[arr.length * 2];
			for(int i = 0; i < arr.length; i++)
				temp[i] = arr[i];
			arr = temp;
		}
		
		if(this.contains(o) || o == null)//Check to see if object is not in the list and isn't null
		{
			size--;
			return false;
		}
		
		binaryInsert(o); // insert object into the array
				
		return true;
	}

	@Override
	public boolean addAll(Collection<? extends E> c) 
	{
		
		int startingLength = size;//the size of the array before we add anything to compare at the end
		for (int i = 0; i < c.size(); i++)
		{
			E component = c.iterator().next();
			if (!(this.contains(component)) && component != null) //check if the component is in the array and it is not null
			{
				this.add(component);
			}
		}
		// if the starting length and the current size are the same, nothing was added and returns false
		if (startingLength == size)
			return false;
		return true;
	}

	@Override
	public void clear() //Create a new array of Objects of length 10
	{
		arr = (E[]) new Object[10];
		size = 0;	
	}

	@Override
	public boolean contains(Object o) 
	{
		int index = binarySearch(0, size - 1, (E) o); //position for where the object should go in the list
		if(arr[index] == o)//if the object already equals the object at that position, the list contains the object
			return true;
		else 
			return false;
	}

	@Override
	public boolean containsAll(Collection<?> c)  // Call the contains method for every object in the Collection and return true only if all object are found
	{
		int count = 0;
		for(int i = 0; i < c.size(); i++)
		{
			if(this.contains(c.iterator().next()))
			{
				count++;
				if(count == c.size()) // if we found all the items in c's list
					return true;
			}
		}
		return false;// if the array hasn't been changed return false
	}

	@Override
	public boolean isEmpty() //If the array is empty return true
	{
		return size == 0;
	}

	@Override
	public Iterator<E> iterator() 
	{
		return this.iterator();
	}

	@Override
	public boolean remove(Object o) 
	{
		
		if(!(this.contains(o)))//if the list doesn't contain the object return false
			return false;
		
		int index = this.binarySearch(0, size - 1, (E) o);//BinarySearch to find the index of the object to be removed
		
			
			for(int i = index; i < size; i++)//remove object given and shift all other objects over
			{
				arr[i] = arr[i + 1];
			}
			arr[size] = null;//Remove last object in array so we don't have any duplicates
			size--;
			return true;

	}

	@Override
	public boolean removeAll(Collection<?> c) // Use the remove method to remove all object is the given collection
	{
		
		int startingSize = size;
		for(int i = 0; i < c.size(); i++)
		{
			Object component = c.iterator().next();
			if(this.contains(component))//If the object is in the collection
				this.remove(component);//Remove the object, this call will also shift all objects in the array
		}
		if (startingSize == size)//If the array hasn't been changed return false
			return false;
		
		return true;	
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public Object[] toArray() 
	{
		E[] toArray = (E[]) new Object[size];
		for(int i = 0; i < size; i++)
			toArray[i] = (E) arr[i];
		return toArray;
	}
	
	/**
	 * Prints a string of this array
	 */
	public String toString() //this was mainly used to help us test
	{
		String array = "[";
		for(int i = 0; i < size; i++)
		{
			if (i == size -1)
				array = array + arr[i] + "]";
			else
				array = array + arr[i] + ", ";
		}
		return array;
		
	}
	
	/**
	 * 
	 * @param low
	 * @param high
	 * @param key
	 * @return index of where the item was found or where it should be inserted
	 */
	private int binarySearch (int low, int high, E key)
	{     
        if(comp == null)//if no comparator was initilized use comparable
        {
	        int mid;
	        
	        if (low == high)
	            return low;
        	        	
        	mid = low + ((high - low) / 2);	            
            	
            if (((Comparable<? super E>) key).compareTo((E) arr[mid]) > 0)
            	return binarySearch(mid + 1, high, key);
            else if (((Comparable<? super E>) key).compareTo((E) arr[mid]) < 0)
            	return binarySearch(low, mid, key);
             
            return mid;          	        
        }
        else
        {
	        int mid;
	        
	        if (low == high)
	            return low;
        	        	
        	mid = low + ((high - low) / 2);	            
            	
            if (comp.compare(key, arr[mid]) > 0)
            	return binarySearch(mid + 1, high, key);
            else if (comp.compare(key, arr[mid]) < 0)
            	return binarySearch(low, mid, key);
             
            return mid;
        }       
	}
	

	/**
	 * inserts the object o in the correct place in the array
	 * @param o
	 */
	private void binaryInsert(E o)
	{
		int insertIndex = binarySearch(0, size - 1, o);
		 for(int i = size; i > insertIndex; i--)
			 arr[i] = arr[i - 1];
		 arr[insertIndex] = o;
	}


}
