package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;



/**
 * 
 * @author Keanu Interone and Jeremy Anderson
 *
 * @param <E>
 */
public class MySortedSetTest {
	
	private Collection<Integer> collection = new ArrayList<Integer>();
	private Collection<String> stringCollection = new ArrayList<String>();
	private MySortedSet<String> MSSString;
	private MySortedSet<Integer> MSSInteger;

	@Before
	public void setUp() throws Exception 
	{
			
		for(int i = 20; i > 11; i--)
			collection.add(i);
		
		for(char i = 'z'; i > 'a'; i--)
			stringCollection.add(i + "");
		
		
		MSSString = new MySortedSet<String>();
		MSSString.add("this");
		MSSString.add("that");
		MSSString.add("test");
		MSSString.add("test2");
		MSSString.add("test3");
		MSSString.add("test4");
		
		
		
		MSSInteger = new MySortedSet<Integer>();
		MSSInteger.add(10);
		MSSInteger.add(1);
		MSSInteger.add(5);
		MSSInteger.add(3);
		MSSInteger.add(4);
		MSSInteger.add(7);



	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void firstTest ()
	{
		assertEquals((Integer)1, MSSInteger.first());
		assertEquals("test",MSSString.first());
		
	}

	
	@Test
	public void lastTest () 
	{	
		assertEquals((Integer)10, MSSInteger.last());
		assertEquals("this",MSSString.last());	
	}
	
	@Test
	public void sizeTest () 
	{	
		assertEquals(6, MSSInteger.size());
		assertEquals(6, MSSString.size());
	}
	
	@Test
	public void addTest () // see if the elements are ordered correctly when added 
	{
		assertEquals("[1, 3, 4, 5, 7, 10]", MSSInteger.toString());
		assertEquals("[test, test2, test3, test4, that, this]", MSSString.toString());

	}
	

	@Test
	public void addAllTest () // add the arraylist collecting and see if it contains all the items 
	{	
		assertEquals(true, MSSInteger.addAll(collection));
		assertEquals(true, MSSInteger.containsAll(collection));	
		assertEquals(true, MSSString.addAll(stringCollection));
		assertEquals(true, MSSString.containsAll(stringCollection));
	}
	
	@Test
	public void removeTest () // remove an item from the list and see if the list still contains it
	{
		assertEquals(true, MSSInteger.remove(10));
		assertEquals(false, MSSInteger.contains(10));
		assertEquals(true, MSSString.remove("this"));
		assertEquals(false, MSSString.contains("this"));
	}
	
	@Test
	public void removeAllTest () // add the collection in, then remove it, then see if some of items are still in the list 
	{
		MSSInteger.addAll(collection);
		assertEquals(true, MSSInteger.removeAll(collection));
		assertEquals(false, MSSInteger.contains(19));
		assertEquals(false, MSSInteger.contains(18));
		assertEquals(false, MSSInteger.contains(17)); // and so on...
		
		MSSString.addAll(stringCollection);
		assertEquals(true, MSSString.removeAll(stringCollection));
		assertEquals(false, MSSString.contains("z"));
		assertEquals(false, MSSString.contains("x"));
		assertEquals(false, MSSString.contains("y")); // and so on...
	}
	
	@Test
	public void containsTest () // see if the list contains the item 
	{	
		assertEquals(true, MSSInteger.contains(4));
		assertEquals(false, MSSInteger.contains(69));
		assertEquals(true, MSSString.contains("this"));
		assertEquals(false, MSSString.contains("sixty nine"));
	}
	
	@Test
	public void containsAllTest ()  
	{	
		assertEquals(false, MSSInteger.containsAll(collection));
		MSSInteger.addAll(collection);
		assertEquals(true, MSSInteger.containsAll(collection));
		
		assertEquals(false, MSSString.containsAll(stringCollection));
		MSSString.addAll(stringCollection);
		assertEquals(true, MSSString.containsAll(stringCollection));

	}
	
	@Test
	public void clearTest () // clear the list and see what its size;
	{	
		MSSInteger.clear();
		assertEquals(0, MSSInteger.size());
		MSSString.clear();
		assertEquals(0, MSSString.size());
	}
	
	@Test
	public void isEmptyTest () // see if they are empty before and after we clear the list 
	{	

	
		assertEquals(false, MSSInteger.isEmpty());
		assertEquals(false, MSSString.isEmpty());
		
		MSSInteger.clear();
		MSSString.clear();
		
		assertEquals(true, MSSInteger.isEmpty());
		assertEquals(true, MSSString.isEmpty());
		
	}
	
	
	
	

}
