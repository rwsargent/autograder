package assignment3;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * 
 * @author Boqian Yao and Yan Tan
 * 
 * @param <E>
 */
public class MySortedSet<E> implements SortedSet<E> {
	// set up variables.
	private Comparator<? super E> com;
	private int count;

	@SuppressWarnings("unchecked")
	private E[] list = (E[]) new Object[8];

	/**
	 * Constructor for natural ordering sorted set.
	 */
	public MySortedSet() {
		count = 0;
	}

	/**
	 * Constructor for using specific comparator
	 * 
	 * @param com
	 */
	public MySortedSet(Comparator<? super E> com) {
		this.com = com;
		count = 0;
	}

	@Override
	public Comparator<? super E> comparator() {

		return com;
	}

	@Override
	public E first() throws NoSuchElementException {
		// if set is empty, it has no first.
		if (count == 0) {
			throw new NoSuchElementException();
		}

		return list[0];
	}

	@Override
	public E last() throws NoSuchElementException {
		// if set is empty, it has no last.
		if (count == 0) {
			throw new NoSuchElementException();
		}
		return list[count - 1];
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean add(E o) {
		// if o is null, or it contains o, return false.
		if (o == null || contains(o) == true) {
			return false;
		}

		// if list has only one space left.
		if (count == list.length) {
			grow();
		}

		// if it's an empty list just add it.
		if (count == 0) {
			list[0] = o;
			count++;
			return true;
		}
		// get the location of o.
		int location = binarySearch(o);

		// if the location has no element, just add.
		if (location > count - 1) {
			list[location] = o;
			count++;
			return true;
		}

		// if the location already had an element,
		// move over, then add it.
		for (int i = count - 1; i >= location; i--) {
			list[i + 1] = list[i];
		}
		list[location] = o;
		count++;
		return true;
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {

		// Do not add if c is empty, return false.
		if (c.isEmpty()) {
			return false;
		}
		// create a new iterator
		Iterator<? extends E> i = c.iterator();

		// default result is false;
		boolean result = false;

		// Use iterator to loop through the set.
		while (i.hasNext()) {
			E e = i.next();

			// Add the elements that are not in set.
			if (!contains(e)) {
				add(e);
				// since we added it, result should be true.
				result = true;
			}
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void clear() {
		// reset the count of elements.
		count = 0;
		// create a variable to save the length.
		int length = list.length;
		// a new empty list with the same length.
		list = (E[]) new Object[length];
	}

	@Override
	public boolean contains(Object o) {

		// Return false if set is empty.
		if (o == null || count == 0)
			return false;

		// the index where o will be added after.
		int location = binarySearch((E) o);

		// if the correct location for object o already had an element.
		if (location < count) {

			// if list[location] is o, return true.
			if (list[location].equals(o)) {

				return true;
			}
		}
		// otherwise, return false.
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		// if c has more elements than this list return false.
		if (c.size() > count)
			return false;
		// new iterator.
		Iterator<?> i = c.iterator();
		// default result is true.
		boolean result = true;
		// if collection c has next element, keep looping.
		while (i.hasNext()) {
			@SuppressWarnings("unchecked")
			// new variable to save the current element
			E e = (E) i.next();
			// once list doesn't have this element, result is false.
			// and stop looping.
			if (!contains(e)) {
				result = false;
				break;
			}
		}
		return result;
	}

	@Override
	public boolean isEmpty() {
		if (count == 0)
			return true;
		else
			return false;
	}

	@Override
	public Iterator<E> iterator() {

		Iterator<E> i = new Iterator<E>() {
			int currentPosition = 0;
			E temp;

			@Override
			public boolean hasNext() {
				if (currentPosition < count - 1) {
					return true;
				}
				return false;
			}

			@Override
			public E next() {
				temp = list[0];
				currentPosition++;
				return temp;
			}

			@Override
			public void remove() {
			}

		};
		return i;
	}

	@Override
	public boolean remove(Object o) {

		// O is not found in set, return false.
		if (!contains(o))
			return false;

		//get the correct location for o.
		int location = binarySearch((E) o);

		 //start at the location of o. 
		// move the rest of elements 1 index forward.
		for (int i = location; i < count; i++) {
			list[i] = list[i + 1];
		}
		//decrease the element count.
		count--;
		return true;

	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean removeAll(Collection<?> c) {

		// The set is already empty.
		if (c.isEmpty() || count == 0)
			return false;

		boolean result = false;
		Iterator<?> i = c.iterator();
		
		//while c still has elements.
		while (i.hasNext()) {
			E e = (E) i.next();
			
			// if list has current element, remove it
			if (contains(e)) {
				remove(e);
				result = true;
			}
		}
		return result;
	}

	@Override
	public int size() {

		return count;
	}

	@Override
	public Object[] toArray() {
		//create a new array has the same size.
		Object[] arr = new Object[count];

		//loop through, and add every element to the array.
		for (int i = 0; i < count; i++) {
			arr[i] = list[i];
		}
		return arr;
	}

	/**
	 * 
	 * @param e
	 *            Object to be found or added. Return the index of o or to be
	 *            added.
	 */
	@SuppressWarnings("unchecked")
	private int binarySearch(E o) {
		int start = 0;
		int end = count - 1;
		int mid;
		int position = 0;

		// Natural ordering set.
		if (com != null) {
			while (start <= end) {
				mid = (start + end) / 2;

				// Compare mid and o, narrow down the range where o is or to be
				// added.
				if (com.compare(o, list[mid]) > 0) {
					start = mid + 1;
					position = start;
				}
				if (com.compare(o, list[mid]) < 0) {
					end = mid - 1;
					position = mid;
				}
				// O is found or the element before o after added is found.
				if (com.compare(o, list[mid]) == 0) {
					return mid;
				}
			}
		} else {

			// Set with specified comparator.
			Comparable<? super E> e = (Comparable<? super E>) o;
			
			while (start <= end) {
				mid = (start + end) / 2;

				// Compare mid and o, narrow down the range where o is or to be
				// added.
				if (e.compareTo(list[mid]) > 0) {
					start = mid + 1;
					position = start;
				}
				if (e.compareTo(list[mid]) < 0) {
					end = mid - 1;
					position = mid;
				}

				// O is found or the element before o after added is found.
				if (e.compareTo(list[mid]) == 0) {
					return mid;
				}
			}
		}
		return position;
	}

	/**
	 * Double the size of array when the set is full.
	 */
	@SuppressWarnings("unchecked")
	private void grow() {

		// Create an empty new array to store list.
		E[] temp = (E[]) new Object[list.length];
		temp = list;
		int length = list.length;

		// Double the length.
		list = (E[]) new Object[length * 2];

		// Copy over back to list.
		for (int i = 0; i < count; i++)
			list[i] = temp[i];
	}
}
