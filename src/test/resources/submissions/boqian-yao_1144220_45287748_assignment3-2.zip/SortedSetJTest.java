package assignment3;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;
/**This is a test class.
 * 
 * @author Boqian Yao and Yan Tan
 *
 */
public class SortedSetJTest {
	private MySortedSet<Integer> s1 = new MySortedSet<Integer>();
	private MySortedSet<Integer> s2  = new MySortedSet<Integer>();
	private MySortedSet<Integer> s3 = new MySortedSet<Integer>();
	private MySortedSet<Integer> correctS3  = new MySortedSet<Integer>();
	private MySortedSet<Integer> s4 = new MySortedSet<Integer>();
	private MySortedSet<Integer> s5 = new MySortedSet<Integer>();
	private MySortedSet<Integer> setForContainsAll = new MySortedSet<Integer>();
	private MySortedSet<Integer> setForClear = new MySortedSet<Integer>();
	private MySortedSet<Integer> setForRemove = new MySortedSet<Integer>();
	private MySortedSet<Integer> setForRemoveAll = new MySortedSet<Integer>();
	
	private ArrayList<Integer> al = new ArrayList<Integer>();
	private ArrayList<String> stringAl = new ArrayList<String>();
	
	DescendingAlphabetOrder comparator = new DescendingAlphabetOrder();
	
	private MySortedSet<String> emptyStr = new MySortedSet<String>(comparator);
	private MySortedSet<String> str1 = new MySortedSet<String>(comparator);
	private MySortedSet<String> str2 = new MySortedSet<String>(comparator);

	@Before
	public void setUp() throws Exception {
		// S2 contains 1 element.
		s2.add(0);
		
		// Add 49 to 0 into s3.
		for (int i = 49; i >= 0; i--) {
			s3.add(i);
		}
		
		
		for(int i = 0; i < 50; i++) {
			// The final expected sorted set for s3, setForClear, setForRemove.
			correctS3.add(i);
			setForClear.add(i);
			setForRemove.add(i);
		}
		
		// Implement the ArrayList for addAll, containsAll, removeAll methods.
		al.add(0);
		al.add(1);
		
		// Implement a set that only has one element from ArrayList al.
		setForContainsAll.add(100);
		setForRemoveAll.add(100);
		setForContainsAll.add(0);
		
		// Implement several elements to str1.
		str1.add("apple");
		str1.add("banana");
		str1.add("cherry");
		str1.add("grapes");
		
		stringAl.add("avocado");
		stringAl.add("kiwi");
		stringAl.add("lemon");
		
		str2.add("avocado");
		
	}

	@Test
	public void testAdd01() {
		//A new set's size should be 0.
		assertEquals( 0, s1.size());
	}

	@Test
	public void testAdd02() {
		//Add one element,size should be 1.
		assertEquals(1, s2.size());
	}

	@Test
	public void testAdd03() {
		
		// Add 50 element,size should be 50.
		assertEquals(50, s3.size());
		
	}
	
	@Test
	public void testAdd03ElementCheck() {
		// Cast to array to check every element in the set.
		Object[] arrS3 = new Object[50];
		Object[] arrCorrectS3 = new Object[50];
		arrS3 =  s3.toArray();
		arrCorrectS3 = correctS3.toArray();
		
		for (int i = 0; i < s3.size(); i++) {
			assertEquals(true, arrS3[i].equals(arrCorrectS3[i]));
		}
	}
	
	@Test
	public void testAddStr1ElementCheck() {
		// Cast to array to check every element in the set.
		Object[] arrStr1 = new Object[4];
		arrStr1 = str1.toArray();
		assertEquals("grapes", arrStr1[0]);
		assertEquals("cherry", arrStr1[1]);
		assertEquals("banana", arrStr1[2]);
		assertEquals("apple", arrStr1[3]);
	}
	
	@Test
	public void testAdd04() {
		
		for (int i = 0; i < 10; i++) {
			assertEquals(false, s3.add(i));
		}
		// "Add 60 element(10 duplicate),size should be 50.
		assertEquals(50, s3.size());
	}
	
	
	@Test
	public void testFirstAndLast01() {
           s4.add(2);
           s4.add(6);
           s4.add(0);
           s4.add(4); 
           s4.add(3);
           
        // Check first() and last() with a regular set.
        assertEquals(0, (int)s4.first());
        assertEquals(6, (int)s4.last());
	}
	
	@Test
	public void testFirstAndLast02() {
		
		// Check these two methods with set that contains only one element.
		assertEquals(0, (int)s2.first());
		assertEquals(0, (int)s2.last());
	}
	
	@Test(expected=NoSuchElementException.class)
	public void testFirstAndLast03() {
		
		// Expecting exception.
		s1.first();
	}
	
	@Test(expected=NoSuchElementException.class)
	public void testFirstAndLast04() {
		
		// Expecting exception.
		s1.last();
	}
	
	@Test
	public void testFirstAndLast05() {
		assertEquals("grapes", (String) str1.first());
		assertEquals("apple", (String) str1.last());
	}
	
	
	@Test
	public void testAddAll01() {
		
		// Add al to an empty set s5.
		assertEquals(true, s5.addAll(al));
		assertEquals(2, s5.size());
	}
	
	
	@Test
	public void testAddAll02() {
		
		// Add al to a set contains 1 element of al.
		assertEquals(true, s2.addAll(al));
		assertEquals(2, s2.size());
	}
	
	@Test
	public void testAddAll03() {
		// Add al to a set contains all elements of al.
		assertEquals(false, s3.addAll(al));
	}
	
	@Test
	public void testAddAll04() {
		// Add stringAl to a set does not contain any elements of stringAl.
		assertEquals(true, str1.addAll(stringAl));
		assertEquals(7, str1.size());
	}
	
	@Test
	public void testClear01() {
		
		//Clear an empty set.
		s1.clear();
		assertEquals(0, s1.size());
	}
	
	@Test
	public void testClear02() {
		
		// Clear an array with size of 50.
		setForClear.clear();
		assertEquals(0, setForClear.size());
	}
	
	@Test
	public void testClear03() {
		str2.clear();
		assertEquals(0, str2.size());
	}
	
	@Test
	public void testContains01() {
		
		// Test contains() with empty set.
		assertEquals(false, s1.contains(5));
	}
	
	@Test
	public void testContains02() {
		
		// Test contains() with a set that does not contain the specified element.
		assertEquals(false, s2.contains(1));
	}
	
	@Test
	public void testContains03() {
		
		// Test contains() with a set that contains the specified element.
		assertEquals(true, s2.contains(0));
	}
	
	@Test
	public void testContains04() {
		assertEquals(true, str1.contains("banana"));

	}
	
	@Test
	public void testContainsAll01() {
		
		// Test with a set that contains all elements in al.
		assertEquals(true, s3.containsAll(al));
	}
	
	@Test
	public void testContainsAll02() {
		
		// Test with a empty set.
		assertEquals(false, s1.contains(al));
	}
	
	@Test
	public void testContainsAll03() {
		
		// Test with a set contains 1 element of al.
		assertEquals(false, setForContainsAll.containsAll(al));
	}
	
	@Test
	public void testContainsAll04() {
		assertEquals(false, str1.containsAll(stringAl));
	}
	
	@Test
	public void testIsEmpty01() {
		
		// Test with an empty set.
		assertEquals(true, s1.isEmpty());
	}
	
	@Test
	public void testIsEmpty02() {
		
		// Test with a set that is not empty.
		assertEquals(false, s2.isEmpty());
	}
	
	@Test
	public void testIsEmpty03() {
		assertEquals(false, str1.isEmpty());
	}
	
	@Test
	public void testRemove01() {
		
		// Test to remove an element from an empty set.
		assertEquals(false, s1.remove(1));
		assertEquals(0, s1.size());
	}
	
	@Test
	public void testRemove02() {
		
		// Test to remove an element which set does not contain.
		assertEquals(false, s2.remove(3));
		assertEquals(1, s2.size());
	}
	
	@Test
	public void testRemove03() {
		
		// Test to remove an element which set does contain.
		assertEquals(true, setForRemove.remove(1));
		assertEquals(49, setForRemove.size());
	}
	
	@Test
	public void testRemove04() {
		assertEquals(false, str1.remove("kiwi"));
	}
	
	@Test
	public void testRemoveAll01() {
		
		// Test with a set that contains all elements in al.
		assertEquals(true, setForRemove.removeAll(al));
	}
	
	@Test
	public void testRemoveAll02() {
		
		// Test with an empty set.
		assertEquals(false, s1.removeAll(al));
	}
	
	@Test
	public void testRemoveAll03() {
		assertEquals(true, setForContainsAll.removeAll(al));
		assertEquals(1, setForContainsAll.size());
	}
	
	@Test
	public void testRemoveAll04() {
		assertEquals(false, setForRemoveAll.removeAll(al));
		assertEquals(1, setForRemoveAll.size());
	}
	
	@Test
	public void testRemoveAll05() {
		assertEquals(true, str2.removeAll(stringAl));
	}
	
	
	protected class DescendingAlphabetOrder implements
	Comparator<String> {

		public int compare(String s1, String s2) {
			if (s1.compareToIgnoreCase(s2) < 0) {
				return 1;
			}
			if (s1.compareToIgnoreCase(s2) == 0) {
				return 0;
			}
			return -1;
		}
		
	}
	
}
