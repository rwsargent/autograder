package assignment01;

public class File1 {
    public int x;
    public in y;

    public File1(int x, int y) {
	this.x = x;
	this.y = y;
    }

    public String toString() {
	return "x: " + this.x + "\n" + "y: " + this.y;
    }
}
