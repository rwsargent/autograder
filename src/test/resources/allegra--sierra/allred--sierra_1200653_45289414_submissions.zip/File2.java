package assignment01;

public class File2 {
    public String name;
    public File2(String name) {
	this.name = name;
    }

    public String toString() {
	return this.name;
    }
}
